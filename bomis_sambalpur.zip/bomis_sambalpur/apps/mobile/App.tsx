/**
 * App.tsx - Master Entrypoint for BOMIS Sambalpur Mobile Application
 * Conforms to Master Implementation Blueprint: Milestone M5 (React Native Expo SDK 51).
 * Wires AuthProvider, ParentProvider, multi-role dynamic view routing,
 * global offline sync status banner, and quick role evaluation switcher.
 */

import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  SafeAreaView,
  Text,
  TouchableOpacity,
  Modal,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { UserRole } from '@bomis/shared';

// Context Providers
import { AuthProvider, useAuth } from './src/state/auth-context';
import { ParentProvider } from './src/state/parent-context';

// UI Primitives
import { BOMISHeader } from './src/components/ui/BOMISHeader';
import { BOMISBadge } from './src/components/ui/BOMISBadge';
import { BOMISButton } from './src/components/ui/BOMISButton';

// Role Screens
import { AuthScreen } from './src/screens/AuthScreen';
import { ParentScreen } from './src/screens/ParentScreen';
import { StudentScreen } from './src/screens/StudentScreen';
import { TeacherScreen } from './src/screens/TeacherScreen';
import { DriverScreen } from './src/screens/DriverScreen';

// Sync Engine
import { defaultSyncManager } from './src/services/sync-manager';
import { SyncStats } from './src/services/outbox-queue';

const MainNavigation: React.FC = () => {
  const { user, role, isAuthenticated, logout, loginWithPreset } = useAuth();
  const [showRoleModal, setShowRoleModal] = useState<boolean>(false);
  const [syncStats, setSyncStats] = useState<SyncStats>({
    pendingCount: 0,
    syncingCount: 0,
    syncedCount: 0,
    failedCount: 0,
    isOnline: true,
    lastSyncAt: null,
  });

  // Subscribe to outbox sync status
  useEffect(() => {
    const unsub = defaultSyncManager.subscribeStats((stats) => {
      setSyncStats(stats);
    });
    return unsub;
  }, []);

  if (!isAuthenticated || !role || !user) {
    return <AuthScreen />;
  }

  const renderActiveScreen = () => {
    switch (role) {
      case UserRole.PARENT:
        return <ParentScreen />;
      case UserRole.STUDENT:
        return <StudentScreen />;
      case UserRole.TEACHER:
        return <TeacherScreen />;
      case UserRole.TRANSPORT_STAFF:
      case 'DRIVER_TRANSPORT' as any:
        return <DriverScreen />;
      default:
        return <ParentScreen />;
    }
  };

  return (
    <View style={styles.root}>
      <BOMISHeader
        userName={`${user.firstName} ${user.lastName}`}
        role={role}
        onLogout={logout}
        onSwitchRole={() => setShowRoleModal(true)}
      />

      {/* Global Offline Sync Banner */}
      {(!syncStats.isOnline || syncStats.pendingCount > 0) && (
        <View style={styles.globalSyncBanner}>
          <View style={styles.syncLeft}>
            <View
              style={[
                styles.syncDot,
                { backgroundColor: syncStats.isOnline ? '#F59E0B' : '#EF4444' },
              ]}
            />
            <Text style={styles.syncText}>
              {!syncStats.isOnline
                ? `Offline • ${syncStats.pendingCount} mutation(s) buffered in outbox`
                : `${syncStats.pendingCount} pending mutation(s) awaiting sync`}
            </Text>
          </View>
          {syncStats.isOnline && syncStats.pendingCount > 0 && (
            <TouchableOpacity
              style={styles.syncTrigger}
              onPress={() => defaultSyncManager.syncPending()}
            >
              <Text style={styles.syncTriggerText}>Sync Now</Text>
            </TouchableOpacity>
          )}
        </View>
      )}

      {/* Screen Body */}
      <View style={styles.screenContainer}>{renderActiveScreen()}</View>

      {/* Role Switcher Evaluation Modal */}
      <Modal visible={showRoleModal} transparent animationType="fade">
        <View style={styles.modalBackdrop}>
          <View style={styles.modalContent}>
            <Text style={styles.modalHeader}>Switch Persona Role</Text>
            <Text style={styles.modalSub}>
              Instantly toggle between verified seed personas for multi-role evaluation
            </Text>

            <View style={styles.roleList}>
              <TouchableOpacity
                style={[styles.roleOption, role === UserRole.PARENT && styles.roleOptionActive]}
                onPress={() => {
                  loginWithPreset('PARENT');
                  setShowRoleModal(false);
                }}
              >
                <BOMISBadge label="PARENT" variant={UserRole.PARENT} size="sm" />
                <View style={{ marginLeft: 10 }}>
                  <Text style={styles.roleName}>Dr. Rajesh Kumar Patel</Text>
                  <Text style={styles.roleMeta}>2 Siblings (Aarav & Ananya) • Bus Sakhipada Stop</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.roleOption, role === UserRole.STUDENT && styles.roleOptionActive]}
                onPress={() => {
                  loginWithPreset('STUDENT');
                  setShowRoleModal(false);
                }}
              >
                <BOMISBadge label="STUDENT" variant={UserRole.STUDENT} size="sm" />
                <View style={{ marginLeft: 10 }}>
                  <Text style={styles.roleName}>Aarav Patel</Text>
                  <Text style={styles.roleMeta}>Grade 5A • Kalinga House • Bus 01 Pass</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.roleOption, role === UserRole.TEACHER && styles.roleOptionActive]}
                onPress={() => {
                  loginWithPreset('TEACHER');
                  setShowRoleModal(false);
                }}
              >
                <BOMISBadge label="TEACHER" variant={UserRole.TEACHER} size="sm" />
                <View style={{ marginLeft: 10 }}>
                  <Text style={styles.roleName}>Mrs. Arundhati Dash</Text>
                  <Text style={styles.roleMeta}>Class Teacher 5A • Rapid Attendance & Homework</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.roleOption, role === UserRole.TRANSPORT_STAFF && styles.roleOptionActive]}
                onPress={() => {
                  loginWithPreset('DRIVER');
                  setShowRoleModal(false);
                }}
              >
                <BOMISBadge label="DRIVER" variant={UserRole.TRANSPORT_STAFF} size="sm" />
                <View style={{ marginLeft: 10 }}>
                  <Text style={styles.roleName}>Maheswar Bhoi</Text>
                  <Text style={styles.roleMeta}>Pilot Bus 01 • Budharaja Shuttle Navigation</Text>
                </View>
              </TouchableOpacity>
            </View>

            <BOMISButton
              title="Close"
              onPress={() => setShowRoleModal(false)}
              variant="outline"
              size="sm"
              style={{ marginTop: 14 }}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <ParentProvider>
        <SafeAreaView style={styles.safeContainer}>
          <StatusBar style="light" backgroundColor="#0F2942" />
          <MainNavigation />
        </SafeAreaView>
      </ParentProvider>
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: '#0F2942',
  },
  root: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  globalSyncBanner: {
    backgroundColor: '#071726',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#1A3A5C',
  },
  syncLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  syncDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  syncText: {
    color: '#D2E3F0',
    fontSize: 11,
    fontWeight: '600',
  },
  syncTrigger: {
    backgroundColor: '#FF6B4A',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  syncTriggerText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
  },
  screenContainer: {
    flex: 1,
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(15, 41, 66, 0.75)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    width: '100%',
    maxWidth: 380,
  },
  modalHeader: {
    fontSize: 18,
    fontWeight: '800',
    color: '#0F2942',
    textAlign: 'center',
  },
  modalSub: {
    fontSize: 12,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 4,
    marginBottom: 16,
  },
  roleList: {
    gap: 10,
  },
  roleOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    backgroundColor: '#F8FAFC',
  },
  roleOptionActive: {
    borderColor: '#FF6B4A',
    backgroundColor: '#FFF5F2',
  },
  roleName: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A',
  },
  roleMeta: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 2,
  },
});
