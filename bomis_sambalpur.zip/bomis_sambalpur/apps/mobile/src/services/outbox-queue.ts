/**
 * Offline Outbox Queue Repository
 * Conforms to ADR 0004: Durable local queue with idempotency keys and retry metadata.
 */

import { IStorageAdapter, defaultStorage } from './storage-adapter';

export type SyncActionType = 'ATTENDANCE_BATCH' | 'BOARDING_SCAN' | 'GPS_PING';
export type SyncItemStatus = 'PENDING' | 'SYNCING' | 'SYNCED' | 'FAILED';

export interface OutboxItem<T = unknown> {
  id: string; // client event uuid
  actionType: SyncActionType;
  idempotencyKey: string; // idem_<actionType>_<id>
  timestamp: number; // epoch ms
  payload: T;
  status: SyncItemStatus;
  retryCount: number;
  maxRetries: number;
  lastAttemptAt?: number;
  lastError?: string;
}

export interface SyncStats {
  pendingCount: number;
  syncingCount: number;
  syncedCount: number;
  failedCount: number;
  isOnline: boolean;
  lastSyncAt: number | null;
}

const OUTBOX_STORAGE_KEY = 'bomis:sync:outbox:v1';

export class OutboxRepository {
  constructor(private storage: IStorageAdapter = defaultStorage) {}

  async getAll(): Promise<OutboxItem[]> {
    const raw = await this.storage.getItem(OUTBOX_STORAGE_KEY);
    if (!raw) return [];
    try {
      return JSON.parse(raw) as OutboxItem[];
    } catch {
      return [];
    }
  }

  async saveAll(items: OutboxItem[]): Promise<void> {
    await this.storage.setItem(OUTBOX_STORAGE_KEY, JSON.stringify(items));
  }

  async enqueue<T>(actionType: SyncActionType, payload: T): Promise<OutboxItem<T>> {
    const items = await this.getAll();
    const id = `evt_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const idempotencyKey = `idem_${actionType}_${id}`;

    const newItem: OutboxItem<T> = {
      id,
      actionType,
      idempotencyKey,
      timestamp: Date.now(),
      payload,
      status: 'PENDING',
      retryCount: 0,
      maxRetries: 5,
    };

    items.push(newItem);
    await this.saveAll(items);
    return newItem;
  }

  async markStatus(ids: string[], status: SyncItemStatus, error?: string): Promise<void> {
    const items = await this.getAll();
    const updated = items.map((item) => {
      if (ids.includes(item.id)) {
        return {
          ...item,
          status,
          lastAttemptAt: Date.now(),
          retryCount: status === 'FAILED' ? item.retryCount + 1 : item.retryCount,
          lastError: error !== undefined ? error : item.lastError,
        };
      }
      return item;
    });
    await this.saveAll(updated);
  }

  async purgeCompleted(olderThanMs: number = 86400000): Promise<number> {
    const items = await this.getAll();
    const cutoff = Date.now() - olderThanMs;
    const remaining = items.filter(
      (item) => !(item.status === 'SYNCED' && item.timestamp < cutoff)
    );
    const purgedCount = items.length - remaining.length;
    if (purgedCount > 0) {
      await this.saveAll(remaining);
    }
    return purgedCount;
  }

  async clear(): Promise<void> {
    await this.storage.removeItem(OUTBOX_STORAGE_KEY);
  }

  async getPendingCount(): Promise<number> {
    const items = await this.getAll();
    return items.filter((i) => i.status === 'PENDING' || i.status === 'FAILED').length;
  }
}

export const defaultOutbox = new OutboxRepository();
