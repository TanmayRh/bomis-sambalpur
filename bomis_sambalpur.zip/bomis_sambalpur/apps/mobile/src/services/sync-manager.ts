/**
 * Offline Sync Manager Engine
 * Conforms to ADR 0004 & POST /api/v1/sync/batch
 * Handles network connectivity tracking, outbox queue draining, and idempotent deduplication.
 */

import { OutboxRepository, OutboxItem, SyncActionType, SyncStats, defaultOutbox } from './outbox-queue';
import { MobileApiClient, defaultApiClient } from './api-client';

export type NetworkListener = (isOnline: boolean) => void;

export class NetworkMonitor {
  private online: boolean = true;
  private listeners: Set<NetworkListener> = new Set();

  constructor() {
    if (typeof window !== 'undefined') {
      this.online = typeof navigator !== 'undefined' ? navigator.onLine ?? true : true;
      window.addEventListener('online', () => this.setOnline(true));
      window.addEventListener('offline', () => this.setOnline(false));
    }
  }

  public isOnline(): boolean {
    return this.online;
  }

  public setOnline(state: boolean): void {
    if (this.online !== state) {
      this.online = state;
      this.listeners.forEach((l) => l(state));
    }
  }

  public subscribe(listener: NetworkListener): () => void {
    this.listeners.add(listener);
    listener(this.online);
    return () => this.listeners.delete(listener);
  }

  public destroy(): void {
    this.listeners.clear();
  }
}

export interface SyncBatchResult {
  syncedCount: number;
  results: Array<{ id: string; status: 'SYNCED' | 'IDEMPOTENT_SKIPPED' | 'FAILED' }>;
}

export class SyncManager {
  private isSyncing = false;
  private statsListeners: Set<(stats: SyncStats) => void> = new Set();
  private lastSyncAt: number | null = null;

  constructor(
    private repository: OutboxRepository = defaultOutbox,
    private network: NetworkMonitor = new NetworkMonitor(),
    private apiClient: MobileApiClient = defaultApiClient
  ) {
    this.network.subscribe((isOnline) => {
      if (isOnline) {
        this.syncPending().catch(() => {});
      }
      this.notifyStats();
    });
  }

  public getNetworkMonitor(): NetworkMonitor {
    return this.network;
  }

  public getRepository(): OutboxRepository {
    return this.repository;
  }

  public subscribeStats(listener: (stats: SyncStats) => void): () => void {
    this.statsListeners.add(listener);
    this.notifyStats();
    return () => this.statsListeners.delete(listener);
  }

  public async getStats(): Promise<SyncStats> {
    const items = await this.repository.getAll();
    return {
      pendingCount: items.filter((i) => i.status === 'PENDING').length,
      syncingCount: items.filter((i) => i.status === 'SYNCING').length,
      syncedCount: items.filter((i) => i.status === 'SYNCED').length,
      failedCount: items.filter((i) => i.status === 'FAILED').length,
      isOnline: this.network.isOnline(),
      lastSyncAt: this.lastSyncAt,
    };
  }

  private async notifyStats(): Promise<void> {
    const stats = await this.getStats();
    this.statsListeners.forEach((l) => l(stats));
  }

  /**
   * Enqueue mutation into local durable outbox and trigger sync if connected
   */
  public async enqueueMutation<T>(actionType: SyncActionType, payload: T): Promise<OutboxItem<T>> {
    const item = await this.repository.enqueue(actionType, payload);
    await this.notifyStats();
    if (this.network.isOnline()) {
      this.syncPending().catch(() => {});
    }
    return item;
  }

  /**
   * Batch drains pending items to POST /api/v1/sync/batch
   */
  public async syncPending(batchSize: number = 25): Promise<SyncBatchResult | null> {
    if (this.isSyncing || !this.network.isOnline()) {
      return null;
    }

    this.isSyncing = true;
    try {
      const items = await this.repository.getAll();
      const eligible = items.filter(
        (i) => i.status === 'PENDING' || (i.status === 'FAILED' && i.retryCount < i.maxRetries)
      );

      if (eligible.length === 0) {
        return null;
      }

      const batch = eligible.slice(0, batchSize);
      const batchIds = batch.map((b) => b.id);

      await this.repository.markStatus(batchIds, 'SYNCING');
      await this.notifyStats();

      // Format payload strictly matching OfflineSyncBatchSchema
      const syncPayload = {
        events: batch.map((item) => ({
          id: item.id,
          actionType: item.actionType,
          idempotencyKey: item.idempotencyKey,
          timestamp: item.timestamp,
          payload: item.payload,
        })),
      };

      const response = await this.apiClient.post<SyncBatchResult>(
        '/sync/batch',
        syncPayload,
        { idempotencyKey: `sync_batch_${Date.now()}` }
      );

      const syncedIds: string[] = [];
      const failedIds: string[] = [];

      (response.results || []).forEach((r) => {
        if (r.status === 'SYNCED' || r.status === 'IDEMPOTENT_SKIPPED') {
          syncedIds.push(r.id);
        } else {
          failedIds.push(r.id);
        }
      });

      if (syncedIds.length > 0) {
        await this.repository.markStatus(syncedIds, 'SYNCED');
      }
      if (failedIds.length > 0) {
        await this.repository.markStatus(failedIds, 'FAILED', 'Server sync rejected');
      }

      this.lastSyncAt = Date.now();
      await this.repository.purgeCompleted();
      await this.notifyStats();

      return response;
    } catch (err: any) {
      const items = await this.repository.getAll();
      const syncingIds = items.filter((i) => i.status === 'SYNCING').map((i) => i.id);
      await this.repository.markStatus(syncingIds, 'FAILED', err.message || 'Sync failed');
      await this.notifyStats();
      throw err;
    } finally {
      this.isSyncing = false;
    }
  }
}

export const defaultSyncManager = new SyncManager();
