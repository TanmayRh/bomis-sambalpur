/**
 * Driver GPS Telemetry Broadcaster & Sambalpur Route 1 Trajectory Simulator
 * Conforms to ADR 0004 & Transport Fleet Telemetry specifications.
 */

import { defaultApiClient } from './api-client';
import { defaultSyncManager } from './sync-manager';

export interface GpsCoordinate {
  latitude: number;
  longitude: number;
  speed: number;
  heading: number;
  timestamp: string;
}

export interface RouteWaypoint {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  order: number;
  scheduledTime: string;
}

// Canonical Sambalpur Route 1 Waypoints
export const ROUTE_1_BUDHARAJA_WAYPOINTS: RouteWaypoint[] = [
  { id: 'st-01', name: 'Budharaja Fatak', latitude: 21.4825, longitude: 83.9782, order: 1, scheduledTime: '07:15 AM' },
  { id: 'p1000000-0001-4000-8000-000000000002', name: 'Sakhipada Chhak', latitude: 21.4669, longitude: 83.9812, order: 2, scheduledTime: '07:25 AM' },
  { id: 'st-03', name: 'Ainthapali Chowk', latitude: 21.4930, longitude: 83.9870, order: 3, scheduledTime: '07:35 AM' },
  { id: 'st-04', name: 'BOMIS Campus Gate', latitude: 21.4938, longitude: 83.9855, order: 4, scheduledTime: '07:45 AM' },
];

/**
 * Calculates Haversine spherical distance between two GPS coordinates in kilometers
 */
export function calculateHaversineDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's mean radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export class LocationService {
  private isBroadcasting = false;
  private intervalTimer: any = null;
  private currentWaypointIndex = 0;
  private progressBetweenWaypoints = 0.0;
  private busId = 'v1000000-0001-4000-8000-000000000001'; // Bus 01 OD-15-AB-1001
  private routeId = 'r1000000-0001-4000-8000-000000000001';
  private pingIntervalMs = 5000; // 5-second broadcast cadence
  private waypoints = ROUTE_1_BUDHARAJA_WAYPOINTS;
  private listeners: Set<(coord: GpsCoordinate, isNearGeofence: boolean) => void> = new Set();
  private lastCoordinate: GpsCoordinate = {
    latitude: 21.4825,
    longitude: 83.9782,
    speed: 28,
    heading: 45,
    timestamp: new Date().toISOString(),
  };
  private isNearSakhipada = false;

  public subscribe(listener: (coord: GpsCoordinate, isNearGeofence: boolean) => void): () => void {
    this.listeners.add(listener);
    listener(this.lastCoordinate, this.isNearSakhipada);
    return () => this.listeners.delete(listener);
  }

  public getLastCoordinate(): GpsCoordinate {
    return this.lastCoordinate;
  }

  public getIsNearGeofence(): boolean {
    return this.isNearSakhipada;
  }

  public isActive(): boolean {
    return this.isBroadcasting;
  }

  public start(): void {
    if (this.isBroadcasting) return;
    this.isBroadcasting = true;
    this.tick();
    this.intervalTimer = setInterval(() => this.tick(), this.pingIntervalMs);
  }

  public stop(): void {
    this.isBroadcasting = false;
    if (this.intervalTimer) {
      clearInterval(this.intervalTimer);
      this.intervalTimer = null;
    }
  }

  private async tick(): Promise<void> {
    // Progress vehicle smoothly between waypoints
    this.progressBetweenWaypoints += 0.2;
    if (this.progressBetweenWaypoints >= 1.0) {
      this.progressBetweenWaypoints = 0.0;
      this.currentWaypointIndex = (this.currentWaypointIndex + 1) % this.waypoints.length;
    }

    const currentWp = this.waypoints[this.currentWaypointIndex]!;
    const nextWp = this.waypoints[(this.currentWaypointIndex + 1) % this.waypoints.length]!;

    const lat = currentWp.latitude + (nextWp.latitude - currentWp.latitude) * this.progressBetweenWaypoints;
    const lng = currentWp.longitude + (nextWp.longitude - currentWp.longitude) * this.progressBetweenWaypoints;

    // Check 5-minute geofence alert for Sakhipada Chhak (Aarav Patel's stop: order 2)
    const sakhipadaStop = this.waypoints[1]!;
    const distanceToSakhipadaKm = calculateHaversineDistanceKm(
      lat,
      lng,
      sakhipadaStop.latitude,
      sakhipadaStop.longitude
    );
    // <= 1.5 km indicates approaching within 5 minutes at ~28 km/h city speed
    this.isNearSakhipada = distanceToSakhipadaKm <= 1.5;

    this.lastCoordinate = {
      latitude: Number(lat.toFixed(6)),
      longitude: Number(lng.toFixed(6)),
      speed: 28,
      heading: 45,
      timestamp: new Date().toISOString(),
    };

    // Notify active UI listeners
    this.listeners.forEach((l) => l(this.lastCoordinate, this.isNearSakhipada));

    // Prepare ping payload
    const payload = {
      busId: this.busId,
      vehicleId: this.busId,
      routeId: this.routeId,
      latitude: this.lastCoordinate.latitude,
      longitude: this.lastCoordinate.longitude,
      speed: this.lastCoordinate.speed,
      heading: this.lastCoordinate.heading,
      timestamp: this.lastCoordinate.timestamp,
    };

    // If online, dispatch to backend; if fails/offline, queue in outbox
    try {
      if (defaultSyncManager.getNetworkMonitor().isOnline()) {
        await defaultApiClient.post('/transport/gps-ping', payload);
      } else {
        await defaultSyncManager.enqueueMutation('GPS_PING', payload);
      }
    } catch {
      // Buffer offline ping in outbox
      try {
        await defaultSyncManager.enqueueMutation('GPS_PING', payload);
      } catch {
        // Safe ignore
      }
    }
  }
}

export const defaultLocationService = new LocationService();
