/**
 * Unified 3-Tier Adaptive Storage Adapter for BOMIS Sambalpur Mobile
 * Conforms to Expo SDK 51, Web Preview, and Node/Jest testing environments.
 */

export interface IStorageAdapter {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
  getAllKeys(): Promise<string[]>;
  multiGet(keys: string[]): Promise<Array<[string, string | null]>>;
  multiSet(keyValuePairs: Array<[string, string]>): Promise<void>;
  clear(): Promise<void>;
}

/**
 * In-Memory Storage Adapter for Node, Jest, and Headless Environments
 */
export class MemoryStorageAdapter implements IStorageAdapter {
  private store = new Map<string, string>();

  async getItem(key: string): Promise<string | null> {
    return this.store.get(key) ?? null;
  }

  async setItem(key: string, value: string): Promise<void> {
    this.store.set(key, value);
  }

  async removeItem(key: string): Promise<void> {
    this.store.delete(key);
  }

  async getAllKeys(): Promise<string[]> {
    return Array.from(this.store.keys());
  }

  async multiGet(keys: string[]): Promise<Array<[string, string | null]>> {
    return keys.map((k) => [k, this.store.get(k) ?? null]);
  }

  async multiSet(pairs: Array<[string, string]>): Promise<void> {
    pairs.forEach(([k, v]) => this.store.set(k, v));
  }

  async clear(): Promise<void> {
    this.store.clear();
  }
}

/**
 * Web LocalStorage Adapter for Expo Web Preview
 */
export class WebLocalStorageAdapter implements IStorageAdapter {
  async getItem(key: string): Promise<string | null> {
    if (typeof window === 'undefined' || !window.localStorage) return null;
    return window.localStorage.getItem(key);
  }

  async setItem(key: string, value: string): Promise<void> {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, value);
    }
  }

  async removeItem(key: string): Promise<void> {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.removeItem(key);
    }
  }

  async getAllKeys(): Promise<string[]> {
    if (typeof window === 'undefined' || !window.localStorage) return [];
    return Object.keys(window.localStorage);
  }

  async multiGet(keys: string[]): Promise<Array<[string, string | null]>> {
    return keys.map((k) => [k, this.getItemSync(k)]);
  }

  async multiSet(pairs: Array<[string, string]>): Promise<void> {
    pairs.forEach(([k, v]) => this.setItemSync(k, v));
  }

  async clear(): Promise<void> {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.clear();
    }
  }

  private getItemSync(key: string): string | null {
    if (typeof window === 'undefined' || !window.localStorage) return null;
    return window.localStorage.getItem(key);
  }

  private setItemSync(key: string, val: string): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, val);
    }
  }
}

/**
 * Storage Factory: Automatically picks the safest adapter for the active runtime
 */
export function createStorageAdapter(): IStorageAdapter {
  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      const testKey = '__bomis_storage_test__';
      window.localStorage.setItem(testKey, '1');
      window.localStorage.removeItem(testKey);
      return new WebLocalStorageAdapter();
    } catch {
      return new MemoryStorageAdapter();
    }
  }
  return new MemoryStorageAdapter();
}

export const defaultStorage: IStorageAdapter = createStorageAdapter();
