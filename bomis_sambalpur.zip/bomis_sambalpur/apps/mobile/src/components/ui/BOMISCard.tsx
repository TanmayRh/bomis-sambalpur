/**
 * BOMISCard - Elevated Container Primitive
 * Styled with rounded corners (16px), elevation shadow, and card border.
 */

import React from 'react';
import { View, Text, StyleSheet, ViewStyle, StyleProp } from 'react-native';

export interface BOMISCardProps {
  title?: string;
  subtitle?: string;
  badge?: React.ReactNode;
  headerRight?: React.ReactNode;
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

export const BOMISCard: React.FC<BOMISCardProps> = ({
  title,
  subtitle,
  badge,
  headerRight,
  children,
  style,
}) => {
  const hasHeader = title || subtitle || badge || headerRight;

  return (
    <View style={[styles.card, style]}>
      {hasHeader && (
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            {badge && <View style={styles.badgeWrapper}>{badge}</View>}
            {title && <Text style={styles.title}>{title}</Text>}
            {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
          </View>
          {headerRight && <View style={styles.headerRight}>{headerRight}</View>}
        </View>
      )}
      <View style={styles.content}>{children}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    shadowColor: '#0F2942',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
    marginBottom: 16,
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  headerLeft: {
    flex: 1,
  },
  badgeWrapper: {
    marginBottom: 6,
    alignSelf: 'flex-start',
  },
  title: {
    fontSize: 17,
    fontWeight: '700',
    color: '#0F172A',
  },
  subtitle: {
    fontSize: 13,
    color: '#64748B',
    marginTop: 2,
  },
  headerRight: {
    marginLeft: 12,
  },
  content: {
    padding: 16,
  },
});
