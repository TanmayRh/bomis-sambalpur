/**
 * BOMISBadge - Pill Badges for Roles, Attendance, and Geofence Alerts
 * Conforms to BOMIS Brand Tokens and high-contrast accessibility standards.
 */

import React from 'react';
import { View, Text, StyleSheet, ViewStyle, TextStyle, StyleProp } from 'react-native';
import { UserRole, AttendanceStatus } from '@bomis/shared';

export type BadgeVariant =
  | 'default'
  | 'primary'
  | 'accent'
  | 'success'
  | 'warning'
  | 'danger'
  | 'info'
  | UserRole
  | AttendanceStatus
  | 'GEOFENCE_APPROACHING'
  | 'GEOFENCE_ARRIVED';

export interface BOMISBadgeProps {
  label: string;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
  style?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  icon?: React.ReactNode;
}

export const BOMISBadge: React.FC<BOMISBadgeProps> = ({
  label,
  variant = 'default',
  size = 'md',
  style,
  textStyle,
  icon,
}) => {
  const getColors = (): { bg: string; text: string; border: string } => {
    switch (variant) {
      // Role tokens
      case UserRole.PARENT:
        return { bg: '#FFF5F2', text: '#94311B', border: '#FFD4CB' };
      case UserRole.STUDENT:
        return { bg: '#F4F8FA', text: '#254E7A', border: '#D2E3F0' };
      case UserRole.TEACHER:
        return { bg: '#EBF2F8', text: '#0F2942', border: '#A4C6E1' };
      case UserRole.TRANSPORT_STAFF:
      case 'DRIVER_TRANSPORT' as any:
        return { bg: '#FEF3C7', text: '#92400E', border: '#FDE68A' };

      // Attendance status tokens
      case AttendanceStatus.PRESENT:
      case 'success':
        return { bg: '#ECFDF5', text: '#065F46', border: '#A7F3D0' };
      case AttendanceStatus.ABSENT:
      case 'danger':
        return { bg: '#FEF2F2', text: '#991B1B', border: '#FECACA' };
      case AttendanceStatus.LATE:
      case 'warning':
      case 'GEOFENCE_APPROACHING':
        return { bg: '#FFFBEB', text: '#92400E', border: '#FDE68A' };
      case AttendanceStatus.HALF_DAY:
      case 'info':
        return { bg: '#EFF6FF', text: '#1E40AF', border: '#BFDBFE' };
      case 'GEOFENCE_ARRIVED':
        return { bg: '#ECFDF5', text: '#065F46', border: '#6EE7B7' };

      // Brand tokens
      case 'primary':
        return { bg: '#0F2942', text: '#FFFFFF', border: '#0F2942' };
      case 'accent':
        return { bg: '#FF6B4A', text: '#FFFFFF', border: '#FF6B4A' };

      default:
        return { bg: '#F1F5F9', text: '#475569', border: '#E2E8F0' };
    }
  };

  const colors = getColors();

  return (
    <View
      style={[
        styles.badge,
        {
          backgroundColor: colors.bg,
          borderColor: colors.border,
        },
        size === 'sm' ? styles.badgeSm : styles.badgeMd,
        style,
      ]}
    >
      {icon}
      <Text
        style={[
          styles.text,
          { color: colors.text },
          size === 'sm' ? styles.textSm : styles.textMd,
          textStyle,
        ]}
      >
        {label}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 9999,
    borderWidth: 1,
    alignSelf: 'flex-start',
    gap: 4,
  },
  badgeSm: {
    paddingVertical: 2,
    paddingHorizontal: 8,
  },
  badgeMd: {
    paddingVertical: 4,
    paddingHorizontal: 12,
  },
  text: {
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  textSm: {
    fontSize: 10,
    letterSpacing: 0.5,
  },
  textMd: {
    fontSize: 12,
    letterSpacing: 0.5,
  },
});
