/**
 * BOMISHeader - Branded Mobile Top Bar
 * Displays school crest, CBSE Affiliation #1530267 badge, active role indicator,
 * user name, and persona switch / logout trigger.
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';
import { UserRole } from '@bomis/shared';
import { BOMISBadge } from './BOMISBadge';

export interface BOMISHeaderProps {
  userName?: string;
  role?: UserRole | null;
  onLogout?: () => void;
  onSwitchRole?: () => void;
}

export const BOMISHeader: React.FC<BOMISHeaderProps> = ({
  userName = 'User',
  role = UserRole.PARENT,
  onLogout,
  onSwitchRole,
}) => {
  const getInitials = (name: string): string => {
    return name
      .split(' ')
      .filter(Boolean)
      .slice(0, 2)
      .map((n) => n.charAt(0).toUpperCase())
      .join('');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Left: Crest and CBSE badge */}
        <View style={styles.leftSection}>
          <View style={styles.crestCircle}>
            <Text style={styles.crestText}>B</Text>
          </View>
          <View>
            <Text style={styles.schoolName}>BOMIS Sambalpur</Text>
            <View style={styles.cbseBadge}>
              <Text style={styles.cbseText}>CBSE #1530267</Text>
            </View>
          </View>
        </View>

        {/* Right: Role badge, Avatar & Actions */}
        <View style={styles.rightSection}>
          {role && (
            <BOMISBadge
              label={role}
              variant={role}
              size="sm"
              style={styles.roleBadge}
            />
          )}

          <TouchableOpacity
            style={styles.avatarButton}
            onPress={onSwitchRole}
            activeOpacity={0.7}
          >
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{getInitials(userName)}</Text>
            </View>
          </TouchableOpacity>

          {onLogout && (
            <TouchableOpacity
              style={styles.logoutButton}
              onPress={onLogout}
              activeOpacity={0.7}
            >
              <Text style={styles.logoutText}>Exit</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: '#0F2942',
  },
  container: {
    backgroundColor: '#0F2942',
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#1A3A5C',
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  crestCircle: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#FF6B4A',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  crestText: {
    color: '#FFFFFF',
    fontWeight: '900',
    fontSize: 20,
    fontFamily: 'sans-serif',
  },
  schoolName: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 16,
  },
  cbseBadge: {
    backgroundColor: '#1A3A5C',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: 'flex-start',
    marginTop: 2,
  },
  cbseText: {
    color: '#FFAFA0',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  roleBadge: {
    marginRight: 4,
  },
  avatarButton: {
    padding: 2,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#3D7FB5',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: '#A4C6E1',
  },
  avatarText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 12,
  },
  logoutButton: {
    backgroundColor: '#1A3A5C',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  logoutText: {
    color: '#FFD4CB',
    fontSize: 11,
    fontWeight: '600',
  },
});
