/**
 * Parent Context & Multi-Child State Isolation Provider
 * Guarantees zero cross-child state bleeding between siblings (Aarav vs Ananya Patel).
 * Manages child-specific attendance, live bus tracking, dismissal OTP, and fee checkout.
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { SEED_PERSONAS, defaultApiClient } from '../services/api-client';

export interface ChildProfile {
  id: string;
  admissionNumber: string;
  rollNumber: string;
  firstName: string;
  lastName: string;
  grade: string;
  section: string;
  classId: string;
  sectionId: string;
  house: string;
  bloodGroup: string;
  stopName: string;
  busNumber: string;
  emergencyContact: string;
  medicalNotes: string;
}

export interface ChildAttendanceSummary {
  totalWorkingDays: number;
  presentDays: number;
  halfDays: number;
  absentDays: number;
  percentage: number;
  lowAttendanceAlert: boolean;
  cbseCompliant: boolean;
}

export interface ChildDismissalPass {
  studentId: string;
  otp: string;
  status: 'ACTIVE' | 'USED' | 'EXPIRED';
  issuedAt: number;
  expiresAt: number;
  qrPayload: string;
  verifiedGate?: string;
}

export interface ParentFeeStatus {
  installmentNumber: number;
  termName: string;
  amount: number;
  status: 'PAID' | 'DUE' | 'OVERDUE';
  receiptNumber?: string;
}

export interface ParentContextType {
  childrenList: ChildProfile[];
  activeChild: ChildProfile;
  selectChild: (childId: string) => void;
  attendance: ChildAttendanceSummary;
  dismissalPass: ChildDismissalPass;
  feeStatus: ParentFeeStatus;
  regenerateDismissalOtp: () => void;
  simulateGatekeeperScan: (gateNumber?: string) => Promise<boolean>;
  payFeeInstallment: (method: string) => Promise<{ receiptNumber: string; orderId: string }>;
}

const ParentContext = createContext<ParentContextType | undefined>(undefined);

const SEED_CHILDREN = SEED_PERSONAS.PARENT.children;

// Distinct fee statuses per sibling to guarantee isolation
const CHILD_FEES: Record<string, ParentFeeStatus> = {
  'b1000000-0005-4000-8000-000000000001': {
    installmentNumber: 2,
    termName: 'Term 2 (Grade 5 Tuition & STEM Lab)',
    amount: 16500,
    status: 'DUE',
  },
  'b1000000-0002-4000-8000-000000000001': {
    installmentNumber: 2,
    termName: 'Term 2 (Grade 2 Foundation & Activity)',
    amount: 14000,
    status: 'PAID',
    receiptNumber: 'REC-2026-03189',
  },
};

// Distinct attendance metrics per sibling
const CHILD_ATTENDANCE: Record<string, ChildAttendanceSummary> = {
  'b1000000-0005-4000-8000-000000000001': {
    totalWorkingDays: 22,
    presentDays: 20,
    halfDays: 1,
    absentDays: 1,
    percentage: 90.9,
    lowAttendanceAlert: false,
    cbseCompliant: true,
  },
  'b1000000-0002-4000-8000-000000000001': {
    totalWorkingDays: 22,
    presentDays: 21,
    halfDays: 0,
    absentDays: 1,
    percentage: 95.5,
    lowAttendanceAlert: false,
    cbseCompliant: true,
  },
};

export const ParentProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [childrenList] = useState<ChildProfile[]>(SEED_CHILDREN);
  const [activeChildId, setActiveChildId] = useState<string>(SEED_CHILDREN[0]!.id);

  // Per-child dismissal pass map: studentId -> ChildDismissalPass
  const [passes, setPasses] = useState<Record<string, ChildDismissalPass>>(() => {
    const initialPasses: Record<string, ChildDismissalPass> = {};
    const now = Date.now();
    // 30 minutes TTL
    const expiry = now + 30 * 60 * 1000;

    const child0 = SEED_CHILDREN[0]!;
    const child1 = SEED_CHILDREN[1]!;

    initialPasses[child0.id] = {
      studentId: child0.id,
      otp: '482910', // Canonical seed OTP for Aarav Patel
      status: 'ACTIVE',
      issuedAt: now,
      expiresAt: expiry,
      qrPayload: `BOMIS:PICKUP:${child0.id}:482910`,
    };

    initialPasses[child1.id] = {
      studentId: child1.id,
      otp: '729104',
      status: 'ACTIVE',
      issuedAt: now,
      expiresAt: expiry,
      qrPayload: `BOMIS:PICKUP:${child1.id}:729104`,
    };

    return initialPasses;
  });

  const [fees, setFees] = useState<Record<string, ParentFeeStatus>>(CHILD_FEES);

  // Active child derivation
  const activeChild = childrenList.find((c) => c.id === activeChildId) || childrenList[0]!;

  const selectChild = (childId: string) => {
    setActiveChildId(childId);
  };

  const regenerateDismissalOtp = () => {
    const now = Date.now();
    const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiry = now + 30 * 60 * 1000; // 30 minutes

    setPasses((prev) => ({
      ...prev,
      [activeChildId]: {
        studentId: activeChildId,
        otp: newOtp,
        status: 'ACTIVE',
        issuedAt: now,
        expiresAt: expiry,
        qrPayload: `BOMIS:PICKUP:${activeChildId}:${newOtp}`,
      },
    }));
  };

  const simulateGatekeeperScan = async (gateNumber: string = 'Gate 1'): Promise<boolean> => {
    const currentPass = passes[activeChildId];
    if (!currentPass || currentPass.status !== 'ACTIVE' || Date.now() > currentPass.expiresAt) {
      return false;
    }

    try {
      await defaultApiClient.post('/safety/pickup/verify', {
        studentId: activeChildId,
        pickupOtp: currentPass.otp,
        gateNumber,
      });
    } catch {
      // In offline mode, simulate successful verification
    }

    setPasses((prev) => ({
      ...prev,
      [activeChildId]: {
        ...prev[activeChildId],
        status: 'USED',
        verifiedGate: gateNumber,
      },
    }));
    return true;
  };

  const payFeeInstallment = async (method: string): Promise<{ receiptNumber: string; orderId: string }> => {
    const currentFee = fees[activeChildId];
    // RFC 4122 v4 UUID generator
    const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });

    const res = await defaultApiClient.post<{
      razorpayOrderId: string;
      receiptNumber: string;
    }>(
      '/fees/orders',
      {
        studentId: activeChildId,
        installmentNumber: currentFee.installmentNumber,
        amountPaise: currentFee.amount * 100,
        paymentMethod: method,
      },
      { idempotencyKey: uuid }
    );

    const receiptNo = res.receiptNumber || `REC-2026-${Math.floor(10000 + Math.random() * 90000)}`;

    setFees((prev) => ({
      ...prev,
      [activeChildId]: {
        ...prev[activeChildId],
        status: 'PAID',
        receiptNumber: receiptNo,
      },
    }));

    return {
      receiptNumber: receiptNo,
      orderId: res.razorpayOrderId || `order_${Date.now()}`,
    };
  };

  const currentAttendance = CHILD_ATTENDANCE[activeChildId] || CHILD_ATTENDANCE[SEED_CHILDREN[0]!.id]!;
  const currentPass = passes[activeChildId] || passes[SEED_CHILDREN[0]!.id]!;
  const currentFee = fees[activeChildId] || fees[SEED_CHILDREN[0]!.id]!;

  return (
    <ParentContext.Provider
      value={{
        childrenList,
        activeChild,
        selectChild,
        attendance: currentAttendance,
        dismissalPass: currentPass,
        feeStatus: currentFee,
        regenerateDismissalOtp,
        simulateGatekeeperScan,
        payFeeInstallment,
      }}
    >
      {children}
    </ParentContext.Provider>
  );
};

export const useParent = (): ParentContextType => {
  const context = useContext(ParentContext);
  if (!context) {
    throw new Error('useParent must be used within a ParentProvider');
  }
  return context;
};
