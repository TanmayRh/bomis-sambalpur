/**
 * ParentScreen - Unified Multi-Child Parent Portal
 * Conforms to R1 / AC-2 specification & Master Implementation Blueprint.
 * Features: Sibling Switcher, Attendance summary, Live Bus Tracker with 5-minute
 * Sakhipada Chhak geofence alert banner, Idempotent Fee Checkout, and Dismissal OTP Card
 * with ticking 30-minute countdown timer & dynamic QR.
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  Alert,
} from 'react-native';
import { useParent } from '../state/parent-context';
import { defaultLocationService, GpsCoordinate } from '../services/location-service';
import { BOMISCard } from '../components/ui/BOMISCard';
import { BOMISButton } from '../components/ui/BOMISButton';
import { BOMISBadge } from '../components/ui/BOMISBadge';
import { AttendanceStatus } from '@bomis/shared';

export const ParentScreen: React.FC = () => {
  const {
    childrenList,
    activeChild,
    selectChild,
    attendance,
    dismissalPass,
    feeStatus,
    regenerateDismissalOtp,
    simulateGatekeeperScan,
    payFeeInstallment,
  } = useParent();

  // Active section tab: 'overview' | 'bus' | 'fees' | 'dismissal'
  const [activeTab, setActiveTab] = useState<'overview' | 'bus' | 'fees' | 'dismissal'>('overview');

  // GPS Telemetry and 5-minute Geofence proximity alert state
  const [busLocation, setBusLocation] = useState<GpsCoordinate>(defaultLocationService.getLastCoordinate());
  const [isNearGeofence, setIsNearGeofence] = useState<boolean>(defaultLocationService.getIsNearGeofence());
  const [geofenceDismissed, setGeofenceDismissed] = useState<boolean>(false);

  // 30-Minute Dismissal Countdown Timer
  const [secondsRemaining, setSecondsRemaining] = useState<number>(() => {
    const remaining = Math.max(0, Math.floor((dismissalPass.expiresAt - Date.now()) / 1000));
    return remaining;
  });

  // Fee Checkout Modal State
  const [showFeeModal, setShowFeeModal] = useState<boolean>(false);
  const [isPaying, setIsPaying] = useState<boolean>(false);
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);
  const [paidReceipt, setPaidReceipt] = useState<string | null>(null);
  const [selectedMethod, setSelectedMethod] = useState<string>('RAZORPAY_UPI');

  // Subscribe to GPS broadcaster
  useEffect(() => {
    const unsubscribe = defaultLocationService.subscribe((coord, near) => {
      setBusLocation(coord);
      setIsNearGeofence(near);
    });
    return unsubscribe;
  }, []);

  // Dismissal OTP Countdown effect
  useEffect(() => {
    // Synchronously set countdown immediately to prevent 1-second lag when toggling active sibling
    setSecondsRemaining(Math.max(0, Math.floor((dismissalPass.expiresAt - Date.now()) / 1000)));

    const timer = setInterval(() => {
      const remaining = Math.max(0, Math.floor((dismissalPass.expiresAt - Date.now()) / 1000));
      setSecondsRemaining(remaining);
    }, 1000);
    return () => clearInterval(timer);
  }, [dismissalPass.expiresAt]);

  const formatCountdown = (secs: number): string => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const isOtpExpired = secondsRemaining <= 0 || dismissalPass.status === 'EXPIRED';

  const handlePay = async () => {
    setIsPaying(true);
    try {
      const res = await payFeeInstallment(selectedMethod);
      setPaidReceipt(res.receiptNumber);
      setPaymentSuccess(true);
    } catch (err: any) {
      Alert.alert('Payment Error', err.message || 'Payment failed');
    } finally {
      setIsPaying(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Sibling Switcher Bar */}
      <View style={styles.siblingSwitcher}>
        <Text style={styles.switcherLabel}>SELECT CHILD:</Text>
        <View style={styles.siblingButtons}>
          {childrenList.map((child) => {
            const isActive = child.id === activeChild.id;
            return (
              <TouchableOpacity
                key={child.id}
                style={[styles.siblingButton, isActive && styles.siblingButtonActive]}
                onPress={() => selectChild(child.id)}
                activeOpacity={0.8}
              >
                <View style={[styles.childAvatar, isActive && styles.childAvatarActive]}>
                  <Text style={styles.childAvatarText}>
                    {child.firstName.charAt(0)}
                  </Text>
                </View>
                <View>
                  <Text style={[styles.siblingName, isActive && styles.siblingNameActive]}>
                    {child.firstName} {child.lastName}
                  </Text>
                  <Text style={styles.siblingGrade}>{child.grade} {child.section}</Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      {/* 5-Minute Proximity Geofence Alert Banner for Sakhipada Chhak */}
      {isNearGeofence && !geofenceDismissed && (
        <View style={styles.geofenceBanner}>
          <View style={styles.geofenceHeader}>
            <BOMISBadge label="5-MIN BUS ALERT" variant="GEOFENCE_APPROACHING" size="sm" />
            <TouchableOpacity onPress={() => setGeofenceDismissed(true)}>
              <Text style={styles.dismissText}>✕</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.geofenceTitle}>
            Bus 01 is approaching {activeChild.stopName}
          </Text>
          <Text style={styles.geofenceBody}>
            Estimated arrival in ~4 minutes. Current speed: {busLocation.speed} km/h. Please proceed to the boarding point.
          </Text>
        </View>
      )}

      {/* Tab Navigation Segment */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'overview' && styles.tabItemActive]}
          onPress={() => setActiveTab('overview')}
        >
          <Text style={[styles.tabText, activeTab === 'overview' && styles.tabTextActive]}>
            Overview
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'bus' && styles.tabItemActive]}
          onPress={() => setActiveTab('bus')}
        >
          <Text style={[styles.tabText, activeTab === 'bus' && styles.tabTextActive]}>
            Live Bus
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'fees' && styles.tabItemActive]}
          onPress={() => setActiveTab('fees')}
        >
          <Text style={[styles.tabText, activeTab === 'fees' && styles.tabTextActive]}>
            Fees
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'dismissal' && styles.tabItemActive]}
          onPress={() => setActiveTab('dismissal')}
        >
          <Text style={[styles.tabText, activeTab === 'dismissal' && styles.tabTextActive]}>
            Gate Pass
          </Text>
        </TouchableOpacity>
      </View>

      {/* VIEW 1: Overview & Attendance Summary */}
      {activeTab === 'overview' && (
        <View>
          {/* Student Profile Snapshot Card */}
          <BOMISCard
            title={`${activeChild.firstName} ${activeChild.lastName}`}
            subtitle={`Admission: ${activeChild.admissionNumber} • Roll: #${activeChild.rollNumber}`}
            badge={<BOMISBadge label={activeChild.house} variant="primary" size="sm" />}
          >
            <View style={styles.profileRow}>
              <View style={styles.profileCol}>
                <Text style={styles.profileLabel}>Grade & Section</Text>
                <Text style={styles.profileValue}>{activeChild.grade} - Section {activeChild.section}</Text>
              </View>
              <View style={styles.profileCol}>
                <Text style={styles.profileLabel}>Blood Group</Text>
                <Text style={styles.profileValue}>{activeChild.bloodGroup}</Text>
              </View>
            </View>

            <View style={styles.profileRow}>
              <View style={styles.profileCol}>
                <Text style={styles.profileLabel}>Bus Route</Text>
                <Text style={styles.profileValue}>{activeChild.busNumber}</Text>
              </View>
              <View style={styles.profileCol}>
                <Text style={styles.profileLabel}>Pickup Stop</Text>
                <Text style={styles.profileValue}>{activeChild.stopName}</Text>
              </View>
            </View>
          </BOMISCard>

          {/* Attendance Compliance & Monthly Statistics Card */}
          <BOMISCard
            title="Attendance Summary (October 2026)"
            subtitle="CBSE 75% minimum compliance monitoring"
            headerRight={
              <BOMISBadge
                label={attendance.cbseCompliant ? 'CBSE Compliant' : 'Alert: Low'}
                variant={attendance.cbseCompliant ? AttendanceStatus.PRESENT : AttendanceStatus.ABSENT}
                size="sm"
              />
            }
          >
            <View style={styles.metricGrid}>
              <View style={styles.metricBox}>
                <Text style={styles.metricBig}>{attendance.percentage}%</Text>
                <Text style={styles.metricLabel}>Attendance Rate</Text>
              </View>
              <View style={styles.metricDetails}>
                <View style={styles.detailRow}>
                  <Text style={styles.detailName}>Present Days:</Text>
                  <Text style={[styles.detailVal, { color: '#065F46' }]}>{attendance.presentDays}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailName}>Half Days:</Text>
                  <Text style={[styles.detailVal, { color: '#1E40AF' }]}>{attendance.halfDays}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailName}>Absent Days:</Text>
                  <Text style={[styles.detailVal, { color: '#991B1B' }]}>{attendance.absentDays}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailName}>Total Working Days:</Text>
                  <Text style={styles.detailVal}>{attendance.totalWorkingDays}</Text>
                </View>
              </View>
            </View>

            {/* Attendance Calendar Preview Dots */}
            <View style={styles.calendarPreview}>
              <Text style={styles.previewTitle}>Last 14 School Days:</Text>
              <View style={styles.dotStrip}>
                {Array.from({ length: 14 }).map((_, i) => {
                  let dotColor = '#10B981'; // Present
                  if (i === 12 && activeChild.firstName === 'Aarav') dotColor = '#3B82F6'; // Half day
                  if (i === 13) dotColor = '#EF4444'; // Absent
                  return (
                    <View key={i} style={[styles.dayDot, { backgroundColor: dotColor }]}>
                      <Text style={styles.dayDotText}>{i + 1}</Text>
                    </View>
                  );
                })}
              </View>
            </View>
          </BOMISCard>
        </View>
      )}

      {/* VIEW 2: Live Bus Tracker */}
      {activeTab === 'bus' && (
        <View>
          <BOMISCard
            title="Budharaja Shuttle (Route 1)"
            subtitle="Vehicle: Tata Winger • Reg: OD-15-AB-1001"
            badge={<BOMISBadge label="IN TRANSIT" variant="accent" size="sm" />}
          >
            {/* Live GPS Telemetry Box */}
            <View style={styles.telemetryBox}>
              <View style={styles.telemetryItem}>
                <Text style={styles.telemetryLabel}>Current Speed</Text>
                <Text style={styles.telemetryValue}>{busLocation.speed} km/h</Text>
              </View>
              <View style={styles.telemetryItem}>
                <Text style={styles.telemetryLabel}>Driver</Text>
                <Text style={styles.telemetryValue}>Maheswar Bhoi</Text>
              </View>
              <View style={styles.telemetryItem}>
                <Text style={styles.telemetryLabel}>Designated Stop</Text>
                <Text style={styles.telemetryValue}>{activeChild.stopName}</Text>
              </View>
            </View>

            {/* Boarding Status Notice */}
            <View style={styles.boardingNotice}>
              <Text style={styles.boardingText}>
                ✓ {activeChild.firstName} safely boarded Bus 01 at 07:28 AM (QR Verified)
              </Text>
            </View>

            {/* Stops Timeline */}
            <View style={styles.timeline}>
              <View style={styles.timelineItem}>
                <View style={[styles.timelineNode, styles.timelineNodeDone]} />
                <View style={styles.timelineContent}>
                  <Text style={styles.stopName}>1. Budharaja Fatak (07:15 AM)</Text>
                  <Text style={styles.stopStatus}>Departed on time</Text>
                </View>
              </View>

              <View style={styles.timelineItem}>
                <View style={[styles.timelineNode, styles.timelineNodeActive]} />
                <View style={styles.timelineContent}>
                  <Text style={[styles.stopName, { color: '#FF6B4A', fontWeight: '800' }]}>
                    2. Sakhipada Chhak (07:25 AM) ★
                  </Text>
                  <Text style={styles.stopStatus}>Approaching • Your child's stop</Text>
                </View>
              </View>

              <View style={styles.timelineItem}>
                <View style={styles.timelineNode} />
                <View style={styles.timelineContent}>
                  <Text style={styles.stopName}>3. Ainthapali Chowk (07:35 AM)</Text>
                  <Text style={styles.stopStatus}>Upcoming</Text>
                </View>
              </View>

              <View style={styles.timelineItem}>
                <View style={styles.timelineNode} />
                <View style={styles.timelineContent}>
                  <Text style={styles.stopName}>4. BOMIS Campus Gate (07:45 AM)</Text>
                  <Text style={styles.stopStatus}>Destination</Text>
                </View>
              </View>
            </View>

            <View style={styles.busActionRow}>
              <BOMISButton
                title="Call Pilot (+919437200001)"
                onPress={() => Alert.alert('Calling Pilot', 'Initiating call to Maheswar Bhoi')}
                variant="outline"
                size="sm"
                style={{ flex: 1, marginRight: 8 }}
              />
              <BOMISButton
                title="Share ETA"
                onPress={() => Alert.alert('Share ETA', 'Bus ETA copied to clipboard')}
                variant="ghost"
                size="sm"
                style={{ flex: 1 }}
              />
            </View>
          </BOMISCard>
        </View>
      )}

      {/* VIEW 3: Fees & Idempotent Checkout */}
      {activeTab === 'fees' && (
        <View>
          <BOMISCard
            title="School Fee Breakdown"
            subtitle={`Academic Year 2026-2027 • ${activeChild.grade}`}
            headerRight={
              <BOMISBadge
                label={feeStatus.status}
                variant={feeStatus.status === 'PAID' ? 'success' : 'warning'}
                size="sm"
              />
            }
          >
            <View style={styles.feeBreakdown}>
              <View style={styles.feeRow}>
                <Text style={styles.feeLabel}>{feeStatus.termName}</Text>
                <Text style={styles.feeAmount}>₹{feeStatus.amount.toLocaleString('en-IN')}</Text>
              </View>
              <View style={styles.feeRow}>
                <Text style={styles.feeSubLabel}>CBSE Digital Learning & STEM Labs</Text>
                <Text style={styles.feeSubLabel}>Included</Text>
              </View>
              <View style={styles.feeRow}>
                <Text style={styles.feeSubLabel}>Arterial Transport Pilot Surcharge</Text>
                <Text style={styles.feeSubLabel}>Included</Text>
              </View>
            </View>

            {feeStatus.status === 'PAID' ? (
              <View style={styles.paidBox}>
                <Text style={styles.paidTitle}>✓ Payment Completed</Text>
                <Text style={styles.paidReceipt}>Receipt: {feeStatus.receiptNumber || 'REC-2026-03189'}</Text>
                <BOMISButton
                  title="Download Tax Receipt (PDF)"
                  onPress={() => Alert.alert('Tax Receipt', 'Downloading official tax receipt for IT Act Sec 80C compliance')}
                  variant="outline"
                  size="sm"
                  style={{ marginTop: 12 }}
                />
              </View>
            ) : (
              <View style={{ marginTop: 16 }}>
                <BOMISButton
                  title={`Pay Now (₹${feeStatus.amount.toLocaleString('en-IN')})`}
                  onPress={() => setShowFeeModal(true)}
                  variant="accent"
                />
              </View>
            )}
          </BOMISCard>

          {/* Payment Modal */}
          <Modal visible={showFeeModal} transparent animationType="slide">
            <View style={styles.modalOverlay}>
              <View style={styles.modalCard}>
                {!paymentSuccess ? (
                  <View>
                    <Text style={styles.modalTitle}>Fee Checkout</Text>
                    <Text style={styles.modalSubtitle}>
                      {feeStatus.termName} for {activeChild.firstName}
                    </Text>

                    <Text style={styles.modalAmount}>
                      ₹{feeStatus.amount.toLocaleString('en-IN')}
                    </Text>

                    <Text style={styles.methodTitle}>Select Payment Method:</Text>
                    {['RAZORPAY_UPI', 'RAZORPAY_NETBANKING', 'RAZORPAY_CARD'].map((m) => (
                      <TouchableOpacity
                        key={m}
                        style={[
                          styles.methodOption,
                          selectedMethod === m && styles.methodOptionActive,
                        ]}
                        onPress={() => setSelectedMethod(m)}
                      >
                        <Text
                          style={[
                            styles.methodText,
                            selectedMethod === m && styles.methodTextActive,
                          ]}
                        >
                          {m.replace('RAZORPAY_', '').replace('_', ' ')}
                        </Text>
                      </TouchableOpacity>
                    ))}

                    <View style={styles.modalActionRow}>
                      <BOMISButton
                        title="Cancel"
                        onPress={() => setShowFeeModal(false)}
                        variant="ghost"
                        style={{ flex: 1, marginRight: 8 }}
                      />
                      <BOMISButton
                        title="Pay with Razorpay"
                        onPress={handlePay}
                        loading={isPaying}
                        variant="accent"
                        style={{ flex: 2 }}
                      />
                    </View>
                  </View>
                ) : (
                  <View style={{ alignItems: 'center' }}>
                    <Text style={styles.successIcon}>✓</Text>
                    <Text style={styles.modalTitle}>Payment Successful!</Text>
                    <Text style={styles.paidReceipt}>Receipt: {paidReceipt}</Text>
                    <Text style={styles.successNote}>
                      Official tax receipt has been generated with Idempotency-Key guarantee.
                    </Text>
                    <BOMISButton
                      title="Done"
                      onPress={() => {
                        setShowFeeModal(false);
                        setPaymentSuccess(false);
                      }}
                      variant="primary"
                      style={{ marginTop: 16, width: '100%' }}
                    />
                  </View>
                )}
              </View>
            </View>
          </Modal>
        </View>
      )}

      {/* VIEW 4: Afternoon Dismissal Single-Use OTP & QR Card */}
      {activeTab === 'dismissal' && (
        <View>
          <BOMISCard
            title="Afternoon Campus Gate Pickup Pass"
            subtitle="Single-use OTP verified by campus gatekeepers for safe child dispersal"
            headerRight={
              <BOMISBadge
                label={dismissalPass.status}
                variant={
                  dismissalPass.status === 'ACTIVE' && !isOtpExpired
                    ? 'success'
                    : dismissalPass.status === 'USED'
                    ? 'info'
                    : 'danger'
                }
                size="sm"
              />
            }
          >
            {/* 6-Digit Gate Code Display with 30-min Countdown */}
            <View style={styles.otpCard}>
              <Text style={styles.otpPrompt}>SHOW THIS CODE AT GATE 1 OR GATE 2:</Text>

              <View style={[styles.otpDisplayBox, isOtpExpired && styles.otpBlurred]}>
                <Text style={styles.otpCodeText}>{dismissalPass.otp}</Text>
              </View>

              {/* Live 30-Minute Countdown Timer */}
              <View style={styles.timerRow}>
                <Text style={styles.timerLabel}>Validity Countdown:</Text>
                <Text
                  style={[
                    styles.timerValue,
                    secondsRemaining < 300 && { color: '#EF4444' },
                  ]}
                >
                  {isOtpExpired ? '00:00 (EXPIRED)' : formatCountdown(secondsRemaining)}
                </Text>
              </View>

              {/* Dynamic QR Pass String View */}
              <View style={styles.qrPayloadBox}>
                <Text style={styles.qrLabel}>Dynamic QR Pass Payload:</Text>
                <Text style={styles.qrText}>{dismissalPass.qrPayload}</Text>
              </View>
            </View>

            {/* Dismissal Actions */}
            <View style={styles.dismissalActions}>
              <BOMISButton
                title="Regenerate Fresh OTP"
                onPress={regenerateDismissalOtp}
                variant="outline"
                size="sm"
                style={{ flex: 1, marginRight: 8 }}
              />
              <BOMISButton
                title="Simulate Gatekeeper Scan"
                onPress={async () => {
                  const ok = await simulateGatekeeperScan('Gate 1');
                  if (ok) {
                    Alert.alert('Pickup Authorized', `Security confirmed pickup of ${activeChild.firstName} at Gate 1`);
                  } else {
                    Alert.alert('Scan Failed', 'OTP is expired or already used');
                  }
                }}
                disabled={dismissalPass.status === 'USED' || isOtpExpired}
                variant="primary"
                size="sm"
                style={{ flex: 1 }}
              />
            </View>
          </BOMISCard>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  siblingSwitcher: {
    marginBottom: 16,
  },
  switcherLabel: {
    fontSize: 11,
    fontWeight: '800',
    color: '#64748B',
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  siblingButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  siblingButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    borderRadius: 12,
    padding: 10,
    gap: 8,
  },
  siblingButtonActive: {
    borderColor: '#FF6B4A',
    backgroundColor: '#FFF5F2',
  },
  childAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  childAvatarActive: {
    backgroundColor: '#FF6B4A',
  },
  childAvatarText: {
    color: '#0F2942',
    fontWeight: '700',
    fontSize: 14,
  },
  siblingName: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A',
  },
  siblingNameActive: {
    color: '#94311B',
  },
  siblingGrade: {
    fontSize: 11,
    color: '#64748B',
  },
  geofenceBanner: {
    backgroundColor: '#FFFBEB',
    borderWidth: 1.5,
    borderColor: '#FDE68A',
    borderRadius: 12,
    padding: 14,
    marginBottom: 16,
  },
  geofenceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  dismissText: {
    fontSize: 14,
    color: '#92400E',
    fontWeight: 'bold',
    paddingHorizontal: 4,
  },
  geofenceTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: '#92400E',
    marginBottom: 4,
  },
  geofenceBody: {
    fontSize: 12,
    color: '#B45309',
    lineHeight: 18,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#E2E8F0',
    borderRadius: 10,
    padding: 3,
    marginBottom: 16,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  tabItemActive: {
    backgroundColor: '#0F2942',
  },
  tabText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
  },
  tabTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  profileRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  profileCol: {
    flex: 1,
  },
  profileLabel: {
    fontSize: 11,
    color: '#64748B',
    marginBottom: 2,
  },
  profileValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0F172A',
  },
  metricGrid: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  metricBox: {
    backgroundColor: '#ECFDF5',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
    minWidth: 100,
  },
  metricBig: {
    fontSize: 26,
    fontWeight: '900',
    color: '#065F46',
  },
  metricLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: '#065F46',
    marginTop: 2,
  },
  metricDetails: {
    flex: 1,
    gap: 4,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  detailName: {
    fontSize: 12,
    color: '#64748B',
  },
  detailVal: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A',
  },
  calendarPreview: {
    marginTop: 4,
  },
  previewTitle: {
    fontSize: 11,
    color: '#64748B',
    fontWeight: '600',
    marginBottom: 8,
  },
  dotStrip: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  dayDot: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dayDotText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
  },
  telemetryBox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#F1F5F9',
    padding: 12,
    borderRadius: 10,
    marginBottom: 12,
  },
  telemetryItem: {
    alignItems: 'center',
  },
  telemetryLabel: {
    fontSize: 10,
    color: '#64748B',
    marginBottom: 2,
  },
  telemetryValue: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A',
  },
  boardingNotice: {
    backgroundColor: '#ECFDF5',
    padding: 10,
    borderRadius: 8,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#A7F3D0',
  },
  boardingText: {
    color: '#065F46',
    fontSize: 12,
    fontWeight: '600',
  },
  timeline: {
    marginBottom: 16,
    gap: 12,
  },
  timelineItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  timelineNode: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#CBD5E1',
    marginTop: 4,
    marginRight: 12,
  },
  timelineNodeDone: {
    backgroundColor: '#10B981',
  },
  timelineNodeActive: {
    backgroundColor: '#FF6B4A',
    transform: [{ scale: 1.3 }],
  },
  timelineContent: {
    flex: 1,
  },
  stopName: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0F172A',
  },
  stopStatus: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 1,
  },
  busActionRow: {
    flexDirection: 'row',
  },
  feeBreakdown: {
    gap: 8,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  feeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  feeLabel: {
    fontSize: 14,
    fontWeight: '700',
    color: '#0F172A',
  },
  feeAmount: {
    fontSize: 15,
    fontWeight: '800',
    color: '#0F2942',
  },
  feeSubLabel: {
    fontSize: 12,
    color: '#64748B',
  },
  paidBox: {
    backgroundColor: '#ECFDF5',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 12,
  },
  paidTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: '#065F46',
  },
  paidReceipt: {
    fontSize: 12,
    color: '#047857',
    marginTop: 2,
    fontFamily: 'monospace',
  },
  otpCard: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  otpPrompt: {
    fontSize: 11,
    fontWeight: '800',
    color: '#64748B',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  otpDisplayBox: {
    backgroundColor: '#0F2942',
    paddingVertical: 14,
    paddingHorizontal: 28,
    borderRadius: 12,
    marginBottom: 12,
  },
  otpBlurred: {
    opacity: 0.3,
  },
  otpCodeText: {
    color: '#FFFFFF',
    fontSize: 32,
    fontWeight: '900',
    fontFamily: 'monospace',
    letterSpacing: 6,
  },
  timerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
  },
  timerLabel: {
    fontSize: 12,
    color: '#64748B',
  },
  timerValue: {
    fontSize: 13,
    fontWeight: '800',
    color: '#FF6B4A',
  },
  qrPayloadBox: {
    backgroundColor: '#F1F5F9',
    padding: 10,
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
  },
  qrLabel: {
    fontSize: 10,
    color: '#64748B',
    fontWeight: '600',
  },
  qrText: {
    fontSize: 11,
    color: '#0F172A',
    fontFamily: 'monospace',
    marginTop: 2,
  },
  dismissalActions: {
    flexDirection: 'row',
    marginTop: 16,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 41, 66, 0.7)',
    justifyContent: 'center',
    padding: 20,
  },
  modalCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#0F2942',
    textAlign: 'center',
  },
  modalSubtitle: {
    fontSize: 12,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 2,
    marginBottom: 12,
  },
  modalAmount: {
    fontSize: 28,
    fontWeight: '900',
    color: '#0F2942',
    textAlign: 'center',
    marginBottom: 16,
  },
  methodTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 8,
  },
  methodOption: {
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    padding: 12,
    borderRadius: 10,
    marginBottom: 8,
  },
  methodOptionActive: {
    borderColor: '#FF6B4A',
    backgroundColor: '#FFF5F2',
  },
  methodText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#475569',
  },
  methodTextActive: {
    color: '#94311B',
    fontWeight: '700',
  },
  modalActionRow: {
    flexDirection: 'row',
    marginTop: 16,
  },
  successIcon: {
    fontSize: 48,
    color: '#10B981',
    fontWeight: 'bold',
    marginBottom: 8,
  },
  successNote: {
    fontSize: 12,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 8,
  },
});
