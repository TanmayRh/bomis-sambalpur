/**
 * TeacherScreen - Rapid Attendance Grid (<10s SLA) & Offline Outbox Sync
 * Conforms to ADR 0004 & Master Implementation Blueprint.
 * Features: 40-student roster, 1-click "Mark All Present", exception cycling,
 * stopwatch SLA timer, offline queue integration, and Homework Announcement Poster.
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { AttendanceStatus } from '@bomis/shared';
import { BOMISCard } from '../components/ui/BOMISCard';
import { BOMISButton } from '../components/ui/BOMISButton';
import { BOMISBadge } from '../components/ui/BOMISBadge';
import { BOMISInput } from '../components/ui/BOMISInput';
import { defaultSyncManager } from '../services/sync-manager';
import { defaultApiClient } from '../services/api-client';

interface StudentRosterItem {
  id: string;
  name: string;
  rollNo: number;
  status: AttendanceStatus;
}

// Canonical 40-student roster for Grade 5A
const GRADE_5A_ROSTER: StudentRosterItem[] = [
  { id: 'b1000000-0005-4000-8000-000000000001', name: 'Aarav Patel', rollNo: 1, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000002', name: 'Isha Mohanty', rollNo: 2, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000003', name: 'Rohan Das', rollNo: 3, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000004', name: 'Ananya Panda', rollNo: 4, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000005', name: 'Subrat Mishra', rollNo: 5, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000006', name: 'Pooja Naik', rollNo: 6, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000007', name: 'Alok Meher', rollNo: 7, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000008', name: 'Satyabrata Pradhan', rollNo: 8, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000009', name: 'Deepika Sahu', rollNo: 9, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000010', name: 'Manish Tripathy', rollNo: 10, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000011', name: 'Ritika Senapati', rollNo: 11, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000012', name: 'Debashis Bhoi', rollNo: 12, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000013', name: 'Smruti Rekha Hota', rollNo: 13, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000014', name: 'Pritam Samal', rollNo: 14, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000015', name: 'Archana Barik', rollNo: 15, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000016', name: 'Siddharth Agrawal', rollNo: 16, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000017', name: 'Bhavna Kedia', rollNo: 17, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000018', name: 'Chirag Seth', rollNo: 18, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000019', name: 'Divya Rungta', rollNo: 19, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000020', name: 'Eshaan Jhunjhunwala', rollNo: 20, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000021', name: 'Gauri Sharma', rollNo: 21, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000022', name: 'Harsh Vardhan', rollNo: 22, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000023', name: 'Indrani Deb', rollNo: 23, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000024', name: 'Jayant Mohapatra', rollNo: 24, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000025', name: 'Kalyani Behera', rollNo: 25, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000026', name: 'Lalit Bag', rollNo: 26, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000027', name: 'Meera Padhi', rollNo: 27, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000028', name: 'Nikhil Swain', rollNo: 28, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000029', name: 'Ojasvi Rout', rollNo: 29, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000030', name: 'Pranav Acharya', rollNo: 30, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000031', name: 'Qadir Khan', rollNo: 31, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000032', name: 'Rupali Majhi', rollNo: 32, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000033', name: 'Shreya Panigrahi', rollNo: 33, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000034', name: 'Tanmayee Kar', rollNo: 34, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000035', name: 'Utkarsh Dalai', rollNo: 35, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000036', name: 'Vaishnavi Sethi', rollNo: 36, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000037', name: 'Waseem Akram', rollNo: 37, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000038', name: 'Yashodhara Ray', rollNo: 38, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000039', name: 'Zoya Parween', rollNo: 39, status: AttendanceStatus.PRESENT },
  { id: 'b1000000-0005-4000-8000-000000000040', name: 'Bhabani Shankar Das', rollNo: 40, status: AttendanceStatus.PRESENT },
];

export const TeacherScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'attendance' | 'homework'>('attendance');
  const [roster, setRoster] = useState<StudentRosterItem[]>(GRADE_5A_ROSTER);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [slaTime, setSlaTime] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [pendingOutboxCount, setPendingOutboxCount] = useState<number>(0);

  // Homework Poster Form State
  const [hwSubject, setHwSubject] = useState<string>('Mathematics');
  const [hwTitle, setHwTitle] = useState<string>('');
  const [hwDescription, setHwDescription] = useState<string>('');
  const [hwDueDate, setHwDueDate] = useState<string>('2026-10-25');
  const [postedHwList, setPostedHwList] = useState<Array<{ id: string; title: string; subject: string; readCount: string }>>([
    { id: 'h1', title: 'Fractions Exercise 4.2', subject: 'Mathematics', readCount: '38/40 Parents' },
  ]);

  // Sync state observer
  useEffect(() => {
    const unsub = defaultSyncManager.subscribeStats((stats) => {
      setPendingOutboxCount(stats.pendingCount);
      setIsOnline(stats.isOnline);
    });
    return unsub;
  }, []);

  const toggleNetworkSimulator = () => {
    const nextState = !isOnline;
    setIsOnline(nextState);
    defaultSyncManager.getNetworkMonitor().setOnline(nextState);
  };

  // 1-Click "Mark All Present"
  const markAllPresent = () => {
    setRoster((prev) => prev.map((s) => ({ ...s, status: AttendanceStatus.PRESENT })));
  };

  // Exception Cycling: PRESENT -> ABSENT -> LATE -> HALF_DAY -> PRESENT
  const cycleException = (studentId: string) => {
    setRoster((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          let nextStatus: AttendanceStatus;
          if (s.status === AttendanceStatus.PRESENT) nextStatus = AttendanceStatus.ABSENT;
          else if (s.status === AttendanceStatus.ABSENT) nextStatus = AttendanceStatus.LATE;
          else if (s.status === AttendanceStatus.LATE) nextStatus = AttendanceStatus.HALF_DAY;
          else nextStatus = AttendanceStatus.PRESENT;
          return { ...s, status: nextStatus };
        }
        return s;
      })
    );
  };

  // Rapid Attendance Submission (<10s SLA)
  const submitAttendanceBatch = async () => {
    const startTime = performance.now();
    setIsSubmitting(true);

    const exceptions = roster
      .filter((s) => s.status !== AttendanceStatus.PRESENT)
      .map((s) => ({
        studentId: s.id,
        status: s.status,
        remarks: `Marked in classroom roll call`,
      }));

    const batchPayload = {
      date: new Date().toISOString().split('T')[0],
      classId: 'c1000000-0005-4000-8000-000000000001',
      sectionId: 's1000000-0005-4000-8000-000000000001',
      defaultStatus: AttendanceStatus.PRESENT,
      exceptions,
    };

    try {
      if (isOnline) {
        await defaultApiClient.post('/attendance', batchPayload);
      } else {
        // Enqueue into local durable outbox
        await defaultSyncManager.enqueueMutation('ATTENDANCE_BATCH', batchPayload);
      }

      const elapsed = ((performance.now() - startTime) / 1000).toFixed(2);
      setSlaTime(`${elapsed}s`);

      Alert.alert(
        isOnline ? 'Batch Recorded (Online)' : 'Batch Queued (Offline Mode)',
        `40 students processed in ${elapsed}s (SLA < 10s passed). ${exceptions.length} exceptions recorded.`
      );
    } catch {
      // Offline fallback: enqueue into outbox
      await defaultSyncManager.enqueueMutation('ATTENDANCE_BATCH', batchPayload);
      const elapsed = ((performance.now() - startTime) / 1000).toFixed(2);
      setSlaTime(`${elapsed}s`);
      Alert.alert('Offline Outbox', `Network unavailable. Batch queued locally in ${elapsed}s.`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSyncNow = async () => {
    try {
      const res = await defaultSyncManager.syncPending();
      if (res) {
        Alert.alert('Sync Complete', `Synchronized ${res.syncedCount} queued batches with backend.`);
      } else {
        Alert.alert('Sync', 'No pending batches to synchronize.');
      }
    } catch (err: any) {
      Alert.alert('Sync Error', err.message || 'Synchronization failed');
    }
  };

  const handlePostHomework = () => {
    if (!hwTitle.trim()) {
      Alert.alert('Required', 'Please enter an assignment title');
      return;
    }

    setPostedHwList((prev) => [
      {
        id: `hw-${Date.now()}`,
        title: hwTitle,
        subject: hwSubject,
        readCount: '0/40 Parents',
      },
      ...prev,
    ]);

    setHwTitle('');
    setHwDescription('');
    Alert.alert('Broadcast Sent', `Homework for ${hwSubject} has been published and dispatched to parents.`);
  };

  // Metrics computation
  const presentCount = roster.filter((s) => s.status === AttendanceStatus.PRESENT).length;
  const absentCount = roster.filter((s) => s.status === AttendanceStatus.ABSENT).length;
  const lateCount = roster.filter((s) => s.status === AttendanceStatus.LATE).length;
  const halfDayCount = roster.filter((s) => s.status === AttendanceStatus.HALF_DAY).length;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Network Simulator Strip */}
      <View style={styles.networkBar}>
        <View style={styles.networkLeft}>
          <View style={[styles.networkDot, { backgroundColor: isOnline ? '#10B981' : '#EF4444' }]} />
          <Text style={styles.networkText}>
            {isOnline ? 'ONLINE: Connected to BOMIS Sambalpur API' : 'OFFLINE MODE: Caching mutations to outbox'}
          </Text>
        </View>
        <TouchableOpacity style={styles.networkToggle} onPress={toggleNetworkSimulator}>
          <Text style={styles.networkToggleText}>{isOnline ? 'Simulate Offline' : 'Go Online'}</Text>
        </TouchableOpacity>
      </View>

      {/* Offline Outbox Queue Banner */}
      {pendingOutboxCount > 0 && (
        <View style={styles.outboxBanner}>
          <View style={{ flex: 1 }}>
            <Text style={styles.outboxTitle}>Offline Queue: {pendingOutboxCount} Batch(es) Pending</Text>
            <Text style={styles.outboxSub}>Saved locally with client UUID & Idempotency Key</Text>
          </View>
          <BOMISButton
            title="Sync Now"
            onPress={handleSyncNow}
            variant="accent"
            size="sm"
          />
        </View>
      )}

      {/* Tabs */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'attendance' && styles.tabItemActive]}
          onPress={() => setActiveTab('attendance')}
        >
          <Text style={[styles.tabText, activeTab === 'attendance' && styles.tabTextActive]}>
            Rapid Attendance (Grade 5A)
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'homework' && styles.tabItemActive]}
          onPress={() => setActiveTab('homework')}
        >
          <Text style={[styles.tabText, activeTab === 'homework' && styles.tabTextActive]}>
            Homework Poster
          </Text>
        </TouchableOpacity>
      </View>

      {/* VIEW 1: Rapid Attendance Grid */}
      {activeTab === 'attendance' && (
        <View>
          <BOMISCard
            title="Class 5A Morning Roll Call (<10s SLA)"
            subtitle="Tap any student to cycle: Present → Absent → Late → Half-day"
            headerRight={
              slaTime ? (
                <BOMISBadge label={`SLA: ${slaTime}`} variant="success" size="sm" />
              ) : null
            }
          >
            {/* Real-Time Metrics Strip */}
            <View style={styles.countsRow}>
              <View style={[styles.countPill, { backgroundColor: '#ECFDF5' }]}>
                <Text style={[styles.countVal, { color: '#065F46' }]}>{presentCount}</Text>
                <Text style={styles.countName}>Present</Text>
              </View>
              <View style={[styles.countPill, { backgroundColor: '#FEF2F2' }]}>
                <Text style={[styles.countVal, { color: '#991B1B' }]}>{absentCount}</Text>
                <Text style={styles.countName}>Absent</Text>
              </View>
              <View style={[styles.countPill, { backgroundColor: '#FFFBEB' }]}>
                <Text style={[styles.countVal, { color: '#92400E' }]}>{lateCount}</Text>
                <Text style={styles.countName}>Late</Text>
              </View>
              <View style={[styles.countPill, { backgroundColor: '#EFF6FF' }]}>
                <Text style={[styles.countVal, { color: '#1E40AF' }]}>{halfDayCount}</Text>
                <Text style={styles.countName}>Half Day</Text>
              </View>
            </View>

            {/* Quick Action Buttons */}
            <View style={styles.actionRow}>
              <BOMISButton
                title="1-Click Mark All Present"
                onPress={markAllPresent}
                variant="outline"
                size="sm"
                style={{ flex: 1, marginRight: 8 }}
              />
              <BOMISButton
                title="Submit Attendance"
                onPress={submitAttendanceBatch}
                loading={isSubmitting}
                variant="primary"
                size="sm"
                style={{ flex: 1 }}
              />
            </View>

            {/* 40-Student Roster Grid */}
            <View style={styles.rosterList}>
              {roster.map((student) => (
                <TouchableOpacity
                  key={student.id}
                  style={styles.rosterRow}
                  onPress={() => cycleException(student.id)}
                  activeOpacity={0.7}
                >
                  <View style={styles.rosterLeft}>
                    <Text style={styles.rollNo}>#{student.rollNo}</Text>
                    <Text style={styles.studentName}>{student.name}</Text>
                  </View>
                  <BOMISBadge
                    label={student.status}
                    variant={student.status}
                    size="sm"
                  />
                </TouchableOpacity>
              ))}
            </View>
          </BOMISCard>
        </View>
      )}

      {/* VIEW 2: Homework Announcement Poster */}
      {activeTab === 'homework' && (
        <View>
          <BOMISCard
            title="Publish New Assignment"
            subtitle="Broadcasts notification to all Grade 5A student & parent portals"
          >
            <BOMISInput
              label="Subject"
              value={hwSubject}
              onChangeText={setHwSubject}
              placeholder="Mathematics, Science, English..."
            />

            <BOMISInput
              label="Assignment Title"
              value={hwTitle}
              onChangeText={setHwTitle}
              placeholder="e.g. Chapter 5 Algebraic Expressions"
            />

            <BOMISInput
              label="Submission Due Date"
              value={hwDueDate}
              onChangeText={setHwDueDate}
              placeholder="YYYY-MM-DD"
            />

            <BOMISInput
              label="Detailed Instructions"
              value={hwDescription}
              onChangeText={setHwDescription}
              placeholder="Instructions for students and parents..."
            />

            <BOMISButton
              title="Post Assignment & Broadcast"
              onPress={handlePostHomework}
              variant="accent"
              style={{ marginTop: 8 }}
            />
          </BOMISCard>

          {/* History of Posted Assignments */}
          <BOMISCard
            title="Recent Assignments (Grade 5A)"
            subtitle="Real-time parent read receipts"
          >
            {postedHwList.map((item) => (
              <View key={item.id} style={styles.historyRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.historyTitle}>{item.title}</Text>
                  <Text style={styles.historySub}>{item.subject}</Text>
                </View>
                <BOMISBadge label={item.readCount} variant="info" size="sm" />
              </View>
            ))}
          </BOMISCard>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  networkBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 10,
    padding: 10,
    marginBottom: 12,
  },
  networkLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  networkDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  networkText: {
    fontSize: 11,
    color: '#0F172A',
    fontWeight: '600',
    flex: 1,
  },
  networkToggle: {
    backgroundColor: '#E2E8F0',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 6,
  },
  networkToggleText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#0F172A',
  },
  outboxBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFF5F2',
    borderWidth: 1.5,
    borderColor: '#FFD4CB',
    borderRadius: 12,
    padding: 12,
    marginBottom: 14,
  },
  outboxTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#94311B',
  },
  outboxSub: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 2,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#E2E8F0',
    borderRadius: 10,
    padding: 3,
    marginBottom: 16,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  tabItemActive: {
    backgroundColor: '#0F2942',
  },
  tabText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
  },
  tabTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  countsRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 14,
  },
  countPill: {
    flex: 1,
    padding: 8,
    borderRadius: 8,
    alignItems: 'center',
  },
  countVal: {
    fontSize: 18,
    fontWeight: '900',
  },
  countName: {
    fontSize: 10,
    fontWeight: '700',
    color: '#64748B',
    marginTop: 1,
  },
  actionRow: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  rosterList: {
    gap: 6,
  },
  rosterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  rosterLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  rollNo: {
    fontSize: 12,
    fontWeight: '800',
    color: '#64748B',
    width: 32,
  },
  studentName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0F172A',
  },
  historyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  historyTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#0F172A',
  },
  historySub: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 2,
  },
});
