/**
 * DriverScreen - Transport Pilot Hub, Live GPS Broadcaster & Student QR Scanner
 * Conforms to ADR 0004 & Transport Fleet Telemetry specifications.
 * Features: Route 1 Budharaja Shuttle stops list, live GPS broadcaster toggle (5s pings),
 * and student boarding/deboarding QR scanner with manual search fallback.
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { BOMISCard } from '../components/ui/BOMISCard';
import { BOMISButton } from '../components/ui/BOMISButton';
import { BOMISBadge } from '../components/ui/BOMISBadge';
import { BOMISInput } from '../components/ui/BOMISInput';
import { defaultLocationService, GpsCoordinate } from '../services/location-service';
import { defaultSyncManager } from '../services/sync-manager';
import { defaultApiClient } from '../services/api-client';

interface StopItem {
  id: string;
  name: string;
  time: string;
  boardedCount: number;
  status: 'DEPARTED' | 'CURRENT' | 'UPCOMING';
}

const ROUTE_1_STOPS: StopItem[] = [
  { id: 'st-01', name: 'Budharaja Fatak', time: '07:15 AM', boardedCount: 6, status: 'DEPARTED' },
  { id: 'p1000000-0001-4000-8000-000000000002', name: 'Sakhipada Chhak (Aarav Stop)', time: '07:25 AM', boardedCount: 8, status: 'CURRENT' },
  { id: 'st-03', name: 'Ainthapali Chowk', time: '07:35 AM', boardedCount: 4, status: 'UPCOMING' },
  { id: 'st-04', name: 'BOMIS Campus Gate', time: '07:45 AM', boardedCount: 0, status: 'UPCOMING' },
];

export const DriverScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'stops' | 'gps' | 'scanner'>('stops');

  // GPS Broadcaster state
  const [isGpsActive, setIsGpsActive] = useState<boolean>(defaultLocationService.isActive());
  const [currentCoord, setCurrentCoord] = useState<GpsCoordinate>(defaultLocationService.getLastCoordinate());
  const [isNearGeofence, setIsNearGeofence] = useState<boolean>(defaultLocationService.getIsNearGeofence());
  const [pingCount, setPingCount] = useState<number>(14);

  // Scanner state
  const [scanMode, setScanMode] = useState<'BOARD' | 'DEBOARD'>('BOARD');
  const [lastScannedStudent, setLastScannedStudent] = useState<any | null>(null);
  const [manualQuery, setManualQuery] = useState<string>('');
  const [stopsList] = useState<StopItem[]>(ROUTE_1_STOPS);

  // Subscribe to location service
  useEffect(() => {
    const unsub = defaultLocationService.subscribe((coord, near) => {
      setCurrentCoord(coord);
      setIsNearGeofence(near);
      setPingCount((c) => c + 1);
    });
    return unsub;
  }, []);

  const toggleGpsBroadcast = () => {
    if (isGpsActive) {
      defaultLocationService.stop();
      setIsGpsActive(false);
      Alert.alert('GPS Standby', 'Vehicle telemetry broadcasting has been paused.');
    } else {
      defaultLocationService.start();
      setIsGpsActive(true);
      Alert.alert('Broadcasting Live GPS', 'Transmitting GPS breadcrumbs every 5s to BOMIS transport server.');
    }
  };

  const handleSimulateScan = async (studentName: string = 'Aarav Patel', studentId: string = 'b1000000-0005-4000-8000-000000000001') => {
    const scanEvent = {
      busId: 'v1000000-0001-4000-8000-000000000001',
      studentId,
      stopId: 'p1000000-0001-4000-8000-000000000002',
      action: scanMode === 'BOARD' ? 'BOARDED' : 'DEBOARDED',
      lat: currentCoord.latitude,
      lng: currentCoord.longitude,
      timestamp: new Date().toISOString(),
    };

    try {
      if (defaultSyncManager.getNetworkMonitor().isOnline()) {
        await defaultApiClient.post('/transport/boarding/scan', scanEvent);
      } else {
        await defaultSyncManager.enqueueMutation('BOARDING_SCAN', scanEvent);
      }
    } catch {
      await defaultSyncManager.enqueueMutation('BOARDING_SCAN', scanEvent);
    }

    setLastScannedStudent({
      name: studentName,
      admissionNo: 'BOMIS-2021-0042',
      grade: 'Grade 5A',
      stop: 'Sakhipada Chhak',
      action: scanMode === 'BOARD' ? 'BOARDED' : 'DEBOARDED',
      time: new Date().toLocaleTimeString(),
    });

    Alert.alert(
      scanMode === 'BOARD' ? 'Student Boarded' : 'Student Deboarded',
      `${studentName} successfully registered at Sakhipada Chhak.`
    );
  };

  const handleManualFallback = () => {
    if (!manualQuery.trim()) {
      Alert.alert('Search Required', 'Enter student roll number or admission number');
      return;
    }
    handleSimulateScan(manualQuery, 'b1000000-0005-4000-8000-000000000001');
    setManualQuery('');
  };

  const totalBoarded = stopsList.reduce((acc, s) => acc + s.boardedCount, 0);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Route & Bus Identity Strip */}
      <View style={styles.identityBar}>
        <View>
          <Text style={styles.routeCode}>ROUTE 1 • RT-BUDHARAJA-01</Text>
          <Text style={styles.busPlate}>Tata Winger • OD-15-AB-1001 (Bus 01)</Text>
        </View>
        <BOMISBadge label={`${totalBoarded}/24 ONBOARD`} variant="accent" size="sm" />
      </View>

      {/* Tabs */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'stops' && styles.tabItemActive]}
          onPress={() => setActiveTab('stops')}
        >
          <Text style={[styles.tabText, activeTab === 'stops' && styles.tabTextActive]}>
            Stops List
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'gps' && styles.tabItemActive]}
          onPress={() => setActiveTab('gps')}
        >
          <Text style={[styles.tabText, activeTab === 'gps' && styles.tabTextActive]}>
            GPS Broadcaster
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'scanner' && styles.tabItemActive]}
          onPress={() => setActiveTab('scanner')}
        >
          <Text style={[styles.tabText, activeTab === 'scanner' && styles.tabTextActive]}>
            QR Pass Scanner
          </Text>
        </TouchableOpacity>
      </View>

      {/* VIEW 1: Route Stops List */}
      {activeTab === 'stops' && (
        <View>
          <BOMISCard
            title="Budharaja Shuttle Route Navigation"
            subtitle="Morning Pickup Run • 4 Arterial Stops"
            headerRight={
              <BOMISBadge
                label={isNearGeofence ? 'At Sakhipada Chhak' : 'In Transit'}
                variant={isNearGeofence ? 'warning' : 'info'}
                size="sm"
              />
            }
          >
            <View style={styles.stopsList}>
              {stopsList.map((stop, index) => {
                const isCurrent = stop.status === 'CURRENT';
                const isDone = stop.status === 'DEPARTED';
                return (
                  <View
                    key={stop.id}
                    style={[
                      styles.stopRow,
                      isCurrent && styles.stopRowCurrent,
                      isDone && styles.stopRowDone,
                    ]}
                  >
                    <View style={styles.stopLeft}>
                      <View
                        style={[
                          styles.stopNumberCircle,
                          isCurrent && styles.stopNumberCircleCurrent,
                          isDone && styles.stopNumberCircleDone,
                        ]}
                      >
                        <Text
                          style={[
                            styles.stopNumberText,
                            (isCurrent || isDone) && { color: '#FFFFFF' },
                          ]}
                        >
                          {index + 1}
                        </Text>
                      </View>
                      <View>
                        <Text style={styles.stopName}>{stop.name}</Text>
                        <Text style={styles.stopTime}>Scheduled: {stop.time}</Text>
                      </View>
                    </View>
                    <View style={styles.stopRight}>
                      <BOMISBadge
                        label={`${stop.boardedCount} Boarded`}
                        variant={isDone ? 'success' : isCurrent ? 'accent' : 'default'}
                        size="sm"
                      />
                    </View>
                  </View>
                );
              })}
            </View>
          </BOMISCard>
        </View>
      )}

      {/* VIEW 2: Live GPS Broadcaster Toggle */}
      {activeTab === 'gps' && (
        <View>
          <BOMISCard
            title="Real-Time Telemetry Broadcaster"
            subtitle="Emits 5-second periodic pings for parent proximity geofences"
            headerRight={
              <BOMISBadge
                label={isGpsActive ? 'TRANSMITTING' : 'PAUSED'}
                variant={isGpsActive ? 'success' : 'default'}
                size="sm"
              />
            }
          >
            {/* Master Broadcaster Button */}
            <BOMISButton
              title={isGpsActive ? 'Stop GPS Broadcast' : 'Start Live GPS Broadcast'}
              onPress={toggleGpsBroadcast}
              variant={isGpsActive ? 'danger' : 'accent'}
              size="lg"
              style={{ marginBottom: 16 }}
            />

            {/* Live GPS Coordinates Panel */}
            <View style={styles.telemetryPanel}>
              <View style={styles.telemetryRow}>
                <Text style={styles.panelLabel}>Latitude:</Text>
                <Text style={styles.panelVal}>{currentCoord.latitude.toFixed(6)}° N</Text>
              </View>
              <View style={styles.telemetryRow}>
                <Text style={styles.panelLabel}>Longitude:</Text>
                <Text style={styles.panelVal}>{currentCoord.longitude.toFixed(6)}° E</Text>
              </View>
              <View style={styles.telemetryRow}>
                <Text style={styles.panelLabel}>Road Speed:</Text>
                <Text style={styles.panelVal}>{currentCoord.speed} km/h</Text>
              </View>
              <View style={styles.telemetryRow}>
                <Text style={styles.panelLabel}>Heading:</Text>
                <Text style={styles.panelVal}>{currentCoord.heading}° North-East</Text>
              </View>
              <View style={styles.telemetryRow}>
                <Text style={styles.panelLabel}>Broadcast Pings Sent:</Text>
                <Text style={[styles.panelVal, { color: '#0F2942' }]}>{pingCount}</Text>
              </View>
            </View>

            {/* Geofence Alert State */}
            {isNearGeofence ? (
              <View style={styles.geofenceActiveBox}>
                <Text style={styles.geofenceActiveTitle}>
                  ★ 5-Minute Proximity Geofence Triggered!
                </Text>
                <Text style={styles.geofenceActiveSub}>
                  Vehicle is within 1.5 km of Sakhipada Chhak. Parents of Aarav Patel and Ananya Patel have received push notifications.
                </Text>
              </View>
            ) : (
              <View style={styles.geofenceInactiveBox}>
                <Text style={styles.geofenceInactiveText}>
                  Normal Route Transit • Next geofence alert at Sakhipada Chhak.
                </Text>
              </View>
            )}
          </BOMISCard>
        </View>
      )}

      {/* VIEW 3: Student Boarding QR Scanner with Manual Fallback */}
      {activeTab === 'scanner' && (
        <View>
          <BOMISCard
            title="Student Boarding / Deboarding"
            subtitle="Scan student digital ID card QR code or search manually"
          >
            {/* Mode Selector */}
            <View style={styles.scanModeTabs}>
              <TouchableOpacity
                style={[styles.scanModeTab, scanMode === 'BOARD' && styles.scanModeTabActive]}
                onPress={() => setScanMode('BOARD')}
              >
                <Text style={[styles.scanModeText, scanMode === 'BOARD' && styles.scanModeTextActive]}>
                  Morning Boarding
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.scanModeTab, scanMode === 'DEBOARD' && styles.scanModeTabActive]}
                onPress={() => setScanMode('DEBOARD')}
              >
                <Text style={[styles.scanModeText, scanMode === 'DEBOARD' && styles.scanModeTextActive]}>
                  Afternoon Drop
                </Text>
              </TouchableOpacity>
            </View>

            {/* Camera Viewfinder Viewport Simulation */}
            <View style={styles.viewfinder}>
              <View style={styles.viewfinderCrosshairs} />
              <Text style={styles.viewfinderText}>Align Student ID Card QR inside frame</Text>
              <View style={styles.laserLine} />
            </View>

            {/* 1-Tap Quick Scan Preset for Aarav Patel */}
            <BOMISButton
              title="⚡ 1-Tap Scan: Aarav Patel (Grade 5A)"
              onPress={() => handleSimulateScan('Aarav Patel', 'b1000000-0005-4000-8000-000000000001')}
              variant="accent"
              size="md"
              style={{ marginTop: 12 }}
            />

            {/* Last Scanned Result Banner */}
            {lastScannedStudent && (
              <View style={styles.scannedResultCard}>
                <View style={styles.resultHeader}>
                  <Text style={styles.resultTitle}>✓ Last Scan Verified</Text>
                  <BOMISBadge label={lastScannedStudent.action} variant="success" size="sm" />
                </View>
                <Text style={styles.resultName}>{lastScannedStudent.name}</Text>
                <Text style={styles.resultMeta}>
                  {lastScannedStudent.grade} • Adm: {lastScannedStudent.admissionNo} • Stop: {lastScannedStudent.stop}
                </Text>
                <Text style={styles.resultTime}>Scanned at {lastScannedStudent.time}</Text>
              </View>
            )}

            {/* Manual Entry Search Fallback */}
            <View style={styles.manualEntryBox}>
              <Text style={styles.manualTitle}>Manual Fallback (Forgot ID Card):</Text>
              <BOMISInput
                value={manualQuery}
                onChangeText={setManualQuery}
                placeholder="Enter Roll # or Admission No..."
              />
              <BOMISButton
                title="Mark Student Onboard (Manual)"
                onPress={handleManualFallback}
                variant="outline"
                size="sm"
              />
            </View>
          </BOMISCard>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  identityBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#0F2942',
    padding: 12,
    borderRadius: 12,
    marginBottom: 16,
  },
  routeCode: {
    color: '#FF6B4A',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  busPlate: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '700',
    marginTop: 2,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#E2E8F0',
    borderRadius: 10,
    padding: 3,
    marginBottom: 16,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  tabItemActive: {
    backgroundColor: '#0F2942',
  },
  tabText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
  },
  tabTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  stopsList: {
    gap: 8,
  },
  stopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderRadius: 10,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  stopRowCurrent: {
    backgroundColor: '#FFF5F2',
    borderColor: '#FF6B4A',
  },
  stopRowDone: {
    opacity: 0.7,
  },
  stopLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  stopNumberCircle: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stopNumberCircleCurrent: {
    backgroundColor: '#FF6B4A',
  },
  stopNumberCircleDone: {
    backgroundColor: '#10B981',
  },
  stopNumberText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#0F2942',
  },
  stopName: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A',
  },
  stopTime: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 1,
  },
  stopRight: {},
  telemetryPanel: {
    backgroundColor: '#F1F5F9',
    borderRadius: 10,
    padding: 12,
    gap: 8,
    marginBottom: 14,
  },
  telemetryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  panelLabel: {
    fontSize: 12,
    color: '#64748B',
  },
  panelVal: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A',
  },
  geofenceActiveBox: {
    backgroundColor: '#FFFBEB',
    borderWidth: 1.5,
    borderColor: '#FDE68A',
    borderRadius: 10,
    padding: 12,
  },
  geofenceActiveTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#92400E',
  },
  geofenceActiveSub: {
    fontSize: 11,
    color: '#B45309',
    marginTop: 4,
    lineHeight: 16,
  },
  geofenceInactiveBox: {
    backgroundColor: '#F8FAFC',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  geofenceInactiveText: {
    fontSize: 11,
    color: '#64748B',
  },
  scanModeTabs: {
    flexDirection: 'row',
    backgroundColor: '#F1F5F9',
    borderRadius: 8,
    padding: 3,
    marginBottom: 12,
  },
  scanModeTab: {
    flex: 1,
    paddingVertical: 6,
    alignItems: 'center',
    borderRadius: 6,
  },
  scanModeTabActive: {
    backgroundColor: '#FFFFFF',
  },
  scanModeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748B',
  },
  scanModeTextActive: {
    color: '#0F2942',
    fontWeight: '700',
  },
  viewfinder: {
    height: 140,
    backgroundColor: '#071726',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#3D7FB5',
    position: 'relative',
    overflow: 'hidden',
  },
  viewfinderCrosshairs: {
    width: 80,
    height: 80,
    borderWidth: 1.5,
    borderColor: '#FF6B4A',
    borderRadius: 8,
  },
  viewfinderText: {
    color: '#D2E3F0',
    fontSize: 11,
    marginTop: 8,
  },
  laserLine: {
    position: 'absolute',
    top: 70,
    left: 20,
    right: 20,
    height: 2,
    backgroundColor: '#EF4444',
  },
  scannedResultCard: {
    backgroundColor: '#ECFDF5',
    borderWidth: 1,
    borderColor: '#A7F3D0',
    borderRadius: 10,
    padding: 12,
    marginTop: 12,
  },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  resultTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: '#065F46',
  },
  resultName: {
    fontSize: 16,
    fontWeight: '800',
    color: '#065F46',
  },
  resultMeta: {
    fontSize: 12,
    color: '#047857',
    marginTop: 2,
  },
  resultTime: {
    fontSize: 10,
    color: '#059669',
    marginTop: 4,
  },
  manualEntryBox: {
    marginTop: 16,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  manualTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A',
    marginBottom: 8,
  },
});
