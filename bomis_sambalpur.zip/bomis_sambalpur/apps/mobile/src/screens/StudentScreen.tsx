/**
 * StudentScreen - Student Digital Identity, Homework, and Timetable
 * Conforms to Master Implementation Blueprint & ADR 0004.
 * Features: Digital Student ID Card with dynamic QR code (House Kalinga, emergency contacts, medical notes),
 * Homework & Digital Diary with status toggles, and weekly class timetable schedule.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { BOMISCard } from '../components/ui/BOMISCard';
import { BOMISBadge } from '../components/ui/BOMISBadge';
import { BOMISButton } from '../components/ui/BOMISButton';

interface HomeworkItem {
  id: string;
  subject: string;
  title: string;
  description: string;
  dueDate: string;
  status: 'ASSIGNED' | 'SUBMITTED' | 'REVIEWED';
  teacher: string;
}

const INITIAL_HOMEWORK: HomeworkItem[] = [
  {
    id: 'hw-01',
    subject: 'Mathematics',
    title: 'Fractions & Decimals Exercise 4.2',
    description: 'Solve questions 1 through 15 in notebook. Show all conversion steps clearly.',
    dueDate: '2026-10-23',
    status: 'ASSIGNED',
    teacher: 'Mrs. Arundhati Dash',
  },
  {
    id: 'hw-02',
    subject: 'Science',
    title: 'Plant Photosynthesis Diagram',
    description: 'Draw and label the chlorophyll light absorption mechanism in your lab journal.',
    dueDate: '2026-10-24',
    status: 'SUBMITTED',
    teacher: 'Mr. Subrat Pradhan',
  },
  {
    id: 'hw-03',
    subject: 'English',
    title: 'Mahanadi River Essay',
    description: 'Write a 200-word descriptive essay about the Sambalpur Hirakud ecosystem.',
    dueDate: '2026-10-25',
    status: 'ASSIGNED',
    teacher: 'Ms. Priyadarshini Mishra',
  },
  {
    id: 'hw-04',
    subject: 'Odia',
    title: 'Kabi Prana Bhabana Recitation',
    description: 'Memorize Stanzas 1-4 for classroom oral presentation.',
    dueDate: '2026-10-26',
    status: 'REVIEWED',
    teacher: 'Mr. Bibhuti Sahoo',
  },
];

const WEEKLY_TIMETABLE: Record<string, Array<{ period: number; time: string; subject: string; teacher: string; room: string }>> = {
  Monday: [
    { period: 1, time: '08:00 - 08:45 AM', subject: 'Mathematics', teacher: 'Mrs. Arundhati Dash', room: 'Room 201' },
    { period: 2, time: '08:45 - 09:30 AM', subject: 'English', teacher: 'Ms. Priyadarshini Mishra', room: 'Room 201' },
    { period: 3, time: '09:30 - 10:15 AM', subject: 'Science', teacher: 'Mr. Subrat Pradhan', room: 'Science Lab A' },
    { period: 4, time: '10:30 - 11:15 AM', subject: 'Social Studies', teacher: 'Mr. Ashok Panigrahi', room: 'Room 201' },
    { period: 5, time: '11:15 - 12:00 PM', subject: 'Odia', teacher: 'Mr. Bibhuti Sahoo', room: 'Room 201' },
    { period: 6, time: '12:45 - 01:30 PM', subject: 'Computer & AI', teacher: 'Mrs. Sneha Naik', room: 'Computer Lab' },
    { period: 7, time: '01:30 - 02:15 PM', subject: 'Physical Education', teacher: 'Coach Rakesh Meher', room: 'Sports Complex' },
    { period: 8, time: '02:15 - 03:00 PM', subject: 'Library & Reading', teacher: 'Mrs. Sunita Panda', room: 'Central Library' },
  ],
  Tuesday: [
    { period: 1, time: '08:00 - 08:45 AM', subject: 'Science', teacher: 'Mr. Subrat Pradhan', room: 'Science Lab A' },
    { period: 2, time: '08:45 - 09:30 AM', subject: 'Mathematics', teacher: 'Mrs. Arundhati Dash', room: 'Room 201' },
    { period: 3, time: '09:30 - 10:15 AM', subject: 'Hindi', teacher: 'Mrs. Kavita Verma', room: 'Room 201' },
    { period: 4, time: '10:30 - 11:15 AM', subject: 'English', teacher: 'Ms. Priyadarshini Mishra', room: 'Room 201' },
    { period: 5, time: '11:15 - 12:00 PM', subject: 'Robotics STEM', teacher: 'Mr. Aniket Das', room: 'Innovation Lab' },
    { period: 6, time: '12:45 - 01:30 PM', subject: 'Odia', teacher: 'Mr. Bibhuti Sahoo', room: 'Room 201' },
    { period: 7, time: '01:30 - 02:15 PM', subject: 'Art & Craft', teacher: 'Mr. Dipak Tripathy', room: 'Art Studio' },
    { period: 8, time: '02:15 - 03:00 PM', subject: 'Value Education', teacher: 'Mrs. Arundhati Dash', room: 'Room 201' },
  ],
  Wednesday: [
    { period: 1, time: '08:00 - 08:45 AM', subject: 'Mathematics', teacher: 'Mrs. Arundhati Dash', room: 'Room 201' },
    { period: 2, time: '08:45 - 09:30 AM', subject: 'Social Studies', teacher: 'Mr. Ashok Panigrahi', room: 'Room 201' },
    { period: 3, time: '09:30 - 10:15 AM', subject: 'English', teacher: 'Ms. Priyadarshini Mishra', room: 'Room 201' },
    { period: 4, time: '10:30 - 11:15 AM', subject: 'Science', teacher: 'Mr. Subrat Pradhan', room: 'Room 201' },
    { period: 5, time: '11:15 - 12:00 PM', subject: 'Music & Drama', teacher: 'Mrs. Geetanjali Hota', room: 'Music Room' },
    { period: 6, time: '12:45 - 01:30 PM', subject: 'Hindi', teacher: 'Mrs. Kavita Verma', room: 'Room 201' },
    { period: 7, time: '01:30 - 02:15 PM', subject: 'Yoga & Wellness', teacher: 'Coach Rakesh Meher', room: 'Yoga Hall' },
    { period: 8, time: '02:15 - 03:00 PM', subject: 'Remedial Math', teacher: 'Mrs. Arundhati Dash', room: 'Room 201' },
  ],
};

export const StudentScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'idcard' | 'homework' | 'timetable'>('idcard');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [homeworkList, setHomeworkList] = useState<HomeworkItem[]>(INITIAL_HOMEWORK);
  const [selectedDay, setSelectedDay] = useState<string>('Monday');

  const toggleHomeworkStatus = (id: string) => {
    setHomeworkList((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nextStatus = item.status === 'ASSIGNED' ? 'SUBMITTED' : 'ASSIGNED';
          return { ...item, status: nextStatus };
        }
        return item;
      })
    );
  };

  const filteredHomework = selectedSubject === 'All'
    ? homeworkList
    : homeworkList.filter((h) => h.subject === selectedSubject);

  const timetableForDay = WEEKLY_TIMETABLE[selectedDay] || WEEKLY_TIMETABLE.Monday!;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Tab Segment Selector */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'idcard' && styles.tabItemActive]}
          onPress={() => setActiveTab('idcard')}
        >
          <Text style={[styles.tabText, activeTab === 'idcard' && styles.tabTextActive]}>
            Digital ID Card
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'homework' && styles.tabItemActive]}
          onPress={() => setActiveTab('homework')}
        >
          <Text style={[styles.tabText, activeTab === 'homework' && styles.tabTextActive]}>
            Homework Diary
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabItem, activeTab === 'timetable' && styles.tabItemActive]}
          onPress={() => setActiveTab('timetable')}
        >
          <Text style={[styles.tabText, activeTab === 'timetable' && styles.tabTextActive]}>
            Timetable
          </Text>
        </TouchableOpacity>
      </View>

      {/* VIEW 1: Digital Student ID Card */}
      {activeTab === 'idcard' && (
        <View>
          <View style={styles.idCardOuter}>
            {/* Card Header Strip */}
            <View style={styles.idCardHeader}>
              <View style={styles.crestCircle}>
                <Text style={styles.crestText}>B</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.idSchoolName}>BIRLA OPEN MINDS</Text>
                <Text style={styles.idSchoolSub}>INTERNATIONAL SCHOOL • SAMBALPUR</Text>
                <Text style={styles.idAffiliation}>CBSE AFFILIATION NO. 1530267</Text>
              </View>
            </View>

            {/* Card Body */}
            <View style={styles.idCardBody}>
              <View style={styles.photoContainer}>
                <View style={styles.photoPlaceholder}>
                  <Text style={styles.photoInitial}>AP</Text>
                </View>
                <BOMISBadge label="KALINGA" variant="accent" size="sm" style={styles.houseBadge} />
              </View>

              <View style={styles.idDetails}>
                <Text style={styles.studentName}>AARAV PATEL</Text>
                <Text style={styles.studentMeta}>GRADE 5 • SECTION A • ROLL #1</Text>
                <Text style={styles.detailLine}>Adm No: BOMIS-2021-0042</Text>
                <Text style={styles.detailLine}>Blood Group: O+ • House: Kalinga</Text>
                <Text style={styles.detailLine}>Bus 01 • Stop: Sakhipada Chhak</Text>
              </View>
            </View>

            {/* Dynamic QR Code Card Slot */}
            <View style={styles.qrSlot}>
              <Text style={styles.qrHeader}>OFFICIAL DIGITAL PASS QR</Text>
              <View style={styles.qrVisualBox}>
                <Text style={styles.qrMockCode}>■■■■■■■■■■■■■■■</Text>
                <Text style={styles.qrPayload}>BOMIS:STUDENT:b1000000-0005-4000-8000-000000000001:BOMIS-2021-0042</Text>
              </View>
              <Text style={styles.qrInstructions}>
                Valid for Bus Boarding, Campus Gate Dispersal, and Library Checkout
              </Text>
            </View>

            {/* Emergency & Safety Strip */}
            <View style={styles.idCardFooter}>
              <View style={styles.footerRow}>
                <Text style={styles.footerLabel}>Emergency Contact:</Text>
                <Text style={styles.footerVal}>Dr. Rajesh Patel (+919876543210)</Text>
              </View>
              <View style={styles.footerRow}>
                <Text style={styles.footerLabel}>Medical Advisory:</Text>
                <Text style={[styles.footerVal, { color: '#EF4444' }]}>Allergic to peanuts and dust</Text>
              </View>
            </View>
          </View>
        </View>
      )}

      {/* VIEW 2: Homework & Digital Diary */}
      {activeTab === 'homework' && (
        <View>
          {/* Subject Filter Pills */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll}>
            {['All', 'Mathematics', 'Science', 'English', 'Odia'].map((sub) => (
              <TouchableOpacity
                key={sub}
                style={[
                  styles.filterPill,
                  selectedSubject === sub && styles.filterPillActive,
                ]}
                onPress={() => setSelectedSubject(sub)}
              >
                <Text
                  style={[
                    styles.filterText,
                    selectedSubject === sub && styles.filterTextActive,
                  ]}
                >
                  {sub}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Homework Cards Feed */}
          {filteredHomework.map((item) => (
            <BOMISCard
              key={item.id}
              title={item.title}
              subtitle={`${item.subject} • Assigned by ${item.teacher}`}
              headerRight={
                <BOMISBadge
                  label={item.status}
                  variant={
                    item.status === 'SUBMITTED'
                      ? 'success'
                      : item.status === 'REVIEWED'
                      ? 'info'
                      : 'warning'
                  }
                  size="sm"
                />
              }
            >
              <Text style={styles.homeworkDesc}>{item.description}</Text>

              <View style={styles.homeworkMetaRow}>
                <Text style={styles.dueDateText}>Due: {item.dueDate}</Text>
                <BOMISButton
                  title={item.status === 'ASSIGNED' ? 'Mark as Completed' : 'Undo Submission'}
                  onPress={() => toggleHomeworkStatus(item.id)}
                  variant={item.status === 'ASSIGNED' ? 'accent' : 'outline'}
                  size="sm"
                />
              </View>
            </BOMISCard>
          ))}
        </View>
      )}

      {/* VIEW 3: Weekly Timetable Schedule */}
      {activeTab === 'timetable' && (
        <View>
          {/* Day of Week Selector */}
          <View style={styles.daySelector}>
            {['Monday', 'Tuesday', 'Wednesday'].map((day) => (
              <TouchableOpacity
                key={day}
                style={[styles.dayButton, selectedDay === day && styles.dayButtonActive]}
                onPress={() => setSelectedDay(day)}
              >
                <Text style={[styles.dayButtonText, selectedDay === day && styles.dayButtonTextActive]}>
                  {day}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Timetable Period Grid */}
          <BOMISCard
            title={`Grade 5A Schedule: ${selectedDay}`}
            subtitle="8 CBSE instructional periods • Academic Session 2026-2027"
          >
            <View style={styles.periodList}>
              {timetableForDay.map((p) => {
                const isCurrent = p.period === 2; // Simulated current period
                return (
                  <View
                    key={p.period}
                    style={[styles.periodCard, isCurrent && styles.periodCardCurrent]}
                  >
                    <View style={styles.periodLeft}>
                      <View style={[styles.periodNumberBox, isCurrent && styles.periodNumberBoxCurrent]}>
                        <Text style={[styles.periodNumber, isCurrent && styles.periodNumberCurrent]}>
                          P{p.period}
                        </Text>
                      </View>
                      <View>
                        <Text style={styles.periodSubject}>{p.subject}</Text>
                        <Text style={styles.periodTeacher}>{p.teacher} • {p.room}</Text>
                      </View>
                    </View>
                    <View style={styles.periodRight}>
                      <Text style={styles.periodTime}>{p.time}</Text>
                      {isCurrent && (
                        <BOMISBadge label="NOW" variant="accent" size="sm" style={{ marginTop: 2 }} />
                      )}
                    </View>
                  </View>
                );
              })}
            </View>
          </BOMISCard>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#E2E8F0',
    borderRadius: 10,
    padding: 3,
    marginBottom: 16,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  tabItemActive: {
    backgroundColor: '#0F2942',
  },
  tabText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
  },
  tabTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  // ID Card Styling
  idCardOuter: {
    backgroundColor: '#0F2942',
    borderRadius: 18,
    borderWidth: 2,
    borderColor: '#3D7FB5',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 8,
    marginBottom: 16,
  },
  idCardHeader: {
    backgroundColor: '#071726',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1A3A5C',
  },
  crestCircle: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#FF6B4A',
    alignItems: 'center',
    justifyContent: 'center',
  },
  crestText: {
    color: '#FFFFFF',
    fontWeight: '900',
    fontSize: 20,
  },
  idSchoolName: {
    color: '#FFFFFF',
    fontWeight: '900',
    fontSize: 14,
    letterSpacing: 0.5,
  },
  idSchoolSub: {
    color: '#D2E3F0',
    fontSize: 10,
    fontWeight: '700',
  },
  idAffiliation: {
    color: '#FFAFA0',
    fontSize: 9,
    fontWeight: '700',
    marginTop: 1,
  },
  idCardBody: {
    flexDirection: 'row',
    padding: 16,
    gap: 16,
  },
  photoContainer: {
    alignItems: 'center',
  },
  photoPlaceholder: {
    width: 76,
    height: 92,
    borderRadius: 10,
    backgroundColor: '#1A3A5C',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: '#A4C6E1',
  },
  photoInitial: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '800',
  },
  houseBadge: {
    marginTop: 6,
  },
  idDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  studentName: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
  },
  studentMeta: {
    color: '#FF6B4A',
    fontSize: 12,
    fontWeight: '800',
    marginBottom: 6,
  },
  detailLine: {
    color: '#E2E8F0',
    fontSize: 11,
    lineHeight: 18,
  },
  qrSlot: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 14,
    marginBottom: 12,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
  },
  qrHeader: {
    fontSize: 10,
    fontWeight: '800',
    color: '#0F2942',
    letterSpacing: 0.5,
    marginBottom: 6,
  },
  qrVisualBox: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1.5,
    borderColor: '#0F2942',
    borderRadius: 8,
    padding: 10,
    width: '100%',
    alignItems: 'center',
  },
  qrMockCode: {
    fontSize: 18,
    fontWeight: 'bold',
    letterSpacing: 2,
    color: '#0F2942',
  },
  qrPayload: {
    fontSize: 9,
    color: '#64748B',
    fontFamily: 'monospace',
    marginTop: 4,
    textAlign: 'center',
  },
  qrInstructions: {
    fontSize: 10,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 6,
  },
  idCardFooter: {
    backgroundColor: '#071726',
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: '#1A3A5C',
    gap: 4,
  },
  footerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  footerLabel: {
    fontSize: 10,
    color: '#94A3B8',
  },
  footerVal: {
    fontSize: 10,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  // Homework styling
  filterScroll: {
    flexDirection: 'row',
    marginBottom: 14,
  },
  filterPill: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 20,
    backgroundColor: '#E2E8F0',
    marginRight: 8,
  },
  filterPillActive: {
    backgroundColor: '#FF6B4A',
  },
  filterText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
  },
  filterTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  homeworkDesc: {
    fontSize: 13,
    color: '#334155',
    lineHeight: 18,
    marginBottom: 12,
  },
  homeworkMetaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dueDateText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#64748B',
  },
  // Timetable styling
  daySelector: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 14,
  },
  dayButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
    backgroundColor: '#E2E8F0',
  },
  dayButtonActive: {
    backgroundColor: '#0F2942',
  },
  dayButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
  },
  dayButtonTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  periodList: {
    gap: 8,
  },
  periodCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderRadius: 10,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  periodCardCurrent: {
    backgroundColor: '#FFF5F2',
    borderColor: '#FF6B4A',
  },
  periodLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  periodNumberBox: {
    width: 32,
    height: 32,
    borderRadius: 6,
    backgroundColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  periodNumberBoxCurrent: {
    backgroundColor: '#FF6B4A',
  },
  periodNumber: {
    fontSize: 12,
    fontWeight: '800',
    color: '#0F2942',
  },
  periodNumberCurrent: {
    color: '#FFFFFF',
  },
  periodSubject: {
    fontSize: 14,
    fontWeight: '700',
    color: '#0F172A',
  },
  periodTeacher: {
    fontSize: 11,
    color: '#64748B',
  },
  periodRight: {
    alignItems: 'flex-end',
  },
  periodTime: {
    fontSize: 11,
    color: '#64748B',
    fontWeight: '600',
  },
});
