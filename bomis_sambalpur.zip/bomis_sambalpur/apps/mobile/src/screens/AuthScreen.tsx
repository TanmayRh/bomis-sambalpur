/**
 * AuthScreen - Mobile Authentication & 1-Click Evaluation Quick Login
 * Supports Indian Phone OTP (+91 validation), dev autofill (123456), staff login,
 * and 1-Click Evaluation Presets for all 4 roles (Parent, Student, Teacher, Driver).
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { useAuth } from '../state/auth-context';
import { BOMISButton } from '../components/ui/BOMISButton';
import { BOMISInput } from '../components/ui/BOMISInput';
import { BOMISCard } from '../components/ui/BOMISCard';
import { BOMISBadge } from '../components/ui/BOMISBadge';
import { UserRole } from '@bomis/shared';

export const AuthScreen: React.FC = () => {
  const { sendPhoneOtp, loginWithPhoneOtp, loginWithStaff, loginWithPreset, isLoading } = useAuth();

  const [mode, setMode] = useState<'otp' | 'staff'>('otp');
  const [phone, setPhone] = useState('9876543210');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [email, setEmail] = useState('arundhati.dash@bomis-sambalpur.edu.in');
  const [password, setPassword] = useState('Admin@Sambalpur2026');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleSendOtp = async () => {
    const fullPhone = `+91${phone.replace(/\D/g, '')}`;
    if (phone.length !== 10) {
      Alert.alert('Invalid Phone', 'Please enter a valid 10-digit Indian mobile number');
      return;
    }
    try {
      const res = await sendPhoneOtp(fullPhone);
      setOtpSent(true);
      setStatusMessage(res.message || 'OTP sent! Use mock OTP 123456');
    } catch {
      setOtpSent(true);
      setStatusMessage('OTP sent in offline mode! Use mock OTP 123456');
    }
  };

  const handleVerifyOtp = async () => {
    const fullPhone = `+91${phone.replace(/\D/g, '')}`;
    if (!otpCode) {
      Alert.alert('Required', 'Please enter the 6-digit OTP');
      return;
    }
    try {
      await loginWithPhoneOtp(fullPhone, otpCode);
    } catch (err: any) {
      Alert.alert('Authentication Failed', err.message || 'Invalid or expired OTP');
    }
  };

  const handleStaffLogin = async () => {
    if (!email || !password) {
      Alert.alert('Required', 'Please enter email and password');
      return;
    }
    try {
      await loginWithStaff(email, password);
    } catch (err: any) {
      Alert.alert('Login Failed', err.message || 'Invalid staff credentials');
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* School Crest & Welcome Banner */}
        <View style={styles.brandHeader}>
          <View style={styles.crestCircle}>
            <Text style={styles.crestLetter}>B</Text>
          </View>
          <Text style={styles.brandTitle}>BOMIS Sambalpur</Text>
          <Text style={styles.brandSubtitle}>
            Birla Open Minds International School • CBSE Affiliation #1530267
          </Text>
        </View>

        {/* 1-Click Evaluation Presets Card */}
        <BOMISCard
          title="⚡ Quick Evaluation Login Presets"
          subtitle="Instant 1-tap sign-in to test each role with seed personas"
          style={styles.presetsCard}
        >
          <View style={styles.presetsGrid}>
            <TouchableOpacity
              style={[styles.presetButton, styles.presetParent]}
              onPress={() => loginWithPreset('PARENT')}
              activeOpacity={0.8}
            >
              <BOMISBadge label="PARENT" variant={UserRole.PARENT} size="sm" />
              <Text style={styles.presetName}>Dr. Rajesh Patel</Text>
              <Text style={styles.presetDetail}>Aarav (5A) & Ananya (2A)</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.presetButton, styles.presetStudent]}
              onPress={() => loginWithPreset('STUDENT')}
              activeOpacity={0.8}
            >
              <BOMISBadge label="STUDENT" variant={UserRole.STUDENT} size="sm" />
              <Text style={styles.presetName}>Aarav Patel</Text>
              <Text style={styles.presetDetail}>Grade 5A • Roll #1</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.presetButton, styles.presetTeacher]}
              onPress={() => loginWithPreset('TEACHER')}
              activeOpacity={0.8}
            >
              <BOMISBadge label="TEACHER" variant={UserRole.TEACHER} size="sm" />
              <Text style={styles.presetName}>Mrs. Arundhati Dash</Text>
              <Text style={styles.presetDetail}>Class Teacher Grade 5A</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.presetButton, styles.presetDriver]}
              onPress={() => loginWithPreset('DRIVER')}
              activeOpacity={0.8}
            >
              <BOMISBadge label="DRIVER" variant={UserRole.TRANSPORT_STAFF} size="sm" />
              <Text style={styles.presetName}>Maheswar Bhoi</Text>
              <Text style={styles.presetDetail}>Pilot Bus 01 • Budharaja</Text>
            </TouchableOpacity>
          </View>
        </BOMISCard>

        {/* Main Authentication Card */}
        <BOMISCard style={styles.authCard}>
          {/* Mode Switcher Tabs */}
          <View style={styles.modeTabs}>
            <TouchableOpacity
              style={[styles.modeTab, mode === 'otp' && styles.modeTabActive]}
              onPress={() => setMode('otp')}
            >
              <Text style={[styles.modeTabText, mode === 'otp' && styles.modeTabTextActive]}>
                Mobile OTP Login
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modeTab, mode === 'staff' && styles.modeTabActive]}
              onPress={() => setMode('staff')}
            >
              <Text style={[styles.modeTabText, mode === 'staff' && styles.modeTabTextActive]}>
                Staff Password
              </Text>
            </TouchableOpacity>
          </View>

          {mode === 'otp' ? (
            <View>
              <BOMISInput
                label="Indian Mobile Number"
                value={phone}
                onChangeText={setPhone}
                placeholder="9876543210"
                keyboardType="phone-pad"
                maxLength={10}
                prefix={<Text style={styles.phonePrefix}>+91</Text>}
                helperText="Enter 10-digit registered mobile number"
              />

              {!otpSent ? (
                <BOMISButton
                  title="Send Verification OTP"
                  onPress={handleSendOtp}
                  loading={isLoading}
                  variant="primary"
                />
              ) : (
                <View style={styles.otpSection}>
                  <BOMISInput
                    label="Enter 6-Digit Verification OTP"
                    value={otpCode}
                    onChangeText={setOtpCode}
                    placeholder="123456"
                    keyboardType="number-pad"
                    maxLength={6}
                    helperText="Dev test mode OTP: 123456"
                  />

                  <TouchableOpacity
                    style={styles.autofillButton}
                    onPress={() => setOtpCode('123456')}
                  >
                    <Text style={styles.autofillText}>⚡ Auto-fill Test OTP (123456)</Text>
                  </TouchableOpacity>

                  <BOMISButton
                    title="Verify & Enter Dashboard"
                    onPress={handleVerifyOtp}
                    loading={isLoading}
                    variant="accent"
                    style={styles.submitButton}
                  />

                  <TouchableOpacity
                    style={styles.resendButton}
                    onPress={handleSendOtp}
                  >
                    <Text style={styles.resendText}>Resend OTP</Text>
                  </TouchableOpacity>
                </View>
              )}

              {statusMessage && (
                <View style={styles.statusBox}>
                  <Text style={styles.statusText}>{statusMessage}</Text>
                </View>
              )}
            </View>
          ) : (
            <View>
              <BOMISInput
                label="Staff Email Address"
                value={email}
                onChangeText={setEmail}
                placeholder="faculty@bomis-sambalpur.edu.in"
                keyboardType="email-address"
                autoCapitalize="none"
              />

              <BOMISInput
                label="Master Password"
                value={password}
                onChangeText={setPassword}
                placeholder="••••••••••••"
                secureTextEntry
              />

              <BOMISButton
                title="Sign In as Staff"
                onPress={handleStaffLogin}
                loading={isLoading}
                variant="primary"
                style={styles.submitButton}
              />
            </View>
          )}
        </BOMISCard>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F2942',
  },
  scrollContent: {
    padding: 16,
    paddingTop: 36,
    paddingBottom: 40,
  },
  brandHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  crestCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#FF6B4A',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: '#FFFFFF',
    marginBottom: 12,
  },
  crestLetter: {
    color: '#FFFFFF',
    fontSize: 34,
    fontWeight: '900',
  },
  brandTitle: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '800',
    textAlign: 'center',
  },
  brandSubtitle: {
    color: '#D2E3F0',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 4,
  },
  presetsCard: {
    backgroundColor: '#FFFFFF',
    marginBottom: 16,
    borderWidth: 1.5,
    borderColor: '#FFD4CB',
  },
  presetsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  presetButton: {
    flexBasis: '48%',
    flexGrow: 1,
    borderRadius: 10,
    padding: 10,
    borderWidth: 1,
    alignItems: 'flex-start',
  },
  presetParent: {
    backgroundColor: '#FFF5F2',
    borderColor: '#FFD4CB',
  },
  presetStudent: {
    backgroundColor: '#F4F8FA',
    borderColor: '#D2E3F0',
  },
  presetTeacher: {
    backgroundColor: '#EBF2F8',
    borderColor: '#A4C6E1',
  },
  presetDriver: {
    backgroundColor: '#FEF3C7',
    borderColor: '#FDE68A',
  },
  presetName: {
    fontSize: 13,
    fontWeight: '700',
    color: '#0F172A',
    marginTop: 4,
  },
  presetDetail: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 2,
  },
  authCard: {
    backgroundColor: '#FFFFFF',
  },
  modeTabs: {
    flexDirection: 'row',
    backgroundColor: '#F1F5F9',
    borderRadius: 8,
    padding: 3,
    marginBottom: 16,
  },
  modeTab: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 6,
  },
  modeTabActive: {
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  modeTabText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748B',
  },
  modeTabTextActive: {
    color: '#0F2942',
    fontWeight: '700',
  },
  phonePrefix: {
    fontSize: 15,
    fontWeight: '700',
    color: '#0F2942',
  },
  otpSection: {
    marginTop: 8,
  },
  autofillButton: {
    backgroundColor: '#FFF5F2',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
    alignSelf: 'flex-start',
    marginBottom: 12,
  },
  autofillText: {
    color: '#FF6B4A',
    fontSize: 12,
    fontWeight: '700',
  },
  submitButton: {
    marginTop: 4,
  },
  resendButton: {
    marginTop: 12,
    alignSelf: 'center',
    padding: 4,
  },
  resendText: {
    color: '#3D7FB5',
    fontSize: 13,
    fontWeight: '600',
  },
  statusBox: {
    backgroundColor: '#ECFDF5',
    padding: 10,
    borderRadius: 8,
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#A7F3D0',
  },
  statusText: {
    color: '#065F46',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
});
