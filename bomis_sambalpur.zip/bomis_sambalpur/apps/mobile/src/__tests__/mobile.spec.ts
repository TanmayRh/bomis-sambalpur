/**
 * Mobile Verification Suite for BOMIS Sambalpur (Milestone M5)
 * Validates:
 * 1. Offline outbox queuing & RFC-compliant idempotency key generation
 * 2. 3-tier Adaptive storage adapter contract
 * 3. Multi-child sibling state isolation (Aarav vs Ananya Patel)
 * 4. 30-minute child dismissal OTP lifecycle & dynamic QR verification
 * 5. Rapid attendance delta calculation (<10s SLA)
 * 6. GPS Haversine distance & 5-minute Sakhipada Chhak geofence detection
 * 7. Standard API envelope unwrapping & offline fallback fixtures
 */

import { AttendanceStatus, UserRole } from '@bomis/shared';
import { MemoryStorageAdapter } from '../services/storage-adapter';
import { OutboxRepository } from '../services/outbox-queue';
import { SyncManager, NetworkMonitor } from '../services/sync-manager';
import { MobileApiClient, SEED_PERSONAS } from '../services/api-client';
import { calculateHaversineDistanceKm, ROUTE_1_BUDHARAJA_WAYPOINTS } from '../services/location-service';

declare const describe: (name: string, fn: () => void) => void;
declare const it: (name: string, fn: () => void | Promise<void>) => void;
declare const beforeEach: (fn: () => void | Promise<void>) => void;
declare const expect: (actual: any) => any;

describe('BOMIS Sambalpur Mobile Architecture Suite (M5)', () => {
  // ==========================================================================
  // Test 1: 3-Tier Adaptive Storage Engine
  // ==========================================================================
  describe('1. 3-Tier Adaptive Storage Engine (MemoryStorageAdapter)', () => {
    let storage: MemoryStorageAdapter;

    beforeEach(() => {
      storage = new MemoryStorageAdapter();
    });

    it('should set, get, and remove key-value items safely', async () => {
      await storage.setItem('test_key', 'test_value');
      const val = await storage.getItem('test_key');
      expect(val).toBe('test_value');

      await storage.removeItem('test_key');
      const removed = await storage.getItem('test_key');
      expect(removed).toBeNull();
    });

    it('should support multiGet and multiSet operations', async () => {
      await storage.multiSet([
        ['k1', 'v1'],
        ['k2', 'v2'],
      ]);

      const keys = await storage.getAllKeys();
      expect(keys).toContain('k1');
      expect(keys).toContain('k2');

      const pairs = await storage.multiGet(['k1', 'k2', 'k3']);
      expect(pairs).toEqual([
        ['k1', 'v1'],
        ['k2', 'v2'],
        ['k3', null],
      ]);
    });

    it('should clear all keys', async () => {
      await storage.setItem('k1', 'v1');
      await storage.clear();
      const keys = await storage.getAllKeys();
      expect(keys.length).toBe(0);
    });
  });

  // ==========================================================================
  // Test 2: Offline Outbox Queue & Idempotency Key Generation
  // ==========================================================================
  describe('2. Offline Outbox Queue & Idempotency Keys', () => {
    let storage: MemoryStorageAdapter;
    let outbox: OutboxRepository;

    beforeEach(() => {
      storage = new MemoryStorageAdapter();
      outbox = new OutboxRepository(storage);
    });

    it('should enqueue mutations with client UUID and idempotency key idem_<actionType>_<id>', async () => {
      const payload = {
        classId: 'c1000000-0005-4000-8000-000000000001',
        date: '2026-10-21',
        defaultStatus: AttendanceStatus.PRESENT,
        exceptions: [],
      };

      const item = await outbox.enqueue('ATTENDANCE_BATCH', payload);

      expect(item.id).toMatch(/^evt_\d+_[a-z0-9]+$/);
      expect(item.actionType).toBe('ATTENDANCE_BATCH');
      expect(item.idempotencyKey).toBe(`idem_ATTENDANCE_BATCH_${item.id}`);
      expect(item.status).toBe('PENDING');
      expect(item.retryCount).toBe(0);
      expect(item.payload).toEqual(payload);

      const all = await outbox.getAll();
      expect(all.length).toBe(1);
      expect(all[0]!.id).toBe(item.id);
    });

    it('should mark statuses: PENDING -> SYNCING -> SYNCED / FAILED', async () => {
      const item = await outbox.enqueue('BOARDING_SCAN', { studentId: 'student-1' });

      await outbox.markStatus([item.id], 'SYNCING');
      let current = (await outbox.getAll())[0]!;
      expect(current.status).toBe('SYNCING');

      await outbox.markStatus([item.id], 'FAILED', 'Connection timeout');
      current = (await outbox.getAll())[0]!;
      expect(current.status).toBe('FAILED');
      expect(current.retryCount).toBe(1);
      expect(current.lastError).toBe('Connection timeout');

      await outbox.markStatus([item.id], 'SYNCED');
      current = (await outbox.getAll())[0]!;
      expect(current.status).toBe('SYNCED');
    });

    it('should purge completed records older than cutoff threshold', async () => {
      const oldItem = await outbox.enqueue('GPS_PING', { lat: 21.4825, lng: 83.9782 });
      await outbox.markStatus([oldItem.id], 'SYNCED');

      // Manipulate timestamp to 2 days ago
      const items = await outbox.getAll();
      items[0]!.timestamp = Date.now() - 2 * 86400000;
      await outbox.saveAll(items);

      const freshItem = await outbox.enqueue('GPS_PING', { lat: 21.4669, lng: 83.9812 });

      const purged = await outbox.purgeCompleted(86400000); // 24 hours
      expect(purged).toBe(1);

      const remaining = await outbox.getAll();
      expect(remaining.length).toBe(1);
      expect(remaining[0]!.id).toBe(freshItem.id);
    });
  });

  // ==========================================================================
  // Test 3: Offline Sync Manager & Idempotent Batch Replay
  // ==========================================================================
  describe('3. Offline Sync Manager & Reconnect Replay', () => {
    let storage: MemoryStorageAdapter;
    let outbox: OutboxRepository;
    let network: NetworkMonitor;
    let apiClient: MobileApiClient;
    let syncManager: SyncManager;

    beforeEach(() => {
      storage = new MemoryStorageAdapter();
      outbox = new OutboxRepository(storage);
      network = new NetworkMonitor();
      apiClient = new MobileApiClient('http://localhost:4000/api/v1', storage);
      syncManager = new SyncManager(outbox, network, apiClient);
    });

    it('should report offline status and buffer mutations in outbox', async () => {
      network.setOnline(false);
      expect(network.isOnline()).toBe(false);

      const item = await syncManager.enqueueMutation('ATTENDANCE_BATCH', { count: 40 });
      expect(item.status).toBe('PENDING');

      const stats = await syncManager.getStats();
      expect(stats.isOnline).toBe(false);
      expect(stats.pendingCount).toBe(1);
    });

    it('should drain pending items on reconnect via syncPending', async () => {
      network.setOnline(false);
      await syncManager.enqueueMutation('BOARDING_SCAN', { studentId: 'student-patel' });

      // Go online and trigger sync
      network.setOnline(true);
      const result = await syncManager.syncPending();

      expect(result).not.toBeNull();
      expect(result?.syncedCount).toBe(1);
      expect(result?.results[0]!.status).toBe('SYNCED');

      const stats = await syncManager.getStats();
      expect(stats.pendingCount).toBe(0);
      expect(stats.syncedCount).toBe(1);
    });
  });

  // ==========================================================================
  // Test 4: Multi-Child Sibling State Isolation
  // ==========================================================================
  describe('4. Multi-Child Sibling State Isolation (Aarav vs Ananya Patel)', () => {
    const aarav = SEED_PERSONAS.PARENT.children[0]!;
    const ananya = SEED_PERSONAS.PARENT.children[1]!;

    it('should have separate identities, grades, rolls, and admission numbers', () => {
      expect(aarav.firstName).toBe('Aarav');
      expect(aarav.grade).toBe('Grade 5');
      expect(aarav.rollNumber).toBe('1');
      expect(aarav.admissionNumber).toBe('BOMIS-2021-0042');
      expect(aarav.bloodGroup).toBe('O+');

      expect(ananya.firstName).toBe('Ananya');
      expect(ananya.grade).toBe('Grade 2');
      expect(ananya.rollNumber).toBe('4');
      expect(ananya.admissionNumber).toBe('BOMIS-2024-0118');
      expect(ananya.bloodGroup).toBe('B+');

      expect(aarav.id).not.toBe(ananya.id);
    });

    it('should maintain independent fee and attendance states per child', () => {
      const childDataMap = {
        [aarav.id]: {
          attendanceRate: 90.9,
          feeStatus: 'DUE',
          feeAmount: 16500,
        },
        [ananya.id]: {
          attendanceRate: 95.5,
          feeStatus: 'PAID',
          feeAmount: 14000,
          receiptNumber: 'REC-2026-03189',
        },
      };

      expect(childDataMap[aarav.id]!.attendanceRate).toBe(90.9);
      expect(childDataMap[aarav.id]!.feeStatus).toBe('DUE');

      expect(childDataMap[ananya.id]!.attendanceRate).toBe(95.5);
      expect(childDataMap[ananya.id]!.feeStatus).toBe('PAID');
    });
  });

  // ==========================================================================
  // Test 5: 30-Minute Child Dismissal OTP & Dynamic QR Lifecycle
  // ==========================================================================
  describe('5. 30-Minute Dismissal OTP Lifecycle & Gate Verification', () => {
    const studentId = 'b1000000-0005-4000-8000-000000000001';

    it('should generate a 6-digit numeric OTP with 30-minute expiry window', () => {
      const issuedAt = Date.now();
      const expiresAt = issuedAt + 30 * 60 * 1000;
      const otp = '482910';

      expect(otp).toMatch(/^\d{6}$/);
      const remainingSeconds = Math.floor((expiresAt - issuedAt) / 1000);
      expect(remainingSeconds).toBe(1800); // exactly 30 minutes
    });

    it('should transition to EXPIRED when countdown reaches 0', () => {
      const issuedAt = Date.now() - 31 * 60 * 1000; // 31 minutes ago
      const expiresAt = issuedAt + 30 * 60 * 1000;
      const remainingSeconds = Math.max(0, Math.floor((expiresAt - Date.now()) / 1000));

      expect(remainingSeconds).toBe(0);
      const isExpired = remainingSeconds === 0;
      expect(isExpired).toBe(true);
    });

    it('should construct dynamic QR pass payload with studentId and OTP', () => {
      const otp = '482910';
      const qrPayload = `BOMIS:PICKUP:${studentId}:${otp}`;
      expect(qrPayload).toBe('BOMIS:PICKUP:b1000000-0005-4000-8000-000000000001:482910');
    });
  });

  // ==========================================================================
  // Test 6: Rapid Attendance Delta Calculation (<10s SLA)
  // ==========================================================================
  describe('6. Rapid Attendance Delta Calculation (<10s SLA)', () => {
    it('should produce 0 exceptions when all 40 students are marked PRESENT', () => {
      const roster = Array.from({ length: 40 }, (_, i) => ({
        id: `student-${i + 1}`,
        status: AttendanceStatus.PRESENT,
      }));

      const exceptions = roster.filter((s) => s.status !== AttendanceStatus.PRESENT);
      expect(exceptions.length).toBe(0);
    });

    it('should calculate only exception deltas when students are marked Absent/Late/Half-day', () => {
      const roster = Array.from({ length: 40 }, (_, i) => ({
        id: `student-${i + 1}`,
        status: AttendanceStatus.PRESENT,
      }));

      // Mark 3 exceptions
      roster[1]!.status = AttendanceStatus.ABSENT;
      roster[5]!.status = AttendanceStatus.LATE;
      roster[12]!.status = AttendanceStatus.HALF_DAY;

      const exceptions = roster
        .filter((s) => s.status !== AttendanceStatus.PRESENT)
        .map((s) => ({
          studentId: s.id,
          status: s.status,
        }));

      expect(exceptions.length).toBe(3);
      expect(exceptions).toEqual([
        { studentId: 'student-2', status: AttendanceStatus.ABSENT },
        { studentId: 'student-6', status: AttendanceStatus.LATE },
        { studentId: 'student-13', status: AttendanceStatus.HALF_DAY },
      ]);

      const presentCount = roster.filter((s) => s.status === AttendanceStatus.PRESENT).length;
      expect(presentCount).toBe(37);
    });
  });

  // ==========================================================================
  // Test 7: GPS Haversine Distance & 5-Minute Geofence Alert
  // ==========================================================================
  describe('7. GPS Haversine Distance & 5-Minute Sakhipada Chhak Geofence Alert', () => {
    it('should calculate accurate distance along Route 1 Budharaja Shuttle', () => {
      const fatak = ROUTE_1_BUDHARAJA_WAYPOINTS[0]!; // Budharaja Fatak (21.4825, 83.9782)
      const sakhipada = ROUTE_1_BUDHARAJA_WAYPOINTS[1]!; // Sakhipada Chhak (21.4669, 83.9812)

      const distKm = calculateHaversineDistanceKm(
        fatak.latitude,
        fatak.longitude,
        sakhipada.latitude,
        sakhipada.longitude
      );

      // Distance between Fatak & Sakhipada is ~1.76 km
      expect(distKm).toBeGreaterThan(1.0);
      expect(distKm).toBeLessThan(2.5);
    });

    it('should trigger 5-minute geofence alert when vehicle is <= 1.5 km of Sakhipada Chhak', () => {
      const sakhipada = ROUTE_1_BUDHARAJA_WAYPOINTS[1]!;

      // Vehicle coordinate 0.8 km away
      const vehicleLat = sakhipada.latitude + 0.005;
      const vehicleLng = sakhipada.longitude + 0.005;

      const distKm = calculateHaversineDistanceKm(
        vehicleLat,
        vehicleLng,
        sakhipada.latitude,
        sakhipada.longitude
      );

      const isNearGeofence = distKm <= 1.5;
      expect(isNearGeofence).toBe(true);
    });
  });

  // ==========================================================================
  // Test 8: Seed Persona Fixtures Integrity
  // ==========================================================================
  describe('8. Seed Persona Fixtures Integrity', () => {
    it('should load all 4 roles conforming to BOMIS domain roles', () => {
      expect(SEED_PERSONAS.PARENT.user.role).toBe(UserRole.PARENT);
      expect(SEED_PERSONAS.STUDENT.user.role).toBe(UserRole.STUDENT);
      expect(SEED_PERSONAS.TEACHER.user.role).toBe(UserRole.TEACHER);
      expect(SEED_PERSONAS.DRIVER.user.role).toBe(UserRole.TRANSPORT_STAFF);

      expect(SEED_PERSONAS.PARENT.user.phone).toBe('+919876543210');
      expect(SEED_PERSONAS.STUDENT.user.phone).toBe('+919876543211');
      expect(SEED_PERSONAS.TEACHER.user.phone).toBe('+919437100005');
      expect(SEED_PERSONAS.DRIVER.user.phone).toBe('+919437200001');
    });
  });
});
