'use client';

import { useEffect } from 'react';

export function PwaRegistrar() {
  useEffect(() => {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker
          .register('/sw.js')
          .then((reg) => {
            console.log('[BOMIS PWA] Service Worker registered:', reg.scope);
          })
          .catch((err) => {
            console.warn('[BOMIS PWA] Service Worker registration failed:', err);
          });
      });
    }
  }, []);

  return null;
}
