'use client';

import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import { safetyApi } from '@/lib/api-client';
import { queryKeys } from '@/lib/query-provider';
import { DataTable, ColumnDef } from '@/components/ui/data-table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { ShieldCheck, UserPlus, QrCode } from 'lucide-react';

export interface VisitorPass {
  id: string;
  passCode: string;
  visitorName: string;
  visitorPhone: string;
  purpose: string;
  hostStaffName: string;
  expectedDate: string;
  status: 'PRE_APPROVED' | 'ACTIVE_ON_CAMPUS' | 'CHECKED_OUT';
}

const DEFAULT_VISITORS: VisitorPass[] = [
  {
    id: 'vis-01',
    passCode: 'VP-2026-081',
    visitorName: 'Dr. Sunil Tripathy',
    visitorPhone: '+919437012345',
    purpose: 'CBSE Regional Affiliation Inspection',
    hostStaffName: 'Dr. Minati Mohanty (Principal)',
    expectedDate: '2026-10-19',
    status: 'ACTIVE_ON_CAMPUS',
  },
  {
    id: 'vis-02',
    passCode: 'VP-2026-082',
    visitorName: 'Mr. Pradeep Sahoo',
    visitorPhone: '+919437198765',
    purpose: 'Solar Inverter Maintenance Vendor',
    hostStaffName: 'Amit Kumar Senapati (Admin)',
    expectedDate: '2026-10-19',
    status: 'PRE_APPROVED',
  },
  {
    id: 'vis-03',
    passCode: 'VP-2026-080',
    visitorName: 'Smt. Mamata Jena',
    visitorPhone: '+919437887766',
    purpose: 'New Grade 1 Student Admission Inquiry',
    hostStaffName: 'Admissions Desk',
    expectedDate: '2026-10-19',
    status: 'CHECKED_OUT',
  },
];

export function VisitorLogTable() {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [page, setPage] = React.useState(1);
  const [pageSize, setPageSize] = React.useState(10);
  const [isAddOpen, setIsAddOpen] = React.useState(false);
  const [viewingQr, setViewingQr] = React.useState<VisitorPass | null>(null);

  // New Pass Form State
  const [newVisitorName, setNewVisitorName] = React.useState('');
  const [newVisitorPhone, setNewVisitorPhone] = React.useState('');
  const [newPurpose, setNewPurpose] = React.useState('');
  const [newHostStaff, setNewHostStaff] = React.useState('Amit Kumar Senapati (Admin)');
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const { data: visitorsData, isLoading, refetch } = useQuery({
    queryKey: queryKeys.safety.visitors,
    queryFn: async () => {
      try {
        const res = await safetyApi.getVisitors();
        return Array.isArray(res) ? res : DEFAULT_VISITORS;
      } catch {
        return DEFAULT_VISITORS;
      }
    },
  });

  const visitors: VisitorPass[] = visitorsData || DEFAULT_VISITORS;

  const filteredVisitors = React.useMemo(() => {
    return visitors.filter((v) => {
      return (
        !searchTerm ||
        v.visitorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.passCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.purpose.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  }, [visitors, searchTerm]);

  const pagedVisitors = React.useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredVisitors.slice(start, start + pageSize);
  }, [filteredVisitors, page, pageSize]);

  const handleCreatePass = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await safetyApi.createVisitor({
        visitorName: newVisitorName,
        visitorPhone: newVisitorPhone,
        purpose: newPurpose,
        hostStaffName: newHostStaff,
        expectedDate: new Date().toISOString().split('T')[0],
      });
      setIsAddOpen(false);
      refetch();
    } catch {
      // Mock append
      visitors.unshift({
        id: `vis-${Date.now()}`,
        passCode: `VP-2026-${Math.floor(100 + Math.random() * 900)}`,
        visitorName: newVisitorName,
        visitorPhone: newVisitorPhone,
        purpose: newPurpose,
        hostStaffName: newHostStaff,
        expectedDate: new Date().toISOString().split('T')[0]!,
        status: 'PRE_APPROVED',
      });
      setIsAddOpen(false);
    } finally {
      setIsSubmitting(false);
      setNewVisitorName('');
      setNewVisitorPhone('');
      setNewPurpose('');
    }
  };

  const columns: ColumnDef<VisitorPass>[] = [
    {
      key: 'passCode',
      header: 'Pass Code',
      className: 'w-32 font-mono text-xs font-semibold text-slate-800',
    },
    {
      key: 'visitorName',
      header: 'Visitor Details',
      className: 'w-48',
      render: (item) => (
        <div>
          <p className="font-semibold text-xs text-slate-900">{item.visitorName}</p>
          <p className="text-[11px] text-slate-500 font-mono">{item.visitorPhone}</p>
        </div>
      ),
    },
    {
      key: 'purpose',
      header: 'Purpose of Visit',
      render: (item) => <span className="text-xs text-slate-700">{item.purpose}</span>,
    },
    {
      key: 'hostStaffName',
      header: 'Host Faculty',
      className: 'w-44 text-xs text-slate-600',
    },
    {
      key: 'status',
      header: 'Campus Status',
      className: 'w-36',
      render: (item) => {
        if (item.status === 'ACTIVE_ON_CAMPUS') {
          return <Badge variant="success">Active On Campus</Badge>;
        }
        if (item.status === 'PRE_APPROVED') {
          return <Badge variant="warning">Pre-Approved</Badge>;
        }
        return <Badge variant="secondary">Checked Out</Badge>;
      },
    },
    {
      key: 'actions',
      header: 'QR Gate Pass',
      className: 'w-28 text-right',
      render: (item) => (
        <Button
          variant="outline"
          size="sm"
          className="h-8 px-2 text-xs"
          onClick={() => setViewingQr(item)}
        >
          <QrCode className="mr-1 h-3.5 w-3.5" /> Show QR
        </Button>
      ),
    },
  ];

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldCheck className="h-5 w-5 text-[#0F2942]" />
            <h3 className="text-lg font-bold text-slate-900">Campus Visitor & Gate Pass Log</h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time tracking of visitor entry permits, host faculty assignments, and check-in status.
          </p>
        </div>

        <Button size="sm" onClick={() => setIsAddOpen(true)} leftIcon={<UserPlus className="h-4 w-4" />}>
          Issue Pre-Approved Pass
        </Button>
      </div>

      <DataTable
        columns={columns}
        data={pagedVisitors}
        totalCount={filteredVisitors.length}
        page={page}
        pageSize={pageSize}
        onPageChange={setPage}
        onPageSizeChange={setPageSize}
        onSearch={setSearchTerm}
        searchPlaceholder="Search visitor name or pass code..."
        isLoading={isLoading}
      />

      {/* Issue Pass Modal */}
      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Issue Pre-Approved Visitor Pass</DialogTitle>
            <DialogDescription>
              Generates a secure digital QR visitor token verified at Campus Gate 1 & 2.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreatePass} className="space-y-4 my-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Visitor Full Name</label>
              <Input
                value={newVisitorName}
                onChange={(e) => setNewVisitorName(e.target.value)}
                placeholder="e.g. Dr. Sunil Tripathy"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Mobile Phone Number</label>
              <Input
                value={newVisitorPhone}
                onChange={(e) => setNewVisitorPhone(e.target.value)}
                placeholder="+919437012345"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Purpose of Visit</label>
              <Input
                value={newPurpose}
                onChange={(e) => setNewPurpose(e.target.value)}
                placeholder="e.g. CBSE Inspection, Vendor Meeting"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Host Faculty / Office</label>
              <Input
                value={newHostStaff}
                onChange={(e) => setNewHostStaff(e.target.value)}
                required
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsAddOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" isLoading={isSubmitting}>
                Issue Pass & Send SMS
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* QR Code Preview Modal */}
      <Dialog open={!!viewingQr} onOpenChange={(open) => !open && setViewingQr(null)}>
        <DialogContent className="max-w-sm text-center">
          <DialogHeader>
            <DialogTitle>Visitor Entry Token</DialogTitle>
            <DialogDescription>{viewingQr?.passCode}</DialogDescription>
          </DialogHeader>

          <div className="py-4 flex flex-col items-center justify-center">
            <div className="h-44 w-44 bg-slate-100 border-2 border-slate-300 rounded-xl flex items-center justify-center p-3 shadow-inner">
              <QrCode className="h-32 w-32 text-[#0F2942]" />
            </div>
            <p className="font-bold text-sm text-slate-900 mt-3">{viewingQr?.visitorName}</p>
            <p className="text-xs text-slate-500">{viewingQr?.purpose}</p>
            <p className="text-[11px] text-slate-400 mt-1">Host: {viewingQr?.hostStaffName}</p>
          </div>

          <DialogFooter>
            <Button variant="outline" className="w-full" onClick={() => setViewingQr(null)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
