'use client';

import * as React from 'react';
import { useQuery } from '@tanstack/react-query';
import { adminApi } from '@/lib/api-client';
import { queryKeys } from '@/lib/query-provider';
import { DataTable, ColumnDef } from '@/components/ui/data-table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { History, Eye, ShieldAlert, Filter } from 'lucide-react';

export interface AuditLogItem {
  id: string;
  action: string;
  entityType: string;
  entityId: string;
  userId?: string;
  userName?: string;
  ipAddress?: string;
  userAgent?: string;
  details?: string;
  beforeState?: any;
  afterState?: any;
  createdAt?: string;
  timestamp?: string;
}

const DEFAULT_AUDIT_LOGS: AuditLogItem[] = [
  {
    id: 'log-001',
    action: 'PAYMENT',
    entityType: 'FeePayment',
    entityId: 'pay-2026-081',
    userName: 'Dr. Rajesh Patel',
    ipAddress: '103.24.18.92',
    details: 'Captured Term 1 Tuition fee installment of ₹16,500 via Razorpay UPI',
    beforeState: { status: 'PENDING' },
    afterState: { status: 'PAID', receiptNo: 'REC-2026-04921' },
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
  },
  {
    id: 'log-002',
    action: 'UPDATE',
    entityType: 'StudentAttendance',
    entityId: 'att-5a-2026-10-19',
    userName: 'Arundhati Dash (Teacher)',
    ipAddress: '192.168.1.45',
    details: 'Submitted rapid classroom attendance batch for Grade 5A (28 Present, 2 Absent)',
    timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
  },
  {
    id: 'log-003',
    action: 'CONSENT_CHANGE',
    entityType: 'DpdpConsentRecord',
    entityId: 'consent-patel-01',
    userName: 'Dr. Rajesh Patel',
    ipAddress: '103.24.18.92',
    details: 'Parent reaffirmed biometric and bus telematics data processing consent',
    afterState: { busTelemetry: true, photoDirectory: true, healthRecords: true },
    timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
  },
  {
    id: 'log-004',
    action: 'CREATE',
    entityType: 'VisitorPass',
    entityId: 'pass-2026-109',
    userName: 'Amit Kumar Senapati (Admin)',
    ipAddress: '192.168.1.10',
    details: 'Pre-approved vendor visitor pass for CBSE Inspector delegation',
    timestamp: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
  },
  {
    id: 'log-005',
    action: 'DELETE',
    entityType: 'SessionToken',
    entityId: 'sess-9821',
    userName: 'System Security Watchdog',
    ipAddress: '127.0.0.1',
    details: 'Revoked expired JWT refresh token family after 7 days TTL',
    timestamp: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
  },
];

export function AuditLogTable() {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedAction, setSelectedAction] = React.useState<string>('ALL');
  const [page, setPage] = React.useState(1);
  const [pageSize, setPageSize] = React.useState(10);
  const [inspectingLog, setInspectingLog] = React.useState<AuditLogItem | null>(null);

  const { data: logsData, isLoading } = useQuery({
    queryKey: queryKeys.admin.auditLogs,
    queryFn: async () => {
      try {
        const res = await adminApi.getAuditLogs();
        return Array.isArray(res) ? res : DEFAULT_AUDIT_LOGS;
      } catch {
        return DEFAULT_AUDIT_LOGS;
      }
    },
  });

  const logs: AuditLogItem[] = logsData || DEFAULT_AUDIT_LOGS;

  const filteredLogs = React.useMemo(() => {
    return logs.filter((log) => {
      const matchesSearch =
        !searchTerm ||
        log.details?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.entityType.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.userName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.id.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesAction = selectedAction === 'ALL' || log.action === selectedAction;
      return matchesSearch && matchesAction;
    });
  }, [logs, searchTerm, selectedAction]);

  const pagedLogs = React.useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredLogs.slice(start, start + pageSize);
  }, [filteredLogs, page, pageSize]);

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'CREATE':
        return <Badge variant="success">CREATE</Badge>;
      case 'UPDATE':
        return <Badge variant="warning">UPDATE</Badge>;
      case 'DELETE':
        return <Badge variant="destructive">DELETE</Badge>;
      case 'PAYMENT':
        return <Badge variant="default">PAYMENT</Badge>;
      case 'CONSENT_CHANGE':
        return <Badge variant="accent">DPDP CONSENT</Badge>;
      default:
        return <Badge variant="secondary">{action}</Badge>;
    }
  };

  const columns: ColumnDef<AuditLogItem>[] = [
    {
      key: 'timestamp',
      header: 'Timestamp',
      className: 'w-44 text-xs font-mono text-slate-500',
      render: (item) => {
        const time = item.timestamp || item.createdAt;
        return time ? new Date(time).toLocaleString('en-IN') : 'Just now';
      },
    },
    {
      key: 'action',
      header: 'Action',
      className: 'w-32',
      render: (item) => getActionBadge(item.action),
    },
    {
      key: 'entityType',
      header: 'Target Entity',
      className: 'w-36 text-xs font-medium text-slate-800',
      render: (item) => (
        <div>
          <span>{item.entityType}</span>
          <span className="block text-[10px] font-mono text-slate-400">{item.entityId}</span>
        </div>
      ),
    },
    {
      key: 'userName',
      header: 'Actor',
      className: 'w-40 text-xs font-semibold text-slate-700',
      render: (item) => item.userName || 'System Service',
    },
    {
      key: 'details',
      header: 'Description & Context',
      render: (item) => (
        <span className="text-xs text-slate-600 leading-snug">{item.details || 'Operational mutation logged'}</span>
      ),
    },
    {
      key: 'actions',
      header: 'Payload',
      className: 'w-24 text-right',
      render: (item) => (
        <Button
          variant="ghost"
          size="sm"
          className="h-8 px-2 text-xs text-slate-500 hover:text-slate-900"
          onClick={() => setInspectingLog(item)}
        >
          <Eye className="mr-1 h-3.5 w-3.5" /> Diff
        </Button>
      ),
    },
  ];

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <History className="h-5 w-5 text-[#0F2942]" />
            <h3 className="text-lg font-bold text-slate-900">DPDP Immutable Audit Trail</h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Section 8 DPDP Act 2023 compliant audit logs recording system modifications with cryptographic correlation.
          </p>
        </div>

        {/* Filter slot */}
        <div className="flex items-center space-x-2">
          <Filter className="h-4 w-4 text-slate-400" />
          <select
            value={selectedAction}
            onChange={(e) => setSelectedAction(e.target.value)}
            className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-[#0F2942]"
          >
            <option value="ALL">All Actions</option>
            <option value="CREATE">CREATE</option>
            <option value="UPDATE">UPDATE</option>
            <option value="DELETE">DELETE</option>
            <option value="PAYMENT">PAYMENT</option>
            <option value="CONSENT_CHANGE">CONSENT CHANGE</option>
          </select>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={pagedLogs}
        totalCount={filteredLogs.length}
        page={page}
        pageSize={pageSize}
        onPageChange={setPage}
        onPageSizeChange={setPageSize}
        onSearch={setSearchTerm}
        searchPlaceholder="Filter audit records by actor, entity or details..."
        isLoading={isLoading}
        emptyMessage="No audit records found matching your filter criteria."
      />

      {/* Payload Diff Modal */}
      <Dialog open={!!inspectingLog} onOpenChange={(open) => !open && setInspectingLog(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Audit Event Details: {inspectingLog?.id}</DialogTitle>
            <DialogDescription>
              Recorded on {inspectingLog?.timestamp ? new Date(inspectingLog.timestamp).toLocaleString('en-IN') : 'N/A'}{' '}
              by {inspectingLog?.userName || 'System'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 my-2 text-xs">
            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg">
              <div>
                <span className="font-semibold text-slate-500 block">IP Address:</span>
                <span className="font-mono text-slate-900">{inspectingLog?.ipAddress || '127.0.0.1'}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Action Type:</span>
                <span className="font-semibold text-slate-900">{inspectingLog?.action}</span>
              </div>
            </div>

            <div>
              <span className="font-semibold text-slate-700 block mb-1">State Payload Diff:</span>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-red-50 border border-red-100 rounded-lg overflow-auto max-h-48">
                  <p className="font-bold text-red-800 text-[11px] mb-1">Before State</p>
                  <pre className="text-[10px] text-red-950 font-mono">
                    {JSON.stringify(inspectingLog?.beforeState || { status: 'UNMODIFIED' }, null, 2)}
                  </pre>
                </div>
                <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-lg overflow-auto max-h-48">
                  <p className="font-bold text-emerald-800 text-[11px] mb-1">After State</p>
                  <pre className="text-[10px] text-emerald-950 font-mono">
                    {JSON.stringify(inspectingLog?.afterState || { status: 'APPLIED' }, null, 2)}
                  </pre>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <Button variant="outline" size="sm" onClick={() => setInspectingLog(null)}>
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
