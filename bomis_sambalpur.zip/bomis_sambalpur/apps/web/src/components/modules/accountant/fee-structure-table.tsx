'use client';

import * as React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Receipt, Plus } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

export interface FeeStructureItem {
  id: string;
  name: string;
  category: string;
  amount: number;
  frequency: 'TERM' | 'ANNUAL' | 'MONTHLY';
  applicableGrades: string;
  mandatory: boolean;
}

const DEFAULT_STRUCTURES: FeeStructureItem[] = [
  { id: 'fs-01', name: 'Annual Tuition Fee', category: 'Tuition', amount: 45000, frequency: 'TERM', applicableGrades: 'Grades 1 - 8', mandatory: true },
  { id: 'fs-02', name: 'Science & Computer Lab Fee', category: 'Laboratory', amount: 8000, frequency: 'TERM', applicableGrades: 'Grades 3 - 8', mandatory: true },
  { id: 'fs-03', name: 'Annual Co-Curricular & Sports', category: 'Activity', amount: 4500, frequency: 'ANNUAL', applicableGrades: 'All Grades', mandatory: true },
  { id: 'fs-04', name: 'School Bus Transport (Budharaja Slab 0-5km)', category: 'Transport', amount: 12000, frequency: 'TERM', applicableGrades: 'Transport Opt-In', mandatory: false },
];

export function FeeStructureTable() {
  const [structures] = React.useState<FeeStructureItem[]>(DEFAULT_STRUCTURES);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <div>
          <CardTitle className="text-base font-bold text-slate-900 flex items-center space-x-2">
            <Receipt className="h-5 w-5 text-[#0F2942]" />
            <span>Official Fee Structure Catalog (AY 2026-27)</span>
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">
            Published schedules governing installment billing and Razorpay order amounts.
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg border border-slate-200 overflow-hidden text-xs">
          <table className="w-full text-left divide-y divide-slate-100">
            <thead className="bg-slate-50 font-semibold text-slate-600">
              <tr>
                <th className="py-2.5 px-3">Fee Component</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Billing Frequency</th>
                <th className="py-2.5 px-3">Applicability</th>
                <th className="py-2.5 px-3 text-right">Amount (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {structures.map((item) => (
                <tr key={item.id}>
                  <td className="py-2.5 px-3 font-semibold text-slate-900">{item.name}</td>
                  <td className="py-2.5 px-3">
                    <Badge variant="outline">{item.category}</Badge>
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 font-medium">
                    {item.frequency === 'TERM' ? 'Per Term (Twice/Year)' : 'Annual'}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600">{item.applicableGrades}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                    {formatCurrency(item.amount)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
