'use client';

import * as React from 'react';
import { StatCard } from '@/components/ui/stat-card';
import { DollarSign, CheckCircle2, Clock, HeartHandshake } from 'lucide-react';

export function FeeReconciliationCard() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard
        title="Total Scheduled Fees (AY 26-27)"
        value="₹1,62,50,000"
        change="1,250 Students"
        changeType="neutral"
        period="Annual Billing"
        icon={DollarSign}
        variant="default"
      />
      <StatCard
        title="Collected & Reconciled"
        value="₹1,43,65,000"
        change="88.4% Collection"
        changeType="increase"
        period="Razorpay + Bank"
        icon={CheckCircle2}
        variant="success"
      />
      <StatCard
        title="Pending Installments Due"
        value="₹18,85,000"
        change="Due Nov 15"
        changeType="decrease"
        period="Term 2 Billing"
        icon={Clock}
        variant="warning"
      />
      <StatCard
        title="Concessions Approved"
        value="₹4,25,000"
        change="28 Students"
        changeType="neutral"
        period="Sibling & Merit"
        icon={HeartHandshake}
        variant="navy"
      />
    </div>
  );
}
