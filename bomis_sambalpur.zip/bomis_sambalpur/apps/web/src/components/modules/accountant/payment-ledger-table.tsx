'use client';

import * as React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CreditCard, Download, ExternalLink } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

export interface PaymentTransaction {
  id: string;
  receiptNo: string;
  date: string;
  studentName: string;
  admissionNo: string;
  grade: string;
  amount: number;
  method: 'RAZORPAY_UPI' | 'RAZORPAY_CARD' | 'RAZORPAY_NETBANKING' | 'CASH';
  orderId: string;
  status: 'SUCCESS' | 'PENDING' | 'FAILED';
}

const DEFAULT_TRANSACTIONS: PaymentTransaction[] = [
  {
    id: 'pay-001',
    receiptNo: 'REC-2026-04921',
    date: '2026-10-19 09:15 AM',
    studentName: 'Aarav Patel',
    admissionNo: 'BOMIS-2021-0042',
    grade: 'Grade 5A',
    amount: 16500,
    method: 'RAZORPAY_UPI',
    orderId: 'order_Odi98127391283',
    status: 'SUCCESS',
  },
  {
    id: 'pay-002',
    receiptNo: 'REC-2026-04922',
    date: '2026-10-19 09:42 AM',
    studentName: 'Ananya Patel',
    admissionNo: 'BOMIS-2024-0118',
    grade: 'Grade 2A',
    amount: 16500,
    method: 'RAZORPAY_UPI',
    orderId: 'order_Odi98127391299',
    status: 'SUCCESS',
  },
  {
    id: 'pay-003',
    receiptNo: 'REC-2026-04919',
    date: '2026-10-18 04:30 PM',
    studentName: 'Isha Mohanty',
    admissionNo: 'BOMIS-2021-0043',
    grade: 'Grade 5A',
    amount: 28500,
    method: 'RAZORPAY_NETBANKING',
    orderId: 'order_Odi98127391102',
    status: 'SUCCESS',
  },
  {
    id: 'pay-004',
    receiptNo: 'REC-2026-04918',
    date: '2026-10-18 02:15 PM',
    studentName: 'Rohan Das',
    admissionNo: 'BOMIS-2021-0044',
    grade: 'Grade 5A',
    amount: 14000,
    method: 'RAZORPAY_CARD',
    orderId: 'order_Odi98127391081',
    status: 'SUCCESS',
  },
];

export function PaymentLedgerTable() {
  const [transactions] = React.useState<PaymentTransaction[]>(DEFAULT_TRANSACTIONS);

  const downloadReceipt = (item: PaymentTransaction) => {
    // Generate a printable/downloadable HTML/PDF receipt trigger
    const receiptWindow = window.open('', '_blank');
    if (receiptWindow) {
      receiptWindow.document.write(`
        <html>
          <head>
            <title>Fee Receipt - ${item.receiptNo}</title>
            <style>
              body { font-family: sans-serif; padding: 40px; color: #0F2942; }
              .header { border-bottom: 2px solid #0F2942; padding-bottom: 20px; margin-bottom: 20px; }
              .title { font-size: 24px; font-weight: bold; }
              .meta { margin-top: 10px; font-size: 14px; color: #64748b; }
              table { width: 100%; border-collapse: collapse; margin-top: 20px; }
              th, td { border: 1px solid #cbd5e1; padding: 10px; text-align: left; }
              th { background: #f8fafc; }
              .total { font-weight: bold; font-size: 18px; text-align: right; margin-top: 20px; }
            </style>
          </head>
          <body>
            <div class="header">
              <div class="title">Birla Open Minds International School, Sambalpur</div>
              <div class="meta">CBSE Affiliation No. 1530267 • Official Tax Fee Receipt</div>
            </div>
            <p><strong>Receipt Number:</strong> ${item.receiptNo}</p>
            <p><strong>Date:</strong> ${item.date}</p>
            <p><strong>Student:</strong> ${item.studentName} (${item.grade})</p>
            <p><strong>Admission No:</strong> ${item.admissionNo}</p>
            <p><strong>Payment Mode:</strong> ${item.method} (Order ID: ${item.orderId})</p>
            <table>
              <tr><th>Description</th><th>Amount</th></tr>
              <tr><td>Term 1 Tuition & Comprehensive Fee</td><td>₹${item.amount.toLocaleString('en-IN')}</td></tr>
            </table>
            <div class="total">Total Paid: ₹${item.amount.toLocaleString('en-IN')} (PAID - SUCCESS)</div>
            <p style="margin-top: 40px; font-size: 11px; color: #94a3b8;">
              This is a computer-generated receipt authorized under Section 43A of the IT Act & DPDP Act 2023.
            </p>
          </body>
        </html>
      `);
      receiptWindow.document.close();
      receiptWindow.print();
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <div>
          <CardTitle className="text-base font-bold text-slate-900 flex items-center space-x-2">
            <CreditCard className="h-5 w-5 text-[#0F2942]" />
            <span>Razorpay Payments Ledger & Reconciled Transactions</span>
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">
            Immutable log of fee settlements with downloadable official tax receipts.
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg border border-slate-200 overflow-hidden text-xs">
          <table className="w-full text-left divide-y divide-slate-100">
            <thead className="bg-slate-50 font-semibold text-slate-600">
              <tr>
                <th className="py-2.5 px-3">Receipt No</th>
                <th className="py-2.5 px-3">Date & Time</th>
                <th className="py-2.5 px-3">Student Name</th>
                <th className="py-2.5 px-3">Payment Method</th>
                <th className="py-2.5 px-3 text-right">Amount (₹)</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {transactions.map((item) => (
                <tr key={item.id}>
                  <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">{item.receiptNo}</td>
                  <td className="py-2.5 px-3 text-slate-500">{item.date}</td>
                  <td className="py-2.5 px-3">
                    <span className="font-semibold text-slate-900 block">{item.studentName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{item.admissionNo} • {item.grade}</span>
                  </td>
                  <td className="py-2.5 px-3">
                    <Badge variant="outline" className="font-mono text-[10px]">
                      {item.method.replace('RAZORPAY_', '')}
                    </Badge>
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                    {formatCurrency(item.amount)}
                  </td>
                  <td className="py-2.5 px-3">
                    <Badge variant="success">Captured</Badge>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 px-2 text-xs"
                      onClick={() => downloadReceipt(item)}
                    >
                      <Download className="mr-1 h-3 w-3" /> PDF
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
