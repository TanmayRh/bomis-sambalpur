'use client';

import * as React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { HeartHandshake, Check, X, CheckCircle2 } from 'lucide-react';

export interface ConcessionRequest {
  id: string;
  studentName: string;
  admissionNo: string;
  grade: string;
  category: string;
  type: 'PERCENTAGE' | 'FIXED';
  value: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
}

const DEFAULT_CONCESSIONS: ConcessionRequest[] = [
  {
    id: 'conc-01',
    studentName: 'Aarav Patel',
    admissionNo: 'BOMIS-2021-0042',
    grade: 'Grade 5A',
    category: 'Tuition Fee',
    type: 'PERCENTAGE',
    value: '25% Sibling Discount',
    reason: 'Younger sibling Ananya Patel enrolled in Grade 2A',
    status: 'APPROVED',
  },
  {
    id: 'conc-02',
    studentName: 'Rohan Das',
    admissionNo: 'BOMIS-2021-0044',
    grade: 'Grade 5A',
    category: 'Activity & Sports',
    type: 'FIXED',
    value: '₹2,500',
    reason: 'State Level Kho-Kho Championship Merit Waiver',
    status: 'PENDING',
  },
  {
    id: 'conc-03',
    studentName: 'Pooja Tripathy',
    admissionNo: 'BOMIS-2021-0046',
    grade: 'Grade 5A',
    category: 'Tuition Fee',
    type: 'PERCENTAGE',
    value: '50% Staff Child Waiver',
    reason: 'Child of Senior Mathematics Faculty',
    status: 'APPROVED',
  },
];

export function ConcessionApprovalDialog() {
  const [concessions, setConcessions] = React.useState<ConcessionRequest[]>(DEFAULT_CONCESSIONS);
  const [feedback, setFeedback] = React.useState<string | null>(null);

  const handleStatusChange = (id: string, newStatus: 'APPROVED' | 'REJECTED') => {
    setConcessions((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: newStatus } : c))
    );
    setFeedback(`Concession request ${newStatus.toLowerCase()} successfully and ledger updated!`);
    setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <div>
          <CardTitle className="text-base font-bold text-slate-900 flex items-center space-x-2">
            <HeartHandshake className="h-5 w-5 text-[#0F2942]" />
            <span>Fee Concession & Scholarship Approvals</span>
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">
            Review sibling discounts, staff child waivers, and athletic merit concessions.
          </p>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {feedback && (
          <Alert variant="success">
            <AlertDescription className="flex items-center font-semibold">
              <CheckCircle2 className="mr-1.5 h-4 w-4 text-emerald-600" />
              {feedback}
            </AlertDescription>
          </Alert>
        )}

        <div className="rounded-lg border border-slate-200 overflow-hidden text-xs">
          <table className="w-full text-left divide-y divide-slate-100">
            <thead className="bg-slate-50 font-semibold text-slate-600">
              <tr>
                <th className="py-2.5 px-3">Student Name & Roll</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Concession Value</th>
                <th className="py-2.5 px-3">Justification</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {concessions.map((item) => (
                <tr key={item.id}>
                  <td className="py-2.5 px-3">
                    <span className="font-semibold text-slate-900 block">{item.studentName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{item.admissionNo} • {item.grade}</span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-700">{item.category}</td>
                  <td className="py-2.5 px-3 font-semibold text-[#0F2942]">{item.value}</td>
                  <td className="py-2.5 px-3 text-slate-600 text-[11px] max-w-xs">{item.reason}</td>
                  <td className="py-2.5 px-3">
                    {item.status === 'APPROVED' ? (
                      <Badge variant="success">Approved</Badge>
                    ) : item.status === 'REJECTED' ? (
                      <Badge variant="destructive">Rejected</Badge>
                    ) : (
                      <Badge variant="warning">Pending Review</Badge>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    {item.status === 'PENDING' ? (
                      <div className="inline-flex items-center space-x-1.5">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-2 text-xs text-emerald-700 hover:bg-emerald-50 border-emerald-300"
                          onClick={() => handleStatusChange(item.id, 'APPROVED')}
                        >
                          <Check className="mr-1 h-3 w-3" /> Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-2 text-xs text-red-700 hover:bg-red-50 border-red-300"
                          onClick={() => handleStatusChange(item.id, 'REJECTED')}
                        >
                          <X className="mr-1 h-3 w-3" /> Reject
                        </Button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-slate-400 font-mono">Processed</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
