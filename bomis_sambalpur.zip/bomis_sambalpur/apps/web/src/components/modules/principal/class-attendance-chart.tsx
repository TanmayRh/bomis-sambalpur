'use client';

import * as React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';

interface ClassAttendanceData {
  grade: string;
  section: string;
  teacher: string;
  enrolled: number;
  present: number;
  absent: number;
  percentage: number;
}

const CLASS_ATTENDANCE: ClassAttendanceData[] = [
  { grade: 'Grade 1', section: 'A', teacher: 'Priyanka Rath', enrolled: 30, present: 29, absent: 1, percentage: 96.7 },
  { grade: 'Grade 2', section: 'A', teacher: 'Subhashree Mishra', enrolled: 30, present: 28, absent: 2, percentage: 93.3 },
  { grade: 'Grade 3', section: 'A', teacher: 'Debashish Sahu', enrolled: 30, present: 28, absent: 2, percentage: 93.3 },
  { grade: 'Grade 4', section: 'A', teacher: 'Tapati Panda', enrolled: 30, present: 27, absent: 3, percentage: 90.0 },
  { grade: 'Grade 5', section: 'A', teacher: 'Arundhati Dash', enrolled: 30, present: 28, absent: 2, percentage: 93.3 },
  { grade: 'Grade 6', section: 'A', teacher: 'Manas Ranjan Barik', enrolled: 30, present: 26, absent: 4, percentage: 86.7 },
  { grade: 'Grade 7', section: 'A', teacher: 'Soumya Mohapatra', enrolled: 30, present: 22, absent: 8, percentage: 73.3 },
  { grade: 'Grade 8', section: 'A', teacher: 'Bhabani Shankar Pradhan', enrolled: 30, present: 27, absent: 3, percentage: 90.0 },
];

export function ClassAttendanceChart() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <div>
          <CardTitle className="text-base font-bold text-slate-900">
            Classroom Attendance Breakdown (Today)
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">
            CBSE circular mandates minimum 75% attendance for examination qualification.
          </p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700">
          Total Enrolled: 240
        </span>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg border border-slate-200 overflow-hidden text-xs">
          <table className="w-full text-left divide-y divide-slate-100">
            <thead className="bg-slate-50 font-semibold text-slate-600">
              <tr>
                <th className="py-2.5 px-3">Class & Section</th>
                <th className="py-2.5 px-3">Class Teacher</th>
                <th className="py-2.5 px-3">Present / Total</th>
                <th className="py-2.5 px-3">Attendance %</th>
                <th className="py-2.5 px-3">Compliance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {CLASS_ATTENDANCE.map((row) => {
                const isBelowThreshold = row.percentage < 75;

                return (
                  <tr key={`${row.grade}-${row.section}`} className={isBelowThreshold ? 'bg-red-50/50' : ''}>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">
                      {row.grade} - {row.section}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">{row.teacher}</td>
                    <td className="py-2.5 px-3">
                      <span className="font-semibold text-slate-900">{row.present}</span>
                      <span className="text-slate-400"> / {row.enrolled}</span>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-slate-200 rounded-full h-2 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              isBelowThreshold ? 'bg-red-500' : 'bg-emerald-500'
                            }`}
                            style={{ width: `${row.percentage}%` }}
                          />
                        </div>
                        <span className="font-semibold">{row.percentage.toFixed(1)}%</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3">
                      {isBelowThreshold ? (
                        <Badge variant="destructive" className="inline-flex items-center">
                          <AlertTriangle className="mr-1 h-3 w-3" /> &lt;75% Alert
                        </Badge>
                      ) : (
                        <Badge variant="success" className="inline-flex items-center">
                          <CheckCircle2 className="mr-1 h-3 w-3" /> CBSE OK
                        </Badge>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
