'use client';

import * as React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Bus, Bell, Radio, Phone, CheckCircle2 } from 'lucide-react';

export interface LiveBusTrackerProps {
  childName: string;
}

export function LiveBusTracker({ childName }: LiveBusTrackerProps) {
  const [showProximityAlert, setShowProximityAlert] = React.useState(true);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <div>
          <CardTitle className="text-base font-bold text-slate-900 flex items-center space-x-2">
            <Bus className="h-5 w-5 text-[#0F2942]" />
            <span>Live School Bus Tracker</span>
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">
            Assigned Bus: <strong>Bus 01 (OD-15-AB-1001)</strong> • Route 1: Budharaja Shuttle
          </p>
        </div>

        <div className="flex items-center space-x-1.5 text-xs text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full font-semibold">
          <Radio className="h-3 w-3 animate-pulse text-emerald-600" />
          <span>Live Bus Location</span>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* 5-Minute Proximity Alert Banner */}
        {showProximityAlert && (
          <Alert variant="warning" className="border-amber-300 bg-amber-50 animate-in fade-in">
            <div className="flex items-start justify-between w-full">
              <div className="flex items-start space-x-2">
                <Bell className="h-4 w-4 text-amber-700 mt-0.5" />
                <div>
                  <AlertTitle className="text-amber-900 text-xs font-bold">
                    Bus Arriving Soon (5 Mins Away)
                  </AlertTitle>
                  <AlertDescription className="text-amber-800 text-xs mt-0.5">
                    Bus 01 is approaching <strong>Sakhipada Chhak</strong> ({childName}&apos;s pickup stop). Estimated arrival in <strong>4 mins</strong>.
                  </AlertDescription>
                </div>
              </div>
              <button
                onClick={() => setShowProximityAlert(false)}
                className="text-amber-700 hover:text-amber-900 text-xs font-bold px-1"
              >
                ✕
              </button>
            </div>
          </Alert>
        )}

        {/* Boarding Status Banner */}
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
            <span className="text-emerald-950 font-medium">
              Morning Trip: <strong>{childName}</strong> safely boarded Bus 01 at 07:28 AM (QR Verified).
            </span>
          </div>
          <Badge variant="success">Boarded</Badge>
        </div>

        {/* Route Stops Timeline */}
        <div className="space-y-3 pt-2 text-xs">
          <span className="font-bold text-slate-700 block">Morning Route Progression:</span>

          <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
            {/* Stop 1 */}
            <div className="relative flex items-start space-x-3">
              <div className="absolute -left-6 top-1 h-3.5 w-3.5 rounded-full bg-slate-400 ring-2 ring-white" />
              <div>
                <p className="font-semibold text-slate-500">Stop 1: Budharaja Fatak (07:15 AM)</p>
                <p className="text-[11px] text-slate-400">Departed on schedule</p>
              </div>
            </div>

            {/* Stop 2: Current Stop */}
            <div className="relative flex items-start space-x-3 bg-amber-50/70 p-2 rounded-lg -ml-2">
              <div className="absolute -left-4 top-3 h-3.5 w-3.5 rounded-full bg-[#FF6B4A] ring-4 ring-[#FF6B4A]/20 animate-ping" />
              <div className="absolute -left-4 top-3 h-3.5 w-3.5 rounded-full bg-[#FF6B4A] ring-2 ring-white" />
              <div>
                <div className="flex items-center space-x-2">
                  <p className="font-bold text-slate-900">Stop 2: Sakhipada Chhak ({childName}&apos;s Stop)</p>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#FF6B4A] text-white">
                    Approaching
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 mt-0.5">Speed: 28 km/h • ETA: 07:28 AM</p>
              </div>
            </div>

            {/* Stop 3 */}
            <div className="relative flex items-start space-x-3">
              <div className="absolute -left-6 top-1 h-3.5 w-3.5 rounded-full bg-slate-300 ring-2 ring-white" />
              <div>
                <p className="font-medium text-slate-400">Stop 3: Ainthapali Chowk (07:40 AM)</p>
                <p className="text-[11px] text-slate-400">Scheduled next</p>
              </div>
            </div>

            {/* Stop 4 */}
            <div className="relative flex items-start space-x-3">
              <div className="absolute -left-6 top-1 h-3.5 w-3.5 rounded-full bg-slate-300 ring-2 ring-white" />
              <div>
                <p className="font-medium text-slate-400">Stop 4: BOMIS Sambalpur Campus (07:55 AM)</p>
                <p className="text-[11px] text-slate-400">Destination</p>
              </div>
            </div>
          </div>
        </div>

        {/* Driver Contact Strip */}
        <div className="border-t border-slate-200 pt-3 flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-400 text-[10px] uppercase font-semibold block">School Bus Driver</span>
            <span className="font-bold text-slate-800">Maheswar Bhoi (Driver Bhaiya)</span>
          </div>
          <a
            href="tel:+919437200001"
            className="inline-flex items-center px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold transition-colors"
          >
            <Phone className="mr-1.5 h-3.5 w-3.5 text-[#0F2942]" />
            Call Driver
          </a>
        </div>
      </CardContent>
    </Card>
  );
}
