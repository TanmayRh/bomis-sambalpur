'use client';

import * as React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { feesApi, ApiClientError } from '@/lib/api-client';
import { CreditCard, CheckCircle2, ShieldCheck, Download, QrCode, Lock } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

export function generateFeeIdempotencyKey(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export interface RazorpayCheckoutModalProps {
  studentName: string;
  studentId: string;
}

export function RazorpayCheckoutModal({ studentName, studentId }: RazorpayCheckoutModalProps) {
  const [modalOpen, setModalOpen] = React.useState(false);
  const [selectedMethod, setSelectedMethod] = React.useState<'UPI' | 'NETBANKING' | 'CARD'>('UPI');
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [paymentSuccess, setPaymentSuccess] = React.useState<{ receiptNo: string; orderId: string } | null>(null);
  const [paymentError, setPaymentError] = React.useState<string | null>(null);

  // Installment 2 state (Term 2)
  const [isTerm2Paid, setIsTerm2Paid] = React.useState(false);

  // Reset payment states when active studentId changes to prevent cross-child state bleeding
  React.useEffect(() => {
    setIsTerm2Paid(false);
    setPaymentSuccess(null);
    setPaymentError(null);
  }, [studentId]);

  const handleStartPayment = async () => {
    // In-flight double-click guard
    if (isProcessing) return;
    setIsProcessing(true);
    setPaymentError(null);

    const idempotencyKey = generateFeeIdempotencyKey();

    try {
      const order = await feesApi.createRazorpayOrder(
        {
          installmentId: `inst-term2-${studentId}`,
          amount: 16500,
          studentId,
        },
        idempotencyKey
      );

      // Simulate payment processing time
      setTimeout(() => {
        setIsProcessing(false);
        setIsTerm2Paid(true);
        setPaymentSuccess({
          receiptNo: `REC-2026-${Math.floor(5000 + Math.random() * 4000)}`,
          orderId: order?.orderId || `order_${idempotencyKey.substring(0, 14)}`,
        });
      }, 1000);
    } catch (err: any) {
      // Differentiate live API HTTP 4xx/5xx rejections from offline simulation
      if (err instanceof ApiClientError || (err?.status && err.status >= 400)) {
        setIsProcessing(false);
        setPaymentError(err.message || 'Payment processing failed on server. Please try again.');
        return;
      }

      // Fallback only in offline simulation
      setTimeout(() => {
        setIsProcessing(false);
        setIsTerm2Paid(true);
        setPaymentSuccess({
          receiptNo: `REC-2026-04928`,
          orderId: `order_sim_${idempotencyKey.substring(0, 10)}`,
        });
      }, 1000);
    }
  };

  const handleDownloadReceipt = (receiptNo: string) => {
    const w = window.open('', '_blank');
    if (w) {
      w.document.write(`
        <html>
          <body style="font-family:sans-serif;padding:30px;color:#0F2942;">
            <h2>Birla Open Minds International School, Sambalpur</h2>
            <p><strong>Official Tax Fee Receipt</strong>: ${receiptNo}</p>
            <p><strong>Student:</strong> ${studentName}</p>
            <p><strong>Amount Paid:</strong> ₹16,500.00 via Razorpay (Confirmed Online Settlement)</p>
            <p><strong>Status:</strong> CONFIRMED & RECONCILED</p>
          </body>
        </html>
      `);
      w.document.close();
      w.print();
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <div>
          <CardTitle className="text-base font-bold text-slate-900 flex items-center space-x-2">
            <CreditCard className="h-5 w-5 text-[#0F2942]" />
            <span>School Fee Ledger & Payment Status</span>
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">
            Academic Year 2026-27 Installments for {studentName}
          </p>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Installments Table */}
        <div className="space-y-3">
          {/* Installment 1: Term 1 */}
          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-200 bg-white">
            <div className="space-y-0.5">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-xs text-slate-900">Term 1 Comprehensive Installment</span>
                <Badge variant="success">PAID</Badge>
              </div>
              <p className="text-[11px] text-slate-400">Paid on 10-Jul-2026 • Ref: REC-2026-04921</p>
            </div>
            <div className="flex items-center space-x-3">
              <span className="font-bold text-sm text-slate-900">₹16,500</span>
              <Button
                size="sm"
                variant="outline"
                className="text-xs h-8"
                onClick={() => handleDownloadReceipt('REC-2026-04921')}
                leftIcon={<Download className="h-3.5 w-3.5" />}
              >
                Receipt
              </Button>
            </div>
          </div>

          {/* Installment 2: Term 2 */}
          <div className={`flex items-center justify-between p-3.5 rounded-xl border ${
            isTerm2Paid ? 'border-slate-200 bg-white' : 'border-amber-200 bg-amber-50/50'
          }`}>
            <div className="space-y-0.5">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-xs text-slate-900">Term 2 Comprehensive Installment</span>
                {isTerm2Paid ? (
                  <Badge variant="success">PAID</Badge>
                ) : (
                  <Badge variant="warning">DUE BY 15-NOV-2026</Badge>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                {isTerm2Paid
                  ? `Paid just now • Ref: ${paymentSuccess?.receiptNo || 'REC-2026-04928'}`
                  : 'Tuition, Computer Lab & Activity Fee'}
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <span className="font-bold text-sm text-slate-900">₹16,500</span>
              {isTerm2Paid ? (
                <Button
                  size="sm"
                  variant="outline"
                  className="text-xs h-8"
                  onClick={() => handleDownloadReceipt(paymentSuccess?.receiptNo || 'REC-2026-04928')}
                  leftIcon={<Download className="h-3.5 w-3.5" />}
                >
                  Receipt
                </Button>
              ) : (
                <Button
                  size="sm"
                  variant="accent"
                  className="text-xs h-8"
                  onClick={() => setModalOpen(true)}
                >
                  Pay Now
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Idempotent Razorpay Checkout Simulation Modal */}
        <Dialog open={modalOpen} onOpenChange={setModalOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <ShieldCheck className="h-5 w-5 text-emerald-600" />
                <span>Razorpay Secure Fee Checkout</span>
              </DialogTitle>
              <DialogDescription>
                Safe and verified fee payment for Birla Open Minds International School
              </DialogDescription>
            </DialogHeader>

            {paymentSuccess ? (
              <div className="py-6 text-center space-y-3">
                <div className="h-12 w-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="h-7 w-7" />
                </div>
                <h4 className="text-base font-bold text-slate-900">Payment Completed Successfully!</h4>
                <p className="text-xs text-slate-500">
                  Amount ₹16,500 settled with receipt <strong>{paymentSuccess.receiptNo}</strong>
                </p>
                <div className="pt-2 flex justify-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDownloadReceipt(paymentSuccess.receiptNo)}
                    leftIcon={<Download className="h-4 w-4" />}
                  >
                    Download Tax Receipt
                  </Button>
                  <Button size="sm" onClick={() => setModalOpen(false)}>
                    Close
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4 my-2 text-xs">
                {paymentError && (
                  <Alert variant="destructive">
                    <AlertDescription>{paymentError}</AlertDescription>
                  </Alert>
                )}
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center">
                  <div>
                    <span className="font-bold text-slate-900 block text-sm">Term 2 Fee Installment</span>
                    <span className="text-slate-500 text-[11px]">{studentName} (AY 2026-27)</span>
                  </div>
                  <span className="font-extrabold text-base text-[#0F2942]">₹16,500</span>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-2">Select Payment Method</label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedMethod('UPI')}
                      className={`p-2.5 rounded-lg border text-center transition-all ${
                        selectedMethod === 'UPI'
                          ? 'border-[#0F2942] bg-[#0F2942]/10 font-bold text-[#0F2942]'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <QrCode className="h-4 w-4 mx-auto mb-1 text-slate-600" />
                      UPI (QR/GPay)
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedMethod('NETBANKING')}
                      className={`p-2.5 rounded-lg border text-center transition-all ${
                        selectedMethod === 'NETBANKING'
                          ? 'border-[#0F2942] bg-[#0F2942]/10 font-bold text-[#0F2942]'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <CreditCard className="h-4 w-4 mx-auto mb-1 text-slate-600" />
                      Netbanking
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedMethod('CARD')}
                      className={`p-2.5 rounded-lg border text-center transition-all ${
                        selectedMethod === 'CARD'
                          ? 'border-[#0F2942] bg-[#0F2942]/10 font-bold text-[#0F2942]'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <Lock className="h-4 w-4 mx-auto mb-1 text-slate-600" />
                      Debit/Credit
                    </button>
                  </div>
                </div>

                <div className="text-[11px] text-slate-500 p-2.5 bg-slate-50 rounded-lg flex items-center">
                  <Lock className="h-3.5 w-3.5 mr-2 text-emerald-600 shrink-0" />
                  <span>
                    Secured with bank-grade 256-bit encryption. Protected against accidental duplicate charges.
                  </span>
                </div>

                <DialogFooter className="mt-4">
                  <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    type="button"
                    variant="accent"
                    isLoading={isProcessing}
                    onClick={handleStartPayment}
                  >
                    Pay ₹16,500 via Razorpay
                  </Button>
                </DialogFooter>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
