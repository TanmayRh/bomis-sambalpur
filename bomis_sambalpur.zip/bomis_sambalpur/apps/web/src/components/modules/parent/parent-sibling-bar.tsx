'use client';

import * as React from 'react';
import { useAuthStore, authStore, DEFAULT_SIBLINGS } from '@/lib/auth-store';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Sparkles } from 'lucide-react';

export function ParentSiblingBar() {
  const linkedChildren = useAuthStore((s) => s.linkedChildren);
  const activeChildId = useAuthStore((s) => s.activeChildId);

  const children = linkedChildren.length > 0 ? linkedChildren : DEFAULT_SIBLINGS;
  const activeChild = children.find((c) => c.id === activeChildId) || children[0]!;

  return (
    <div className="bg-gradient-to-r from-[#0F2942] to-[#1A3A5C] text-white rounded-2xl p-6 shadow-md">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        {/* Active Child Highlight */}
        <div className="flex items-center space-x-4">
          <Avatar
            name={`${activeChild.firstName} ${activeChild.lastName}`}
            size="lg"
            className="ring-4 ring-white/20 bg-white/10 text-white border-none"
          />
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-extrabold tracking-tight">
                {activeChild.firstName} {activeChild.lastName}
              </h2>
              <Badge variant="accent" className="text-[10px] uppercase font-bold bg-[#FF6B4A] text-white border-none">
                {activeChild.house || 'KALINGA'} HOUSE
              </Badge>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Grade {activeChild.grade} - Section {activeChild.section} • Roll No: {activeChild.rollNumber} • Admission: {activeChild.admissionNumber}
            </p>
          </div>
        </div>

        {/* Quick Sibling Switcher Tabs */}
        <div className="flex items-center space-x-2 bg-white/10 p-1.5 rounded-xl backdrop-blur-sm self-stretch md:self-auto justify-center">
          <span className="text-[11px] font-semibold text-slate-300 px-2 flex items-center">
            <Sparkles className="mr-1 h-3 w-3 text-[#FF6B4A]" /> Switch Child:
          </span>
          {children.map((child) => {
            const isSelected = child.id === activeChild.id;

            return (
              <button
                key={child.id}
                type="button"
                onClick={() => authStore.setActiveChildId(child.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  isSelected
                    ? 'bg-white text-[#0F2942] shadow-sm'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                {child.firstName} (Gr {child.grade})
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
