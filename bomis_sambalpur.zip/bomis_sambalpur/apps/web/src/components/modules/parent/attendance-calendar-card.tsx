'use client';

import * as React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CalendarCheck2, CheckCircle2, Plus } from 'lucide-react';
import { attendanceApi } from '@/lib/api-client';

export interface AttendanceCalendarCardProps {
  childName: string;
  childId: string;
}

export function AttendanceCalendarCard({ childName, childId }: AttendanceCalendarCardProps) {
  const [leaveModalOpen, setLeaveModalOpen] = React.useState(false);
  const [fromDate, setFromDate] = React.useState('2026-10-24');
  const [toDate, setToDate] = React.useState('2026-10-25');
  const [leaveType, setLeaveType] = React.useState('SICK');
  const [reason, setReason] = React.useState('Viral fever and doctor consultation');
  const [leaveSuccess, setLeaveSuccess] = React.useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  // Calendar days generation for October 2026 (31 days, starts on Thursday)
  const daysInMonth = 31;
  const startDayOffset = 4; // Thursday

  const handleApplyLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setLeaveSuccess(null);

    try {
      await attendanceApi.applyLeave({
        fromDate,
        toDate,
        leaveType,
        reason,
        studentId: childId,
      });
      setLeaveSuccess('Leave application successfully submitted to Class Teacher!');
      setTimeout(() => {
        setLeaveModalOpen(false);
        setLeaveSuccess(null);
      }, 1500);
    } catch {
      setLeaveSuccess('Leave application recorded (Simulated mode).');
      setTimeout(() => {
        setLeaveModalOpen(false);
        setLeaveSuccess(null);
      }, 1500);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 gap-2">
        <div>
          <CardTitle className="text-base font-bold text-slate-900 flex items-center space-x-2">
            <CalendarCheck2 className="h-5 w-5 text-[#0F2942]" />
            <span>Attendance Record: October 2026</span>
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">
            CBSE compliance tracking for {childName}
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <Badge variant="success" className="text-xs font-bold">
            95.5% (CBSE Compliant)
          </Badge>
          <Button
            size="sm"
            variant="outline"
            className="text-xs h-8"
            onClick={() => setLeaveModalOpen(true)}
            leftIcon={<Plus className="h-3.5 w-3.5" />}
          >
            Apply Leave
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Metric summary */}
        <div className="grid grid-cols-4 gap-2 text-center text-xs p-2.5 bg-slate-50 rounded-xl border border-slate-200">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Working Days</span>
            <span className="font-extrabold text-slate-900 text-sm">22</span>
          </div>
          <div>
            <span className="text-emerald-600 block text-[10px] uppercase font-semibold">Present</span>
            <span className="font-extrabold text-emerald-700 text-sm">21</span>
          </div>
          <div>
            <span className="text-red-600 block text-[10px] uppercase font-semibold">Absent</span>
            <span className="font-extrabold text-red-700 text-sm">1</span>
          </div>
          <div>
            <span className="text-amber-600 block text-[10px] uppercase font-semibold">Late</span>
            <span className="font-extrabold text-amber-700 text-sm">0</span>
          </div>
        </div>

        {/* Calendar Day Grid */}
        <div className="space-y-1 text-xs">
          <div className="grid grid-cols-7 gap-1 text-center font-bold text-slate-400 text-[11px] mb-1">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>

          <div className="grid grid-cols-7 gap-1 text-center text-xs">
            {/* Empty offset padding for Thursday */}
            {Array.from({ length: startDayOffset }).map((_, i) => (
              <div key={`empty-${i}`} className="h-8 rounded-lg bg-slate-50/50" />
            ))}

            {/* Days 1 to 31 */}
            {Array.from({ length: daysInMonth }).map((_, idx) => {
              const day = idx + 1;
              const isSunday = (day + startDayOffset - 1) % 7 === 0;
              const isAbsent = day === 14;
              const isFuture = day > 19;
              const isPresent = !isSunday && !isAbsent && !isFuture;

              return (
                <div
                  key={`day-${day}`}
                  className={`h-8 flex flex-col items-center justify-center rounded-lg font-semibold transition-colors ${
                    isSunday
                      ? 'bg-slate-100 text-slate-400'
                      : isAbsent
                      ? 'bg-red-100 text-red-700 border border-red-300'
                      : isPresent
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-white border border-slate-100 text-slate-400'
                  }`}
                  title={
                    isSunday
                      ? 'Sunday Holiday'
                      : isAbsent
                      ? 'Absent (Sick Leave)'
                      : isPresent
                      ? 'Present'
                      : 'Upcoming'
                  }
                >
                  <span className="text-[11px] leading-none">{day}</span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-center space-x-4 pt-3 text-[11px] text-slate-500">
            <span className="flex items-center">
              <span className="h-2 w-2 rounded-full bg-emerald-500 mr-1.5" /> Present
            </span>
            <span className="flex items-center">
              <span className="h-2 w-2 rounded-full bg-red-500 mr-1.5" /> Absent
            </span>
            <span className="flex items-center">
              <span className="h-2 w-2 rounded-full bg-slate-300 mr-1.5" /> Weekend / Holiday
            </span>
          </div>
        </div>
      </CardContent>

      {/* Apply Leave Modal */}
      <Dialog open={leaveModalOpen} onOpenChange={setLeaveModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Apply for Student Leave</DialogTitle>
            <DialogDescription>
              Submit formal leave intimation for {childName} to Class Teacher.
            </DialogDescription>
          </DialogHeader>

          {leaveSuccess && (
            <Alert variant="success" className="my-2">
              <AlertDescription>{leaveSuccess}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleApplyLeave} className="space-y-4 my-2 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">From Date</label>
                <Input
                  type="date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">To Date</label>
                <Input
                  type="date"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Leave Category</label>
              <Select
                value={leaveType}
                onValueChange={setLeaveType}
                options={[
                  { label: 'Sick / Medical Leave', value: 'SICK' },
                  { label: 'Casual / Family Function', value: 'CASUAL' },
                  { label: 'Out of Town Travel', value: 'TRAVEL' },
                ]}
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Reason Description</label>
              <textarea
                rows={3}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0F2942]"
                required
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setLeaveModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" isLoading={isSubmitting}>
                Submit Application
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
