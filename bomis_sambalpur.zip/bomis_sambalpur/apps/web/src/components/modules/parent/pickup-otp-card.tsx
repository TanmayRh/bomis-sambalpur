'use client';

import * as React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck, Clock, RefreshCw, CheckCircle2, AlertTriangle } from 'lucide-react';

export type OtpStatus = 'ACTIVE' | 'USED' | 'EXPIRED';

export interface PickupOtpCardProps {
  childName: string;
  childId?: string;
}

export function PickupOtpCard({ childName, childId }: PickupOtpCardProps) {
  const [otp, setOtp] = React.useState('482910');
  const [secondsRemaining, setSecondsRemaining] = React.useState(1800); // 30 mins
  const [status, setStatus] = React.useState<OtpStatus>('ACTIVE');
  const [isRegenerating, setIsRegenerating] = React.useState(false);

  // Key OTP per childId so siblings have independent OTP states
  React.useEffect(() => {
    setSecondsRemaining(1800);
    setStatus('ACTIVE');
    if (childId) {
      let hash = 0;
      for (let i = 0; i < childId.length; i++) {
        hash = (hash << 5) - hash + childId.charCodeAt(i);
        hash |= 0;
      }
      setOtp(Math.floor(100000 + (Math.abs(hash) % 900000)).toString());
    } else {
      setOtp('482910');
    }
  }, [childId]);

  // Countdown timer with automatic status transition to EXPIRED at T=0
  React.useEffect(() => {
    if (status !== 'ACTIVE') return;

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setStatus('EXPIRED');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [status]);

  const formatTimer = (totalSeconds: number) => {
    const minutes = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleRegenerate = () => {
    setIsRegenerating(true);
    setTimeout(() => {
      setOtp(Math.floor(100000 + Math.random() * 900000).toString());
      setSecondsRemaining(1800);
      setStatus('ACTIVE');
      setIsRegenerating(false);
    }, 400);
  };

  // Simulate gatekeeper verification action marking OTP used
  const handleSimulateGateVerification = () => {
    setStatus('USED');
  };

  return (
    <Card className="border-emerald-200 bg-gradient-to-br from-white to-emerald-50/30">
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <div>
          <CardTitle className="text-base font-bold text-slate-900 flex items-center space-x-2">
            <ShieldCheck className="h-5 w-5 text-emerald-600" />
            <span>Child Gate Pass (Pick-up PIN)</span>
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">
            Show to gate security guard during afternoon dispersal for {childName}
          </p>
        </div>

        {status === 'ACTIVE' && (
          <Badge variant="success" className="text-xs">
            Active
          </Badge>
        )}
        {status === 'EXPIRED' && (
          <Badge variant="destructive" className="text-xs">
            Expired
          </Badge>
        )}
        {status === 'USED' && (
          <Badge variant="secondary" className="text-xs">
            Dismissed / Picked Up
          </Badge>
        )}
      </CardHeader>

      <CardContent className="space-y-4 text-center">
        {/* OTP Display Card */}
        <div
          className={`p-4 bg-white rounded-xl border-2 shadow-sm inline-block w-full max-w-sm mx-auto transition-all ${
            status === 'ACTIVE'
              ? 'border-emerald-300'
              : status === 'EXPIRED'
              ? 'border-red-300 bg-red-50/30'
              : 'border-slate-300 bg-slate-50/70'
          }`}
        >
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            Gate Pick-up PIN
          </span>

          <div
            className={`font-mono text-3xl md:text-4xl font-extrabold tracking-widest my-2 select-all transition-all ${
              status === 'ACTIVE'
                ? 'text-[#0F2942]'
                : status === 'EXPIRED'
                ? 'text-red-300 filter blur-sm select-none'
                : 'text-slate-400 filter blur-sm select-none'
            }`}
          >
            {status === 'ACTIVE' ? otp : '••••••'}
          </div>

          <div className="flex items-center justify-center space-x-1.5 text-xs font-semibold">
            {status === 'ACTIVE' && (
              <span className="text-amber-700 flex items-center space-x-1.5">
                <Clock className="h-3.5 w-3.5 animate-spin" />
                <span>Expires in: {formatTimer(secondsRemaining)}</span>
              </span>
            )}
            {status === 'EXPIRED' && (
              <span className="text-red-600 flex items-center space-x-1.5 font-bold">
                <AlertTriangle className="h-3.5 w-3.5" />
                <span>Code Expired (00:00). Please regenerate.</span>
              </span>
            )}
            {status === 'USED' && (
              <span className="text-slate-600 flex items-center space-x-1.5 font-bold">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                <span>Verified by Campus Security at Gate</span>
              </span>
            )}
          </div>
        </div>

        {/* Guidance and Actions */}
        <div className="text-xs text-slate-500 max-w-sm mx-auto space-y-2">
          <p>
            Show this 6-digit code or QR code to Campus Security at Gate 1 or Gate 2 during afternoon dispersal.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-1">
            <Button
              type="button"
              variant={status === 'EXPIRED' ? 'accent' : 'outline'}
              size="sm"
              onClick={handleRegenerate}
              isLoading={isRegenerating}
              leftIcon={<RefreshCw className="h-3.5 w-3.5" />}
            >
              Generate New PIN
            </Button>

            {status === 'ACTIVE' && (
              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={handleSimulateGateVerification}
                leftIcon={<CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />}
              >
                Simulate Gate Pickup Verification
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
