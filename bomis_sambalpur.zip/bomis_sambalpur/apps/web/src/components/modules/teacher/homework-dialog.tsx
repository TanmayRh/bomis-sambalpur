'use client';

import * as React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BookOpen, Sparkles, Send } from 'lucide-react';

export interface HomeworkDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function HomeworkDialog({ open, onOpenChange }: HomeworkDialogProps) {
  const [subject, setSubject] = React.useState('Mathematics');
  const [title, setTitle] = React.useState('Chapter 4: Fractions & Decimals Worksheet');
  const [dueDate, setDueDate] = React.useState('2026-10-22');
  const [description, setDescription] = React.useState(
    'Complete exercises 4.1 to 4.3 in the NCERT Mathematics workbook. Practice fraction addition on number lines.'
  );
  const [isGeneratingAi, setIsGeneratingAi] = React.useState(false);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [feedback, setFeedback] = React.useState<string | null>(null);

  const handleAiDraft = () => {
    setIsGeneratingAi(true);
    setTimeout(() => {
      setDescription(
        'CBSE Learning Objective: Master conversion of improper fractions into mixed numbers. Please complete questions 1-8 on page 64. Ensure all steps are shown clearly in the notebook. Self-assessment checklist attached.'
      );
      setIsGeneratingAi(false);
    }, 400);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setFeedback('Homework and digital diary circular dispatched to all Grade 5A parents!');
      setIsSubmitting(false);
      setTimeout(() => {
        onOpenChange(false);
        setFeedback(null);
      }, 1200);
    }, 500);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <BookOpen className="h-5 w-5 text-[#0F2942]" />
            <span>Create Digital Diary & Homework Entry</span>
          </DialogTitle>
          <DialogDescription>
            Publishes homework assignment and study circular to parent portal and student diary.
          </DialogDescription>
        </DialogHeader>

        {feedback && (
          <Alert variant="success" className="my-2">
            <AlertDescription>{feedback}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 my-2 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Subject</label>
              <Select
                value={subject}
                onValueChange={setSubject}
                options={[
                  { label: 'Mathematics', value: 'Mathematics' },
                  { label: 'Science & EVS', value: 'Science' },
                  { label: 'English Literature', value: 'English' },
                  { label: 'Social Studies', value: 'Social' },
                  { label: 'Hindi', value: 'Hindi' },
                ]}
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Submission Due Date</label>
              <Input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Homework Topic / Title</label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Chapter 4 Fractions Practice"
              required
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-semibold text-slate-700">Instructions & Objectives</label>
              <button
                type="button"
                onClick={handleAiDraft}
                disabled={isGeneratingAi}
                className="inline-flex items-center text-[11px] font-semibold text-[#FF6B4A] hover:underline"
              >
                <Sparkles className="mr-1 h-3 w-3" />
                {isGeneratingAi ? 'Drafting...' : 'AI Assistant Draft'}
              </button>
            </div>
            <textarea
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0F2942]"
              required
            />
            <p className="text-[10px] text-slate-400 mt-1">
              Human-in-the-loop: Teachers can edit, refine, or approve generated lesson instructions before publishing.
            </p>
          </div>

          <DialogFooter className="mt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" isLoading={isSubmitting} leftIcon={<Send className="h-4 w-4" />}>
              Publish to Parents
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
