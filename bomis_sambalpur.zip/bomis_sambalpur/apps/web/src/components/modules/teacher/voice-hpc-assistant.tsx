'use client';

import * as React from 'react';
import {
  Mic,
  MicOff,
  Sparkles,
  CheckCircle2,
  Share2,
  Award,
  Layers,
  HeartHandshake,
  BrainCircuit,
  MessageSquare,
  Volume2,
  RefreshCw,
  Edit3,
} from 'lucide-react';

interface VoiceHpcResult {
  studentName: string;
  grade: string;
  subject: string;
  transcript: string;
  language: string;
  rubrics: {
    collaboration: string;
    scientificTemper: string;
    communication: string;
    empathyAndValues: string;
  };
  reportCardRemark: string;
  parentDigestSnippet: string;
  dinnerPrompt: string;
  housePoints: number;
}

const PRESETS = [
  {
    label: '🌊 Science Project & Leadership',
    lang: 'English',
    text: 'Aarav displayed great team leadership during the water conservation diorama project today, helping Rohan structure the dam gates.',
  },
  {
    label: '🇮🇳 Hindi (सहयोग और वैज्ञानिक दृष्टिकोण)',
    lang: 'Hindi',
    text: 'आरव ने आज विज्ञान प्रदर्शनी में बहुत ही उत्सुकता से भाग लिया और अपनी टीम के सभी सहपाठियों का हौसला बढ़ाया।',
  },
  {
    label: '🌸 Odia (ନେତୃତ୍ୱ ଓ ସାମୂହିକ କାର୍ଯ୍ୟ)',
    lang: 'Odia',
    text: 'ଆରଭ ଆଜି ବିଜ୍ଞାନ ପ୍ରକଳ୍ପରେ ବହୁତ ଭଲ ନେତୃତ୍ୱ ନେଇଥିଲେ ଏବଂ ସାଙ୍ଗମାନଙ୍କୁ ସାହାଯ୍ୟ କରିଥିଲେ।',
  },
  {
    label: '📐 Math Geometry Peer Mentorship',
    lang: 'English',
    text: 'Aarav patiently helped 3 classmates calculate 3D volume ratios using wooden blocks in the math lab.',
  },
];

export function VoiceHpcAssistant() {
  const [isRecording, setIsRecording] = React.useState(false);
  const [selectedLanguage, setSelectedLanguage] = React.useState<'English' | 'Hindi' | 'Odia'>('English');
  const [transcript, setTranscript] = React.useState(
    'Aarav displayed great team leadership during the water conservation diorama project today, helping Rohan structure the dam gates.'
  );
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [hpcResult, setHpcResult] = React.useState<VoiceHpcResult | null>(null);
  const [isApproved, setIsApproved] = React.useState(false);

  // Auto-generate on first mount with initial preset
  React.useEffect(() => {
    handleProcess(transcript, 'English');
  }, []);

  const handleStartRecording = () => {
    setIsRecording(true);
    setTranscript('');
    // Simulate speech-to-text stream
    let currentText = '';
    const sample = 'Aarav took initiative during group diorama construction, guiding peers on water reservoir gates.';
    let i = 0;
    const interval = setInterval(() => {
      if (i < sample.length) {
        currentText += sample[i];
        setTranscript(currentText);
        i += 3;
      } else {
        clearInterval(interval);
        setIsRecording(false);
        handleProcess(sample, selectedLanguage);
      }
    }, 80);
  };

  const handleProcess = (textToProcess: string, lang: string) => {
    setIsProcessing(true);
    setIsApproved(false);

    setTimeout(() => {
      const isLeadership = textToProcess.toLowerCase().includes('lead') || 
                           textToProcess.toLowerCase().includes('help') || 
                           textToProcess.toLowerCase().includes('ସାହାଯ୍ୟ') || 
                           textToProcess.toLowerCase().includes('सहपाठियों');
      const isScience = textToProcess.toLowerCase().includes('diorama') || 
                        textToProcess.toLowerCase().includes('water') || 
                        textToProcess.toLowerCase().includes('विज्ञान') || 
                        textToProcess.toLowerCase().includes('ବିଜ୍ଞାନ');

      const result: VoiceHpcResult = {
        studentName: 'Aarav Patel (5A)',
        grade: 'Grade 5A',
        subject: isScience ? 'Environmental Studies & Science' : 'Mathematics Lab',
        transcript: textToProcess,
        language: lang,
        rubrics: {
          collaboration: isLeadership ? 'Level 4: Exemplary (Proactive Peer Mentorship)' : 'Level 3: Proficient (Active Co-worker)',
          scientificTemper: isScience ? 'Level 4: Exemplary (Practical Hydraulic Modeling)' : 'Level 3: Proficient (Concept Mastery)',
          communication: 'Level 3: Proficient (Clear Articulation of Ideas)',
          empathyAndValues: isLeadership ? 'Level 4: Exemplary (Voluntary Peer Support)' : 'Level 3: Proficient (Respectful Interaction)',
        },
        reportCardRemark: `Aarav demonstrated exemplary collaborative initiative and applied scientific reasoning during hands-on project work. Readily assisted team members with practical structure engineering.`,
        parentDigestSnippet: `🌟 Class Highlight: Aarav took positive leadership in team diorama construction, helping classmates understand reservoir mechanics!`,
        dinnerPrompt: `Ask Aarav how his team designed the spillway gates for the Hirakud diorama model today!`,
        housePoints: 5,
      };

      setHpcResult(result);
      setIsProcessing(false);
    }, 450);
  };

  return (
    <div className="rounded-2xl border border-indigo-200 bg-white p-6 shadow-sm">
      {/* Title & Badge */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-sm">
              <Mic className="h-4 w-4" />
            </span>
            <h2 className="text-lg font-bold text-slate-900">
              Teacher Voice-to-Rubric Assistant (Voice HPC)
            </h2>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            CBSE NEP 2020 Holistic Progress Card (HPC) 360° Rubrics • Zero Data Entry • Odia/Hindi/English Support
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 border border-emerald-200">
            <Sparkles className="h-3 w-3" /> NEP 2020 CCE Compliant
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-700 border border-indigo-200">
            <Award className="h-3 w-3" /> +5 House Points
          </span>
        </div>
      </div>

      {/* Dictation Box & Controls */}
      <div className="mt-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600">Language:</span>
            {(['English', 'Hindi', 'Odia'] as const).map((lang) => (
              <button
                key={lang}
                onClick={() => {
                  setSelectedLanguage(lang);
                  const p = PRESETS.find((x) => x.lang === lang);
                  if (p) {
                    setTranscript(p.text);
                    handleProcess(p.text, lang);
                  }
                }}
                className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-all ${
                  selectedLanguage === lang
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {lang === 'English' ? '🇬🇧 English' : lang === 'Hindi' ? '🇮🇳 हिन्दी' : '🌸 ଓଡ଼ିଆ'}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">Quick Presets:</span>
            <div className="flex flex-wrap gap-1.5">
              {PRESETS.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSelectedLanguage(p.lang as any);
                    setTranscript(p.text);
                    handleProcess(p.text, p.lang);
                  }}
                  className="rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] font-medium text-slate-700 hover:bg-indigo-50 hover:border-indigo-300 transition-colors"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Dictation Input / Speech Waveform */}
        <div className="relative rounded-xl border border-slate-200 bg-slate-50/70 p-4 transition-all focus-within:border-indigo-500 focus-within:bg-white">
          <div className="flex items-center justify-between gap-2 pb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Spoken Teacher Observation
            </span>
            {isRecording && (
              <div className="flex items-center gap-1.5">
                <span className="flex h-2 w-2 rounded-full bg-rose-500 animate-ping" />
                <span className="text-xs font-semibold text-rose-600">Listening to Teacher Voice...</span>
              </div>
            )}
          </div>

          <textarea
            value={transcript}
            onChange={(e) => setTranscript(e.target.value)}
            rows={2}
            className="w-full resize-none bg-transparent text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-hidden"
            placeholder="Dictate your classroom observation in English, Hindi, or Odia..."
          />

          <div className="mt-3 flex items-center justify-between border-t border-slate-200/60 pt-3">
            <div className="flex items-center gap-2">
              <button
                onClick={isRecording ? () => setIsRecording(false) : handleStartRecording}
                className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition-all shadow-sm ${
                  isRecording
                    ? 'bg-rose-600 text-white animate-pulse'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                {isRecording ? 'Stop Recording' : '🎙️ Hold to Speak (Mic)'}
              </button>

              <button
                onClick={() => handleProcess(transcript, selectedLanguage)}
                disabled={isProcessing || !transcript.trim()}
                className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${isProcessing ? 'animate-spin' : ''}`} />
                Analyze & Map Rubrics
              </button>
            </div>

            <span className="text-[11px] text-slate-400">
              Student: <strong className="text-slate-700">Aarav Patel (5A, Roll #01)</strong>
            </span>
          </div>
        </div>
      </div>

      {/* AI Processed Rubric Result */}
      {hpcResult && (
        <div className="mt-5 space-y-4 rounded-xl border border-indigo-100 bg-indigo-50/30 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-indigo-100 pb-3">
            <div className="flex items-center gap-2">
              <BrainCircuit className="h-4 w-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900">
                AI Rubric Synthesis for {hpcResult.studentName}
              </h3>
            </div>
            <span className="text-xs font-medium text-indigo-700 bg-indigo-100 px-2.5 py-0.5 rounded-full">
              Language: {hpcResult.language} • {hpcResult.subject}
            </span>
          </div>

          {/* 4 Rubric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-2xs">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-900">
                <HeartHandshake className="h-3.5 w-3.5 text-indigo-600" />
                Collaboration
              </div>
              <p className="mt-1 text-xs font-bold text-emerald-700">
                {hpcResult.rubrics.collaboration}
              </p>
              <span className="mt-1 inline-block text-[10px] text-slate-500">Affective Domain</span>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-2xs">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-900">
                <Sparkles className="h-3.5 w-3.5 text-indigo-600" />
                Scientific Temper
              </div>
              <p className="mt-1 text-xs font-bold text-emerald-700">
                {hpcResult.rubrics.scientificTemper}
              </p>
              <span className="mt-1 inline-block text-[10px] text-slate-500">Cognitive Domain</span>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-2xs">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-900">
                <MessageSquare className="h-3.5 w-3.5 text-indigo-600" />
                Communication
              </div>
              <p className="mt-1 text-xs font-bold text-indigo-700">
                {hpcResult.rubrics.communication}
              </p>
              <span className="mt-1 inline-block text-[10px] text-slate-500">Language Fluency</span>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white p-3 shadow-2xs">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-900">
                <Award className="h-3.5 w-3.5 text-indigo-600" />
                Empathy & Values
              </div>
              <p className="mt-1 text-xs font-bold text-emerald-700">
                {hpcResult.rubrics.empathyAndValues}
              </p>
              <span className="mt-1 inline-block text-[10px] text-slate-500">Socio-Emotional</span>
            </div>
          </div>

          {/* Automated Parent Evening Digest Snippet & Dinner Prompt */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-3.5">
              <div className="flex items-center justify-between gap-2 pb-1.5">
                <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                  <Share2 className="h-3.5 w-3.5 text-amber-700" />
                  Feeds Parent 60-Second Evening Digest (3:30 PM)
                </span>
                <span className="rounded-full bg-amber-200 px-2 py-0.5 text-[10px] font-bold text-amber-800">
                  Zero Teacher Typing
                </span>
              </div>
              <p className="text-xs text-amber-950 leading-relaxed font-medium">
                {hpcResult.parentDigestSnippet}
              </p>
            </div>

            <div className="rounded-xl border border-sky-200 bg-sky-50/70 p-3.5">
              <div className="flex items-center justify-between gap-2 pb-1.5">
                <span className="text-xs font-bold text-sky-900 flex items-center gap-1.5">
                  <Volume2 className="h-3.5 w-3.5 text-sky-700" />
                  "Ask Aarav at Dinner" Prompt
                </span>
                <span className="rounded-full bg-sky-200 px-2 py-0.5 text-[10px] font-bold text-sky-800">
                  Family Delight
                </span>
              </div>
              <p className="text-xs text-sky-950 leading-relaxed font-medium italic">
                "{hpcResult.dinnerPrompt}"
              </p>
            </div>
          </div>

          {/* Report Card Official Remark */}
          <div className="rounded-xl border border-slate-200 bg-white p-3.5">
            <div className="flex items-center justify-between gap-2 pb-1.5">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Edit3 className="h-3.5 w-3.5 text-indigo-600" />
                CBSE Report Card Official Observation Draft
              </span>
              <span className="text-[11px] text-slate-400">Editable by Teacher</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-normal bg-slate-50 p-2.5 rounded-lg border border-slate-100">
              {hpcResult.reportCardRemark}
            </p>
          </div>

          {/* Teacher Approval Action */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span>Human-in-the-Loop: Requires Teacher Sign-off before official record commit</span>
            </div>

            <button
              onClick={() => setIsApproved(true)}
              disabled={isApproved}
              className={`inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold transition-all shadow-sm ${
                isApproved
                  ? 'bg-emerald-600 text-white cursor-default'
                  : 'bg-indigo-600 text-white hover:bg-indigo-700'
              }`}
            >
              <CheckCircle2 className="h-4 w-4" />
              {isApproved
                ? '✓ Committed to Aarav’s HPC & Digest'
                : 'Commit & Sign Off (Mrs. Arundhati Dash)'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
