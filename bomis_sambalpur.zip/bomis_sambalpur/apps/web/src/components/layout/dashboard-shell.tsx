'use client';

import * as React from 'react';
import { UserRole } from '@bomis/shared';
import { Sidebar } from './sidebar';
import { TopNavbar } from './top-navbar';

export interface DashboardShellProps {
  user: {
    name: string;
    email: string;
    avatarUrl?: string;
    role: UserRole;
  };
  childrenList?: Array<{ id: string; name: string; grade: string; admissionNo: string }>;
  activeChildId?: string;
  onSelectChild?: (childId: string) => void;
  onLogout?: () => void;
  children: React.ReactNode;
}

export function DashboardShell({
  user,
  childrenList,
  activeChildId,
  onSelectChild,
  onLogout = () => {},
  children,
}: DashboardShellProps) {
  const [collapsed, setCollapsed] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Sidebar Navigation */}
      <Sidebar
        role={user.role}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed(!collapsed)}
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
      />

      {/* Main Body */}
      <div className="flex flex-1 flex-col min-w-0">
        <TopNavbar
          user={user}
          childrenList={childrenList}
          activeChildId={activeChildId}
          onSelectChild={onSelectChild}
          onMobileMenuToggle={() => setMobileOpen(true)}
          onLogout={onLogout}
        />

        <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl w-full mx-auto animate-in fade-in duration-150">
          {children}
        </main>

        <footer className="border-t border-slate-200 bg-white py-3 px-6 text-center text-xs text-slate-400">
          Birla Open Minds International School, Sambalpur • DPDP Act (2023) Compliant • CBSE Affiliation No. 1530267
        </footer>
      </div>
    </div>
  );
}
