'use client';

import * as React from 'react';
import { UserRole } from '@bomis/shared';
import { User, Shield, LogOut, Settings, HelpCircle } from 'lucide-react';
import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';

export interface UserNavProps {
  user: {
    name: string;
    email: string;
    avatarUrl?: string;
    role: UserRole;
  };
  onLogout: () => void;
}

export function UserNav({ user, onLogout }: UserNavProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger>
        <button className="flex items-center space-x-2 rounded-full p-0.5 focus:outline-none focus:ring-2 focus:ring-[#0F2942]">
          <Avatar src={user.avatarUrl} name={user.name} size="sm" status="online" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="right" className="w-56">
        <DropdownMenuLabel>
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-semibold text-slate-900 leading-none">{user.name}</p>
            <p className="text-xs text-slate-500 truncate leading-none mt-1">{user.email}</p>
            <div className="pt-2">
              <Badge role={user.role} />
            </div>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => { alert(`Profile: ${user.name}\nRole: ${user.role}\nEmail: ${user.email}\nInstitution: Birla Open Minds International School, Sambalpur`); }}>
          <User className="mr-2 h-4 w-4 text-slate-500" /> Profile & Account
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => { alert('DPDP Act (2023) Notice: All student and parent records are encrypted with AES-256-GCM. You have the right to request access, correction, or erasure under the Digital Personal Data Protection Act.'); }}>
          <Shield className="mr-2 h-4 w-4 text-slate-500" /> DPDP Privacy Consent
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => { alert('BOMIS Sambalpur Support Desk:\nPhone: +91 94370 00001\nEmail: helpdesk@bomis-sambalpur.edu.in\nCampus: NH-53 Bypass Road, Near Remed Chhak, Sambalpur, Odisha'); }}>
          <HelpCircle className="mr-2 h-4 w-4 text-slate-500" /> Help & Support
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem destructive onClick={onLogout}>
          <LogOut className="mr-2 h-4 w-4" /> Sign Out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
