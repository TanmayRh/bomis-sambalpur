'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { UserRole } from '@bomis/shared';
import {
  LayoutDashboard,
  GraduationCap,
  Bus,
  Receipt,
  Utensils,
  Shield,
  FileText,
  ChevronLeft,
  ChevronRight,
  X,
  LucideIcon,
} from 'lucide-react';

export interface SidebarProps {
  role?: UserRole;
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onMobileClose: () => void;
}

interface NavItem {
  name: string;
  href: string;
  icon: LucideIcon;
  roles: UserRole[];
}

const NAV_ITEMS: NavItem[] = [
  {
    name: 'Home / Day-Stream',
    href: '/',
    icon: LayoutDashboard,
    roles: [
      UserRole.SUPER_ADMIN,
      UserRole.ADMIN,
      UserRole.PRINCIPAL,
      UserRole.TEACHER,
      UserRole.PARENT,
      UserRole.ACCOUNTANT,
      UserRole.TRANSPORT_STAFF,
    ],
  },
  {
    name: 'Academics & HPC',
    href: '/academics',
    icon: GraduationCap,
    roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.TEACHER, UserRole.PARENT],
  },
  {
    name: 'Transport & Fleet',
    href: '/transport',
    icon: Bus,
    roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.TRANSPORT_STAFF, UserRole.PARENT],
  },
  {
    name: 'Fee Ledger',
    href: '/fees',
    icon: Receipt,
    roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.ACCOUNTANT, UserRole.PARENT],
  },
  {
    name: 'Smart Canteen',
    href: '/canteen',
    icon: Utensils,
    roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.PARENT],
  },
  {
    name: 'DPDP Privacy Shield',
    href: '/privacy',
    icon: Shield,
    roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.PARENT],
  },
  {
    name: 'Audit Logs',
    href: '/audit',
    icon: FileText,
    roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL],
  },
];

export function Sidebar({
  role = UserRole.PARENT,
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onMobileClose,
}: SidebarProps) {
  const pathname = usePathname();

  const filteredNav = NAV_ITEMS.filter((item) => item.roles.includes(role));

  const content = (
    <aside
      className={`flex flex-col bg-[#0F2942] text-white border-r border-slate-800 transition-all duration-200 h-full ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-800/80">
        <Link href="/" className="flex items-center gap-3 overflow-hidden">
          <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 font-black flex items-center justify-center shrink-0 shadow-md">
            B
          </div>
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="font-black text-sm tracking-wide text-white">BOMIS</span>
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">Sambalpur</span>
            </div>
          )}
        </Link>

        {/* Desktop Collapse Toggle */}
        <button
          onClick={onToggleCollapse}
          className="hidden md:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>

        {/* Mobile Close Button */}
        <button
          onClick={onMobileClose}
          className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Nav List */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {filteredNav.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onMobileClose}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl font-bold text-xs transition-colors ${
                isActive
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
              title={collapsed ? item.name : undefined}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {!collapsed && <span className="truncate">{item.name}</span>}
            </Link>
          );
        })}
      </nav>

      {/* Footer Meta */}
      {!collapsed && (
        <div className="p-4 border-t border-slate-800/80 text-[10px] text-slate-400">
          <p className="font-semibold text-slate-300">CBSE Affiliation: 1530267</p>
          <p className="text-slate-500 mt-0.5">DPDP Act 2023 · ISO 27001</p>
        </div>
      )}
    </aside>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <div className="hidden md:block shrink-0">{content}</div>

      {/* Mobile Overlay Sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onMobileClose} />
          <div className="relative z-10 w-64 h-full shadow-2xl">{content}</div>
        </div>
      )}
    </>
  );
}
