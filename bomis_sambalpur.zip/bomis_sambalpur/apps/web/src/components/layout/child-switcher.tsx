'use client';

import * as React from 'react';
import { Check, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Avatar } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';

export interface ChildItem {
  id: string;
  name: string;
  grade: string;
  admissionNo: string;
  avatarUrl?: string;
}

export interface ChildSwitcherProps {
  childrenList: ChildItem[];
  activeChildId: string;
  onSelectChild: (childId: string) => void;
}

export function ChildSwitcher({ childrenList, activeChildId, onSelectChild }: ChildSwitcherProps) {
  const activeChild = childrenList.find((c) => c.id === activeChildId) || childrenList[0];

  if (!activeChild) return null;

  // Single child display mode (no dropdown if parent has only 1 child)
  if (childrenList.length === 1) {
    return (
      <div className="flex items-center space-x-2 rounded-lg bg-slate-100 px-3 py-1.5 text-xs text-slate-700">
        <Avatar name={activeChild.name} size="xs" />
        <span className="font-semibold">{activeChild.name}</span>
        <span className="text-slate-400">({activeChild.grade})</span>
      </div>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger>
        <button className="flex w-full items-center justify-between space-x-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs hover:bg-slate-100 transition-colors focus:outline-none focus:ring-2 focus:ring-[#0F2942]">
          <div className="flex items-center space-x-2 truncate">
            <Avatar name={activeChild.name} size="xs" />
            <div className="truncate text-left leading-tight">
              <span className="font-bold text-slate-900 block truncate">{activeChild.name}</span>
              <span className="text-[11px] text-slate-500">{activeChild.grade} • {activeChild.admissionNo}</span>
            </div>
          </div>
          <ChevronDown className="h-3.5 w-3.5 text-slate-400 shrink-0 ml-1" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="left" className="w-64">
        <DropdownMenuLabel>Switch Student</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {childrenList.map((child) => {
          const isSelected = child.id === activeChild.id;
          return (
            <DropdownMenuItem
              key={child.id}
              onClick={() => onSelectChild(child.id)}
              className={cn(isSelected && 'bg-[#0F2942]/10 font-semibold text-[#0F2942]')}
            >
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center space-x-2 truncate">
                  <Avatar name={child.name} size="xs" />
                  <div className="truncate">
                    <p className="text-xs font-semibold leading-none">{child.name}</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">{child.grade} • Adm: {child.admissionNo}</p>
                  </div>
                </div>
                {isSelected && <Check className="h-4 w-4 text-[#0F2942]" />}
              </div>
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
