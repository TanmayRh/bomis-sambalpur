'use client';

import * as React from 'react';
import { Menu, Bell, School } from 'lucide-react';
import { UserRole } from '@bomis/shared';
import { Badge } from '@/components/ui/badge';
import { UserNav } from './user-nav';
import { ChildSwitcher } from './child-switcher';

export interface TopNavbarProps {
  user: {
    name: string;
    email: string;
    avatarUrl?: string;
    role: UserRole;
  };
  childrenList?: Array<{ id: string; name: string; grade: string; admissionNo: string }>;
  activeChildId?: string;
  onSelectChild?: (childId: string) => void;
  onMobileMenuToggle: () => void;
  onLogout: () => void;
}

export function TopNavbar({
  user,
  childrenList,
  activeChildId,
  onSelectChild,
  onMobileMenuToggle,
  onLogout,
}: TopNavbarProps) {
  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur md:px-6 shadow-sm">
      {/* Left: Mobile Toggle & Campus Badge */}
      <div className="flex items-center space-x-3">
        <button
          onClick={onMobileMenuToggle}
          className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 md:hidden focus:outline-none"
          aria-label="Toggle menu"
        >
          <Menu className="h-6 w-6" />
        </button>

        <div className="hidden sm:flex items-center space-x-2">
          <School className="h-5 w-5 text-[#0F2942]" />
          <span className="font-semibold text-sm text-slate-800">
            BOMIS Sambalpur
          </span>
          <span className="text-slate-300">•</span>
          <span className="text-xs text-slate-500 hidden lg:inline">CBSE Affiliation 1530267</span>
          <Badge variant="outline" className="text-[11px] font-semibold text-slate-600 bg-slate-50">
            AY 2026-27
          </Badge>
        </div>
      </div>

      {/* Center: Parent Sibling Switcher (if applicable) */}
      {user.role === UserRole.PARENT && childrenList && childrenList.length > 0 && (
        <div className="mx-2 flex-1 max-w-xs">
          <ChildSwitcher
            childrenList={childrenList}
            activeChildId={activeChildId || childrenList[0]?.id || ''}
            onSelectChild={onSelectChild || (() => {})}
          />
        </div>
      )}

      {/* Right: Notifications & User Menu */}
      <div className="flex items-center space-x-3">
        {/* Notification Bell */}
        <button
          className="relative rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-colors"
          aria-label="Notifications"
        >
          <Bell className="h-5 w-5" />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-[#FF6B4A] ring-2 ring-white animate-pulse" />
        </button>

        <div className="h-6 w-px bg-slate-200" />

        {/* User Profile Menu */}
        <UserNav user={user} onLogout={onLogout} />
      </div>
    </header>
  );
}
