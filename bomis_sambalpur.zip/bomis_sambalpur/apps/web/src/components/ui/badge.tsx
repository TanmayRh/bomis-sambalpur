import * as React from 'react';
import { UserRole, AttendanceStatus } from '@bomis/shared';
import { roleBadgeColors, attendanceStatusStyles } from '@bomis/ui';
import { cn } from '@/lib/utils';

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'accent' | 'secondary' | 'destructive' | 'outline' | 'success' | 'warning';
  role?: UserRole;
  attendanceStatus?: AttendanceStatus;
}

export function Badge({ className, variant = 'default', role, attendanceStatus, style, children, ...props }: BadgeProps) {
  // If role is passed, use official @bomis/ui role token styling
  if (role && roleBadgeColors[role]) {
    const roleStyle = roleBadgeColors[role];
    return (
      <div
        className={cn(
          'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold tracking-wide transition-colors',
          className
        )}
        style={{
          backgroundColor: roleStyle.bg,
          color: roleStyle.text,
          borderColor: roleStyle.border,
          ...style,
        }}
        {...props}
      >
        {children || role.replace('_', ' ')}
      </div>
    );
  }

  // If attendanceStatus is passed, use official @bomis/ui status style
  if (attendanceStatus && attendanceStatusStyles[attendanceStatus]) {
    const attStyle = attendanceStatusStyles[attendanceStatus];
    return (
      <div
        className={cn(
          'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors',
          className
        )}
        style={{
          backgroundColor: attStyle.bg,
          color: attStyle.text,
          ...style,
        }}
        {...props}
      >
        {children || attStyle.label}
      </div>
    );
  }

  const variants: Record<string, string> = {
    default: 'bg-[#0F2942] text-white hover:bg-[#1A3A5C]',
    accent: 'bg-[#FFF5F2] text-[#94311B] border border-[#FFD4CB]',
    secondary: 'bg-slate-100 text-slate-800 hover:bg-slate-200',
    destructive: 'bg-red-100 text-red-800 border border-red-200',
    outline: 'border border-slate-300 text-slate-700',
    success: 'bg-emerald-50 text-emerald-800 border border-emerald-200',
    warning: 'bg-amber-50 text-amber-800 border border-amber-200',
  };

  return (
    <div
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors',
        variants[variant],
        className
      )}
      style={style}
      {...props}
    >
      {children}
    </div>
  );
}
