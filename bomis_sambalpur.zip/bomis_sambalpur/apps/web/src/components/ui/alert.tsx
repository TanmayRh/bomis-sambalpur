import * as React from 'react';
import { AlertCircle, CheckCircle2, AlertTriangle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface AlertProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'info' | 'success' | 'warning' | 'destructive';
  icon?: React.ReactNode;
}

export const Alert = React.forwardRef<HTMLDivElement, AlertProps>(
  ({ className, variant = 'default', icon, children, ...props }, ref) => {
    const variants: Record<string, { container: string; defaultIcon: React.ReactNode }> = {
      default: {
        container: 'bg-slate-50 text-slate-900 border-slate-200',
        defaultIcon: <Info className="h-5 w-5 text-[#0F2942]" />,
      },
      info: {
        container: 'bg-blue-50 text-blue-900 border-blue-200',
        defaultIcon: <Info className="h-5 w-5 text-blue-600" />,
      },
      success: {
        container: 'bg-emerald-50 text-emerald-900 border-emerald-200',
        defaultIcon: <CheckCircle2 className="h-5 w-5 text-emerald-600" />,
      },
      warning: {
        container: 'bg-amber-50 text-amber-900 border-amber-200',
        defaultIcon: <AlertTriangle className="h-5 w-5 text-amber-600" />,
      },
      destructive: {
        container: 'bg-red-50 text-red-900 border-red-200',
        defaultIcon: <AlertCircle className="h-5 w-5 text-red-600" />,
      },
    };

    const currentVariant = variants[variant] || variants.default || {
      container: 'bg-slate-50 text-slate-900 border-slate-200',
      defaultIcon: <Info className="h-5 w-5 text-slate-600" />,
    };

    return (
      <div
        ref={ref}
        role="alert"
        className={cn(
          'relative w-full rounded-xl border p-4 flex items-start space-x-3 text-sm shadow-sm',
          currentVariant.container,
          className
        )}
        {...props}
      >
        <span className="shrink-0 mt-0.5">{icon || currentVariant.defaultIcon}</span>
        <div className="flex-1">{children}</div>
      </div>
    );
  }
);
Alert.displayName = 'Alert';

export function AlertTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return <h5 className={cn('font-semibold leading-tight tracking-tight mb-1 text-slate-900', className)} {...props} />;
}

export function AlertDescription({ className, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return <div className={cn('text-xs opacity-90 leading-relaxed text-slate-700', className)} {...props} />;
}
