import * as React from 'react';
import { cn } from '@/lib/utils';

interface TabsContextType {
  value: string;
  onValueChange: (value: string) => void;
  variant: 'pill' | 'underline';
}

const TabsContext = React.createContext<TabsContextType | undefined>(undefined);

export function Tabs({
  value: controlledValue,
  defaultValue = '',
  onValueChange,
  variant = 'pill',
  children,
  className,
}: {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  variant?: 'pill' | 'underline';
  children: React.ReactNode;
  className?: string;
}) {
  const [internalValue, setInternalValue] = React.useState(defaultValue);
  const activeValue = controlledValue !== undefined ? controlledValue : internalValue;

  const handleValueChange = (val: string) => {
    if (controlledValue === undefined) setInternalValue(val);
    onValueChange?.(val);
  };

  return (
    <TabsContext.Provider value={{ value: activeValue, onValueChange: handleValueChange, variant }}>
      <div className={cn('w-full', className)}>{children}</div>
    </TabsContext.Provider>
  );
}

export function TabsList({ className, children }: { className?: string; children: React.ReactNode }) {
  const context = React.useContext(TabsContext);
  if (!context) throw new Error('TabsList must be used within Tabs');

  const pillStyles = 'inline-flex h-10 items-center justify-center rounded-lg bg-slate-100 p-1 text-slate-500';
  const underlineStyles = 'inline-flex border-b border-slate-200 gap-6 w-full';

  return (
    <div
      role="tablist"
      className={cn(context.variant === 'pill' ? pillStyles : underlineStyles, className)}
    >
      {children}
    </div>
  );
}

export function TabsTrigger({
  value,
  className,
  children,
}: {
  value: string;
  className?: string;
  children: React.ReactNode;
}) {
  const context = React.useContext(TabsContext);
  if (!context) throw new Error('TabsTrigger must be used within Tabs');

  const isSelected = context.value === value;

  const pillTrigger = cn(
    'inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F2942]',
    isSelected ? 'bg-white text-[#0F2942] shadow-sm font-semibold' : 'hover:text-slate-900 text-slate-600'
  );

  const underlineTrigger = cn(
    'inline-flex items-center justify-center whitespace-nowrap pb-3 text-sm font-medium transition-colors border-b-2 -mb-px focus-visible:outline-none',
    isSelected ? 'border-[#0F2942] text-[#0F2942] font-semibold' : 'border-transparent text-slate-500 hover:text-slate-800'
  );

  return (
    <button
      role="tab"
      aria-selected={isSelected}
      type="button"
      onClick={() => context.onValueChange(value)}
      className={cn(context.variant === 'pill' ? pillTrigger : underlineTrigger, className)}
    >
      {children}
    </button>
  );
}

export function TabsContent({
  value,
  className,
  children,
}: {
  value: string;
  className?: string;
  children: React.ReactNode;
}) {
  const context = React.useContext(TabsContext);
  if (!context) throw new Error('TabsContent must be used within Tabs');

  if (context.value !== value) return null;

  return (
    <div role="tabpanel" className={cn('mt-4 focus-visible:outline-none', className)}>
      {children}
    </div>
  );
}
