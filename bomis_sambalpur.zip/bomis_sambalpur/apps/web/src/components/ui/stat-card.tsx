import * as React from 'react';
import { LucideIcon, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { Card, CardContent } from './card';
import { cn } from '@/lib/utils';

export interface StatCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'increase' | 'decrease' | 'neutral';
  period?: string;
  icon: LucideIcon;
  variant?: 'default' | 'navy' | 'coral' | 'success' | 'warning';
  className?: string;
}

export function StatCard({
  title,
  value,
  change,
  changeType = 'neutral',
  period,
  icon: Icon,
  variant = 'default',
  className,
}: StatCardProps) {
  const iconVariants: Record<string, string> = {
    default: 'bg-slate-100 text-slate-700',
    navy: 'bg-[#0F2942]/10 text-[#0F2942]',
    coral: 'bg-[#FF6B4A]/10 text-[#FF6B4A]',
    success: 'bg-emerald-100 text-emerald-700',
    warning: 'bg-amber-100 text-amber-700',
  };

  return (
    <Card className={cn('hover:shadow-md transition-shadow', className)}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-slate-500">{title}</p>
          <div className={cn('rounded-lg p-2.5', iconVariants[variant])}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
        <div className="mt-3">
          <h3 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-900">{value}</h3>
          {change && (
            <div className="mt-2 flex items-center text-xs space-x-1.5">
              {changeType === 'increase' && (
                <span className="inline-flex items-center font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                  <TrendingUp className="mr-1 h-3 w-3" /> {change}
                </span>
              )}
              {changeType === 'decrease' && (
                <span className="inline-flex items-center font-semibold text-red-600 bg-red-50 px-1.5 py-0.5 rounded">
                  <TrendingDown className="mr-1 h-3 w-3" /> {change}
                </span>
              )}
              {changeType === 'neutral' && (
                <span className="inline-flex items-center font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
                  <Minus className="mr-1 h-3 w-3" /> {change}
                </span>
              )}
              {period && <span className="text-slate-400">{period}</span>}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
