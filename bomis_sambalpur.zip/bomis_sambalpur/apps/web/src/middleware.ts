import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { UserRole } from '@bomis/shared';

export const ROUTE_ROLE_PERMISSIONS: Record<string, UserRole[]> = {
  '/admin': [UserRole.SUPER_ADMIN, UserRole.ADMIN],
  '/principal': [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL],
  '/teacher': [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.TEACHER],
  '/accountant': [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.ACCOUNTANT],
  '/parent': [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PARENT, UserRole.STUDENT],
  '/profile': [
    UserRole.SUPER_ADMIN,
    UserRole.ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TEACHER,
    UserRole.ACCOUNTANT,
    UserRole.PARENT,
    UserRole.STUDENT,
    UserRole.TRANSPORT_STAFF,
  ],
};

export const DEFAULT_ROLE_REDIRECT: Record<UserRole, string> = {
  [UserRole.SUPER_ADMIN]: '/admin',
  [UserRole.ADMIN]: '/admin',
  [UserRole.PRINCIPAL]: '/principal',
  [UserRole.TEACHER]: '/teacher',
  [UserRole.ACCOUNTANT]: '/accountant',
  [UserRole.PARENT]: '/parent',
  [UserRole.STUDENT]: '/parent',
  [UserRole.TRANSPORT_STAFF]: '/admin',
};

function decodeJwtPayload(token: string): { role?: UserRole; exp?: number; sub?: string } | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const base64 = parts[1]!.replace(/-/g, '+').replace(/_/g, '/');
    const json = atob(base64);
    return JSON.parse(json);
  } catch {
    return null;
  }
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Ignore static assets, next internal routes, and api routes
  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    pathname.startsWith('/static') ||
    pathname.includes('.')
  ) {
    return NextResponse.next();
  }

  const token = request.cookies.get('bomis_access_token')?.value;
  const roleCookie = request.cookies.get('bomis_user_role')?.value as UserRole | undefined;

  let decoded = token ? decodeJwtPayload(token) : null;
  let isTokenExpired = decoded?.exp ? decoded.exp * 1000 < Date.now() : false;
  // If token is a dummy/mock token without standard jwt structure or expired, check roleCookie
  let userRole = decoded?.role || roleCookie;
  let isAuthenticated = !!token && !isTokenExpired;

  const isAuthRoute =
    pathname.startsWith('/login') ||
    pathname.startsWith('/verify-otp') ||
    pathname.startsWith('/forgot-password');

  // Case 1: Authenticated user accessing auth routes -> Redirect to dashboard
  if (isAuthRoute && isAuthenticated && userRole) {
    const redirectUrl = DEFAULT_ROLE_REDIRECT[userRole] || '/parent';
    return NextResponse.redirect(new URL(redirectUrl, request.url));
  }

  // Case 2: Public landing page '/'
  if (pathname === '/') {
    if (isAuthenticated && userRole) {
      const redirectUrl = DEFAULT_ROLE_REDIRECT[userRole] || '/parent';
      return NextResponse.redirect(new URL(redirectUrl, request.url));
    }
    return NextResponse.next();
  }

  // Case 3: Public Auth Routes
  if (isAuthRoute) {
    return NextResponse.next();
  }

  // Case 4: Protected Routes
  const matchedPrefix = Object.keys(ROUTE_ROLE_PERMISSIONS).find(
    (prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`)
  );

  if (matchedPrefix) {
    // Unauthenticated user attempting to access protected route
    if (!isAuthenticated) {
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      const response = NextResponse.redirect(loginUrl);
      response.cookies.delete('bomis_access_token');
      response.cookies.delete('bomis_user_role');
      return response;
    }

    // Role authorization check (fail-closed)
    const allowedRoles = ROUTE_ROLE_PERMISSIONS[matchedPrefix];
    if (!userRole || (allowedRoles && !allowedRoles.includes(userRole))) {
      const userDashboard = userRole ? (DEFAULT_ROLE_REDIRECT[userRole] || '/parent') : '/login';
      return NextResponse.redirect(new URL(userDashboard, request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/',
    '/login/:path*',
    '/admin/:path*',
    '/principal/:path*',
    '/teacher/:path*',
    '/accountant/:path*',
    '/parent/:path*',
    '/profile/:path*',
  ],
};
