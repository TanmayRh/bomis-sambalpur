'use client';

import { useSyncExternalStore } from 'react';
import { UserRole } from '@bomis/shared';
import {
  getAuthTokens,
  setAuthTokens,
  clearAuthTokens,
  setActiveChildCookie,
  getActiveChildCookie,
} from './api-client';

export interface AuthUser {
  id: string;
  email: string | null;
  phone: string | null;
  role: UserRole;
  schoolId: string;
  firstName: string;
  lastName: string;
}

export interface LinkedSibling {
  id: string;
  admissionNumber: string;
  rollNumber: string;
  firstName: string;
  lastName: string;
  grade: number;
  section: string;
  classId: string;
  sectionId: string;
  bloodGroup: string;
  emergencyContact: string;
  relationship: string;
  house?: string;
}

export interface AuthState {
  user: AuthUser | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  linkedChildren: LinkedSibling[];
  activeChildId: string | null;
  activeChild: LinkedSibling | null;
}

// Initial mock siblings for Aarav & Ananya Patel if offline/development
export const DEFAULT_SIBLINGS: LinkedSibling[] = [
  {
    id: 'b1000000-0005-4000-8000-000000000001',
    admissionNumber: 'BOMIS-2021-0042',
    rollNumber: '1',
    firstName: 'Aarav',
    lastName: 'Patel',
    grade: 5,
    section: 'A',
    classId: 'c1000000-0005-4000-8000-000000000001',
    sectionId: 's1000000-0005-4000-8000-000000000001',
    bloodGroup: 'O+',
    emergencyContact: '+919876543210',
    relationship: 'FATHER',
    house: 'KALINGA',
  },
  {
    id: 'b1000000-0002-4000-8000-000000000001',
    admissionNumber: 'BOMIS-2024-0118',
    rollNumber: '4',
    firstName: 'Ananya',
    lastName: 'Patel',
    grade: 2,
    section: 'A',
    classId: 'c1000000-0002-4000-8000-000000000001',
    sectionId: 's1000000-0002-4000-8000-000000000001',
    bloodGroup: 'B+',
    emergencyContact: '+919876543210',
    relationship: 'FATHER',
    house: 'KALINGA',
  },
];

class AuthStore {
  private state: AuthState;
  private listeners = new Set<() => void>();

  constructor() {
    const tokens = typeof window !== 'undefined' ? getAuthTokens() : { accessToken: null, refreshToken: null, role: null };
    const savedChildId = typeof window !== 'undefined' ? getActiveChildCookie() : null;
    let savedUser: AuthUser | null = null;
    if (typeof window !== 'undefined') {
      try {
        const str = localStorage.getItem('bomis_user');
        if (str) savedUser = JSON.parse(str);
      } catch {}
    }

    const defaultChild = DEFAULT_SIBLINGS[0]!;
    const activeId = savedChildId || defaultChild.id;

    this.state = {
      user: savedUser,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      isAuthenticated: !!tokens.accessToken,
      linkedChildren: DEFAULT_SIBLINGS,
      activeChildId: activeId,
      activeChild: DEFAULT_SIBLINGS.find((c) => c.id === activeId) || defaultChild,
    };
  }

  getState = (): AuthState => this.state;

  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };

  private notify() {
    this.listeners.forEach((l) => l());
  }

  setSession = (user: AuthUser, accessToken: string, refreshToken: string) => {
    setAuthTokens(accessToken, refreshToken, user.role);
    if (typeof window !== 'undefined') {
      localStorage.setItem('bomis_user', JSON.stringify(user));
    }
    this.state = {
      ...this.state,
      user,
      accessToken,
      refreshToken,
      isAuthenticated: true,
    };
    this.notify();
  };

  setLinkedChildren = (children: LinkedSibling[]) => {
    let activeId = this.state.activeChildId;
    if (!activeId || !children.some((c) => c.id === activeId)) {
      activeId = children[0]?.id || null;
    }
    if (activeId) {
      setActiveChildCookie(activeId);
    }
    const activeChild = children.find((c) => c.id === activeId) || null;

    this.state = {
      ...this.state,
      linkedChildren: children,
      activeChildId: activeId,
      activeChild,
    };
    this.notify();
  };

  setActiveChildId = (childId: string) => {
    setActiveChildCookie(childId);
    const activeChild = this.state.linkedChildren.find((c) => c.id === childId) || null;
    this.state = {
      ...this.state,
      activeChildId: childId,
      activeChild,
    };
    this.notify();
  };

  logout = () => {
    clearAuthTokens();
    if (typeof window !== 'undefined') {
      localStorage.removeItem('bomis_user');
    }
    this.state = {
      user: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,
      linkedChildren: DEFAULT_SIBLINGS,
      activeChildId: DEFAULT_SIBLINGS[0]!.id,
      activeChild: DEFAULT_SIBLINGS[0]!,
    };
    this.notify();
    if (typeof window !== 'undefined') {
      window.location.href = '/login';
    }
  };
}

export const authStore = new AuthStore();

export function useAuthStore<T>(selector: (state: AuthState) => T): T {
  return useSyncExternalStore(
    authStore.subscribe,
    () => selector(authStore.getState()),
    () => selector(authStore.getState())
  );
}
