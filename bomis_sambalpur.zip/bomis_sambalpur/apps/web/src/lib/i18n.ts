// BOMIS Sambalpur Unified Platform - Tri-lingual i18n Catalog (en, hi, or)
// Strictly follows the Master String Table for English, Hindi, and Odia

export type SupportedLocale = 'en' | 'hi' | 'or';

export const STRING_CATALOG: Record<string, Record<SupportedLocale, string>> = {
  // Closure Alert
  'closure.title': {
    en: 'No school today',
    hi: 'आज स्कूल बंद है',
    or: 'ଆଜି ସ୍କୁଲ ବନ୍ଦ ଅଛି',
  },
  'closure.detail.rain': {
    en: 'Heavy rain across Sambalpur · Classes {classes} suspended today · Buses will not run',
    hi: 'संबलपुर में भारी बारिश · कक्षा {classes} आज बंद रहेगी · बसें नहीं चलेंगी',
    or: 'ସମ୍ବଲପୁରରେ ପ୍ରବଳ ବର୍ଷା · {classes} ଶ୍ରେଣୀ ଆଜି ବନ୍ଦ ରହିବ · ବସ୍ ଚାଲିବ ନାହିଁ',
  },
  'closure.source': {
    en: 'By order of the District Collector, Sambalpur · {time}',
    hi: 'जिला कलेक्टर, संबलपुर के आदेश से · {time}',
    or: 'ସମ୍ବଲପୁର ଜିଲ୍ଲାପାଳଙ୍କ ଆଦେଶକ୍ରମେ · {time}',
  },
  'closure.btn.ack': {
    en: "Got it, keeping children home",
    hi: 'समझ गए, बच्चे घर पर सुरक्षित हैं',
    or: 'ବୁଝିଲୁ, ପିଲାମାନେ ଘରେ ସୁରକ୍ଷିତ ଅଛନ୍ତି',
  },
  'closure.btn.left': {
    en: 'Child already left for bus stop',
    hi: 'बच्चा बस स्टॉप के लिए निकल चुका है',
    or: 'ପିଲା ବସ୍ ଷ୍ଟପେଜକୁ ବାହାରି ସାରିଛି',
  },
  'closure.footer': {
    en: 'Next update by {time}',
    hi: 'अगला अपडेट {time} तक',
    or: 'ପରବର୍ତ୍ତୀ ଅପଡେଟ୍ {time} ସୁଦ୍ଧା',
  },
  'closure.updated': {
    en: 'Updated {time}',
    hi: 'अपडेट किया गया {time}',
    or: '{time}ରେ ଅପଡେଟ୍ ହୋଇଛି',
  },
  'common.listen': {
    en: 'Listen',
    hi: 'सुनिए',
    or: 'ଶୁଣନ୍ତୁ',
  },

  // Fee Card (Four States + Calm Escrow Shield)
  'fee.title': {
    en: 'Payment in progress, your fee is safe',
    hi: 'भुगतान प्रक्रिया में है — आपकी फ़ीस सुरक्षित है',
    or: 'ପେମେଣ୍ଟ ଚାଲିଛି — ଆପଣଙ୍କ ଫି ସୁରକ୍ଷିତ',
  },
  'fee.detail': {
    en: 'Waiting for your bank to confirm. You started {amount} at {time}, before the deadline.',
    hi: 'आपके बैंक की पुष्टि का इंतज़ार है। आपने {amount} का भुगतान {time} पर शुरू किया था — समय-सीमा से पहले।',
    or: 'ଆପଣଙ୍କ ବ୍ୟାଙ୍କ ନିଶ୍ଚିତ କରିବାକୁ ଅପେକ୍ଷା ଚାଲିଛି। ଆପଣ {amount} ପେମେଣ୍ଟ {time}ରେ ଆରମ୍ଭ କରିଥିଲେ — ଶେଷ ସମୟ ପୂର୍ବରୁ।',
  },
  'fee.nolate': {
    en: 'No late fee',
    hi: 'कोई लेट फ़ीस नहीं',
    or: 'କୌଣସି ବିଳମ୍ବ ଶୁଳ୍କ ନାହିଁ',
  },
  'fee.exam': {
    en: "{child}'s exam is not affected",
    hi: '{child} की परीक्षा पर कोई असर नहीं',
    or: '{child}ର ପରୀକ୍ଷା ଉପରେ କୌଣସି ପ୍ରଭାବ ନାହିଁ',
  },
  'fee.norepay': {
    en: "Please don't pay again — bank confirmation takes 15–30 mins",
    hi: 'कृपया दोबारा भुगतान न करें — बैंक से पुष्टि में 15–30 मिनट लगते हैं',
    or: 'ଦୟାକରି ପୁଣି ପେମେଣ୍ଟ କରନ୍ତୁ ନାହିଁ — ବ୍ୟାଙ୍କ ନିଶ୍ଚିତକରଣ ପାଇଁ ୧୫-୩୦ ମିନିଟ୍ ଲାଗିଥାଏ',
  },
  'fee.footer': {
    en: "We'll message you the moment it's confirmed",
    hi: 'पुष्टि होते ही हम आपको संदेश भेजेंगे',
    or: 'ନିଶ୍ଚିତ ହେବା ମାତ୍ରେ ଆମେ ଆପଣଙ୍କୁ ମେସେଜ୍ ପଠାଇବୁ',
  },
  'fee.btn.save': {
    en: 'Save as proof',
    hi: 'प्रमाण के रूप में सहेजें',
    or: 'ପ୍ରମାଣ ଭାବେ ସେଭ୍ କରନ୍ତୁ',
  },
  'fee.btn.call': {
    en: 'Call accounts',
    hi: 'अकाउंट्स विभाग को कॉल करें',
    or: 'ଆକାଉଣ୍ଟ୍ସ ବିଭାଗକୁ କଲ୍ କରନ୍ତୁ',
  },

  // Sibling Clarity
  'sib.both': {
    en: '{a} & {b} · both at school today',
    hi: '{a} और {b} · दोनों आज स्कूल में हैं',
    or: '{a} ଓ {b} · ଦୁହେଁ ଆଜି ସ୍କୁଲରେ ଅଛନ୍ତି',
  },
  'sib.closed_all': {
    en: '{a} & {b} · staying safe at home today (rain holiday)',
    hi: '{a} और {b} · आज घर पर सुरक्षित हैं (बारिश की छुट्टी)',
    or: '{a} ଓ {b} · ଆଜି ଘରେ ସୁରକ୍ଷିତ (ପ୍ରବଳ ବର୍ଷା ଛୁଟି)',
  },
  'sib.off': {
    en: '{child} · no school today ({reason})',
    hi: '{child} · आज स्कूल नहीं ({reason})',
    or: '{child} · ଆଜି ସ୍କୁଲ ନାହିଁ ({reason})',
  },
  'sib.badge_off': {
    en: 'Holiday ({reason})',
    hi: 'छुट्टी ({reason})',
    or: 'ଛୁଟି ({reason})',
  },
  'reason.sports': {
    en: 'sports practice',
    hi: 'खेल अभ्यास',
    or: 'ଖେଳ ଅଭ୍ୟାସ',
  },
  'sib.absent': {
    en: '{child} is marked absent. Not expecting this?',
    hi: '{child} अनुपस्थित दर्ज है। क्या आपको इसकी उम्मीद नहीं थी?',
    or: '{child} ଅନୁପସ୍ଥିତ ଦର୍ଶାଯାଇଛି। ଆପଣ ଏହା ଆଶା କରି ନଥିଲେ କି?',
  },
  'sib.btn.call': {
    en: 'Call school',
    hi: 'स्कूल को कॉल करें',
    or: 'ସ୍କୁଲକୁ କଲ୍ କରନ୍ତୁ',
  },
  'sib.btn.know': {
    en: 'I know about this',
    hi: 'मुझे पता है',
    or: 'ମୁଁ ଜାଣେ',
  },

  // Infirmary / Medical Alert
  'inf.title': {
    en: '{child} is with the school nurse',
    hi: '{child} स्कूल नर्स के पास है',
    or: '{child} ସ୍କୁଲ ନର୍ସଙ୍କ ପାଖରେ ଅଛି',
  },
  'complaint.twisted_ankle': {
    en: 'Mild sprain (twisted ankle)',
    hi: 'टखने में हल्की मोच',
    or: 'ଗୋଇଠିରେ ସାମାନ୍ୟ ମୋଚଡ଼ା',
  },
  'inf.awake': {
    en: '{child} is awake, alert, and resting in the sick bay.',
    hi: '{child} पूरी तरह होश में है और आराम से है।',
    or: '{child} ସମ୍ପୂର୍ଣ୍ଣ ସଚେତ ଅଛି ଏବଂ ଆରାମରେ ବିଶ୍ରାମ ନେଉଛି।',
  },
  'action.ice': {
    en: 'Ice pack applied.',
    hi: 'बर्फ़ लगाई गई है।',
    or: 'ବରଫ ଲଗାଯାଇଛି।',
  },
  'medicine.none': {
    en: 'No medicine given without parent consent.',
    hi: 'आपकी अनुमति के बिना कोई दवा नहीं दी गई।',
    or: 'ଆପଣଙ୍କ ବିନା ଅନୁମତିରେ କୌଣସି ଔଷଧ ଦିଆଯାଇ ନାହିଁ।',
  },
  'medicine.given': {
    en: 'Medicine given: {name} at {time} (consent on file).',
    hi: 'दवा दी गई: {name}, {time} पर (सहमति दर्ज है)।',
    or: 'ଔଷଧ ଦିଆଯାଇଛି: {name}, {time}ରେ (ସମ୍ମତି ରେକର୍ଡରେ ଅଛି)।',
  },
  'inf.ask.amber': {
    en: 'Child is stable. Please come to school when convenient to take them home.',
    hi: 'बच्चा ठीक है। कृपया समय मिलते ही स्कूल आकर ले जाएँ।',
    or: 'ପିଲା ଠିକ୍ ଅଛି। ଦୟାକରି ସୁବିଧା ଅନୁସାରେ ସ୍କୁଲ ଆସି ଘରକୁ ନିଅନ୍ତୁ।',
  },
  'inf.ask.red': {
    en: 'Please come now.',
    hi: 'कृपया अभी आएँ।',
    or: 'ଦୟାକରି ଏବେ ଆସନ୍ତୁ।',
  },
  'inf.btn.call': {
    en: 'Call the nurse',
    hi: 'नर्स को कॉल करें',
    or: 'ନର୍ସଙ୍କୁ କଲ୍ କରନ୍ତୁ',
  },
  'inf.btn.coming': {
    en: "On our way to school",
    hi: 'हम स्कूल आ रहे हैं',
    or: 'ଆମେ ସ୍କୁଲ ଆସୁଛୁ',
  },
  'inf.btn.wa': {
    en: "Please WhatsApp me updates",
    hi: 'कृपया व्हाट्सऐप पर अपडेट दें',
    or: 'ଦୟାକରି ହ୍ୱାଟ୍ସଆପ୍‌ରେ ଜଣାନ୍ତୁ',
  },
  'inf.lock': {
    en: '{child} · School nurse, open now',
    hi: '{child} · स्कूल नर्स — अभी खोलें',
    or: '{child} · ସ୍କୁଲ ନର୍ସ — ଏବେ ଖୋଲନ୍ତୁ',
  },
  'inf.onit': {
    en: 'Nurse notified · {parent} taking care of this',
    hi: 'नर्स को सूचित किया गया · {parent} इसे देख रहे हैं',
    or: 'ନର୍ସଙ୍କୁ ଜଣାଇ ଦିଆଗଲା · {parent} ଏହା ଦେଖୁଛନ୍ତି',
  },
  'inf.resolved': {
    en: '{child} is back in class · {time}',
    hi: '{child} वापस कक्षा में है · {time}',
    or: '{child} ଫେରି କ୍ଲାସରେ ଅଛି · {time}',
  },

  // Elder / Non-Reader Simple Gate Pass
  'elder.title': {
    en: 'To pick up {child}, show this at Gate {gate}',
    hi: '{child} को लेने के लिए यह गेट {gate} पर दिखाइए',
    or: '{child}କୁ ନେବା ପାଇଁ ଏହା ଗେଟ୍ {gate} ରେ ଦେଖାନ୍ତୁ',
  },
  'elder.guard_pin': {
    en: 'PIN Code for Gate Guard',
    hi: 'गार्ड को बताने के लिए 6-अंकों का पिन',
    or: 'ଗାର୍ଡଙ୍କୁ କହିବା ପାଇଁ ପିନ୍ କୋଡ୍',
  },
  'elder.audio': {
    en: 'Namaste. Show this phone to the guard at Gate {gate}. {child} will be brought to you.',
    hi: 'नमस्ते। यह फ़ोन गेट {gate} पर गार्ड को दिखाइए। {child} को आपके पास भेजा जाएगा।',
    or: 'ନମସ୍କାର। ଏହି ଫୋନ୍ ଗେଟ୍ {gate} ରେ ଗାର୍ଡଙ୍କୁ ଦେଖାନ୍ତୁ। {child}କୁ ଆପଣଙ୍କ ପାଖକୁ ପଠାଯିବ।',
  },
  'elder.btn.call': {
    en: 'Call {parent}',
    hi: '{parent} को फ़ोन करें',
    or: '{parent}ଙ୍କୁ ଫୋନ୍ କରନ୍ତୁ',
  },
  'elder.btn.wa': {
    en: 'WhatsApp {parent}',
    hi: '{parent} को व्हाट्सऐप करें',
    or: '{parent}ଙ୍କୁ ହ୍ୱାଟ୍ସଆପ୍ କରନ୍ତୁ',
  },
  'elder.done': {
    en: '{child} is with you',
    hi: '{child} आपके साथ है',
    or: '{child} ଆପଣଙ୍କ ସହିତ ଅଛି',
  },
  'elder.expired': {
    en: 'This pass has expired. Ask {parent} for a new one.',
    hi: 'यह पास समाप्त हो गया है। {parent} से नया पास माँगिए।',
    or: 'ଏହି ପାସ୍ ମିଆଦ ଶେଷ ହୋଇଯାଇଛି। {parent}ଙ୍କଠାରୁ ନୂଆ ପାସ୍ ମାଗନ୍ତୁ।',
  },
  'elder.reached': {
    en: 'Present at school: {child} · {time}',
    hi: 'स्कूल में उपस्थित: {child} · {time}',
    or: 'ସ୍କୁଲରେ ଉପସ୍ଥିତ: {child} · {time}',
  },

  // Home Screen Essentials
  'home.school_today': {
    en: 'School today',
    hi: 'आज स्कूल है',
    or: 'ଆଜି ସ୍କୁଲ ଅଛି',
  },
  'home.bus': {
    en: 'Bus {n} reaches your stop at {time}',
    hi: 'बस {n} {time} पर आपके स्टॉप पर पहुँचेगी',
    or: 'ବସ୍ {n} {time}ରେ ଆପଣଙ୍କ ବସ୍ ଷ୍ଟପେଜକୁ ପହଞ୍ଚିବ',
  },
  'home.ontime': {
    en: 'On time',
    hi: 'समय पर',
    or: 'ସମୟରେ',
  },
  'home.nothing': {
    en: '✓ All good! Nothing needed today',
    hi: '✓ सब ठीक है! आज कुछ करने की ज़रूरत नहीं',
    or: '✓ ସବୁ ଠିକ୍ ଅଛି! ଆଜି କିଛି କରିବାକୁ ପଡ଼ିବ ନାହିଁ',
  },
  'home.later': {
    en: 'Later today',
    hi: 'आज बाद में',
    or: 'ଆଜି ପରେ',
  },
  'home.more': {
    en: 'More',
    hi: 'और देखें',
    or: 'ଅଧିକ',
  },
  'home.services': {
    en: 'Everyday School Services',
    hi: 'दैनिक स्कूल सेवाएँ',
    or: 'ଦୈନନ୍ଦିନ ସ୍କୁଲ ସେବା',
  },
  'service.diary': {
    en: 'Daily Diary',
    hi: 'दैनिक डायरी',
    or: 'ଦୈନିକ ଡାଏରୀ',
  },
  'service.attendance': {
    en: 'Attendance & Leave',
    hi: 'उपस्थिति एवं छुट्टी',
    or: 'ଉପସ୍ଥିତି ଓ ଛୁଟି',
  },
  'service.exams': {
    en: 'Exams & Marks',
    hi: 'परीक्षा एवं अंक',
    or: 'ପରୀକ୍ଷା ଓ ମାର୍କ',
  },
  'service.fees': {
    en: 'Fees & Receipts',
    hi: 'फ़ीस एवं रसीद',
    or: 'ଫିସ୍ ଓ ରସିଦ',
  },
  'service.ptm': {
    en: 'Book PTM Slot',
    hi: 'पीटीएम बुक करें',
    or: 'ପିଟିଏମ୍ ବୁକ୍ କରନ୍ତୁ',
  },
  'service.circulars': {
    en: 'School Notices',
    hi: 'स्कूल सूचनाएँ',
    or: 'ସ୍କୁଲ ନୋଟିସ୍',
  },
  'service.canteen': {
    en: 'Canteen & Meal',
    hi: 'कैंटीन भोजन',
    or: 'କ୍ୟାଣ୍ଟିନ୍ ଖାଦ୍ୟ',
  },
  'service.transport': {
    en: 'Bus Schedule',
    hi: 'बस समय-सारणी',
    or: 'ବସ୍ ସମୟ-ସୂଚୀ',
  },
  'bus.estimated': {
    en: 'Last seen {time} near {place}. Expected between {t1} and {t2}.',
    hi: 'आख़िरी बार {time} पर {place} के पास दिखी। {t1} से {t2} के बीच पहुँचने की उम्मीद।',
    or: 'ଶେଷ ଥର {time}ରେ {place} ପାଖରେ ଦେଖାଯାଇଥିଲା। {t1} ରୁ {t2} ମଧ୍ୟରେ ପହଞ୍ଚିବ ବୋଲି ଅନୁମାନ।',
  },
  'bus.lost': {
    en: 'GPS signal paused. Bus is on route. Call driver if urgent.',
    hi: 'जीपीएस सिग्नल थोड़ी देर के लिए रुका है। बस रास्ते पर है। ज़रूरत हो तो ड्राइवर को कॉल करें।',
    or: 'ଜିପିଏସ୍ ସିଗ୍ନାଲ୍ ବନ୍ଦ ଅଛି। ବସ୍ ରାସ୍ତାରେ ଅଛି। ଜରୁରୀ ହେଲେ ଡ୍ରାଇଭରଙ୍କୁ କଲ୍ କରନ୍ତୁ।',
  },
  'bus.btn.driver': {
    en: 'Call driver',
    hi: 'ड्राइवर को कॉल करें',
    or: 'ଡ୍ରାଇଭରଙ୍କୁ କଲ୍ କରନ୍ତୁ',
  },
  'bus.off': {
    en: 'Buses are not running today',
    hi: 'आज बसें नहीं चलेंगी',
    or: 'ଆଜି ବସ୍ ଚାଲିବ ନାହିଁ',
  },
};

/**
 * Format time with localized day period buckets:
 * Buckets:
 * 4 - 12: Morning (सुबह / ସକାଳ)
 * 12 - 16: Afternoon (दोपहर / ଅପରାହ୍ନ)
 * 16 - 19: Evening (शाम / ସନ୍ଧ୍ୟା)
 * 19 - 4: Night (रात / ରାତି)
 * Always uses standard Arabic digits (0-9)
 */
export function formatTime(dateInput: Date | string | number, locale: SupportedLocale = 'en'): string {
  let d: Date;
  if (typeof dateInput === 'string' || typeof dateInput === 'number') {
    // If it's already a formatted string like "7:42 AM" or "6:45 AM"
    if (typeof dateInput === 'string' && dateInput.includes(':') && (dateInput.includes('AM') || dateInput.includes('PM'))) {
      const parts = dateInput.trim().split(' ');
      const timePart = parts[0] || '12:00';
      const ampm = parts[1] || 'AM';
      const [hStr, mStr] = timePart.split(':');
      let h = parseInt(hStr || '12', 10);
      if (ampm.toUpperCase() === 'PM' && h < 12) h += 12;
      if (ampm.toUpperCase() === 'AM' && h === 12) h = 0;
      d = new Date();
      d.setHours(h, parseInt(mStr || '0', 10), 0, 0);
    } else {
      d = new Date(dateInput);
    }
  } else {
    d = dateInput;
  }

  if (isNaN(d.getTime())) {
    return String(dateInput);
  }

  const hours = d.getHours();
  const minutes = d.getMinutes().toString().padStart(2, '0');
  const displayHours = hours % 12 || 12;
  const timeString = `${displayHours}:${minutes}`;

  if (locale === 'en') {
    const period = hours >= 12 ? 'PM' : 'AM';
    return `${timeString} ${period}`;
  }

  // Buckets: 4-12, 12-16, 16-19, 19-4
  if (locale === 'hi') {
    let prefix = 'सुबह';
    if (hours >= 12 && hours < 16) prefix = 'दोपहर';
    else if (hours >= 16 && hours < 19) prefix = 'शाम';
    else if (hours >= 19 || hours < 4) prefix = 'रात';
    return `${prefix} ${timeString}`;
  }

  if (locale === 'or') {
    let prefix = 'ସକାଳ';
    if (hours >= 12 && hours < 16) prefix = 'ଅପରାହ୍ନ';
    else if (hours >= 16 && hours < 19) prefix = 'ସନ୍ଧ୍ୟା';
    else if (hours >= 19 || hours < 4) prefix = 'ରାତି';
    return `${prefix} ${timeString}`;
  }

  return `${timeString} ${hours >= 12 ? 'PM' : 'AM'}`;
}

/**
 * Translate string from catalog with parameter interpolation
 */
export function t(
  key: string,
  locale: SupportedLocale = 'en',
  params: Record<string, string | number> = {}
): string {
  const item = STRING_CATALOG[key];
  if (!item) {
    return key;
  }
  let str = item[locale] || item['en'] || key;
  Object.keys(params).forEach((paramKey) => {
    const val = params[paramKey];
    str = str.replace(new RegExp(`\\{${paramKey}\\}`, 'g'), String(val));
  });
  return str;
}
