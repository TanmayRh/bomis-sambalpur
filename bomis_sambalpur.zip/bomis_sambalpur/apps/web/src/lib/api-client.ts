import { ApiResponse, ApiErrorDetail, UserRole, AttendanceStatus } from '@bomis/shared';

export class ApiClientError extends Error {
  public readonly status: number;
  public readonly code: string;
  public readonly details?: unknown;
  public readonly correlationId?: string;

  constructor(status: number, errorObj?: ApiErrorDetail | null, correlationId?: string) {
    super(errorObj?.message || `HTTP ${status} API Error`);
    this.name = 'ApiClientError';
    this.status = status;
    this.code = errorObj?.code || 'UNKNOWN_ERROR';
    this.details = errorObj?.details;
    this.correlationId = correlationId;
  }
}

export interface StoredTokens {
  accessToken: string | null;
  refreshToken: string | null;
  role: UserRole | null;
}

function parseCookie(name: string): string | null {
  if (typeof document === 'undefined') return null;
  const match = document.cookie.match(new RegExp(`(^|;\\s*)(${name})=([^;]*)`));
  return match ? decodeURIComponent(match[3] || '') : null;
}

export function getAuthTokens(): StoredTokens {
  return {
    accessToken: parseCookie('bomis_access_token'),
    refreshToken: parseCookie('bomis_refresh_token'),
    role: parseCookie('bomis_user_role') as UserRole | null,
  };
}

export function setAuthTokens(accessToken: string, refreshToken: string, role: UserRole) {
  if (typeof document === 'undefined') return;
  // 15 min expiry for access token
  document.cookie = `bomis_access_token=${encodeURIComponent(accessToken)}; Path=/; Max-Age=900; SameSite=Lax`;
  // 7 days expiry for refresh token
  document.cookie = `bomis_refresh_token=${encodeURIComponent(refreshToken)}; Path=/; Max-Age=604800; SameSite=Lax`;
  document.cookie = `bomis_user_role=${encodeURIComponent(role)}; Path=/; Max-Age=604800; SameSite=Lax`;
}

export function clearAuthTokens() {
  if (typeof document === 'undefined') return;
  document.cookie = 'bomis_access_token=; Path=/; Max-Age=0; SameSite=Lax';
  document.cookie = 'bomis_refresh_token=; Path=/; Max-Age=0; SameSite=Lax';
  document.cookie = 'bomis_user_role=; Path=/; Max-Age=0; SameSite=Lax';
  document.cookie = 'bomis_active_child_id=; Path=/; Max-Age=0; SameSite=Lax';
}

export function setActiveChildCookie(childId: string) {
  if (typeof document === 'undefined') return;
  document.cookie = `bomis_active_child_id=${encodeURIComponent(childId)}; Path=/; Max-Age=604800; SameSite=Lax`;
}

export function getActiveChildCookie(): string | null {
  return parseCookie('bomis_active_child_id');
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || '/api/v1';

export interface RequestOptions extends RequestInit {
  params?: Record<string, string | number | boolean | undefined>;
  idempotencyKey?: string;
  skipAuth?: boolean;
}

let isRefreshing = false;
let failedQueue: Array<{
  resolve: (token: string) => void;
  reject: (error: any) => void;
}> = [];

function processQueue(error: any, token: string | null = null) {
  failedQueue.forEach((promise) => {
    if (error) {
      promise.reject(error);
    } else if (token) {
      promise.resolve(token);
    }
  });
  failedQueue = [];
}

async function refreshAccessToken(): Promise<string> {
  const { refreshToken } = getAuthTokens();
  if (!refreshToken) {
    clearAuthTokens();
    if (typeof window !== 'undefined') {
      window.location.href = '/login?session_expired=1';
    }
    throw new Error('No refresh token available');
  }

  try {
    const res = await fetch(`${API_BASE_URL}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    });

    const envelope: ApiResponse<{
      accessToken: string;
      refreshToken: string;
      user: { role: UserRole };
    }> = await res.json();

    if (!res.ok || !envelope.success || !envelope.data) {
      throw new Error(envelope.error?.message || 'Refresh failed');
    }

    setAuthTokens(envelope.data.accessToken, envelope.data.refreshToken, envelope.data.user.role);
    return envelope.data.accessToken;
  } catch (err) {
    clearAuthTokens();
    if (typeof window !== 'undefined') {
      window.location.href = '/login?session_expired=1';
    }
    throw err;
  }
}

export async function request<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
  const { params, idempotencyKey, skipAuth = false, headers: customHeaders, ...restOptions } = options;

  let url = endpoint.startsWith('http') ? endpoint : `${API_BASE_URL}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;

  if (params) {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        searchParams.append(key, String(value));
      }
    });
    const queryString = searchParams.toString();
    if (queryString) {
      url += (url.includes('?') ? '&' : '?') + queryString;
    }
  }

  const { accessToken } = getAuthTokens();
  const correlationId = `web-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

  const headers = new Headers(customHeaders);
  headers.set('Accept', 'application/json');
  headers.set('X-Correlation-Id', correlationId);

  if (!headers.has('Content-Type') && !(restOptions.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  if (idempotencyKey) {
    headers.set('Idempotency-Key', idempotencyKey);
  }

  if (!skipAuth && accessToken) {
    headers.set('Authorization', `Bearer ${accessToken}`);
  }

  let response = await fetch(url, { ...restOptions, headers });

  // Handle 401 Unauthorized token rotation
  if (response.status === 401 && !skipAuth) {
    if (isRefreshing) {
      return new Promise<string>((resolve, reject) => {
        failedQueue.push({ resolve, reject });
      }).then((newToken) => {
        headers.set('Authorization', `Bearer ${newToken}`);
        return fetch(url, { ...restOptions, headers }).then((r) => handleResponse<T>(r));
      });
    }

    isRefreshing = true;
    try {
      const newAccessToken = await refreshAccessToken();
      processQueue(null, newAccessToken);
      headers.set('Authorization', `Bearer ${newAccessToken}`);
      response = await fetch(url, { ...restOptions, headers });
    } catch (refreshErr) {
      processQueue(refreshErr, null);
      throw refreshErr;
    } finally {
      isRefreshing = false;
    }
  }

  return handleResponse<T>(response);
}

async function handleResponse<T>(response: Response): Promise<T> {
  const correlationId = response.headers.get('x-correlation-id') || undefined;

  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/pdf') || contentType.includes('text/csv')) {
    const blob = await response.blob();
    return blob as unknown as T;
  }

  let envelope: ApiResponse<T>;
  try {
    envelope = await response.json();
  } catch {
    throw new ApiClientError(
      response.status,
      { code: 'INVALID_JSON', message: 'Unable to parse server response' },
      correlationId
    );
  }

  if (!response.ok || !envelope.success) {
    throw new ApiClientError(response.status, envelope.error, correlationId || envelope.correlationId);
  }

  return envelope.data as T;
}

export const apiClient = {
  get: <T>(url: string, options?: RequestOptions) => request<T>(url, { method: 'GET', ...options }),
  post: <T>(url: string, body?: any, options?: RequestOptions) =>
    request<T>(url, {
      method: 'POST',
      body: body instanceof FormData ? body : JSON.stringify(body),
      ...options,
    }),
  put: <T>(url: string, body?: any, options?: RequestOptions) =>
    request<T>(url, {
      method: 'PUT',
      body: body instanceof FormData ? body : JSON.stringify(body),
      ...options,
    }),
  patch: <T>(url: string, body?: any, options?: RequestOptions) =>
    request<T>(url, {
      method: 'PATCH',
      body: body instanceof FormData ? body : JSON.stringify(body),
      ...options,
    }),
  delete: <T>(url: string, options?: RequestOptions) => request<T>(url, { method: 'DELETE', ...options }),
};

// Domain APIs
export const authApi = {
  sendOtp: (phone: string, schoolId?: string, purpose = 'LOGIN') =>
    apiClient.post<{ expiresInSeconds: number; message: string }>(
      '/auth/otp/send',
      { phone, schoolId, purpose },
      { skipAuth: true }
    ),
  verifyOtp: (phone: string, code: string) =>
    apiClient.post<{
      accessToken: string;
      refreshToken: string;
      user: {
        id: string;
        email: string | null;
        phone: string | null;
        role: UserRole;
        schoolId: string;
        firstName: string;
        lastName: string;
      };
    }>('/auth/otp/verify', { phone, code }, { skipAuth: true }),
  loginStaff: (email: string, password: string) =>
    apiClient.post<{
      accessToken: string;
      refreshToken: string;
      user: {
        id: string;
        email: string;
        phone: string | null;
        role: UserRole;
        schoolId: string;
        firstName: string;
        lastName: string;
      };
    }>('/auth/staff/login', { email, password }, { skipAuth: true }),
  logout: (refreshToken?: string) =>
    apiClient.post<{ message: string }>('/auth/logout', { refreshToken }),
};

export const peopleApi = {
  getLinkedSiblings: () =>
    apiClient.get<Array<{
      id: string;
      admissionNumber: string;
      rollNumber: string;
      firstName: string;
      lastName: string;
      grade: number;
      section: string;
      classId: string;
      sectionId: string;
      bloodGroup: string;
      emergencyContact: string;
      relationship: string;
      house?: string;
    }>>('/people/guardians/siblings'),
  listStudents: (params?: { grade?: number; section?: string; page?: number; limit?: number }) =>
    apiClient.get<{ students: any[]; total: number; page: number; limit: number }>('/people/students', { params }),
  getStudentById: (id: string) => apiClient.get<any>(`/people/students/${id}`),
  listStaff: () => apiClient.get<any[]>('/people/staff'),
  bulkImportStudents: (data: any) => apiClient.post('/people/students/bulk-import', data),
};

export const attendanceApi = {
  recordRapidBatch: (payload: {
    date: string;
    classId: string;
    sectionId: string;
    defaultStatus?: AttendanceStatus;
    exceptions?: Array<{ studentId: string; status: AttendanceStatus; remarks?: string }>;
  }) => apiClient.post('/attendance', payload),
  getStudentStats: (studentId: string, month?: number, year?: number) =>
    apiClient.get<{
      studentId: string;
      studentName: string;
      presentDays: number;
      totalWorkingDays: number;
      attendancePercentage: number;
      lateDays: number;
      halfDays: number;
      absentDays: number;
      month: number;
      year: number;
      cbseCompliant?: boolean;
    }>(`/attendance/students/${studentId}`, { params: { month, year } }),
  applyLeave: (payload: { fromDate: string; toDate: string; reason: string; leaveType: string; studentId?: string }) =>
    apiClient.post('/attendance/leaves', payload),
};

export const feesApi = {
  getStructures: (grade?: string | number, academicYear?: string) =>
    apiClient.get<any[]>('/fees/structures', { params: { grade: grade ? String(grade) : undefined, academicYear } }),
  createRazorpayOrder: (
    payload: { installmentId: string; amount: number; studentId: string },
    idempotencyKey?: string
  ) =>
    apiClient.post<{
      orderId: string;
      amount: number;
      currency: string;
      keyId: string;
      installmentId: string;
    }>('/fees/orders', payload, { idempotencyKey }),
  getConcessions: () => apiClient.get<any[]>('/fees/concessions'),
  applyConcession: (payload: any) => apiClient.post('/fees/concessions', payload),
  getReceipt: (id: string) => apiClient.get<any>(`/fees/receipts/${id}`),
};

export const pulseApi = {
  getMetrics: () =>
    apiClient.get<{
      attendanceRate: number;
      feeCollectionRate: number;
      totalStudents: number;
      activeBuses: number;
      safetyIncidentsPending: number;
      academicYear: string;
      systemHealth: string;
      lastUpdated: string;
    }>('/pulse/metrics'),
};

export const adminApi = {
  getAuditLogs: () => apiClient.get<any[]>('/admin/audit-logs'),
};

export const transportApi = {
  getBuses: () => apiClient.get<any[]>('/transport/buses'),
  getRoutes: () => apiClient.get<any[]>('/transport/routes'),
};

export const safetyApi = {
  getVisitors: () => apiClient.get<any[]>('/safety/visitors'),
  createVisitor: (payload: any) => apiClient.post('/safety/visitors', payload),
  verifyPickup: (payload: { studentId: string; otp: string; gateNumber?: string }) =>
    apiClient.post('/safety/pickup/verify', payload),
};
