'use client';

import React, { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

export const queryKeys = {
  auth: {
    me: ['auth', 'me'] as const,
  },
  people: {
    siblings: ['people', 'siblings'] as const,
    students: (params?: any) => ['people', 'students', params] as const,
    student: (id: string) => ['people', 'student', id] as const,
    staff: ['people', 'staff'] as const,
  },
  attendance: {
    stats: (studentId: string, month?: number, year?: number) =>
      ['attendance', 'stats', studentId, month, year] as const,
    records: (params?: any) => ['attendance', 'records', params] as const,
  },
  fees: {
    structures: (grade?: string | number, year?: string) => ['fees', 'structures', grade, year] as const,
    concessions: ['fees', 'concessions'] as const,
    receipt: (id: string) => ['fees', 'receipt', id] as const,
  },
  pulse: {
    metrics: ['pulse', 'metrics'] as const,
  },
  transport: {
    routes: ['transport', 'routes'] as const,
    buses: ['transport', 'buses'] as const,
  },
  safety: {
    visitors: ['safety', 'visitors'] as const,
  },
  admin: {
    auditLogs: ['admin', 'audit-logs'] as const,
  },
};

export function makeQueryClient(): QueryClient {
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 60 * 1000,
        gcTime: 10 * 60 * 1000,
        retry: (failureCount, error: any) => {
          if (error?.status === 401 || error?.status === 403 || error?.status === 404) {
            return false;
          }
          return failureCount < 1;
        },
        refetchOnWindowFocus: false,
      },
      mutations: {
        retry: 0,
      },
    },
  });
}

let browserQueryClient: QueryClient | undefined = undefined;

export function getQueryClient(): QueryClient {
  if (typeof window === 'undefined') {
    return makeQueryClient();
  }
  if (!browserQueryClient) {
    browserQueryClient = makeQueryClient();
  }
  return browserQueryClient;
}

export function QueryProvider({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(() => getQueryClient());

  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
}
