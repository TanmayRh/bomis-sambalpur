import { cn, formatCurrency } from './utils';
import { calculateCbseGrade } from '../components/modules/teacher/cbse-marks-entry';

/**
 * Smoke tests for utilities and CBSE grade calculations
 */
export function verifyWebUtilities(): boolean {
  const merged = cn('a', false && 'b', 'c');
  if (!merged.includes('a') || !merged.includes('c')) {
    throw new Error('cn() failed merge check');
  }

  const curr = formatCurrency(45000);
  if (!curr.includes('45,000')) {
    throw new Error('formatCurrency() failed formatting check');
  }

  const grade95 = calculateCbseGrade(95);
  if (grade95.grade !== 'A1' || grade95.points !== 10.0) {
    throw new Error('CBSE 9-point scale A1 calculation failed');
  }

  const grade45 = calculateCbseGrade(45);
  if (grade45.grade !== 'C2' || grade45.points !== 5.0) {
    throw new Error('CBSE 9-point scale C2 calculation failed');
  }

  return true;
}
