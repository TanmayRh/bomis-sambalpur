import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    status: 'ok',
    service: '@bomis/web',
    timestamp: new Date().toISOString(),
    version: '0.1.0',
    school: 'Birla Open Minds International School, Sambalpur',
    affiliationNo: '1530267',
  });
}
