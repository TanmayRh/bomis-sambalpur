'use client';

import * as React from 'react';
import {
  Bell,
  Bus,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  Menu,
  Phone,
  QrCode,
  Volume2,
  X,
  AlertTriangle,
  BookOpen,
  Calendar,
  GraduationCap,
  Receipt,
  Users,
  FileText,
  Utensils,
  MapPin,
  Download,
  Send,
  Sparkles,
  Shield,
} from 'lucide-react';
import { SupportedLocale, formatTime, t } from '@/lib/i18n';

/* ==============================================================================
   TYPES & MOCK STATE DATA (BOMIS Sambalpur Unified Platform)
   ============================================================================== */

export type DemoScenario =
  | 'NORMAL_COMMUTE'
  | 'MONSOON_CLOSURE'
  | 'UPI_IN_PROGRESS'
  | 'SIBLING_ASYMMETRY'
  | 'INFIRMARY_SOS'
  | 'SIMPLE_ELDER_VIEW';

export type ActiveDrawer =
  | null
  | 'DIARY'
  | 'ATTENDANCE'
  | 'EXAMS'
  | 'FEES'
  | 'PTM'
  | 'CIRCULARS'
  | 'CANTEEN'
  | 'TRANSPORT';

export interface ChildProfile {
  id: string;
  firstName: string;
  nameHi: string;
  nameOr: string;
  grade: string;
  rollNumber: string;
  accentColor: string; // Cool-hue token (never matches amber/red status)
  shape: 'circle' | 'diamond';
  photoUrl: string;
  schoolStatus: 'school_today' | 'off' | 'absent';
  offReasonKey?: string;
  busNumber: number;
  busEta: string;
  busStatus: 'live' | 'estimated' | 'lost';
  allergy?: string;
}

const CHILDREN: ChildProfile[] = [
  {
    id: 'aarav',
    firstName: 'Aarav',
    nameHi: 'आरव',
    nameOr: 'ଆରଭ',
    grade: '5A',
    rollNumber: 'BOMIS-2021-0042',
    accentColor: '#2563EB', // Blue
    shape: 'circle',
    photoUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=150&auto=format&fit=crop&q=80',
    schoolStatus: 'school_today',
    busNumber: 3,
    busEta: '7:42 AM',
    busStatus: 'live',
    allergy: 'Peanut',
  },
  {
    id: 'ananya',
    firstName: 'Ananya',
    nameHi: 'अनन्या',
    nameOr: 'ଅନନ୍ୟା',
    grade: '2A',
    rollNumber: 'BOMIS-2024-0118',
    accentColor: '#7C3AED', // Purple
    shape: 'diamond',
    photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    schoolStatus: 'school_today',
    busNumber: 3,
    busEta: '7:42 AM',
    busStatus: 'live',
  },
];

export default function CalmParentApp() {
  // Locale State
  const [locale, setLocale] = React.useState<SupportedLocale>('en');
  const [isSimpleView, setIsSimpleView] = React.useState<boolean>(false);
  const [selectedElderChildId, setSelectedElderChildId] = React.useState<string>('aarav');

  // Active Demo Scenario
  const [scenario, setScenario] = React.useState<DemoScenario>('NORMAL_COMMUTE');

  // Filter single child (resets after 60s or on demand)
  const [activeChildFilter, setActiveChildFilter] = React.useState<string | null>(null);

  // Closure Ack State
  const [closureAck, setClosureAck] = React.useState<'none' | 'staying_home' | 'already_left'>('none');

  // Infirmary Ack State
  const [infirmaryReply, setInfirmaryReply] = React.useState<string | null>(null);

  // More Sheet Open State
  const [isMoreOpen, setIsMoreOpen] = React.useState(false);

  // Pickup Pass inline expansion state
  const [isPickupExpanded, setIsPickupExpanded] = React.useState(false);
  const [pickupDelegatedTo, setPickupDelegatedTo] = React.useState<'Dada Ji' | 'Self'>('Dada Ji');
  const [pickupStatus, setPickupStatus] = React.useState<'draft' | 'sent' | 'opened' | 'released'>('draft');

  // Photo consent toggle per child
  const [photoConsent, setPhotoConsent] = React.useState<Record<string, boolean>>({
    aarav: true,
    ananya: true,
  });

  // Emergency Alerts Chip
  const [hasTurnedOnAlerts, setHasTurnedOnAlerts] = React.useState(false);

  // Active Interactive Drawer (100x Better than traditional school apps)
  const [activeDrawer, setActiveDrawer] = React.useState<ActiveDrawer>(null);

  // Homework & Diary Interactive State
  const [diaryChild, setDiaryChild] = React.useState<'aarav' | 'ananya'>('aarav');
  const [completedHw, setCompletedHw] = React.useState<Record<string, boolean>>({
    m1: false, // Math Fractions
    s1: false, // Hirakud diorama sketch
    h1: true,  // Language reading
    e1: false, // Ananya EVS
    en1: true, // Ananya English
  });
  const [diarySigned, setDiarySigned] = React.useState(false);

  // Attendance & 1-Tap Leave State
  const [leaveChild, setLeaveChild] = React.useState<'aarav' | 'ananya' | 'both'>('aarav');
  const [leaveReason, setLeaveReason] = React.useState<'fever' | 'family' | 'travel'>('fever');
  const [leaveSubmitted, setLeaveSubmitted] = React.useState(false);

  // PTM Appointment Booking State
  const [ptmTeacher, setPtmTeacher] = React.useState<'dash' | 'mohanty'>('dash');
  const [ptmSlot, setPtmSlot] = React.useState<string>('10:20 AM - 10:35 AM');
  const [ptmMode, setPtmMode] = React.useState<'campus' | 'video'>('campus');
  const [ptmConfirmed, setPtmConfirmed] = React.useState(false);

  // Voice Rubric & Circular Audio State
  const [isPlayingHpcVoice, setIsPlayingHpcVoice] = React.useState(false);
  const [receiptDownloaded, setReceiptDownloaded] = React.useState(false);

  // Speech synthesizer helper for audio playback
  const speakText = (text: string) => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      if (locale === 'hi') utterance.lang = 'hi-IN';
      else if (locale === 'en') utterance.lang = 'en-IN';
      // Odia fallback warning: Web speech lacks natural Odia on many devices, but speaks phonetic text
      else utterance.lang = 'or-IN';
      window.speechSynthesis.speak(utterance);
    }
  };

  // Switch scenario helper
  const handleSwitchScenario = (newScenario: DemoScenario) => {
    setScenario(newScenario);
    setClosureAck('none');
    setInfirmaryReply(null);
    if (newScenario === 'SIMPLE_ELDER_VIEW') {
      setIsSimpleView(true);
    } else {
      setIsSimpleView(false);
    }
  };

  // Derive active children considering scenario modifications
  const displayChildren = React.useMemo(() => {
    return CHILDREN.map((c) => {
      if (scenario === 'SIBLING_ASYMMETRY') {
        if (c.id === 'ananya') {
          return {
            ...c,
            schoolStatus: 'off' as const,
            offReasonKey: 'reason.sports',
          };
        }
      }
      return c;
    });
  }, [scenario]);

  const filteredChildren = activeChildFilter
    ? displayChildren.filter((c) => c.id === activeChildFilter)
    : displayChildren;

  // Determine if TodayBar should merge or split
  const isIdenticalStatus =
    displayChildren.length === 2 &&
    displayChildren[0] !== undefined &&
    displayChildren[1] !== undefined &&
    displayChildren[0].schoolStatus === displayChildren[1].schoolStatus &&
    displayChildren[0].busNumber === displayChildren[1].busNumber;

  /* ============================================================================
     RENDER: SIMPLE ELDER VIEW (Grandparents / Non-Readers / High Contrast >= 7:1)
     ============================================================================ */
  if (isSimpleView) {
    const mainChild = displayChildren.find((c) => c.id === selectedElderChildId) ?? displayChildren[0] ?? CHILDREN[0]!;
    const childName = locale === 'hi' ? mainChild.nameHi : locale === 'or' ? mainChild.nameOr : mainChild.firstName;
    const isAarav = mainChild.id === 'aarav';
    const passPin = isAarav ? '8 3 1 2 9 4' : '6 4 0 5 1 2';
    const passCode = isAarav ? 'GATE-PASS #831294' : 'GATE-PASS #831295';

    return (
      <main className="min-h-screen bg-black text-yellow-300 p-4 sm:p-6 flex flex-col justify-between select-none">
        {/* Top Control Bar */}
        <header className="flex items-center justify-between border-b-2 border-yellow-400 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-3xl">👴</span>
            <span className="text-xl font-black uppercase tracking-wider text-white">
              {locale === 'or' ? 'ବଡ଼ ଅକ୍ଷର ପାସ୍' : locale === 'hi' ? 'बुजुर्ग मोड' : 'Senior Mode'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Language Switcher */}
            <div className="flex rounded-lg border border-yellow-400 p-0.5">
              {(['or', 'hi', 'en'] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLocale(l)}
                  className={`px-3 py-1.5 text-base font-bold rounded ${
                    locale === l ? 'bg-yellow-400 text-black' : 'text-yellow-400 hover:bg-yellow-950'
                  }`}
                >
                  {l === 'or' ? 'ଓଡ଼ିଆ' : l === 'hi' ? 'हिन्दी' : 'EN'}
                </button>
              ))}
            </div>

            <button
              onClick={() => setIsSimpleView(false)}
              className="px-4 py-2 bg-yellow-400 text-black font-black text-base rounded-xl hover:bg-yellow-300"
            >
              ✕ Exit
            </button>
          </div>
        </header>

        {/* Grandchild Selector Switcher (Touch targets >= 60px) */}
        <div className="grid grid-cols-2 gap-3 my-3">
          {displayChildren.map((child) => {
            const isSelected = child.id === selectedElderChildId;
            const cName = locale === 'hi' ? child.nameHi : locale === 'or' ? child.nameOr : child.firstName;
            return (
              <button
                key={child.id}
                onClick={() => setSelectedElderChildId(child.id)}
                className={`min-h-[58px] px-3 py-2 rounded-2xl text-lg font-black border-2 transition flex items-center justify-center gap-2 ${
                  isSelected
                    ? 'bg-yellow-400 text-black border-yellow-300 shadow-md'
                    : 'bg-zinc-900 text-yellow-300 border-yellow-400/50 hover:bg-zinc-800'
                }`}
              >
                <span>{child.id === 'aarav' ? '👦' : '👧'}</span>
                <span>{cName} ({child.grade})</span>
              </button>
            );
          })}
        </div>

        {/* Large Gate Pickup Pass Card (Touch targets >= 64px, text >= 22px, contrast >= 7:1) */}
        <section className="my-auto space-y-5">
          <div className="bg-yellow-400 text-black rounded-3xl p-5 text-center space-y-4 shadow-2xl">
            {/* Child Photo and Name */}
            <div className="flex flex-col items-center">
              <div className="w-24 h-24 rounded-full border-4 border-black overflow-hidden shadow-lg mb-2">
                <img src={mainChild.photoUrl} alt={childName} className="w-full h-full object-cover" />
              </div>
              <h1 className="text-3xl font-black tracking-tight">{childName} · Grade {mainChild.grade}</h1>
              <p className="text-lg font-bold mt-1 text-slate-900">
                {t('elder.title', locale, { child: childName, gate: '1' })}
              </p>
            </div>

            {/* Giant High-Contrast QR Simulation */}
            <div className="bg-white p-3 rounded-2xl inline-block border-4 border-black mx-auto">
              <div className="w-44 h-44 bg-slate-950 flex flex-col items-center justify-center text-white rounded-xl p-2 relative">
                <QrCode className="w-32 h-32 text-yellow-400" />
                <span className="text-[10px] font-mono tracking-widest text-slate-300 mt-1">{passCode}</span>
              </div>
            </div>

            {/* 6-Digit Verbal PIN for the Guard */}
            <div className="bg-black text-yellow-400 p-3 rounded-2xl">
              <span className="text-xs font-bold uppercase tracking-widest block text-yellow-200">
                {t('elder.guard_pin', locale)}
              </span>
              <span className="text-4xl font-mono font-black tracking-widest block mt-1">{passPin}</span>
            </div>
          </div>

          {/* Large Action Buttons (>= 64px height) */}
          <div className="space-y-3">
            <button
              onClick={() => speakText(t('elder.audio', locale, { child: childName, gate: '1' }))}
              className="w-full min-h-[64px] bg-yellow-400 hover:bg-yellow-300 text-black text-xl font-black rounded-2xl flex items-center justify-center gap-3 shadow-lg active:scale-98 transition"
            >
              <Volume2 className="w-8 h-8" />
              <span>🔊 {locale === 'or' ? 'ଶୁଣନ୍ତୁ (ଅଡିଓ)' : locale === 'hi' ? 'बोलकर सुनें' : 'Listen Aloud'}</span>
            </button>

            <a
              href="tel:+919876543210"
              className="w-full min-h-[64px] bg-zinc-900 border-2 border-yellow-400 text-yellow-400 text-xl font-black rounded-2xl flex items-center justify-center gap-3 active:scale-98 transition"
            >
              <Phone className="w-8 h-8" />
              <span>{t('elder.btn.call', locale, { parent: locale === 'hi' ? 'आरव की मम्मी' : locale === 'or' ? 'ମମି' : "Mummy (Dr. Patel)" })}</span>
            </a>
          </div>
        </section>

        {/* Footer info */}
        <footer className="text-center text-xs font-bold text-yellow-200/80 pt-2 border-t border-yellow-900">
          Birla Open Minds International School, Sambalpur • Gate 1 Afternoon Dispersal
        </footer>
      </main>
    );
  }

  /* ============================================================================
     RENDER: STANDARD CALM PARENT HOME (Under 3-Second Cognitive Rule)
     ============================================================================ */
  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans flex flex-col justify-between">
      {/* ------------------------------------------------------------------------
          TOP DEMO SCENARIO SWITCHER (Clean dev/demo bar for stakeholder testing)
          ------------------------------------------------------------------------ */}
      <nav aria-label="Demo Scenarios" className="bg-slate-900 text-white text-xs px-3 py-2 border-b border-slate-800">
        <div className="max-w-md mx-auto flex items-center justify-between gap-1 overflow-x-auto no-scrollbar">
          <span className="font-bold text-amber-400 shrink-0">⚡ Scenarios:</span>
          <button
            onClick={() => handleSwitchScenario('NORMAL_COMMUTE')}
            className={`px-2 py-1 rounded font-medium whitespace-nowrap transition ${
              scenario === 'NORMAL_COMMUTE' ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            ☀️ Normal 7:30 AM
          </button>
          <button
            onClick={() => handleSwitchScenario('MONSOON_CLOSURE')}
            className={`px-2 py-1 rounded font-medium whitespace-nowrap transition ${
              scenario === 'MONSOON_CLOSURE' ? 'bg-rose-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            🌧️ 6:45 AM Monsoon Closure
          </button>
          <button
            onClick={() => handleSwitchScenario('UPI_IN_PROGRESS')}
            className={`px-2 py-1 rounded font-medium whitespace-nowrap transition ${
              scenario === 'UPI_IN_PROGRESS' ? 'bg-amber-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            ⏳ Fee In Progress
          </button>
          <button
            onClick={() => handleSwitchScenario('SIBLING_ASYMMETRY')}
            className={`px-2 py-1 rounded font-medium whitespace-nowrap transition ${
              scenario === 'SIBLING_ASYMMETRY' ? 'bg-purple-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            ⚖️ Sibling Split
          </button>
          <button
            onClick={() => handleSwitchScenario('INFIRMARY_SOS')}
            className={`px-2 py-1 rounded font-medium whitespace-nowrap transition ${
              scenario === 'INFIRMARY_SOS' ? 'bg-rose-700 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`}
          >
            🩹 Nurse Alert
          </button>
        </div>
      </nav>

      {/* Main Parent Mobile Container (Centered at 390px mobile viewport) */}
      <main className="w-full max-w-md mx-auto bg-white min-h-[92vh] shadow-xl flex flex-col flex-1 border-x border-slate-200 relative pb-12">
        {/* Top Header: Branding + Language Picker + Simple Toggle */}
        <header className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-sm tracking-tight text-[#0F2942]">BOMIS Sambalpur</span>
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
            </div>
            <p className="text-[10px] text-slate-500 font-medium">CBSE Affiliated • Campus & Transport Care (Sambalpur)</p>
          </div>

          <div className="flex items-center gap-2">
            {/* Tri-lingual Picker: ଓଡ଼ିଆ · हिन्दी · English */}
            <div className="flex rounded-lg border border-slate-300 bg-white p-0.5 shadow-2xs">
              {(['or', 'hi', 'en'] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLocale(l)}
                  className={`px-2 py-0.5 text-xs font-bold rounded ${
                    locale === l ? 'bg-[#0F2942] text-white shadow-2xs' : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {l === 'or' ? 'ଓଡ଼ିଆ' : l === 'hi' ? 'हिन्दी' : 'EN'}
                </button>
              ))}
            </div>

            {/* Simple Elder View Toggle Button */}
            <button
              onClick={() => setIsSimpleView(true)}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-black bg-amber-100 text-amber-900 border border-amber-300 rounded-lg hover:bg-amber-200 transition"
              title="Senior Mode for Grandparents (High Contrast & Large Text)"
            >
              <span>👴</span>
              <span>{locale === 'or' ? 'ବଡ଼ ଅକ୍ଷର' : locale === 'hi' ? 'बुजुर्ग मोड' : 'Senior Mode'}</span>
            </button>
          </div>
        </header>

        {/* ------------------------------------------------------------------------
            1. ALERT SLOT (0 Height on a Normal Day; Only Amber / Red Appears Here)
            ------------------------------------------------------------------------ */}
        <section aria-label="Emergency Alerts">
          {/* Scenario: 6:45 AM Monsoon District Collector Closure */}
          {scenario === 'MONSOON_CLOSURE' && (
            <div className="bg-amber-500 text-slate-950 p-4 border-b-2 border-amber-600 animate-in fade-in duration-200">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2.5">
                  <span className="text-2xl mt-0.5">🌧️</span>
                  <div>
                    <h2 className="text-base font-black leading-tight">
                      {t('closure.title', locale)}
                    </h2>
                    <p className="text-xs font-semibold text-amber-950 mt-0.5">
                      {t('closure.detail.rain', locale, { classes: '1-8' })}
                    </p>
                    <p className="text-[11px] text-amber-900 font-medium mt-1">
                      {t('closure.source', locale, { time: formatTime('6:45 AM', locale) })}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() =>
                    speakText(
                      `${t('closure.title', locale)}. ${t('closure.detail.rain', locale, { classes: '1-8' })}`
                    )
                  }
                  className="p-1.5 bg-amber-400 hover:bg-amber-300 rounded-lg text-amber-950"
                  title="Listen aloud"
                >
                  <Volume2 className="h-4 w-4" />
                </button>
              </div>

              {/* Action Buttons: Ack stay home vs already left */}
              {closureAck === 'none' ? (
                <div className="mt-3.5 pt-3 border-t border-amber-600/40 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setClosureAck('staying_home')}
                    className="min-h-[44px] bg-slate-950 text-white rounded-xl px-3 py-2 text-xs font-black shadow-sm hover:bg-slate-900 active:scale-98 transition"
                  >
                    {t('closure.btn.ack', locale)}
                  </button>
                  <button
                    onClick={() => setClosureAck('already_left')}
                    className="min-h-[44px] bg-amber-200 text-rose-950 border border-rose-400 rounded-xl px-3 py-2 text-xs font-black shadow-sm hover:bg-amber-100 active:scale-98 transition"
                  >
                    {t('closure.btn.left', locale)}
                  </button>
                </div>
              ) : (
                <div className="mt-3 pt-2 border-t border-amber-600/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1 text-xs font-bold text-amber-950">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4 text-emerald-900 shrink-0" />
                    {closureAck === 'staying_home'
                      ? '✓ Acknowledged: Children safe at home'
                      : '⚠ Alert sent to Transport In-Charge: Child left for stop'}
                  </span>
                  <span className="text-[11px] text-amber-900 font-normal">
                    {t('closure.footer', locale, { time: formatTime('6:00 PM', locale) })}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Scenario: Mid-Day Infirmary SOS */}
          {scenario === 'INFIRMARY_SOS' && (
            <div className="bg-rose-50 border-b-2 border-rose-300 p-4 text-slate-900 animate-in fade-in">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2.5">
                  <span className="text-2xl mt-0.5">🩹</span>
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full inline-block mb-1">
                      Nurse Notice · Sick Bay
                    </span>
                    <h2 className="text-sm font-black text-rose-950">
                      {t('inf.title', locale, { child: 'Aarav' })}
                    </h2>
                    <p className="text-xs text-slate-700 font-semibold mt-0.5">
                      {t('complaint.twisted_ankle', locale)} • {formatTime('11:30 AM', locale)}
                    </p>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      {t('inf.awake', locale, { child: 'Aarav' })} {t('action.ice', locale)}{' '}
                      {t('medicine.none', locale)}
                    </p>
                    <p className="text-xs font-bold text-rose-800 mt-1">
                      {t('inf.ask.amber', locale)}
                    </p>
                  </div>
                </div>

                <a
                  href="tel:+919437100008"
                  className="p-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-xs shrink-0 flex items-center gap-1 text-xs font-bold"
                  title="Call Nurse Sunita"
                >
                  <Phone className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Call Nurse</span>
                </a>
              </div>

              {/* 1-Tap Responses (No typing required) */}
              <div className="mt-3 pt-2.5 border-t border-rose-200/60 flex items-center gap-2">
                {infirmaryReply ? (
                  <span className="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                    <span>{infirmaryReply}</span>
                  </span>
                ) : (
                  <>
                    <button
                      onClick={() => setInfirmaryReply("✓ Nurse notified: On our way to school to pick up Aarav")}
                      className="flex-1 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold text-center"
                    >
                      🚗 {t('inf.btn.coming', locale)}
                    </button>
                    <button
                      onClick={() => setInfirmaryReply("✓ Nurse notified: Sister Sunita will WhatsApp you live updates")}
                      className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold text-center"
                    >
                      💬 {t('inf.btn.wa', locale)}
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </section>

        {/* If closure is active and not acknowledged, show clear guidance */}
        {scenario === 'MONSOON_CLOSURE' && closureAck === 'none' ? (
          <div className="p-8 text-center my-auto space-y-4">
            <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center text-3xl mx-auto shadow-xs">
              🏡
            </div>
            <h3 className="text-base font-black text-slate-800">
              Classes 1-8 Suspended Today
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed max-w-xs mx-auto">
              Due to heavy monsoon rainfall in Sambalpur, classes 1 to 8 are closed. School buses remain parked safely at the campus. Please tap an option above to let the school know your children are safe.
            </p>
            <div className="pt-2">
              <a
                href="tel:+919437000003"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-900 bg-amber-100 hover:bg-amber-200 px-3.5 py-2 rounded-xl transition"
              >
                <Phone className="h-3.5 w-3.5" />
                <span>Need help? Call Front Desk: +91 94370 00003</span>
              </a>
            </div>
          </div>
        ) : (
          /* ====================================================================
             NORMAL CALM DAY STREAM CONTENT
             ==================================================================== */
          <div className="p-4 space-y-4 flex-1">
            {/* Filter Strip if single child is isolated */}
            {activeChildFilter && (
              <div className="flex items-center justify-between bg-slate-100 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700">
                <span>Showing only {displayChildren.find((c) => c.id === activeChildFilter)?.firstName}</span>
                <button
                  onClick={() => setActiveChildFilter(null)}
                  className="text-indigo-600 hover:underline font-bold"
                >
                  Show both children
                </button>
              </div>
            )}

            {/* ------------------------------------------------------------------
                2. TODAY BAR (1 row if identical, splits dynamically if asymmetric)
                ------------------------------------------------------------------ */}
            <section aria-label="Today Bar" className="rounded-2xl border border-slate-200 bg-white p-3.5 shadow-2xs space-y-2">
              {scenario === 'MONSOON_CLOSURE' ? (
                /* Both children staying safe at home on monsoon closure */
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="h-3 w-3 rounded-full bg-blue-600" title="Aarav (5A)" />
                    <span className="h-3 w-3 bg-purple-600 rotate-45 transform" title="Ananya (2A)" />
                    <span className="text-sm font-bold text-slate-900">
                      {t('sib.closed_all', locale, { a: 'Aarav (5A)', b: 'Ananya (2A)' })}
                    </span>
                  </div>
                  <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-300">
                    🌧️ Rain Holiday
                  </span>
                </div>
              ) : isIdenticalStatus && !activeChildFilter ? (
                /* Merged Single Row when both kids have identical schedule */
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {/* Aarav (Blue circle) */}
                    <span className="h-3 w-3 rounded-full bg-blue-600" title="Aarav (5A)" />
                    {/* Ananya (Purple diamond) */}
                    <span className="h-3 w-3 bg-purple-600 rotate-45 transform" title="Ananya (2A)" />
                    <span className="text-sm font-bold text-slate-900">
                      {t('sib.both', locale, { a: 'Aarav (5A)', b: 'Ananya (2A)' })}
                    </span>
                  </div>
                  <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    <Check className="h-3 w-3" /> {t('home.school_today', locale)}
                  </span>
                </div>
              ) : (
                /* Split Rows when status or bus route differs */
                filteredChildren.map((child) => (
                  <div
                    key={child.id}
                    onClick={() => setActiveChildFilter(activeChildFilter === child.id ? null : child.id)}
                    className="flex items-center justify-between py-1.5 border-b border-slate-100 last:border-none cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      {/* Identity: Cool-hue accent + distinct shape (Never matches amber/red status) */}
                      {child.shape === 'circle' ? (
                        <span className="h-3.5 w-3.5 rounded-full bg-blue-600 shrink-0" />
                      ) : (
                        <span className="h-3.5 w-3.5 bg-purple-600 rotate-45 transform shrink-0" />
                      )}

                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-black text-slate-900">
                          {child.firstName} · {child.grade}
                        </span>
                        {child.allergy && (
                          <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200">
                            🥜 {child.allergy} on file
                          </span>
                        )}
                      </div>
                    </div>

                    <div>
                      {child.schoolStatus === 'school_today' ? (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          <Check className="h-3 w-3" /> {t('home.school_today', locale)}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-300">
                          {t('sib.badge_off', locale, {
                            reason: t(child.offReasonKey || 'reason.sports', locale),
                          })}
                        </span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </section>

            {/* ------------------------------------------------------------------
                3. BUS LINE (One line per distinct route; 3 honest states)
                ------------------------------------------------------------------ */}
            {scenario === 'MONSOON_CLOSURE' ? (
              <section aria-label="Bus Line" className="rounded-2xl border border-amber-200 bg-amber-50/50 p-3.5 shadow-2xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">🚌</span>
                    <div>
                      <h3 className="text-xs font-bold text-slate-900">
                        {t('bus.off', locale)}
                      </h3>
                      <p className="text-[11px] text-slate-600 font-medium">
                        All school buses parked safely at BOMIS campus • No trips today
                      </p>
                    </div>
                  </div>

                  <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-300">
                    No Service Today
                  </span>
                </div>
              </section>
            ) : (
              <section aria-label="Bus Line" className="rounded-2xl border border-slate-200 bg-slate-50/70 p-3.5 shadow-2xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">🚌</span>
                    <div>
                      <h3 className="text-xs font-bold text-slate-900">
                        {t('home.bus', locale, { n: '3', time: formatTime('7:42 AM', locale) })}
                      </h3>
                      <p className="text-[11px] text-slate-500 font-medium">
                        {scenario === 'SIBLING_ASYMMETRY'
                          ? "Aarav's morning trip • Route: Sakhipada • Driver Maheswar Bhoi (OD-15)"
                          : 'Route: Sakhipada • Driver Maheswar Bhoi (OD-15)'}
                      </p>
                    </div>
                  </div>

                  <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    {t('home.ontime', locale)}
                  </span>
                </div>
              </section>
            )}

            {/* ------------------------------------------------------------------
                4. ONE THING (Single most urgent to-do, or "✓ Nothing needed today")
                ------------------------------------------------------------------ */}
            <section aria-label="One Thing To-Do">
              {scenario === 'MONSOON_CLOSURE' ? (
                <div className="rounded-2xl border border-amber-200 bg-amber-50/70 p-3.5 flex items-center justify-between shadow-2xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                    <span className="text-xs font-bold text-slate-800">
                      Safe at home · Status confirmed for teachers
                    </span>
                  </div>
                  <span className="text-[11px] text-amber-900 font-medium">Reopen update by 6:00 PM</span>
                </div>
              ) : scenario === 'UPI_IN_PROGRESS' ? (
                /* 4-State FeeCard: In Progress with Calm Reassurance */
                <div className="rounded-2xl border-2 border-amber-400 bg-amber-50/80 p-4 shadow-sm space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2">
                      <Clock className="h-5 w-5 text-amber-700 shrink-0 mt-0.5" />
                      <div>
                        <h3 className="text-sm font-black text-amber-950">
                          {t('fee.title', locale)}
                        </h3>
                        <p className="text-xs text-amber-900 mt-0.5 font-medium leading-relaxed">
                          {t('fee.detail', locale, {
                            amount: '₹18,500',
                            time: formatTime('11:58 PM', locale),
                          })}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Guaranteed Shields: No late fee & Exam not affected */}
                  <div className="space-y-2 text-xs font-bold text-slate-800 bg-white/90 p-3 rounded-xl border border-amber-200">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center gap-1.5 text-emerald-800">
                        <Check className="h-4 w-4 text-emerald-600 shrink-0" />
                        <span>{t('fee.nolate', locale)}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-emerald-800">
                        <Check className="h-4 w-4 text-emerald-600 shrink-0" />
                        <span>{t('fee.exam', locale, { child: 'Aarav' })}</span>
                      </div>
                    </div>
                    <div className="text-amber-950 font-normal text-[11px] pt-1.5 border-t border-amber-100 flex items-start gap-1.5">
                      <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                      <span>{t('fee.norepay', locale)}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-amber-950 pt-1">
                    <span className="font-mono font-bold">Provisional Ref: #PROV-8821</span>
                    <button
                      onClick={() => alert('Provisional receipt saved as proof for school front desk.')}
                      className="text-xs font-black text-indigo-700 hover:underline"
                    >
                      {t('fee.btn.save', locale)}
                    </button>
                  </div>
                </div>
              ) : (
                /* Default Clean State: Nothing needed */
                <div className="rounded-2xl border border-slate-200 bg-white p-3.5 flex items-center justify-between shadow-2xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                    <span className="text-xs font-bold text-slate-800">
                      {t('home.nothing', locale)}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 font-medium">All forms & fees clear</span>
                </div>
              )}
            </section>

            {/* ------------------------------------------------------------------
                4B. EVERYDAY SCHOOL SERVICES (100x Better than Traditional School ERPs)
                Consolidates Diary, Attendance, Exams, Fees, PTM, Notices in 1 tap
                ------------------------------------------------------------------ */}
            <section aria-label="Everyday Services" className="space-y-2 pt-1">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500">
                  {t('home.services', locale)}
                </span>
                <span className="text-[11px] text-indigo-700 font-bold bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200">
                  {locale === 'or' ? 'ସମସ୍ତ ସୁବିଧା ଏକାଠି' : locale === 'hi' ? 'सभी सेवाएँ एक जगह' : 'All-in-One'}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {/* 1. Daily Diary & Homework */}
                <button
                  onClick={() => setActiveDrawer('DIARY')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <BookOpen className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.diary', locale)}</span>
                  <span className="text-[10px] text-slate-500 font-medium mt-0.5">2 tasks tonight</span>
                </button>

                {/* 2. Attendance & Leave */}
                <button
                  onClick={() => setActiveDrawer('ATTENDANCE')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.attendance', locale)}</span>
                  <span className="text-[10px] text-emerald-700 font-medium mt-0.5">96.4% Present</span>
                </button>

                {/* 3. Exams & Report Card */}
                <button
                  onClick={() => setActiveDrawer('EXAMS')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <GraduationCap className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.exams', locale)}</span>
                  <span className="text-[10px] text-indigo-700 font-medium mt-0.5">Exam in 4 days</span>
                </button>

                {/* 4. Fees & 80C Receipts */}
                <button
                  onClick={() => setActiveDrawer('FEES')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <Receipt className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.fees', locale)}</span>
                  <span className="text-[10px] text-emerald-700 font-medium mt-0.5">₹0 Due · Paid</span>
                </button>

                {/* 5. Book PTM Slot */}
                <button
                  onClick={() => setActiveDrawer('PTM')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <Users className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.ptm', locale)}</span>
                  <span className="text-[10px] text-slate-500 font-medium mt-0.5">Sat 8 Nov</span>
                </button>

                {/* 6. School Notices & Audio */}
                <button
                  onClick={() => setActiveDrawer('CIRCULARS')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <FileText className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.circulars', locale)}</span>
                  <span className="text-[10px] text-rose-700 font-medium mt-0.5">Winter Uniform</span>
                </button>
              </div>
            </section>

            {/* ------------------------------------------------------------------
                5. DAY STREAM (Time-Ordered Vertical Progression)
                ------------------------------------------------------------------ */}
            {scenario === 'MONSOON_CLOSURE' ? (
              <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4 space-y-2.5">
                <div className="flex items-center gap-2 text-amber-950 font-bold text-sm">
                  <span className="text-lg">🏡</span>
                  <span>Rainy Day at Home</span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">
                  Campus is closed today due to heavy rain in Sambalpur. Online reading stories and fun learning activities are available for Grade 5 and Grade 2. Stay warm and safe with family!
                </p>
                <div className="text-[11px] text-amber-950 font-semibold pt-1 border-t border-amber-200/60 flex items-center justify-between">
                  <span>Reopening update: Today by 6:00 PM</span>
                  <a href="tel:+919437000003" className="text-indigo-700 hover:underline font-bold">
                    Front Desk: +91 94370 00003
                  </a>
                </div>
              </div>
            ) : (
              <section aria-label="Day Stream" className="space-y-2 pt-1">
                <div className="flex items-center justify-between px-1">
                  <span className="text-xs font-black uppercase tracking-wider text-slate-400">
                    {t('home.later', locale)}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Today • {new Date().toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}
                  </span>
                </div>

                {/* Stream Item 1: 10:45 AM Recess & Dining Allergy Protection */}
                <div className="rounded-2xl border border-slate-200 bg-white p-3 shadow-2xs flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs font-mono font-bold text-slate-400">10:45 AM</span>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Recess & Dining Hall</h4>
                      <p className="text-[11px] text-slate-500">
                        Dining team alerted: Peanut-free meal reserved for Aarav
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    Peanut-Free Verified
                  </span>
                </div>

                {/* Stream Item 2: 2:45 PM Pickup: Send a Pass (Expands in Place) */}
                <div className="rounded-2xl border border-slate-200 bg-white p-3 shadow-2xs space-y-3">
                  <div
                    onClick={() => setIsPickupExpanded(!isPickupExpanded)}
                    className="flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-xs font-mono font-bold text-slate-400">2:45 PM</span>
                      <div>
                        <h4 className="text-xs font-bold text-slate-900">Afternoon Dispersal & Gate Pickup</h4>
                        <p className="text-[11px] text-slate-500">
                          {pickupStatus === 'draft'
                            ? 'Send 1-tap pass for Gate 1'
                            : `Pass sent to ${pickupDelegatedTo} · Active for Gate 1`}
                        </p>
                      </div>
                    </div>
                    <ChevronDown
                      className={`h-4 w-4 text-slate-400 transition-transform ${
                        isPickupExpanded ? 'rotate-180' : ''
                      }`}
                    />
                  </div>

                  {/* In-Place Expansion */}
                  {isPickupExpanded && (
                    <div className="pt-2 border-t border-slate-100 space-y-3 animate-in fade-in">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-slate-600">Pick up by:</span>
                        <button
                          onClick={() => setPickupDelegatedTo('Dada Ji')}
                          className={`px-2.5 py-1 text-xs font-bold rounded-lg ${
                            pickupDelegatedTo === 'Dada Ji'
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          👴 Dada Ji (Grandfather)
                        </button>
                        <button
                          onClick={() => setPickupDelegatedTo('Self')}
                          className={`px-2.5 py-1 text-xs font-bold rounded-lg ${
                            pickupDelegatedTo === 'Self'
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          👩 Mother (Self)
                        </button>
                      </div>

                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                        <div>
                          <strong>One-Time WhatsApp Pass</strong>
                          <p className="text-[11px] text-slate-500">Valid for 15 minutes after reaching Gate 1</p>
                        </div>
                        <button
                          onClick={() => {
                            setPickupStatus('sent');
                            alert(`1-Tap pass dispatched to ${pickupDelegatedTo}'s WhatsApp via official BOMIS gateway.`);
                          }}
                          className="px-3 py-1.5 bg-[#0F2942] hover:bg-slate-800 text-white font-bold rounded-lg text-xs"
                        >
                          {pickupStatus === 'draft' ? 'Send Pass' : 'Resend Pass'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Stream Item 3: 3:30 PM Today at School (Teacher Voice & Dinner Question) */}
                <div className="rounded-2xl border border-slate-200 bg-white p-3 shadow-2xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-slate-400">3:30 PM</span>
                      <h4 className="text-xs font-bold text-slate-900">Today at School · Dinner Question</h4>
                    </div>
                    <span className="text-[10px] font-semibold text-slate-400">
                      {activeChildFilter === 'ananya' ? 'Mrs. Mohanty (Grade 2A)' : 'Ms. Dash (Grade 5A)'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 italic leading-relaxed">
                    {activeChildFilter === 'ananya'
                      ? '"Ask Ananya about the colorful butterfly life-cycle chart she drew in environmental studies today!"'
                      : '"Ask Aarav how his team designed the spillway gates for the Hirakud diorama model today in Grade 5A!"'}
                  </p>
                </div>

                {/* Stream Item 4: Thought & Word of the Day (Collapsed Stream Line with Audio) */}
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3 shadow-2xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-base">💭</span>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">
                        Word of the Day: <strong className="text-indigo-700">Resilience</strong> (
                        {locale === 'or' ? 'ସହନଶୀଳତା' : locale === 'hi' ? 'लचीलापन' : 'Bouncing Back'})
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        "Never stop trying when facing difficult problems."
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() =>
                      speakText(
                        locale === 'or'
                          ? 'ସହନଶୀଳତା. Resilience. କେବେ ହାର ମାନନ୍ତୁ ନାହିଁ.'
                          : locale === 'hi'
                          ? 'लचीलापन. Resilience. मुश्किलों से सीखकर आगे बढ़ें.'
                          : 'Resilience. The capacity to recover quickly from difficulties.'
                      )
                    }
                    className="p-1.5 bg-white hover:bg-slate-100 rounded-lg text-slate-700 border border-slate-200 shrink-0"
                    title="Listen pronunciation"
                  >
                    <Volume2 className="h-4 w-4" />
                  </button>
                </div>

                {/* Stream Item 5: Turn on Emergency Alerts (Chip from 2nd visit) */}
                {!hasTurnedOnAlerts && (
                  <div className="pt-2 text-center">
                    <button
                      onClick={() => {
                        setHasTurnedOnAlerts(true);
                        alert('Emergency push notifications enabled for monsoon closures & bus alerts.');
                      }}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-full border border-indigo-200 transition"
                    >
                      <Bell className="h-3.5 w-3.5" />
                      <span>Turn on emergency alerts</span>
                    </button>
                  </div>
                )}
              </section>
            )}
          </div>
        )}

        {/* ------------------------------------------------------------------------
            6. "MORE" BOTTOM TRIGGER (The Only Other Door in the App)
            ------------------------------------------------------------------------ */}
        <footer className="mt-auto border-t border-slate-200 bg-white p-3 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            <span>Updated {formatTime(new Date(), locale)}</span>
          </div>

          <button
            onClick={() => setIsMoreOpen(true)}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-100 hover:bg-slate-200 px-4 py-2 text-xs font-black text-slate-800 transition"
          >
            <Menu className="h-4 w-4" />
            <span>{t('home.more', locale)}</span>
          </button>
        </footer>
      </main>

      {/* ------------------------------------------------------------------------
          INTERACTIVE SERVICE DRAWERS (100x Better than Traditional ERPs)
          Full Rich Features: Diary, Attendance, Exams, Fees, PTM, Notices
          ------------------------------------------------------------------------ */}
      {activeDrawer && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end justify-center p-0"
        >
          <div className="bg-white w-full max-w-lg rounded-t-3xl shadow-2xl p-5 space-y-4 max-h-[88vh] overflow-y-auto animate-in slide-in-from-bottom duration-200 border-t border-slate-200">
            {/* Header with Title and Close Button */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                {activeDrawer === 'DIARY' && <BookOpen className="h-5 w-5 text-blue-600" />}
                {activeDrawer === 'ATTENDANCE' && <Calendar className="h-5 w-5 text-emerald-600" />}
                {activeDrawer === 'EXAMS' && <GraduationCap className="h-5 w-5 text-indigo-600" />}
                {activeDrawer === 'FEES' && <Receipt className="h-5 w-5 text-amber-600" />}
                {activeDrawer === 'PTM' && <Users className="h-5 w-5 text-purple-600" />}
                {activeDrawer === 'CIRCULARS' && <FileText className="h-5 w-5 text-rose-600" />}
                <h3 className="text-base font-black text-slate-900">
                  {activeDrawer === 'DIARY' && t('service.diary', locale)}
                  {activeDrawer === 'ATTENDANCE' && t('service.attendance', locale)}
                  {activeDrawer === 'EXAMS' && t('service.exams', locale)}
                  {activeDrawer === 'FEES' && t('service.fees', locale)}
                  {activeDrawer === 'PTM' && t('service.ptm', locale)}
                  {activeDrawer === 'CIRCULARS' && t('service.circulars', locale)}
                </h3>
              </div>
              <button
                onClick={() => setActiveDrawer(null)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* ==================================================================
                DRAWER 1: DAILY DIARY & HOMEWORK
                ================================================================== */}
            {activeDrawer === 'DIARY' && (
              <div className="space-y-4">
                {/* Sibling Switcher Tabs */}
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                  <button
                    onClick={() => setDiaryChild('aarav')}
                    className={`py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
                      diaryChild === 'aarav'
                        ? 'bg-white text-blue-700 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    👦 Aarav Patel (Grade 5A)
                  </button>
                  <button
                    onClick={() => setDiaryChild('ananya')}
                    className={`py-2 text-xs font-bold rounded-lg transition cursor-pointer ${
                      diaryChild === 'ananya'
                        ? 'bg-white text-purple-700 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    👧 Ananya Patel (Grade 2A)
                  </button>
                </div>

                {/* Progress bar */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-slate-800">Tonight's Homework Progress</span>
                    <p className="text-[11px] text-slate-500">
                      {diaryChild === 'aarav'
                        ? `${[completedHw.m1, completedHw.s1, completedHw.h1].filter(Boolean).length} of 3 tasks completed`
                        : `${[completedHw.e1, completedHw.en1].filter(Boolean).length} of 2 tasks completed`}
                    </p>
                  </div>
                  <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-200">
                    {diaryChild === 'aarav' && [completedHw.m1, completedHw.s1, completedHw.h1].every(Boolean)
                      ? '🎉 All Done!'
                      : 'In Progress'}
                  </span>
                </div>

                {/* Homework Task Cards */}
                {diaryChild === 'aarav' ? (
                  <div className="space-y-2.5">
                    {/* Math */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-black uppercase text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                            Mathematics · Ms. Arundhati Dash
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1">Exercise 4.2 Fractions (Q1 to Q5)</h4>
                          <p className="text-[11px] text-slate-600 mt-0.5">
                            Solve in Classwork notebook. Simplify mixed fractions to lowest terms.
                          </p>
                        </div>
                        <button
                          onClick={() => setCompletedHw({ ...completedHw, m1: !completedHw.m1 })}
                          className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 ${
                            completedHw.m1
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                          }`}
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>{completedHw.m1 ? 'Done' : 'Mark Done'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Science */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-black uppercase text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                            Science · Mr. Subhasis Panda
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1">Hirakud Dam Spillway Gates Sketch</h4>
                          <p className="text-[11px] text-slate-600 mt-0.5">
                            Draw and label the sluice gates in the EVS project file.
                          </p>
                          <p className="text-[11px] text-indigo-700 italic mt-1">
                            💡 Parent Tip: Ask Aarav how his group designed the diorama today!
                          </p>
                        </div>
                        <button
                          onClick={() => setCompletedHw({ ...completedHw, s1: !completedHw.s1 })}
                          className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 ${
                            completedHw.s1
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                          }`}
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>{completedHw.s1 ? 'Done' : 'Mark Done'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Language */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-black uppercase text-amber-600 bg-amber-50 px-2 py-0.5 rounded">
                            {locale === 'or' ? 'ଓଡ଼ିଆ ସାହିତ୍ୟ' : 'Hindi / Odia Reading'} · Mrs. Rekha Sharma
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1">
                            {locale === 'or' ? 'ଅଧ୍ୟାୟ ୬: ସାହସୀ ବାଳକ (ପୃଷ୍ଠା ୪୨)' : 'Chapter 6: Courage (Page 42-45)'}
                          </h4>
                          <p className="text-[11px] text-slate-600 mt-0.5">Read 2 paragraphs aloud with correct pronunciation.</p>
                        </div>
                        <button
                          onClick={() => setCompletedHw({ ...completedHw, h1: !completedHw.h1 })}
                          className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 ${
                            completedHw.h1
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                          }`}
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>{completedHw.h1 ? 'Done' : 'Mark Done'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {/* Ananya Tasks */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-black uppercase text-purple-600 bg-purple-50 px-2 py-0.5 rounded">
                          EVS · Mrs. Mohanty
                        </span>
                        <h4 className="text-xs font-bold text-slate-900 mt-1">Butterfly Life-Cycle Coloring Sheet</h4>
                        <p className="text-[11px] text-slate-600 mt-0.5">Color the 4 stages: Egg, Caterpillar, Pupa, Butterfly.</p>
                      </div>
                      <button
                        onClick={() => setCompletedHw({ ...completedHw, e1: !completedHw.e1 })}
                        className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 ${
                          completedHw.e1
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <Check className="h-3.5 w-3.5" />
                        <span>{completedHw.e1 ? 'Done' : 'Mark Done'}</span>
                      </button>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-black uppercase text-purple-600 bg-purple-50 px-2 py-0.5 rounded">
                          English Phonics · Ms. Tanya
                        </span>
                        <h4 className="text-xs font-bold text-slate-900 mt-1">Phonics Workbook Page 18</h4>
                        <p className="text-[11px] text-slate-600 mt-0.5">Trace and match words ending with 'ight'.</p>
                      </div>
                      <button
                        onClick={() => setCompletedHw({ ...completedHw, en1: !completedHw.en1 })}
                        className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 ${
                          completedHw.en1
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <Check className="h-3.5 w-3.5" />
                        <span>{completedHw.en1 ? 'Done' : 'Mark Done'}</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Parent Acknowledgment Action */}
                <div className="pt-2">
                  <button
                    onClick={() => {
                      setDiarySigned(true);
                      alert('Signed! Class teacher has been informed that parent checked tonight\'s diary.');
                    }}
                    className={`w-full py-3 rounded-xl font-bold text-xs shadow transition cursor-pointer flex items-center justify-center gap-2 ${
                      diarySigned
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#0F2942] hover:bg-slate-800 text-white'
                    }`}
                  >
                    <CheckCircle2 className="h-4 w-4" />
                    <span>{diarySigned ? '✓ Verified & Signed by Parent' : 'Sign & Acknowledge Homework'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* ==================================================================
                DRAWER 2: ATTENDANCE & 1-TAP LEAVE APPLICATION
                ================================================================== */}
            {activeDrawer === 'ATTENDANCE' && (
              <div className="space-y-4">
                {/* Metric Summary */}
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800">
                      Term 1 Attendance Record
                    </span>
                    <h3 className="text-2xl font-black text-emerald-950 mt-0.5">96.4%</h3>
                    <p className="text-[11px] text-emerald-800 font-medium">
                      68 of 70 days present • CBSE minimum is 75%
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 bg-white px-3 py-1 rounded-full border border-emerald-200">
                      <Check className="h-3 w-3" /> Safe Zone
                    </span>
                  </div>
                </div>

                {/* 1-Tap Absence Application Form */}
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">🤒</span>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Notify School & Driver of Absence</h4>
                      <p className="text-[11px] text-slate-500">
                        Auto-updates attendance ledger and stops bus from waiting at your gate
                      </p>
                    </div>
                  </div>

                  {leaveSubmitted ? (
                    <div className="p-3 bg-emerald-100/70 border border-emerald-300 rounded-xl text-xs text-emerald-900 font-medium space-y-1 animate-in fade-in">
                      <p className="font-bold flex items-center gap-1.5">
                        <CheckCircle2 className="h-4 w-4 text-emerald-700" />
                        Absence Registered for Tomorrow
                      </p>
                      <p className="text-[11px]">
                        Teacher Ms. Arundhati Dash and Driver Maheswar Bhoi (OD-15) have been alerted. Bus #3 will skip Sakhipada stop.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3 pt-1">
                      {/* Select Child */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-700">Child:</label>
                        <div className="grid grid-cols-3 gap-2">
                          {(['aarav', 'ananya', 'both'] as const).map((c) => (
                            <button
                              key={c}
                              onClick={() => setLeaveChild(c)}
                              className={`py-1.5 px-2 text-xs font-bold rounded-lg border transition cursor-pointer ${
                                leaveChild === c
                                  ? 'bg-indigo-600 text-white border-indigo-600'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              {c === 'aarav' ? 'Aarav (5A)' : c === 'ananya' ? 'Ananya (2A)' : 'Both Siblings'}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Select Reason */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-700">Reason:</label>
                        <div className="grid grid-cols-3 gap-2 text-xs">
                          {(
                            [
                              { key: 'fever', label: '🤒 Fever / Cold' },
                              { key: 'family', label: '👨‍👩‍👧 Family Function' },
                              { key: 'travel', label: '🚗 Travel / Away' },
                            ] as const
                          ).map((r) => (
                            <button
                              key={r.key}
                              onClick={() => setLeaveReason(r.key)}
                              className={`py-2 px-1 text-center font-bold rounded-lg border transition cursor-pointer text-[11px] ${
                                leaveReason === r.key
                                  ? 'bg-indigo-600 text-white border-indigo-600'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              {r.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={() => setLeaveSubmitted(true)}
                        className="w-full py-2.5 bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Send className="h-3.5 w-3.5" />
                        <span>Send 1-Tap Absence Notification</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ==================================================================
                DRAWER 3: EXAMS, SYLLABUS & CBSE HOLISTIC PROGRESS CARD (HPC)
                ================================================================== */}
            {activeDrawer === 'EXAMS' && (
              <div className="space-y-4">
                {/* Upcoming Assessment Countdown */}
                <div className="bg-indigo-50 border border-indigo-200 rounded-2xl p-4 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider text-indigo-700">
                      Upcoming Assessment
                    </span>
                    <span className="text-xs font-bold text-indigo-900 bg-white px-2 py-0.5 rounded-full border border-indigo-200">
                      Starts in 4 Days
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-indigo-950">
                    Periodic Assessment 2 (Nov 4 – Nov 8, 2026)
                  </h4>
                  <p className="text-xs text-indigo-800">
                    Grade 5A & Grade 2A syllabus schedules are finalized by CBSE Academic Cell.
                  </p>
                </div>

                {/* Exam Date Sheet */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                    Date Sheet & Syllabus Topics
                  </span>
                  <div className="space-y-1.5 text-xs">
                    {[
                      { date: 'Mon, Nov 4', subject: 'Mathematics', topics: 'Fractions, Decimals, Perimeter' },
                      { date: 'Tue, Nov 5', subject: 'Science', topics: 'Water cycle, Dam Spillways, Force & Motion' },
                      { date: 'Wed, Nov 6', subject: 'English', topics: 'Unseen Passage, Informal Letter, Tenses' },
                      { date: 'Thu, Nov 7', subject: 'Social Studies', topics: 'Odisha River Basins, Monuments' },
                      { date: 'Fri, Nov 8', subject: 'Hindi / Odia', topics: 'Ch 5 & 6 Comprehension, Grammar' },
                    ].map((row, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-800">{row.subject}</span>
                            <span className="text-[10px] text-slate-500 font-mono">({row.date})</span>
                          </div>
                          <p className="text-[11px] text-slate-500">{row.topics}</p>
                        </div>
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          Syllabus Set
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CBSE Holistic Progress Card (HPC) & Teacher Audio Note */}
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                        Term 1 Holistic Progress Card (HPC)
                      </span>
                      <h4 className="text-xs font-bold text-slate-900 mt-0.5">Aarav Patel · Grade 5A</h4>
                    </div>
                    <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                      Distinction (92.4%)
                    </span>
                  </div>

                  {/* Teacher Voice Rubric Clip */}
                  <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-base">🎙️</span>
                        <div>
                          <p className="text-xs font-bold text-slate-800">Teacher Voice Rubric Note</p>
                          <p className="text-[10px] text-slate-500">Ms. Arundhati Dash (Grade 5A Class Teacher)</p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setIsPlayingHpcVoice(true);
                          speakText(
                            locale === 'or'
                              ? 'ନମସ୍କାର। ବିଜ୍ଞାନ ପ୍ରକଳ୍ପରେ ଆରଭ ବହୁତ ଭଲ ସହଯୋଗ କରିଛି। ତାର ଗ୍ରୁପ୍ କାର୍ଯ୍ୟ ଏବଂ ଉତ୍ସାହ ପ୍ରଶଂସନୀୟ।'
                              : locale === 'hi'
                              ? 'नमस्ते। आरव ने इस सत्र विज्ञान प्रोजेक्ट में बहुत उत्कृष्ट कार्य किया है। उनकी टीम भावना सराहनीय है।'
                              : 'Namaste. Aarav showed wonderful curiosity in the Hirakud dam model project this term. His peer collaboration is outstanding.'
                          );
                        }}
                        className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-lg border border-indigo-200 flex items-center gap-1 cursor-pointer"
                      >
                        <Volume2 className="h-3.5 w-3.5" />
                        <span>Play Audio</span>
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-600 italic bg-slate-50 p-2 rounded-lg border border-slate-100">
                      "Aarav showed wonderful curiosity in the Hirakud dam model project this term. His peer collaboration and mathematical reasoning are outstanding."
                    </p>
                  </div>

                  {/* Download Official PDF */}
                  <button
                    onClick={() => alert('Official CBSE Term 1 Holistic Progress Card (HPC) PDF downloaded.')}
                    className="w-full py-2.5 bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Download Official CBSE Marksheet (PDF)</span>
                  </button>
                </div>
              </div>
            )}

            {/* ==================================================================
                DRAWER 4: SCHOOL FEES, ESCROW SHIELD & 80C RECEIPTS
                ================================================================== */}
            {activeDrawer === 'FEES' && (
              <div className="space-y-4">
                {/* Fee Status Card */}
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800">
                      Quarter 3 Status (Oct – Dec 2026)
                    </span>
                    <h3 className="text-xl font-black text-emerald-950 mt-0.5">₹0 Dues Pending</h3>
                    <p className="text-[11px] text-emerald-800 font-medium">
                      All tuition & transport paid · Next due Dec 15 (Q4)
                    </p>
                  </div>
                  <span className="text-xs font-bold text-emerald-800 bg-white px-3 py-1 rounded-full border border-emerald-200">
                    ✓ Paid in Full
                  </span>
                </div>

                {/* Itemized Fee Breakdown */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                    Quarter 3 Fee Breakdown
                  </span>
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2 text-xs">
                    <div className="flex justify-between text-slate-700">
                      <span>Tuition & Smart Learning Lab (Grade 5A)</span>
                      <strong className="text-slate-900 font-mono">₹14,000</strong>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span>AC Bus Route #3 Fleet (OD-15)</span>
                      <strong className="text-slate-900 font-mono">₹3,500</strong>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span>Nutritional Recess Meal Subscription</span>
                      <strong className="text-slate-900 font-mono">₹1,000</strong>
                    </div>
                    <div className="border-t border-slate-200 pt-2 flex justify-between font-bold text-slate-900">
                      <span>Total Paid via UPI</span>
                      <span className="text-emerald-700 font-mono">₹18,500</span>
                    </div>
                  </div>
                </div>

                {/* 80C Tax Proof Download */}
                <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Official GST 80C Tax Receipt</h4>
                    <p className="text-[11px] text-slate-500">Receipt #BOMIS-2026-REC-001 • Eligible for Income Tax rebate</p>
                  </div>
                  <button
                    onClick={() => {
                      setReceiptDownloaded(true);
                      alert('GST 80C Tax Receipt #BOMIS-2026-REC-001 downloaded to your device.');
                    }}
                    className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-lg border border-indigo-200 flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>{receiptDownloaded ? 'Downloaded' : 'Download'}</span>
                  </button>
                </div>

                {/* Calm Escrow Shield Information */}
                <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-1.5 text-xs text-amber-950">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Shield className="h-4 w-4 text-amber-700" />
                    <span>BOMIS Calm Escrow Shield Guarantee</span>
                  </div>
                  <p className="text-[11px] text-amber-900 leading-relaxed">
                    If your bank times out during UPI payments at 11:59 PM, our system automatically issues a 48-Hour Provisional Clearance Pass (#PROV-8821). Your child will NEVER be barred from classes or exams due to bank gateway delays.
                  </p>
                </div>
              </div>
            )}

            {/* ==================================================================
                DRAWER 5: PTM (PARENT-TEACHER MEETING) 1-TAP BOOKING
                ================================================================== */}
            {activeDrawer === 'PTM' && (
              <div className="space-y-4">
                {/* Upcoming PTM Banner */}
                <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 space-y-1">
                  <span className="text-[10px] font-black uppercase tracking-wider text-purple-700">
                    Term 1 Parent-Teacher Conference
                  </span>
                  <h4 className="text-sm font-black text-purple-950">Saturday, Nov 8, 2026</h4>
                  <p className="text-xs text-purple-800">
                    10-minute one-on-one session with your child's class teacher to review progress.
                  </p>
                </div>

                {ptmConfirmed ? (
                  <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl space-y-2 text-xs animate-in fade-in">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold">
                      <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                      <span>Appointment Confirmed!</span>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-emerald-200 space-y-1 text-slate-700">
                      <p><strong>Teacher:</strong> {ptmTeacher === 'dash' ? 'Ms. Arundhati Dash (Grade 5A)' : 'Mrs. Mohanty (Grade 2A)'}</p>
                      <p><strong>Time:</strong> Saturday, Nov 8 · {ptmSlot}</p>
                      <p><strong>Format:</strong> {ptmMode === 'campus' ? 'Room 204 (Academic Block)' : 'Google Meet Video Link'}</p>
                      <p className="font-mono font-bold text-indigo-700 pt-1">Gate Pass Code: #PTM-442</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Teacher Selector */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700">Select Teacher:</label>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <button
                          onClick={() => setPtmTeacher('dash')}
                          className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                            ptmTeacher === 'dash'
                              ? 'bg-purple-50 border-purple-500 text-purple-950 font-bold'
                              : 'bg-white border-slate-200 text-slate-700'
                          }`}
                        >
                          <p className="font-bold">Ms. Arundhati Dash</p>
                          <p className="text-[10px] text-slate-500">Grade 5A Class Teacher</p>
                        </button>
                        <button
                          onClick={() => setPtmTeacher('mohanty')}
                          className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                            ptmTeacher === 'mohanty'
                              ? 'bg-purple-50 border-purple-500 text-purple-950 font-bold'
                              : 'bg-white border-slate-200 text-slate-700'
                          }`}
                        >
                          <p className="font-bold">Mrs. Mohanty</p>
                          <p className="text-[10px] text-slate-500">Grade 2A Class Teacher</p>
                        </button>
                      </div>
                    </div>

                    {/* Mode Selector */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700">Meeting Format:</label>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <button
                          onClick={() => setPtmMode('campus')}
                          className={`py-2 px-3 rounded-lg border font-bold transition cursor-pointer ${
                            ptmMode === 'campus'
                              ? 'bg-indigo-600 text-white border-indigo-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          🏫 In-Person at Campus
                        </button>
                        <button
                          onClick={() => setPtmMode('video')}
                          className={`py-2 px-3 rounded-lg border font-bold transition cursor-pointer ${
                            ptmMode === 'video'
                              ? 'bg-indigo-600 text-white border-indigo-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          📹 Google Meet Video
                        </button>
                      </div>
                    </div>

                    {/* Slot Selector */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700">Available Time Slots (Saturday):</label>
                      <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                        {['10:00 AM - 10:15 AM', '10:20 AM - 10:35 AM', '10:40 AM - 10:55 AM', '11:00 AM - 11:15 AM'].map(
                          (slot) => (
                            <button
                              key={slot}
                              onClick={() => setPtmSlot(slot)}
                              className={`py-2 px-2 rounded-lg border font-bold transition cursor-pointer ${
                                ptmSlot === slot
                                  ? 'bg-purple-600 text-white border-purple-600'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                              }`}
                            >
                              {slot}
                            </button>
                          )
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => setPtmConfirmed(true)}
                      className="w-full py-2.5 bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer"
                    >
                      Confirm PTM Appointment
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* ==================================================================
                DRAWER 6: SCHOOL CIRCULARS & NOTICES (TRI-LINGUAL AUDIO)
                ================================================================== */}
            {activeDrawer === 'CIRCULARS' && (
              <div className="space-y-4">
                {/* Latest Circular */}
                <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider text-rose-700">
                      Official Circular #BOMIS-2026-CIR-088
                    </span>
                    <span className="text-[10px] font-bold text-slate-500">Oct 26, 2026</span>
                  </div>
                  <h4 className="text-sm font-black text-rose-950">
                    Winter Uniform Transition & Annual Athletics Selections
                  </h4>
                  <p className="text-xs text-rose-900 leading-relaxed">
                    Winter navy blue blazers and sweaters are mandatory starting Nov 15. Annual Sports Day selections for Grade 1–8 will take place on Nov 12 at the athletics grounds.
                  </p>

                  {/* Audio Read-Out */}
                  <div className="pt-1 flex items-center gap-2">
                    <span className="text-[11px] font-bold text-slate-600">Listen:</span>
                    <button
                      onClick={() =>
                        speakText(
                          'Circular 88. Winter navy blue blazers and sweaters are mandatory starting November 15. Annual sports day selections will begin on November 12.'
                        )
                      }
                      className="px-2.5 py-1 bg-white hover:bg-rose-100 text-rose-900 font-bold text-[11px] rounded-lg border border-rose-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="h-3 w-3 text-rose-600" />
                      <span>English</span>
                    </button>
                    <button
                      onClick={() =>
                        speakText(
                          'ପରିପତ୍ର ୮୮. ନଭେମ୍ବର ୧୫ ତାରିଖରୁ ଶୀତକାଳୀନ ୟୁନିଫର୍ମ ଏବଂ ସ୍ୱେଟର ବାଧ୍ୟତାମୂଳକ। ନଭେମ୍ବର ୧୨ ତାରିଖରେ ବାର୍ଷିକ କ୍ରୀଡ଼ା ପ୍ରତିଯୋଗିତା ଅନୁଷ୍ଠିତ ହେବ।'
                        )
                      }
                      className="px-2.5 py-1 bg-white hover:bg-rose-100 text-rose-900 font-bold text-[11px] rounded-lg border border-rose-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="h-3 w-3 text-rose-600" />
                      <span>ଓଡ଼ିଆ</span>
                    </button>
                    <button
                      onClick={() =>
                        speakText(
                          'परिपत्र 88. 15 नवंबर से शीतकालीन यूनिफॉर्म और स्वेटर अनिवार्य है। 12 नवंबर से वार्षिक खेलकूद चयन शुरू होगा।'
                        )
                      }
                      className="px-2.5 py-1 bg-white hover:bg-rose-100 text-rose-900 font-bold text-[11px] rounded-lg border border-rose-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="h-3 w-3 text-rose-600" />
                      <span>हिन्दी</span>
                    </button>
                  </div>
                </div>

                {/* Past Notices List */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                    Recent Notices Archive
                  </span>
                  <div className="space-y-1.5 text-xs">
                    {[
                      {
                        title: 'Diwali Break Schedule & Science Model Exhibition',
                        date: 'Oct 20, 2026',
                        summary: 'School closed Oct 28 - Nov 1. Reopens Nov 2.',
                      },
                      {
                        title: 'Hirakud Nature Trail Educational Excursion',
                        date: 'Oct 10, 2026',
                        summary: 'Grade 5 field visit permissions and safety protocol.',
                      },
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between"
                      >
                        <div>
                          <h5 className="font-bold text-slate-800">{item.title}</h5>
                          <p className="text-[11px] text-slate-500 mt-0.5">{item.summary}</p>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 shrink-0 ml-2">{item.date}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Download PDF button */}
                <button
                  onClick={() => alert('Official Circular #BOMIS-2026-CIR-088 PDF downloaded.')}
                  className="w-full py-2.5 bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download Official Circular (PDF)</span>
                </button>
              </div>
            )}

            {/* Close Drawer Button */}
            <div className="pt-1">
              <button
                onClick={() => setActiveDrawer(null)}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------------
          MORE SHEET (Bottom Sheet replacing messy multi-tab navigation)
          ------------------------------------------------------------------------ */}
      {isMoreOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end justify-center p-0"
        >
          <div className="bg-white w-full max-w-md rounded-t-3xl shadow-2xl p-5 space-y-4 max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-200 border-t border-slate-200">
            {/* Sheet Handle and Title */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="text-xl">☰</span>
                <h3 className="text-base font-black text-slate-900">{t('home.more', locale)}</h3>
              </div>
              <button
                onClick={() => setIsMoreOpen(false)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Section 1: Quick Access to Core Modules */}
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                Quick Access Modules
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('DIARY'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <BookOpen className="h-4 w-4 text-blue-600 shrink-0" />
                  <span>{t('service.diary', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('ATTENDANCE'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <Calendar className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span>{t('service.attendance', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('EXAMS'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <GraduationCap className="h-4 w-4 text-indigo-600 shrink-0" />
                  <span>{t('service.exams', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('FEES'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <Receipt className="h-4 w-4 text-amber-600 shrink-0" />
                  <span>{t('service.fees', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('PTM'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <Users className="h-4 w-4 text-purple-600 shrink-0" />
                  <span>{t('service.ptm', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('CIRCULARS'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <FileText className="h-4 w-4 text-rose-600 shrink-0" />
                  <span>{t('service.circulars', locale)}</span>
                </button>
              </div>
            </div>

            {/* Section 3: Photo Privacy & Consent */}
            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                Child Photo Privacy & Permissions
              </span>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">
                    Allow school to include Aarav in newsletter and celebration photos
                  </span>
                  <input
                    type="checkbox"
                    checked={photoConsent.aarav}
                    onChange={(e) => setPhotoConsent({ ...photoConsent, aarav: e.target.checked })}
                    className="h-4 w-4 rounded accent-indigo-600 cursor-pointer"
                  />
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-slate-200/60">
                  <span className="text-xs font-bold text-slate-800">
                    Allow school to include Ananya in newsletter and celebration photos
                  </span>
                  <input
                    type="checkbox"
                    checked={photoConsent.ananya}
                    onChange={(e) => setPhotoConsent({ ...photoConsent, ananya: e.target.checked })}
                    className="h-4 w-4 rounded accent-indigo-600 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Section 4: Emergency Contacts & Front Desk */}
            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                School Contacts & Emergency Help
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <a
                  href="tel:+919437000003"
                  className="p-2.5 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold text-slate-800 flex items-center gap-1.5"
                >
                  <Phone className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
                  <span>Front Desk</span>
                </a>
                <a
                  href="tel:+919437200001"
                  className="p-2.5 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold text-slate-800 flex items-center gap-1.5"
                >
                  <Bus className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                  <span>Transport In-Charge</span>
                </a>
                <a
                  href="tel:+919437100008"
                  className="p-2.5 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold text-slate-800 flex items-center gap-1.5"
                >
                  <span className="text-rose-600 text-sm">🩹</span>
                  <span>Sick Bay Nurse</span>
                </a>
              </div>
            </div>

            {/* Close Sheet Button */}
            <div className="pt-2">
              <button
                onClick={() => setIsMoreOpen(false)}
                className="w-full py-3 bg-[#0F2942] text-white font-black text-xs rounded-xl shadow transition"
              >
                Close Menu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
