import React from 'react';
import Link from 'next/link';
import { School } from 'lucide-react';

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col justify-center py-12 sm:px-6 lg:px-8 bg-gradient-to-b from-slate-100 to-white">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link href="/" className="inline-flex items-center space-x-3 group">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#0F2942] text-white shadow-md group-hover:scale-105 transition-transform">
            <School className="h-6 w-6 text-white" />
          </div>
          <div className="text-left">
            <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-tight">BOMIS Sambalpur</h1>
            <p className="text-xs text-slate-500 font-medium">Birla Open Minds International School</p>
          </div>
        </Link>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-xl sm:rounded-2xl sm:px-10 border border-slate-200">
          {children}
        </div>
        <p className="mt-6 text-center text-xs text-slate-400">
          CBSE Affiliation No. 1530267 • Sambalpur Campus, Odisha
        </p>
      </div>
    </div>
  );
}
