'use client';

import * as React from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { UserRole } from '@bomis/shared';
import { useAuthStore, authStore, DEFAULT_SIBLINGS } from '@/lib/auth-store';
import { DashboardShell } from '@/components/layout/dashboard-shell';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  const user = useAuthStore((s) => s.user);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const linkedChildren = useAuthStore((s) => s.linkedChildren);
  const activeChildId = useAuthStore((s) => s.activeChildId);

  // Derive role fallback based on pathname if user hasn't explicitly logged in
  const derivedRole = React.useMemo<UserRole>(() => {
    if (user?.role) return user.role;
    if (pathname.startsWith('/admin')) return UserRole.ADMIN;
    if (pathname.startsWith('/principal')) return UserRole.PRINCIPAL;
    if (pathname.startsWith('/teacher')) return UserRole.TEACHER;
    if (pathname.startsWith('/accountant')) return UserRole.ACCOUNTANT;
    if (pathname.startsWith('/parent')) return UserRole.PARENT;
    return UserRole.PARENT;
  }, [user, pathname]);

  const activeUser = React.useMemo(() => {
    if (user) return user;
    // Default preview profiles corresponding to roles
    switch (derivedRole) {
      case UserRole.PRINCIPAL:
        return {
          id: 'u-principal',
          name: 'Dr. Minati Mohanty',
          email: 'principal@bomis-sambalpur.edu.in',
          role: UserRole.PRINCIPAL,
          schoolId: 'e4b3c2a1-0001-4000-8000-000000000001',
        };
      case UserRole.TEACHER:
        return {
          id: 'u-teacher',
          name: 'Arundhati Dash',
          email: 'arundhati.dash@bomis-sambalpur.edu.in',
          role: UserRole.TEACHER,
          schoolId: 'e4b3c2a1-0001-4000-8000-000000000001',
        };
      case UserRole.ACCOUNTANT:
        return {
          id: 'u-accountant',
          name: 'Birendra Nath Sahu',
          email: 'birendra.sahu@bomis-sambalpur.edu.in',
          role: UserRole.ACCOUNTANT,
          schoolId: 'e4b3c2a1-0001-4000-8000-000000000001',
        };
      case UserRole.ADMIN:
      case UserRole.SUPER_ADMIN:
        return {
          id: 'u-admin',
          name: 'Amit Kumar Senapati',
          email: 'amit.senapati@bomis-sambalpur.edu.in',
          role: UserRole.ADMIN,
          schoolId: 'e4b3c2a1-0001-4000-8000-000000000001',
        };
      case UserRole.PARENT:
      default:
        return {
          id: 'u-parent',
          name: 'Dr. Rajesh Kumar Patel',
          email: 'rajesh.patel@example.com',
          role: UserRole.PARENT,
          schoolId: 'e4b3c2a1-0001-4000-8000-000000000001',
        };
    }
  }, [user, derivedRole]);

  const childrenSummaries = React.useMemo(() => {
    const list = linkedChildren.length > 0 ? linkedChildren : DEFAULT_SIBLINGS;
    return list.map((c) => ({
      id: c.id,
      name: `${c.firstName} ${c.lastName}`,
      grade: `Grade ${c.grade}${c.section}`,
      admissionNo: c.admissionNumber,
    }));
  }, [linkedChildren]);

  const handleSelectChild = (childId: string) => {
    authStore.setActiveChildId(childId);
  };

  const handleLogout = () => {
    authStore.logout();
    router.push('/login');
  };

  const uAny = activeUser as any;
  const displayName = uAny.name || [uAny.firstName, uAny.lastName].filter(Boolean).join(' ') || 'User';

  return (
    <DashboardShell
      user={{
        name: displayName,
        email: activeUser.email || '',
        role: derivedRole,
      }}
      childrenList={childrenSummaries}
      activeChildId={activeChildId || childrenSummaries[0]?.id}
      onSelectChild={handleSelectChild}
      onLogout={handleLogout}
    >
      {children}
    </DashboardShell>
  );
}
