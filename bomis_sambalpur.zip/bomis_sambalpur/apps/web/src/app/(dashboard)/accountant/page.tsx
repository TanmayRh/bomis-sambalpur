'use client';

import * as React from 'react';
import { FeeReconciliationCard } from '@/components/modules/accountant/fee-reconciliation-card';
import { FeeStructureTable } from '@/components/modules/accountant/fee-structure-table';
import { ConcessionApprovalDialog } from '@/components/modules/accountant/concession-approval-dialog';
import { PaymentLedgerTable } from '@/components/modules/accountant/payment-ledger-table';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

export default function AccountantDashboardPage() {
  const [activeTab, setActiveTab] = React.useState('ledger');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Financial Operations & Fee Management
          </h1>
          <p className="text-sm text-slate-500">
            Birendra Nath Sahu • Senior Accountant • Tuition, transport reconciliation & concessions
          </p>
        </div>
      </div>

      {/* Financial KPIs */}
      <FeeReconciliationCard />

      {/* Tabbed Financial Operations */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 max-w-lg">
          <TabsTrigger value="ledger">Payment Ledger & Receipts</TabsTrigger>
          <TabsTrigger value="structures">Fee Structures</TabsTrigger>
          <TabsTrigger value="concessions">Concession Approvals</TabsTrigger>
        </TabsList>

        <TabsContent value="ledger">
          <PaymentLedgerTable />
        </TabsContent>

        <TabsContent value="structures">
          <FeeStructureTable />
        </TabsContent>

        <TabsContent value="concessions">
          <ConcessionApprovalDialog />
        </TabsContent>
      </Tabs>
    </div>
  );
}
