'use client';

import * as React from 'react';
import { useAuthStore, DEFAULT_SIBLINGS } from '@/lib/auth-store';
import { ParentSiblingBar } from '@/components/modules/parent/parent-sibling-bar';
import { AttendanceCalendarCard } from '@/components/modules/parent/attendance-calendar-card';
import { RazorpayCheckoutModal } from '@/components/modules/parent/razorpay-checkout-modal';
import { LiveBusTracker } from '@/components/modules/parent/live-bus-tracker';
import { PickupOtpCard } from '@/components/modules/parent/pickup-otp-card';
import { Bus, CreditCard, CalendarCheck, ShieldCheck } from 'lucide-react';

export default function ParentDashboardPage() {
  const linkedChildren = useAuthStore((s) => s.linkedChildren);
  const activeChildId = useAuthStore((s) => s.activeChildId);

  const children = linkedChildren.length > 0 ? linkedChildren : DEFAULT_SIBLINGS;
  const activeChild = children.find((c) => c.id === activeChildId) || children[0]!;
  const childFullName = `${activeChild.firstName} ${activeChild.lastName}`;

  // Smooth scroll ref anchors
  const busRef = React.useRef<HTMLDivElement>(null);
  const feeRef = React.useRef<HTMLDivElement>(null);
  const attRef = React.useRef<HTMLDivElement>(null);
  const otpRef = React.useRef<HTMLDivElement>(null);

  const scrollTo = (ref: React.RefObject<HTMLDivElement>) => {
    ref.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Sibling Switcher Bar */}
      <ParentSiblingBar />

      {/* 4 Big Simple Action Buttons */}
      <div>
        <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
          Quick 1-Tap Shortcuts for Parents:
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => scrollTo(busRef)}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 text-white font-bold text-left shadow hover:shadow-md transition active:scale-95 flex items-center space-x-3"
          >
            <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <Bus className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-extrabold leading-tight">Track Bus</div>
              <div className="text-[11px] text-amber-100 font-medium mt-0.5">Live GPS</div>
            </div>
          </button>

          <button
            onClick={() => scrollTo(feeRef)}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-[#FF6B4A] to-[#E05232] text-white font-bold text-left shadow hover:shadow-md transition active:scale-95 flex items-center space-x-3"
          >
            <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <CreditCard className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-extrabold leading-tight">Pay Fees</div>
              <div className="text-[11px] text-orange-100 font-medium mt-0.5">UPI / Card</div>
            </div>
          </button>

          <button
            onClick={() => scrollTo(attRef)}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-600 to-emerald-700 text-white font-bold text-left shadow hover:shadow-md transition active:scale-95 flex items-center space-x-3"
          >
            <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <CalendarCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-extrabold leading-tight">Attendance</div>
              <div className="text-[11px] text-emerald-100 font-medium mt-0.5">Present Today</div>
            </div>
          </button>

          <button
            onClick={() => scrollTo(otpRef)}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-[#0F2942] to-[#1A3A5C] text-white font-bold text-left shadow hover:shadow-md transition active:scale-95 flex items-center space-x-3"
          >
            <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-extrabold leading-tight">Gate Pass</div>
              <div className="text-[11px] text-slate-300 font-medium mt-0.5">Pickup OTP</div>
            </div>
          </button>
        </div>
      </div>

      {/* Grid: Attendance & Razorpay Fees */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div ref={attRef}>
          <AttendanceCalendarCard key={`att-${activeChild.id}`} childName={childFullName} childId={activeChild.id} />
        </div>
        <div ref={feeRef}>
          <RazorpayCheckoutModal key={`fee-${activeChild.id}`} studentName={childFullName} studentId={activeChild.id} />
        </div>
      </div>

      {/* Grid: Live Bus GPS & Dismissal OTP */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div ref={busRef}>
          <LiveBusTracker key={`bus-${activeChild.id}`} childName={activeChild.firstName} />
        </div>
        <div ref={otpRef}>
          <PickupOtpCard key={`otp-${activeChild.id}`} childName={childFullName} childId={activeChild.id} />
        </div>
      </div>
    </div>
  );
}
