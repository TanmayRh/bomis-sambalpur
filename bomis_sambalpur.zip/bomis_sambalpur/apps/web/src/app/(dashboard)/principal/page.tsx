'use client';

import * as React from 'react';
import { PulseKpiGrid } from '@/components/modules/principal/pulse-kpi-grid';
import { ClassAttendanceChart } from '@/components/modules/principal/class-attendance-chart';
import { BusTelemetryWidget } from '@/components/modules/principal/bus-telemetry-widget';
import { SubstituteModal } from '@/components/modules/principal/substitute-modal';
import { Button } from '@/components/ui/button';
import { Clock, ShieldCheck, Download } from 'lucide-react';

export default function PrincipalDashboardPage() {
  const [subModalOpen, setSubModalOpen] = React.useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Principal Pulse Command Center
          </h1>
          <p className="text-sm text-slate-500">
            Executive overview for Dr. Minati Mohanty • Live attendance radar & campus operations
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant="accent"
            size="sm"
            onClick={() => setSubModalOpen(true)}
            leftIcon={<Clock className="h-4 w-4" />}
          >
            Quick Substitute Allocation
          </Button>
        </div>
      </div>

      {/* Hero Pulse Metrics */}
      <PulseKpiGrid />

      {/* Grid: Attendance breakdown & Fleet tracking */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ClassAttendanceChart />
        <BusTelemetryWidget />
      </div>

      {/* Substitute Quick Action Modal */}
      <SubstituteModal open={subModalOpen} onOpenChange={setSubModalOpen} />
    </div>
  );
}
