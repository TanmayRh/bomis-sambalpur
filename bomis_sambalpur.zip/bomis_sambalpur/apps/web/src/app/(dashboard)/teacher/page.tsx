'use client';

import * as React from 'react';
import { RapidAttendanceGrid } from '@/components/modules/teacher/rapid-attendance-grid';
import { CbseMarksEntry } from '@/components/modules/teacher/cbse-marks-entry';
import { HomeworkDialog } from '@/components/modules/teacher/homework-dialog';
import { VoiceHpcAssistant } from '@/components/modules/teacher/voice-hpc-assistant';
import { Button } from '@/components/ui/button';
import { BookOpen, CalendarCheck2, FileSpreadsheet, Users, Mic } from 'lucide-react';

export default function TeacherDashboardPage() {
  const [hwModalOpen, setHwModalOpen] = React.useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Teacher Operations Hub
          </h1>
          <p className="text-sm text-slate-500">
            Arundhati Dash • Class Teacher Grade 5A • TGT Mathematics • BOMIS Sambalpur
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={() => setHwModalOpen(true)}
            leftIcon={<BookOpen className="h-4 w-4" />}
            variant="accent"
            size="sm"
          >
            New Diary & Homework
          </Button>
        </div>
      </div>

      {/* Feature 1: Rapid Classroom Attendance (<10s SLA) */}
      <RapidAttendanceGrid />

      {/* Feature 2: Teacher Voice-to-Rubric Assistant (Voice HPC - Zero Data Entry) */}
      <VoiceHpcAssistant />

      {/* Feature 3: CBSE 9-Point Marks Entry Table */}
      <CbseMarksEntry />

      {/* Class Diary Dialog */}
      <HomeworkDialog open={hwModalOpen} onOpenChange={setHwModalOpen} />
    </div>
  );
}
