'use client';

import * as React from 'react';
import { Users, GraduationCap, Bus, ShieldCheck } from 'lucide-react';
import { StatCard } from '@/components/ui/stat-card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { AuditLogTable } from '@/components/modules/admin/audit-log-table';
import { BulkCsvImporter } from '@/components/modules/admin/bulk-csv-importer';
import { VisitorLogTable } from '@/components/modules/admin/visitor-log-table';

export default function AdminDashboardPage() {
  const [activeTab, setActiveTab] = React.useState('audit');

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Administrative Operations Center
          </h1>
          <p className="text-sm text-slate-500">
            Birla Open Minds International School, Sambalpur • Master Management & Compliance
          </p>
        </div>
        <div className="text-xs font-semibold px-3 py-1.5 rounded-full bg-slate-100 text-slate-700">
          Campus AY 2026-27
        </div>
      </div>

      {/* KPI Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Enrolled Students"
          value="1,250"
          change="+12% YoY"
          changeType="increase"
          period="vs AY 2025-26"
          icon={GraduationCap}
          variant="navy"
        />
        <StatCard
          title="Academic Faculty & Staff"
          value="85"
          change="Full Strength"
          changeType="neutral"
          period="Zero vacancies"
          icon={Users}
          variant="default"
        />
        <StatCard
          title="Transport Fleet Status"
          value="4 / 4 Active"
          change="100% On-Route"
          changeType="increase"
          period="GPS live ping < 15s"
          icon={Bus}
          variant="success"
        />
        <StatCard
          title="Campus Safety Index"
          value="0 Incidents"
          change="100% Safe"
          changeType="increase"
          period="All 2 gates secured"
          icon={ShieldCheck}
          variant="coral"
        />
      </div>

      {/* Main Admin Tabbed Modules */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 max-w-lg">
          <TabsTrigger value="audit">Audit Trail (DPDP)</TabsTrigger>
          <TabsTrigger value="ingest">Bulk CSV Ingestion</TabsTrigger>
          <TabsTrigger value="visitors">Visitor Passes</TabsTrigger>
        </TabsList>

        <TabsContent value="audit">
          <AuditLogTable />
        </TabsContent>

        <TabsContent value="ingest">
          <BulkCsvImporter />
        </TabsContent>

        <TabsContent value="visitors">
          <VisitorLogTable />
        </TabsContent>
      </Tabs>
    </div>
  );
}
