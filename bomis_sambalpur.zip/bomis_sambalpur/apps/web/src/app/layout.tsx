import React from 'react';
import { QueryProvider } from '@/lib/query-provider';
import { PwaRegistrar } from '@/components/pwa-registrar';
import './globals.css';

export const metadata = {
  title: 'BOMIS Sambalpur | Parent & Student Unified App',
  description: 'Official Operating Platform & Parent App for Birla Open Minds International School, Sambalpur (Odisha)',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'BOMIS Parent',
  },
  icons: {
    icon: '/icon.svg',
    apple: '/icon.svg',
  },
};

export const viewport = {
  themeColor: '#0F2942',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        <QueryProvider>
          <PwaRegistrar />
          {children}
        </QueryProvider>
      </body>
    </html>
  );
}
