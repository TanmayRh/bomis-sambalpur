/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['@bomis/shared', '@bomis/ui'],
  reactStrictMode: true,
  async rewrites() {
    return [
      {
        source: '/api/v1/:path*',
        destination: `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'}/api/v1/:path*`,
      },
    ];
  },
};

export default nextConfig;
