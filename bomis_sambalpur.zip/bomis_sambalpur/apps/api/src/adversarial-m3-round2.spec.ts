import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException, UnauthorizedException } from '@nestjs/common';
import * as crypto from 'crypto';
import * as jwt from 'jsonwebtoken';

import { SafetyService } from './modules/safety/safety.service';
import { PulseService } from './modules/pulse/pulse.service';
import { AuthService } from './modules/auth/auth.service';
import { PeopleService } from './modules/people/people.service';
import { FeesService } from './modules/fees/fees.service';

import { PrismaService } from './database/prisma.service';
import { MockStoreService } from './database/mock-store.service';
import { MockRedisService } from './common/redis/mock-redis.service';
import { CryptoService } from './common/crypto/crypto.service';
import { SEED_IDS } from './database/seed-fixtures';

describe('Adversarial Stress Testing Suite - M3 Round 2 Remediations', () => {
  let safetyService: SafetyService;
  let pulseService: PulseService;
  let authService: AuthService;
  let peopleService: PeopleService;
  let feesService: FeesService;
  let prisma: PrismaService;
  let redis: MockRedisService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    process.env.JWT_SECRET = 'bomis_jwt_secret_sambalpur_2026_dev_key_min32';
    process.env.RAZORPAY_WEBHOOK_SECRET = 'bomis_razorpay_secret_sambalpur_2026';

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SafetyService,
        PulseService,
        AuthService,
        PeopleService,
        FeesService,
        PrismaService,
        MockStoreService,
        MockRedisService,
        CryptoService,
      ],
    }).compile();

    safetyService = module.get<SafetyService>(SafetyService);
    pulseService = module.get<PulseService>(PulseService);
    authService = module.get<AuthService>(AuthService);
    peopleService = module.get<PeopleService>(PeopleService);
    feesService = module.get<FeesService>(FeesService);
    prisma = module.get<PrismaService>(PrismaService);
    redis = module.get<MockRedisService>(MockRedisService);

    prisma.isMock = true;
  });

  describe('1. Child Pickup OTP Replay Protection Stress Tests', () => {
    it('1A: should successfully authorize on first valid OTP submission', async () => {
      const studentId = 'stu_grade5a_001';
      const guardianId = 'grd_parent_001';
      const otp = '654321';

      await safetyService.generatePickupAuthorization(studentId, guardianId, otp);

      const firstAttempt = await safetyService.verifyChildPickup({
        studentId,
        pickupOtp: otp,
        gateNumber: 'GATE_1',
      });

      expect(firstAttempt.authorized).toBe(true);
      expect(firstAttempt.message).toBe('Child dismissal authorized successfully');
      expect(firstAttempt.gateNumber).toBe('GATE_1');
    });

    it('1B: should strictly reject replay of used OTP at same gate', async () => {
      const studentId = 'stu_grade5a_001';
      const otp = '654321';

      const replayAttempt = await safetyService.verifyChildPickup({
        studentId,
        pickupOtp: otp,
        gateNumber: 'GATE_1',
      });

      expect(replayAttempt.authorized).toBe(false);
      expect(replayAttempt.message).toBe('Pickup authorization has already been used');
    });

    it('1C: should strictly reject replay of used OTP across multiple gates (Gate 2, 3, Main)', async () => {
      const studentId = 'stu_grade5a_001';
      const otp = '654321';

      for (const gate of ['GATE_2', 'GATE_3', 'MAIN_GATE', 'BUS_BAY']) {
        const replay = await safetyService.verifyChildPickup({
          studentId,
          pickupOtp: otp,
          gateNumber: gate,
        });
        expect(replay.authorized).toBe(false);
        expect(replay.message).toBe('Pickup authorization has already been used');
      }
    });

    it('1D: should reject expired OTP and mark authorization status as EXPIRED', async () => {
      const studentId = 'stu_grade5a_002';
      const guardianId = 'grd_parent_002';
      const otp = '112233';

      const auth = await safetyService.generatePickupAuthorization(studentId, guardianId, otp);
      // Fast forward expiry into the past
      auth.expires_at = new Date(Date.now() - 60000);

      const attempt = await safetyService.verifyChildPickup({
        studentId,
        pickupOtp: otp,
        gateNumber: 'GATE_1',
      });

      expect(attempt.authorized).toBe(false);
      expect(attempt.message).toBe('Pickup OTP has expired');
      expect(auth.status).toBe('EXPIRED');
    });

    it('1E: should strictly reject subsequent replay of already-expired OTP', async () => {
      const studentId = 'stu_grade5a_002';
      const otp = '112233';

      const replayExpired = await safetyService.verifyChildPickup({
        studentId,
        pickupOtp: otp,
        gateNumber: 'GATE_2',
      });

      expect(replayExpired.authorized).toBe(false);
      expect(replayExpired.message).toBe('Pickup OTP has expired');
    });

    it('1F: should reject invalid OTP without marking authorization as USED', async () => {
      const studentId = 'stu_grade5a_003';
      const guardianId = 'grd_parent_003';
      const realOtp = '998877';

      const auth = await safetyService.generatePickupAuthorization(studentId, guardianId, realOtp);

      const wrongAttempt = await safetyService.verifyChildPickup({
        studentId,
        pickupOtp: '000000',
        gateNumber: 'GATE_1',
      });

      expect(wrongAttempt.authorized).toBe(false);
      expect(wrongAttempt.message).toBe('Invalid pickup OTP');
      expect(auth.status).toBe('ACTIVE'); // remains active for legitimate attempt

      // Now legitimate attempt succeeds
      const legitAttempt = await safetyService.verifyChildPickup({
        studentId,
        pickupOtp: realOtp,
        gateNumber: 'GATE_1',
      });
      expect(legitAttempt.authorized).toBe(true);
      expect(auth.status).toBe('USED');
    });

    it('1G: should throw BadRequestException for non-6-digit OTP formats', async () => {
      const invalidOtps = ['123', '12345', '1234567', 'abcdef', '12a456', ''];
      for (const badOtp of invalidOtps) {
        await expect(
          safetyService.verifyChildPickup({
            studentId: 'stu_grade5a_001',
            pickupOtp: badOtp,
            gateNumber: 'GATE_1',
          })
        ).rejects.toThrow(BadRequestException);
      }
    });

    it('1H: should safely reject student without pickup authorization', async () => {
      const nonExistentStudentResult = await safetyService.verifyChildPickup({
        studentId: 'stu_non_existent_random_id',
        pickupOtp: '123456',
        gateNumber: 'GATE_1',
      });
      expect(nonExistentStudentResult.authorized).toBe(false);
      expect(nonExistentStudentResult.message).toBe('No active pickup authorization found for student');
    });
  });

  describe('2. Principal Pulse Dynamic Metrics & Zero-Data Defense', () => {
    it('2A: should calculate non-zero dynamic metrics for default seed data', async () => {
      const metrics = await pulseService.getMetrics();
      expect(metrics.attendanceRate).toBeGreaterThan(0);
      expect(metrics.feeCollectionRate).toBeGreaterThan(0);
      expect(metrics.attendanceRate).not.toBe(95.4); // Verify literal eliminated
      expect(metrics.feeCollectionRate).not.toBe(89.2); // Verify literal eliminated
    });

    it('2B: should defend against 0/0 division when attendance store is empty', async () => {
      // Backup store
      const backupAttendance = new Map(prisma.mockStore.attendance);
      prisma.mockStore.attendance.clear();

      try {
        const metrics = await pulseService.getMetrics();
        expect(metrics.attendanceRate).toBe(0);
        expect(Number.isNaN(metrics.attendanceRate)).toBe(false);
      } finally {
        // Restore store
        for (const [k, v] of backupAttendance.entries()) {
          prisma.mockStore.attendance.set(k, v);
        }
      }
    });

    it('2C: should defend against 0/0 division when fee installments and payments are empty', async () => {
      const backupPayments = new Map(prisma.mockStore.payments);
      const backupInstallments = new Map(prisma.mockStore.feeInstallments);
      prisma.mockStore.payments.clear();
      prisma.mockStore.feeInstallments.clear();

      try {
        const metrics = await pulseService.getMetrics();
        expect(metrics.feeCollectionRate).toBe(0);
        expect(Number.isNaN(metrics.feeCollectionRate)).toBe(false);
      } finally {
        for (const [k, v] of backupPayments.entries()) {
          prisma.mockStore.payments.set(k, v);
        }
        for (const [k, v] of backupInstallments.entries()) {
          prisma.mockStore.feeInstallments.set(k, v);
        }
      }
    });

    it('2D: should accurately compute weighted half-day attendance formula ((present + 0.5*half) / total) * 100', async () => {
      const backupAttendance = new Map(prisma.mockStore.attendance);
      prisma.mockStore.attendance.clear();

      try {
        // 1 PRESENT + 1 HALF_DAY + 2 ABSENT = total 4 working days
        // formula: ((1 + 0.5 * 1) / 4) * 100 = (1.5 / 4) * 100 = 37.5%
        prisma.mockStore.attendance.set('s1', { status: 'PRESENT' });
        prisma.mockStore.attendance.set('s2', { status: 'HALF_DAY' });
        prisma.mockStore.attendance.set('s3', { status: 'ABSENT' });
        prisma.mockStore.attendance.set('s4', { status: 'ABSENT' });

        const metrics = await pulseService.getMetrics();
        expect(metrics.attendanceRate).toBe(37.5);
      } finally {
        for (const [k, v] of backupAttendance.entries()) {
          prisma.mockStore.attendance.set(k, v);
        }
      }
    });

    it('2E: should accurately compute fee collection percentage (paid / installment) * 100', async () => {
      const backupPayments = new Map(prisma.mockStore.payments);
      const backupInstallments = new Map(prisma.mockStore.feeInstallments);
      prisma.mockStore.payments.clear();
      prisma.mockStore.feeInstallments.clear();

      try {
        // Total installment = 100000, Total paid = 45000 -> 45.00%
        prisma.mockStore.feeInstallments.set('inst1', { net_amount: 60000 });
        prisma.mockStore.feeInstallments.set('inst2', { net_amount: 40000 });
        prisma.mockStore.payments.set('pay1', { status: 'SUCCESS', amount: 25000 });
        prisma.mockStore.payments.set('pay2', { status: 'SUCCESS', amount: 20000 });
        prisma.mockStore.payments.set('pay3', { status: 'FAILED', amount: 50000 }); // Ignored

        const metrics = await pulseService.getMetrics();
        expect(metrics.feeCollectionRate).toBe(45);
      } finally {
        for (const [k, v] of backupPayments.entries()) {
          prisma.mockStore.payments.set(k, v);
        }
        for (const [k, v] of backupInstallments.entries()) {
          prisma.mockStore.feeInstallments.set(k, v);
        }
      }
    });
  });

  describe('3. Auth Refresh Token Rejection & Privilege Isolation', () => {
    it('3A: should reject refresh token for non-existent user with UnauthorizedException', async () => {
      const token = jwt.sign(
        { sub: 'usr_non_existent_ghost_99999', role: 'PARENT' },
        process.env.JWT_SECRET || 'bomis_jwt_secret_sambalpur_2026_dev_key_min32'
      );

      await expect(authService.rotateRefreshToken(token)).rejects.toThrow(
        UnauthorizedException
      );
    });

    it('3B: should verify non-existent user refresh NEVER falls back to admin', async () => {
      const ghostToken = jwt.sign(
        { sub: 'usr_attacker_fake_user', role: 'UNKNOWN' },
        process.env.JWT_SECRET || 'bomis_jwt_secret_sambalpur_2026_dev_key_min32'
      );

      let thrownError: any = null;
      try {
        await authService.rotateRefreshToken(ghostToken);
      } catch (err) {
        thrownError = err;
      }

      expect(thrownError).toBeInstanceOf(UnauthorizedException);
      expect(thrownError.message).toMatch(/Invalid or expired refresh token|User associated with refresh token does not exist/i);
    });

    it('3C: should reject expired refresh token', async () => {
      const expiredToken = jwt.sign(
        { sub: SEED_IDS.USER_ADMIN, exp: Math.floor(Date.now() / 1000) - 3600 },
        process.env.JWT_SECRET || 'bomis_jwt_secret_sambalpur_2026_dev_key_min32'
      );

      await expect(authService.rotateRefreshToken(expiredToken)).rejects.toThrow(
        UnauthorizedException
      );
    });

    it('3D: should reject forged signature refresh token', async () => {
      const forgedToken = jwt.sign(
        { sub: SEED_IDS.USER_ADMIN },
        'wrong_attacker_secret_key_1234567890'
      );

      await expect(authService.rotateRefreshToken(forgedToken)).rejects.toThrow(
        UnauthorizedException
      );
    });

    it('3E: should reject missing refresh token with BadRequestException', async () => {
      await expect(authService.rotateRefreshToken('')).rejects.toThrow(
        BadRequestException
      );
    });
  });

  describe('4. Sibling Privacy & Zero Cross-Tenant Data Leakage', () => {
    it('4A: should return legitimate linked children for Parent Patel', async () => {
      const siblings = await peopleService.getLinkedSiblings({ id: SEED_IDS.USER_PARENT_PATEL });
      expect(Array.isArray(siblings)).toBe(true);
      expect(siblings.length).toBeGreaterThanOrEqual(2);
      const studentNames = siblings.map((s) => s.firstName);
      expect(studentNames).toContain('Aarav');
      expect(studentNames).toContain('Ananya');
    });

    it('4B: should strictly return empty array [] for unlinked guardian', async () => {
      const siblings = await peopleService.getLinkedSiblings({ id: 'usr_random_unlinked_guardian_xyz' });
      expect(siblings).toEqual([]);
      expect(siblings.length).toBe(0);
    });

    it('4C: should verify zero leakage of Patel family children to unlinked guardian', async () => {
      const siblings = await peopleService.getLinkedSiblings({ id: 'usr_random_attacker_guardian' });
      const leakedAarav = siblings.find((s) => s.firstName === 'Aarav');
      const leakedAnanya = siblings.find((s) => s.firstName === 'Ananya');
      expect(leakedAarav).toBeUndefined();
      expect(leakedAnanya).toBeUndefined();
    });

    it('4D: should return empty array [] when user is null or undefined', async () => {
      expect(await peopleService.getLinkedSiblings(null as any)).toEqual([]);
      expect(await peopleService.getLinkedSiblings(undefined as any)).toEqual([]);
      expect(await peopleService.getLinkedSiblings({} as any)).toEqual([]);
    });

    it('4E: should return empty array [] for guardian registered without students in studentGuardians', async () => {
      const orphanGuardianId = 'grd_orphan_test';
      const orphanUserId = 'usr_orphan_test';
      prisma.mockStore.guardians.set(orphanGuardianId, {
        id: orphanGuardianId,
        user_id: orphanUserId,
        first_name: 'Orphan',
        last_name: 'Guardian',
      });

      try {
        const siblings = await peopleService.getLinkedSiblings({ id: orphanUserId });
        expect(siblings).toEqual([]);
      } finally {
        prisma.mockStore.guardians.delete(orphanGuardianId);
      }
    });
  });

  describe('5. Razorpay HMAC Webhook Cryptography & Mandatory Idempotency', () => {
    it('5A: should succeed with authentic HMAC-SHA256 signature', async () => {
      const secret = process.env.RAZORPAY_WEBHOOK_SECRET || 'bomis_razorpay_secret_sambalpur_2026';
      const payload = {
        event: 'payment.captured',
        payload: {
          payment: {
            entity: {
              id: 'pay_stress_test_valid',
              order_id: 'order_stress_001',
              amount: 1500000,
              currency: 'INR',
              status: 'captured',
            },
          },
        },
      };

      const validSignature = crypto
        .createHmac('sha256', secret)
        .update(JSON.stringify(payload))
        .digest('hex');

      const result = await feesService.processWebhook(payload, validSignature);
      expect(result.processed).toBe(true);
      expect(result.paymentId).toBe('pay_stress_test_valid');
    });

    it('5B: should reject legacy bypass signature test_hmac_sha256_mock_signature', async () => {
      const payload = {
        event: 'payment.captured',
        payload: {
          payment: {
            entity: {
              id: 'pay_bypass_attack',
              order_id: 'order_bypass_999',
              amount: 100000,
            },
          },
        },
      };

      await expect(
        feesService.processWebhook(payload, 'test_hmac_sha256_mock_signature')
      ).rejects.toThrow(BadRequestException);
    });

    it('5C: should reject forged / tampered HMAC signature', async () => {
      const payload = { event: 'payment.captured' };
      await expect(
        feesService.processWebhook(payload, 'deadbeef1234567890abcdef')
      ).rejects.toThrow(BadRequestException);
    });

    it('5D: should reject payment order creation if idempotency-key is missing', async () => {
      await expect(
        feesService.createRazorpayOrder({
          studentId: 'stu_grade5a_001',
          installmentNumber: 1,
          amountPaise: 1650000,
        })
      ).rejects.toThrow(BadRequestException);
    });

    it('5E: should return cached order on identical idempotency-key replay', async () => {
      const idempotencyKey = 'idem_key_stress_test_unique_42';
      const orderPayload = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 1,
        amountPaise: 1650000,
      };

      const firstOrder = await feesService.createRazorpayOrder(orderPayload, idempotencyKey);
      expect(firstOrder.orderId).toBeDefined();

      const replayOrder = await feesService.createRazorpayOrder(orderPayload, idempotencyKey);
      expect(replayOrder.orderId).toBe(firstOrder.orderId);
    });
  });
});
