import {
  Controller,
  Get,
  Post,
  Body,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UserRole } from '@bomis/shared';
import { SafetyService } from './safety.service';
import { Roles } from '../../common/decorators/roles.decorator';
import { Public } from '../../common/decorators/public.decorator';

@ApiTags('Safety & Security')
@ApiBearerAuth()
@Controller('safety')
export class SafetyController {
  constructor(private readonly safetyService: SafetyService) {}

  @Post('visitors')
  @Roles(
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TRANSPORT_STAFF
  )
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create Pre-Approved QR Visitor Pass' })
  createVisitorPass(@Body() body: any) {
    return this.safetyService.createVisitorPass(body);
  }

  @Get('visitors')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL)
  @ApiOperation({ summary: 'List Visitor Passes' })
  getVisitorPasses() {
    return this.safetyService.getVisitorPasses();
  }

  @Post('pickup/authorize')
  @Roles(
    UserRole.PARENT,
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL
  )
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Issue / Generate Child Pickup Authorization OTP for Parent' })
  generatePickupAuth(@Body() body: any) {
    return this.safetyService.generatePickupAuthorization(
      body?.studentId,
      body?.guardianId,
      body?.otp
    );
  }

  @Post('pickup/verify')
  @Roles(
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TRANSPORT_STAFF
  )
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Verify Child Pickup OTP / Dynamic QR' })
  verifyPickup(@Body() body: any) {
    return this.safetyService.verifyChildPickup(body);
  }

  @Public()
  @Post('incidents/anonymous')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Submit Zero-Log Anonymous Anti-Bullying Incident' })
  recordAnonymousIncident(@Body() body: any) {
    return this.safetyService.recordAnonymousIncident(body);
  }
}
