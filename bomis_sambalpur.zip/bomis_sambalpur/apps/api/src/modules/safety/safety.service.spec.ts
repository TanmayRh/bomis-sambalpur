import { Test, TestingModule } from '@nestjs/testing';
import { SafetyService } from './safety.service';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';

describe('SafetyService Unit Tests', () => {
  let service: SafetyService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SafetyService,
        PrismaService,
        MockStoreService,
        MockRedisService,
      ],
    }).compile();

    service = module.get<SafetyService>(SafetyService);
    const prisma = module.get<PrismaService>(PrismaService);
    prisma.isMock = true;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('createVisitorPass', () => {
    it('should generate a time-limited QR visitor pass for campus entry', async () => {
      const payload = {
        visitorName: 'Ramesh Sharma',
        visitorPhone: '+919988776655',
        purpose: 'PTM Meeting with Grade 5 Teacher',
        hostStaffId: 'usr_teacher_g5a_001',
        expectedDate: '2026-10-17',
      };

      const result = await service.createVisitorPass(payload);
      expect(result.passId).toBeDefined();
      expect(result.qrCodeData).toContain('BOMIS:PASS:');
      expect(result.status).toBe('PRE_APPROVED');
      expect(result.visitorName).toBe('Ramesh Sharma');
    });

    it('should reject visitor pass if required fields are missing', async () => {
      await expect(
        service.createVisitorPass({
          visitorName: '',
          visitorPhone: '',
          purpose: '',
          hostStaffId: '',
          expectedDate: '',
        })
      ).rejects.toThrow();
    });
  });

  describe('verifyChildPickup', () => {
    it('should verify dismissal authorization using valid active stored 6-digit OTP', async () => {
      const payload = {
        studentId: 'stu_grade5a_001',
        pickupOtp: '482910',
        gateNumber: 'GATE_1',
      };

      const result = await service.verifyChildPickup(payload);
      expect(result.authorized).toBe(true);
      expect(result.studentId).toBeDefined();
      expect(result.guardianId).toBeDefined();
      expect(result.gateNumber).toBe('GATE_1');
      expect(result.dismissalTime).toBeDefined();
      expect(result.message).toContain('dismissal authorized');
    });

    it('should reject dismissal when pickup OTP does not match stored OTP', async () => {
      // Re-seed or create fresh active authorization
      await service.generatePickupAuthorization('stu_grade5a_001', 'grd_parent_001', '654321');

      const result = await service.verifyChildPickup({
        studentId: 'stu_grade5a_001',
        pickupOtp: '000000', // Wrong OTP
        gateNumber: 'GATE_1',
      });

      expect(result.authorized).toBe(false);
      expect(result.message).toBe('Invalid pickup OTP');
    });

    it('should reject dismissal when no active authorization exists for student', async () => {
      const result = await service.verifyChildPickup({
        studentId: 'stu_unknown_student_999',
        pickupOtp: '123456',
        gateNumber: 'GATE_2',
      });

      expect(result.authorized).toBe(false);
      expect(result.message).toContain('No active pickup authorization');
    });

    it('should reject pickup OTP if length is not 6 digits', async () => {
      await expect(
        service.verifyChildPickup({
          studentId: 'stu_grade5a_001',
          pickupOtp: '123', // Invalid length
          gateNumber: 'GATE_1',
        })
      ).rejects.toThrow();
    });

    it('should dynamically issue new pickup OTP and verify child release', async () => {
      const generated = await service.generatePickupAuthorization(
        'stu_grade5a_001',
        'grd_parent_001',
        '789012'
      );
      expect(generated.otp).toBe('789012');
      expect(generated.status).toBe('ACTIVE');

      const verifyResult = await service.verifyChildPickup({
        studentId: 'stu_grade5a_001',
        pickupOtp: '789012',
        gateNumber: 'GATE_3',
      });
      expect(verifyResult.authorized).toBe(true);
      expect(verifyResult.gateNumber).toBe('GATE_3');
    });

    it('should reject dismissal when pickup OTP has already been used (single-use OTP guarantee)', async () => {
      // 1. Issue dynamic single-use authorization
      await service.generatePickupAuthorization('stu_grade5a_001', 'grd_parent_001', '847291');

      // 2. First verification attempt: MUST SUCCEED
      const firstResult = await service.verifyChildPickup({
        studentId: 'stu_grade5a_001',
        pickupOtp: '847291',
        gateNumber: 'GATE_1',
      });
      expect(firstResult.authorized).toBe(true);

      // 3. Second verification attempt with identical OTP: MUST BE REJECTED
      const secondResult = await service.verifyChildPickup({
        studentId: 'stu_grade5a_001',
        pickupOtp: '847291',
        gateNumber: 'GATE_2',
      });
      expect(secondResult.authorized).toBe(false);
      expect(secondResult.message).toMatch(/already been used/i);
    });
  });

  describe('recordAnonymousIncident (Zero-Log Mandate)', () => {
    it('should record anti-bullying incident without saving user identity or IP address', async () => {
      const payload = {
        incidentType: 'BULLYING',
        grade: 7,
        location: 'Senior Playground',
        description: 'Witnessed verbal intimidation during afternoon recess.',
        timestamp: '2026-10-17T11:00:00Z',
      };

      const result = await service.recordAnonymousIncident(payload);
      expect(result.trackingCode).toMatch(/^INC-\d{6}$/);
      expect(result.status).toBe('RECEIVED');
    });

    it('should reject incident with description shorter than 10 characters', async () => {
      await expect(
        service.recordAnonymousIncident({
          incidentType: 'BULLYING',
          grade: 7,
          location: 'Playground',
          description: 'Too short',
        })
      ).rejects.toThrow();
    });
  });
});
