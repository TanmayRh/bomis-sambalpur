import { Test, TestingModule } from '@nestjs/testing';
import { PulseService } from './pulse.service';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';

describe('PulseService Unit Tests', () => {
  let service: PulseService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        PulseService,
        PrismaService,
        MockStoreService,
        MockRedisService,
      ],
    }).compile();

    service = module.get<PulseService>(PulseService);
    const prisma = module.get<PrismaService>(PrismaService);
    prisma.isMock = true;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getMetrics', () => {
    it("should return Principal's real-time Pulse KPIs", async () => {
      const metrics = await service.getMetrics();
      expect(metrics).toBeDefined();
      expect(metrics.attendanceRate).toBeGreaterThan(0);
      expect(metrics.feeCollectionRate).toBeGreaterThan(0);
      expect(metrics.totalStudents).toBeGreaterThanOrEqual(1);
      expect(metrics.activeBuses).toBeGreaterThanOrEqual(4);
      expect(metrics.systemHealth).toBe('HEALTHY');
      expect(metrics.lastUpdated).toBeDefined();
    });

    it('should calculate dynamic rates from attendance records correctly', async () => {
      const metrics = await service.getMetrics();
      expect(metrics.attendanceRate).toBeLessThanOrEqual(100);
      expect(metrics.feeCollectionRate).toBeLessThanOrEqual(100);
    });
  });
});

