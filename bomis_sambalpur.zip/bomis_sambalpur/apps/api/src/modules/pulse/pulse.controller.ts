import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UserRole } from '@bomis/shared';
import { PulseService } from './pulse.service';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('Principal Pulse Dashboard')
@ApiBearerAuth()
@Controller('pulse')
export class PulseController {
  constructor(private readonly pulseService: PulseService) {}

  @Get('metrics')
  @Roles(UserRole.PRINCIPAL, UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: "Get Principal's real-time Pulse dashboard KPIs" })
  getMetrics() {
    return this.pulseService.getMetrics();
  }
}
