import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../database/prisma.service';

@Injectable()
export class PulseService {
  private readonly logger = new Logger(PulseService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Principal's real-time Pulse dashboard KPIs
   * Dynamically aggregates attendance rates and fee collection metrics
   */
  async getMetrics() {
    let studentCount = 240; // Default 8 grades x 30 students
    let busCount = 4;
    let incidentCount = 0;
    let attendanceRate = 0;
    let feeCollectionRate = 0;

    if (this.prisma.isMock) {
      studentCount = this.prisma.mockStore.students.size || 240;
      busCount = this.prisma.mockStore.vehicles.size || 4;
      incidentCount = Array.from(this.prisma.mockStore.incidents.values()).filter(
        (i) => i.status === 'PENDING_REVIEW'
      ).length;

      // Dynamic Attendance Rate calculation from mockStore
      const attendanceRecords = Array.from(this.prisma.mockStore.attendance.values());
      if (attendanceRecords.length > 0) {
        let presentDays = 0;
        let halfDays = 0;
        let absentDays = 0;

        for (const rec of attendanceRecords) {
          const status = String(rec.status).toUpperCase();
          if (status === 'PRESENT') {
            presentDays++;
          } else if (status === 'HALF_DAY') {
            halfDays++;
          } else if (status === 'ABSENT') {
            absentDays++;
          }
        }

        const totalWorkingDays = presentDays + halfDays + absentDays;
        attendanceRate =
          totalWorkingDays > 0
            ? Number((((presentDays + 0.5 * halfDays) / totalWorkingDays) * 100).toFixed(2))
            : 0;
      }

      // Dynamic Fee Collection Rate calculation from mockStore
      const payments = Array.from(this.prisma.mockStore.payments.values()).filter(
        (p) => p.status === 'SUCCESS' || p.status === 'captured'
      );
      const installments = Array.from(this.prisma.mockStore.feeInstallments.values());

      const totalPaidAmount = payments.reduce(
        (sum, p) => sum + (Number(p.amount) || 0),
        0
      );
      const totalInstallmentAmount = installments.reduce(
        (sum, inst) => sum + (Number(inst.amount) || Number(inst.net_amount) || 0),
        0
      );

      feeCollectionRate =
        totalInstallmentAmount > 0
          ? Number(((totalPaidAmount / totalInstallmentAmount) * 100).toFixed(2))
          : 0;
    } else {
      // Live PostgreSQL mode aggregation
      try {
        studentCount = await this.prisma.student.count({ where: { deleted_at: null } });
        busCount = await this.prisma.vehicle.count();

        const attendanceRecords = await this.prisma.attendance.findMany({
          where: { deleted_at: null },
          select: { status: true },
        });

        if (attendanceRecords.length > 0) {
          let presentDays = 0;
          let halfDays = 0;
          let absentDays = 0;

          for (const rec of attendanceRecords) {
            const status = String(rec.status).toUpperCase();
            if (status === 'PRESENT') {
              presentDays++;
            } else if (status === 'HALF_DAY') {
              halfDays++;
            } else if (status === 'ABSENT') {
              absentDays++;
            }
          }

          const totalWorkingDays = presentDays + halfDays + absentDays;
          attendanceRate =
            totalWorkingDays > 0
              ? Number((((presentDays + 0.5 * halfDays) / totalWorkingDays) * 100).toFixed(2))
              : 0;
        }

        const payments = await this.prisma.payment.findMany({
          where: { payment_status: 'SUCCESS', deleted_at: null },
          select: { amount: true },
        });

        const installments = await this.prisma.feeInstallment.findMany({
          where: { deleted_at: null },
          select: { net_amount: true, base_amount: true },
        });

        const totalPaidAmount = payments.reduce(
          (sum, p) => sum + Number(p.amount || 0),
          0
        );
        const totalInstallmentAmount = installments.reduce(
          (sum, inst) => sum + (Number(inst.net_amount) || Number(inst.base_amount) || 0),
          0
        );

        feeCollectionRate =
          totalInstallmentAmount > 0
            ? Number(((totalPaidAmount / totalInstallmentAmount) * 100).toFixed(2))
            : 0;
      } catch (err: any) {
        this.logger.warn(`PostgreSQL pulse metric aggregation query encountered: ${err.message}`);
      }
    }

    this.logger.log(`Aggregated Principal Pulse Metrics: Attendance ${attendanceRate}%, Fees ${feeCollectionRate}%`);

    return {
      attendanceRate,
      feeCollectionRate,
      totalStudents: studentCount,
      activeBuses: busCount,
      safetyIncidentsPending: incidentCount,
      academicYear: '2026-2027',
      systemHealth: 'HEALTHY',
      lastUpdated: new Date().toISOString(),
    };
  }
}
