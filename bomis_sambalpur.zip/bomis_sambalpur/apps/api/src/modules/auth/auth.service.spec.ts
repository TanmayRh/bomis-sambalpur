import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from './auth.service';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';

describe('AuthService Unit Tests', () => {
  let service: AuthService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        PrismaService,
        MockStoreService,
        MockRedisService,
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    const prisma = module.get<PrismaService>(PrismaService);
    prisma.isMock = true;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('sendOtp', () => {
    it('should dispatch 6-digit OTP with 300s TTL for valid Indian mobile number', async () => {
      const result = await service.sendOtp('+919876543210');
      expect(result.expiresInSeconds).toBe(300);
      expect(result.message).toBe('OTP sent successfully');
    });

    it('should reject invalid mobile number format with BadRequestException', async () => {
      await expect(service.sendOtp('12345')).rejects.toThrow();
    });
  });

  describe('verifyOtp', () => {
    it('should verify OTP "123456" and issue JWT access and refresh token pair', async () => {
      await service.sendOtp('+919876543210');
      const authResult = await service.verifyOtp('+919876543210', '123456');

      expect(authResult.accessToken).toBeDefined();
      expect(authResult.refreshToken).toBeDefined();
      expect(authResult.user).toBeDefined();
      expect(authResult.user.role).toBe('PARENT');
    });

    it('should reject incorrect OTP with UnauthorizedException', async () => {
      await expect(
        service.verifyOtp('+919876543210', '999999')
      ).rejects.toThrow();
    });
  });

  describe('loginStaff', () => {
    it('should authenticate admin staff with correct email and password', async () => {
      const result = await service.loginStaff(
        'admin@bomis-sambalpur.edu.in',
        'Admin@Sambalpur2026'
      );

      expect(result.accessToken).toBeDefined();
      expect(result.refreshToken).toBeDefined();
      expect(result.user.role).toBe('ADMIN');
      expect(result.user.email).toBe('admin@bomis-sambalpur.edu.in');
    });

    it('should reject invalid password with UnauthorizedException', async () => {
      await expect(
        service.loginStaff('admin@bomis-sambalpur.edu.in', 'WrongPassword123')
      ).rejects.toThrow();
    });
  });

  describe('rotateRefreshToken', () => {
    it('should exchange active refresh token for a new access token', async () => {
      const login = await service.loginStaff(
        'admin@bomis-sambalpur.edu.in',
        'Admin@Sambalpur2026'
      );

      const rotated = await service.rotateRefreshToken(login.refreshToken);
      expect(rotated.accessToken).toBeDefined();
      expect(rotated.refreshToken).toBeDefined();
    });

    it('should reject refresh token with UnauthorizedException when user does not exist', async () => {
      const jwt = require('jsonwebtoken');
      const nonExistentUserToken = jwt.sign(
        { sub: 'usr_non_existent_99999', role: 'PARENT' },
        process.env.JWT_SECRET || 'bomis_jwt_secret_sambalpur_2026_dev_key_min32'
      );
      await expect(service.rotateRefreshToken(nonExistentUserToken)).rejects.toThrow();
    });
  });

  describe('logout', () => {
    it('should revoke session successfully', async () => {
      const result = await service.logout({ id: 'u1' }, 'mock-refresh-token');
      expect(result.message).toContain('Session revoked');
    });
  });
});
