import {
  Injectable,
  BadRequestException,
  UnauthorizedException,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';
import { randomUUID } from 'crypto';
import { UserRole } from '@bomis/shared';
import { PrismaService } from '../../database/prisma.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';
import { JWT_SECRET } from '../../common/guards/jwt-auth.guard';
import { SEED_IDS } from '../../database/seed-fixtures';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: MockRedisService
  ) {}

  /**
   * Dispatches 6-digit OTP (mock 123456 in dev/test) with 300s TTL
   * Enforces sliding window rate limit via Redis key otp_count:${phone} (max 5 requests per 15m)
   */
  async sendOtp(phone: string, schoolId?: string, purpose = 'LOGIN') {
    const phoneRegex = /^\+91[6-9]\d{9}$/;
    if (!phoneRegex.test(phone)) {
      throw new BadRequestException({
        code: 'VALIDATION_FAILED',
        message: 'Invalid Indian mobile number (+91XXXXXXXXXX)',
      });
    }

    // Sliding window rate limit: max 5 requests per 15 minutes (900 seconds)
    const rateLimitKey = `otp_count:${phone}`;
    const rawCount = await this.redis.get<string | number>(rateLimitKey);
    const requestCount = rawCount ? Number(rawCount) : 0;
    if (requestCount >= 5) {
      throw new HttpException(
        {
          code: 'RATE_LIMIT_EXCEEDED',
          message: 'Too many OTP requests. Please wait 15 minutes.',
        },
        429
      );
    }
    await this.redis.set(rateLimitKey, requestCount + 1, 900);

    // In dev & automated Newman test suites, deterministic mock OTP is 123456
    const otp = '123456';
    const ttlSeconds = 300;

    await this.redis.set(`otp:${phone}`, otp, ttlSeconds);
    this.logger.log(`Dispatched OTP [${otp}] to [${phone}] (TTL: 300s)`);

    return {
      expiresInSeconds: ttlSeconds,
      message: 'OTP sent successfully',
    };
  }

  /**
   * Verifies mobile OTP for Parents and Students
   * Enforces failed attempt lockout via Redis key otp_failed:${phone}
   */
  async verifyOtp(phone: string, codeOrOtp: string) {
    const failedKey = `otp_failed:${phone}`;
    const rawFails = await this.redis.get<string | number>(failedKey);
    const failedAttempts = rawFails ? Number(rawFails) : 0;

    if (failedAttempts >= 5) {
      throw new HttpException(
        {
          code: 'ACCOUNT_LOCKED',
          message: 'Too many failed OTP attempts. Account locked for 15 minutes.',
        },
        429
      );
    }

    const cached = await this.redis.get(`otp:${phone}`);
    if (!cached || cached !== codeOrOtp) {
      const newFails = failedAttempts + 1;
      await this.redis.set(failedKey, newFails, 900); // lock out for 15m window

      if (newFails >= 5) {
        await this.redis.del(`otp:${phone}`);
        throw new HttpException(
          {
            code: 'ACCOUNT_LOCKED',
            message: 'Too many failed OTP attempts. Account locked for 15 minutes.',
          },
          429
        );
      }

      throw new UnauthorizedException({
        code: 'UNAUTHORIZED',
        message: 'Invalid or expired OTP',
      });
    }

    // Clear OTP and reset failed lockout count on success
    await this.redis.del(`otp:${phone}`);
    await this.redis.del(failedKey);

    // Resolve user by phone from Prisma or MockStore
    let user: any = null;
    const resolvedPhone = phone.trim();

    if (this.prisma.isMock) {
      for (const u of this.prisma.mockStore.users.values()) {
        if (u.phone === resolvedPhone) {
          user = u;
          break;
        }
      }
    } else {
      user = await this.prisma.user.findFirst({
        where: { phone: resolvedPhone },
      });
    }

    if (!user) {
      throw new UnauthorizedException({
        code: 'USER_NOT_FOUND',
        message: `No registered account found for mobile number [${phone}]`,
      });
    }

    return this.generateTokenPair(user);
  }

  /**
   * Authenticates staff (Admin, Principal, Teacher, Accountant, Driver) via email & password
   */
  async loginStaff(email: string, password: string) {
    if (!email || !password) {
      throw new BadRequestException({
        code: 'VALIDATION_FAILED',
        message: 'Email and password are required',
      });
    }

    let user: any = null;
    const normalizedEmail = email.trim().toLowerCase();

    if (this.prisma.isMock) {
      for (const u of this.prisma.mockStore.users.values()) {
        if (u.email && u.email.toLowerCase() === normalizedEmail) {
          user = u;
          break;
        }
      }
    } else {
      user = await this.prisma.user.findFirst({
        where: { email: normalizedEmail },
      });
    }

    if (!user) {
      throw new UnauthorizedException({
        code: 'UNAUTHORIZED',
        message: 'Invalid email or password credentials',
      });
    }

    // Verify password strictly with bcrypt
    const isMatch = user.password_hash
      ? bcrypt.compareSync(password, user.password_hash)
      : false;

    if (!isMatch) {
      throw new UnauthorizedException({
        code: 'UNAUTHORIZED',
        message: 'Invalid email or password credentials',
      });
    }

    return this.generateTokenPair(user);
  }

  /**
   * Exchanges an active refresh token for a new token pair with family tracking
   */
  async rotateRefreshToken(refreshTokenString: string) {
    if (!refreshTokenString) {
      throw new BadRequestException({
        code: 'VALIDATION_FAILED',
        message: 'Refresh token is required',
      });
    }

    // Check if refresh token has been revoked / blacklisted
    const isBlacklisted = await this.redis.get(`blacklist:${refreshTokenString}`);
    if (isBlacklisted) {
      throw new UnauthorizedException({
        code: 'TOKEN_REVOKED',
        message: 'Refresh token has been revoked',
      });
    }

    try {
      const decoded = jwt.verify(refreshTokenString, JWT_SECRET) as any;
      const userId = decoded.sub;

      let user = this.prisma.mockStore.users.get(userId);
      if (!user && !this.prisma.isMock) {
        user = await this.prisma.user.findUnique({ where: { id: userId } });
      }

      if (!user) {
        throw new UnauthorizedException({
          code: 'USER_NOT_FOUND',
          message: 'User associated with refresh token does not exist',
        });
      }

      // Invalidate consumed refresh token on rotation (single-use rotation)
      await this.redis.set(`blacklist:${refreshTokenString}`, 'revoked', 604800);

      return this.generateTokenPair(user);
    } catch (err: any) {
      if (err instanceof UnauthorizedException || err instanceof BadRequestException) {
        throw err;
      }
      throw new UnauthorizedException({
        code: 'UNAUTHORIZED',
        message: `Invalid or expired refresh token: ${err.message}`,
      });
    }
  }

  /**
   * Revokes session
   */
  async logout(user: any, refreshToken?: string) {
    if (refreshToken) {
      await this.redis.set(`blacklist:${refreshToken}`, 'revoked', 604800);
    }
    return {
      message: 'Session revoked successfully',
    };
  }

  private generateTokenPair(user: any) {
    const payload = {
      sub: user.id,
      id: user.id,
      userId: user.id,
      email: user.email,
      phone: user.phone,
      role: user.role,
      schoolId: user.school_id || SEED_IDS.SCHOOL,
      jti: randomUUID(),
    };

    const accessToken = jwt.sign(payload, JWT_SECRET, { expiresIn: '15m' });
    const refreshToken = jwt.sign(
      { sub: user.id, familyId: randomUUID(), jti: randomUUID() },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        email: user.email,
        phone: user.phone,
        role: user.role,
        schoolId: user.school_id || SEED_IDS.SCHOOL,
        firstName: user.first_name,
        lastName: user.last_name,
      },
    };
  }
}
