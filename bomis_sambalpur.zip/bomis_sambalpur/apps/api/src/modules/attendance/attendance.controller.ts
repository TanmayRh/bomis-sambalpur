import {
  Controller,
  Get,
  Post,
  Param,
  Query,
  Body,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UserRole } from '@bomis/shared';
import { AttendanceService } from './attendance.service';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('Attendance & Leaves')
@ApiBearerAuth()
@Controller('attendance')
export class AttendanceController {
  constructor(private readonly attendanceService: AttendanceService) {}

  @Post()
  @Roles(UserRole.TEACHER, UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Rapid Classroom Attendance Batch (<10s Submission)' })
  recordRapidBatch(@Body() body: any) {
    return this.attendanceService.recordRapidBatch(body);
  }

  @Post('batch')
  @Roles(UserRole.TEACHER, UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Granular attendance batch marking' })
  recordBatch(@Body() body: any) {
    return this.attendanceService.recordBatch(body);
  }

  @Get('students/:id')
  @Roles(
    UserRole.PARENT,
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TEACHER,
    UserRole.STUDENT
  )
  @ApiOperation({ summary: 'Get student monthly attendance percentage and statistics' })
  getStudentStats(
    @Param('id') studentId: string,
    @Query('month') month?: number,
    @Query('year') year?: number
  ) {
    return this.attendanceService.getStudentMonthlyStats(studentId, month, year);
  }

  @Get()
  @Roles(
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TEACHER,
    UserRole.PARENT
  )
  @ApiOperation({ summary: 'Query attendance records' })
  queryAttendance(@Query() query: any) {
    return this.attendanceService.queryAttendance(query);
  }

  @Post('leaves')
  @Roles(
    UserRole.TEACHER,
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.PARENT,
    UserRole.STUDENT
  )
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Submit staff or student leave application' })
  applyLeave(@Body() body: any) {
    return this.attendanceService.applyLeave(body);
  }
}
