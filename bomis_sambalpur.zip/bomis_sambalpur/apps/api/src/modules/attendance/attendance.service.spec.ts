import { Test, TestingModule } from '@nestjs/testing';
import { AttendanceService } from './attendance.service';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';
import { SEED_IDS } from '../../database/seed-fixtures';

describe('AttendanceService Unit Tests', () => {
  let service: AttendanceService;
  let mockStore: MockStoreService;
  let prisma: PrismaService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AttendanceService,
        PrismaService,
        MockStoreService,
        MockRedisService,
      ],
    }).compile();

    service = module.get<AttendanceService>(AttendanceService);
    mockStore = module.get<MockStoreService>(MockStoreService);
    prisma = module.get<PrismaService>(PrismaService);
    prisma.isMock = true;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('recordRapidBatch', () => {
    it('should record full classroom attendance with exception array in rapid time', async () => {
      const payload = {
        date: '2026-10-17',
        classId: 'cls_grade_5',
        sectionId: 'sec_grade_5_a',
        defaultStatus: 'PRESENT',
        exceptions: [
          {
            studentId: 'stu_grade5a_001',
            status: 'ABSENT',
            remarks: 'Medical leave reported by parent',
          },
        ],
      };

      const result = await service.recordRapidBatch(payload);
      expect(result).toBeDefined();
      expect(result.processedCount).toBeGreaterThan(0);
      expect(result.absentCount).toBe(1);
      expect(result.status).toBe('RECORDED');
    });

    it('should reject submission with missing date', async () => {
      await expect(
        service.recordRapidBatch({ date: '' } as any)
      ).rejects.toThrow();
    });
  });

  describe('Attendance Percentage Formula', () => {
    it('should calculate monthly attendance percentage using CBSE formula: ((Present + 0.5 * HalfDay) / WorkingDays) * 100', async () => {
      const stats = await service.getStudentMonthlyStats('stu_grade5a_001', 10, 2026);
      expect(stats).toBeDefined();
      expect(stats.studentId).toBe(SEED_IDS.STUDENT_AARAV);
      expect(stats.totalWorkingDays).toBe(22);
      expect(stats.presentDays).toBe(20);
      expect(stats.halfDays).toBe(1);

      // Expected calculation: ((20 + 0.5 * 1) / 22) * 100 = 93.18%
      const expectedPercentage = Number((((20 + 0.5) / 22) * 100).toFixed(2));
      expect(stats.percentage).toBe(expectedPercentage);
      expect(stats.lowAttendanceAlert).toBe(false);
      expect(stats.cbseCompliant).toBe(true);
    });

    it('should flag low attendance alert when percentage falls below 75% for chronically absent student', async () => {
      // Seed authentic low-attendance records for Student Ananya (12 Present, 8 Absent, 0 Half-day = 20 days -> 60%)
      for (let day = 1; day <= 20; day++) {
        const dayStr = String(day).padStart(2, '0');
        const dateStr = `2026-10-${dayStr}`;
        const status = day <= 12 ? 'PRESENT' : 'ABSENT';

        mockStore.attendance.set(`${SEED_IDS.STUDENT_ANANYA}:${dateStr}`, {
          id: `att_ananya_${dayStr}`,
          school_id: SEED_IDS.SCHOOL,
          student_id: SEED_IDS.STUDENT_ANANYA,
          date: dateStr,
          status,
          recorded_at: new Date(),
        });
      }

      const lowStats = await service.getStudentMonthlyStats(SEED_IDS.STUDENT_ANANYA, 10, 2026);
      expect(lowStats).toBeDefined();
      expect(lowStats.totalWorkingDays).toBe(20);
      expect(lowStats.presentDays).toBe(12);
      expect(lowStats.halfDays).toBe(0);
      expect(lowStats.absentDays).toBe(8);
      expect(lowStats.percentage).toBe(60);
      expect(lowStats.lowAttendanceAlert).toBe(true);
      expect(lowStats.cbseCompliant).toBe(false);
    });

    it('should return zero stats and compliant status when no records exist for month', async () => {
      const emptyStats = await service.getStudentMonthlyStats(SEED_IDS.STUDENT_AARAV, 5, 2026);
      expect(emptyStats.totalWorkingDays).toBe(0);
      expect(emptyStats.presentDays).toBe(0);
      expect(emptyStats.percentage).toBe(0);
      expect(emptyStats.lowAttendanceAlert).toBe(false);
      expect(emptyStats.cbseCompliant).toBe(true);
    });
  });

  describe('recordBatch', () => {
    it('should record granular student-by-student attendance records', async () => {
      const payload = {
        date: '2026-10-18',
        records: [
          { studentId: SEED_IDS.STUDENT_AARAV, status: 'PRESENT' },
          { studentId: SEED_IDS.STUDENT_ANANYA, status: 'PRESENT' },
        ],
      };

      const result = await service.recordBatch(payload);
      expect(result.processedCount).toBe(2);
      expect(result.date).toBe('2026-10-18');
    });
  });

  describe('applyLeave', () => {
    it('should submit leave application with PENDING status', async () => {
      const payload = {
        fromDate: '2026-10-20',
        toDate: '2026-10-22',
        reason: 'Family wedding ceremony',
        leaveType: 'CASUAL',
        studentId: 'stu_grade5a_001',
      };

      const result = await service.applyLeave(payload);
      expect(result.leaveId).toBeDefined();
      expect(result.status).toBe('PENDING');
    });
  });

  describe('syncBatch (Offline Outbox Sync)', () => {
    it('should process offline sync events idempotently', async () => {
      const payload = {
        events: [
          {
            id: 'evt_outbox_001',
            actionType: 'ATTENDANCE_BATCH',
            idempotencyKey: 'idemp-sync-test-001',
            timestamp: Date.now(),
            payload: {
              studentId: 'stu_grade5a_001',
              date: '2026-10-17',
              status: 'PRESENT',
            },
          },
        ],
      };

      const firstSync = await service.syncBatch(payload);
      expect(firstSync.syncedCount).toBe(1);
      expect(firstSync.results[0].status).toBe('SYNCED');

      // Second sync with identical idempotency key should be idempotent
      const secondSync = await service.syncBatch(payload);
      expect(secondSync.results[0].status).toBe('IDEMPOTENT_SKIPPED');
    });
  });
});
