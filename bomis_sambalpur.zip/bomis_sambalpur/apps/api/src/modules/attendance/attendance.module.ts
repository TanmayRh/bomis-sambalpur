import { Module } from '@nestjs/common';
import { AttendanceController } from './attendance.controller';
import { SyncController } from './sync.controller';
import { AttendanceService } from './attendance.service';

@Module({
  controllers: [AttendanceController, SyncController],
  providers: [AttendanceService],
  exports: [AttendanceService],
})
export class AttendanceModule {}
