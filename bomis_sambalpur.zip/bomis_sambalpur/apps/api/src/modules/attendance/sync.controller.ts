import {
  Controller,
  Post,
  Body,
  HttpCode,
  HttpStatus,
  Headers,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UserRole } from '@bomis/shared';
import { AttendanceService } from './attendance.service';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('Offline Sync')
@ApiBearerAuth()
@Controller('sync')
export class SyncController {
  constructor(private readonly attendanceService: AttendanceService) {}

  @Post('batch')
  @Roles(
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.TEACHER,
    UserRole.TRANSPORT_STAFF,
    UserRole.PARENT
  )
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Offline Outbox Batch Synchronization' })
  syncBatch(
    @Body() body: any,
    @Headers('idempotency-key') idempotencyKey?: string
  ) {
    return this.attendanceService.syncBatch(body);
  }
}
