import { Test, TestingModule } from '@nestjs/testing';
import { AdminController } from './admin.controller';
import { AdminService } from './admin.service';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';

describe('AdminController Unit Tests', () => {
  let controller: AdminController;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AdminController],
      providers: [AdminService, PrismaService, MockStoreService, MockRedisService],
    }).compile();

    controller = module.get<AdminController>(AdminController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('getAuditLogs', () => {
    it('should return DPDP audit logs array for authorized staff sorted by timestamp descending', async () => {
      const logs = await controller.getAuditLogs();
      expect(logs).toBeInstanceOf(Array);
      expect(logs.length).toBeGreaterThanOrEqual(2);
      expect(logs[0]).toHaveProperty('action');
      expect(logs[0]).toHaveProperty('schoolId');

      // Verify descending order
      const t0 = new Date(logs[0].created_at || logs[0].timestamp).getTime();
      const t1 = new Date(logs[1].created_at || logs[1].timestamp).getTime();
      expect(t0).toBeGreaterThanOrEqual(t1);
    });

    it('should record a dynamic audit log entry and return it at the head of the trail', async () => {
      const adminService = controller['adminService'];
      const newEntry = await adminService.recordAuditLog({
        action: 'CREATE',
        entityType: 'Student',
        entityId: 'stu_new_001',
        details: 'Admitted new student under RTE quota',
      });

      expect(newEntry.id).toBeDefined();
      expect(newEntry.action).toBe('CREATE');

      const logs = await controller.getAuditLogs();
      expect(logs[0].id).toBe(newEntry.id);
      expect(logs[0].action).toBe('CREATE');
      expect(logs[0].entityType).toBe('Student');
    });
  });
});
