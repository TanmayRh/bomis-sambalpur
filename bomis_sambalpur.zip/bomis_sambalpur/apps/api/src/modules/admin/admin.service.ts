import { Injectable, Logger } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { PrismaService } from '../../database/prisma.service';
import { SEED_IDS } from '../../database/seed-fixtures';

@Injectable()
export class AdminService {
  private readonly logger = new Logger(AdminService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Record a new audit log entry in compliance with DPDP Act 2023
   */
  async recordAuditLog(payload: {
    action: string;
    entityType: string;
    entityId: string;
    userId?: string;
    schoolId?: string;
    details?: string;
    beforeState?: any;
    afterState?: any;
    diff?: any;
    ipAddress?: string;
    userAgent?: string;
  }) {
    const id = `aud-${randomUUID().substring(0, 8)}`;
    const now = new Date();
    const entry = {
      id,
      schoolId: payload.schoolId || SEED_IDS.SCHOOL,
      school_id: payload.schoolId || SEED_IDS.SCHOOL,
      userId: payload.userId || SEED_IDS.USER_ADMIN,
      user_id: payload.userId || SEED_IDS.USER_ADMIN,
      action: payload.action,
      entityType: payload.entityType,
      entity_type: payload.entityType,
      entityId: payload.entityId,
      entity_id: payload.entityId,
      beforeState: payload.beforeState,
      afterState: payload.afterState,
      diff: payload.diff,
      ipAddress: payload.ipAddress,
      userAgent: payload.userAgent,
      details:
        payload.details ||
        `${payload.action} operation on ${payload.entityType} [${payload.entityId}]`,
      timestamp: now.toISOString(),
      created_at: now,
    };

    if (this.prisma.isMock) {
      this.prisma.mockStore.auditLogs.set(id, entry);
    } else {
      await this.prisma.auditLog.create({
        data: {
          id,
          school_id: entry.school_id,
          user_id: entry.user_id,
          action: entry.action as any,
          entity_type: entry.entity_type,
          entity_id: entry.entity_id,
          before_state: payload.beforeState,
          after_state: payload.afterState,
          diff: payload.diff,
          ip_address: payload.ipAddress,
          user_agent: payload.userAgent,
          created_at: now,
        },
      });
    }

    this.logger.log(`Audit log recorded [${id}]: ${entry.action} on ${entry.entityType}`);
    return entry;
  }

  /**
   * DPDP Administrative Audit Trail
   * Queries real audit logs, returning entries sorted by timestamp descending
   */
  async getAuditLogs() {
    this.logger.log('Retrieving DPDP administrative audit logs from store/database');

    if (this.prisma.isMock) {
      const logs = Array.from(this.prisma.mockStore.auditLogs.values()).sort(
        (a, b) =>
          new Date(b.created_at || b.timestamp).getTime() -
          new Date(a.created_at || a.timestamp).getTime()
      );
      return logs;
    }

    const dbLogs = await this.prisma.auditLog.findMany({
      orderBy: { created_at: 'desc' },
      take: 100,
    });

    return dbLogs.map((log) => ({
      id: log.id,
      schoolId: log.school_id,
      school_id: log.school_id,
      userId: log.user_id,
      user_id: log.user_id,
      action: log.action,
      entityType: log.entity_type,
      entity_type: log.entity_type,
      entityId: log.entity_id,
      entity_id: log.entity_id,
      beforeState: log.before_state,
      afterState: log.after_state,
      diff: log.diff,
      ipAddress: log.ip_address,
      userAgent: log.user_agent,
      details: `${log.action} on ${log.entity_type}`,
      timestamp: log.created_at.toISOString(),
      created_at: log.created_at,
    }));
  }
}
