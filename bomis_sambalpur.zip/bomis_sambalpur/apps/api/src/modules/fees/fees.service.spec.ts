import { Test, TestingModule } from '@nestjs/testing';
import * as crypto from 'crypto';
import { FeesService } from './fees.service';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';
import { SEED_IDS } from '../../database/seed-fixtures';

describe('FeesService Unit Tests', () => {
  let service: FeesService;
  let mockStore: MockStoreService;
  let redis: MockRedisService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        FeesService,
        PrismaService,
        MockStoreService,
        MockRedisService,
      ],
    }).compile();

    service = module.get<FeesService>(FeesService);
    mockStore = module.get<MockStoreService>(MockStoreService);
    redis = module.get<MockRedisService>(MockRedisService);
    const prisma = module.get<PrismaService>(PrismaService);
    prisma.isMock = true;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getStructures', () => {
    it('should return fee structures for Grade 5 and Academic Year 2026-2027', async () => {
      const structures = await service.getStructures(5, '2026-2027');
      expect(structures).toBeInstanceOf(Array);
      expect(structures.length).toBeGreaterThanOrEqual(1);

      const tuition = structures.find((s) => s.category.includes('Tuition'));
      expect(tuition).toBeDefined();
      expect(tuition?.totalAmount).toBe(45000);
      expect(tuition?.frequency).toBe('TERM');
    });
  });

  describe('createRazorpayOrder & Idempotency-Key Protection', () => {
    it('should create Razorpay payment order and cache idempotency result', async () => {
      const idempotencyKey = 'idemp-order-test-001';
      const payload = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 2,
        amountPaise: 1650000,
        paymentMethod: 'UPI',
      };

      const order1 = await service.createRazorpayOrder(payload, idempotencyKey);
      expect(order1).toBeDefined();
      expect(order1.razorpayOrderId).toBeDefined();
      expect(order1.amount).toBe(16500);
      expect(order1.currency).toBe('INR');

      // Replay identical request with same idempotency key -> MUST return identical cached order
      const order2 = await service.createRazorpayOrder(payload, idempotencyKey);
      expect(order2.razorpayOrderId).toBe(order1.razorpayOrderId);
    });

    it('should reject same idempotency key with conflicting payload', async () => {
      const idempotencyKey = 'idemp-order-conflict-test';
      const payload1 = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 1,
        amountPaise: 1650000,
        paymentMethod: 'UPI',
      };
      const payload2 = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 2, // Changed installment
        amountPaise: 2000000,
        paymentMethod: 'CARD',
      };

      await service.createRazorpayOrder(payload1, idempotencyKey);

      // Same key, different body -> MUST throw ConflictException (409)
      await expect(
        service.createRazorpayOrder(payload2, idempotencyKey)
      ).rejects.toThrow();
    });

    it('should throw BadRequestException when Idempotency-Key header is missing', async () => {
      const payload = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 2,
        amountPaise: 1650000,
        paymentMethod: 'UPI',
      };
      await expect(service.createRazorpayOrder(payload, undefined)).rejects.toThrow();
    });
  });

  describe('Razorpay Webhook & Cryptographic HMAC Verification', () => {
    it('should reject webhook when signature header is missing', async () => {
      const webhookPayload = {
        entity: 'event',
        event: 'payment.captured',
      };

      await expect(service.processWebhook(webhookPayload, undefined)).rejects.toThrow();
    });

    it('should process webhook with authentic cryptographic HMAC-SHA256 signature', async () => {
      const secret = process.env.RAZORPAY_WEBHOOK_SECRET || 'bomis_razorpay_secret_sambalpur_2026';
      const webhookPayload = {
        entity: 'event',
        event: 'payment.captured',
        payload: {
          payment: {
            entity: {
              id: 'pay_authentic_test_456',
              order_id: 'order_authentic_001',
              amount: 1650000,
              currency: 'INR',
              status: 'captured',
              method: 'netbanking',
            },
          },
        },
      };

      const realHmacSignature = crypto
        .createHmac('sha256', secret)
        .update(JSON.stringify(webhookPayload))
        .digest('hex');

      const result = await service.processWebhook(webhookPayload, realHmacSignature);
      expect(result.processed).toBe(true);
      expect(result.paymentId).toBe('pay_authentic_test_456');
    });

    it('should reject webhook with fake mock signature when bypass is removed', async () => {
      const webhookPayload = {
        entity: 'event',
        event: 'payment.captured',
        payload: {
          payment: {
            entity: {
              id: 'pay_mock_test_123',
              order_id: 'order_test_999',
              amount: 1650000,
              currency: 'INR',
              status: 'captured',
              method: 'upi',
            },
          },
        },
      };

      await expect(
        service.processWebhook(
          webhookPayload,
          'test_hmac_sha256_mock_signature'
        )
      ).rejects.toThrow();
    });

    it('should reject webhook with invalid/forged HMAC signature', async () => {
      const webhookPayload = {
        entity: 'event',
        event: 'payment.captured',
        payload: {
          payment: {
            entity: {
              id: 'pay_forged_999',
              amount: 1000,
            },
          },
        },
      };

      await expect(
        service.processWebhook(webhookPayload, 'invalid_forged_hmac_signature')
      ).rejects.toThrow();
    });
  });

  describe('getReceiptById', () => {
    it('should retrieve tax fee receipt metadata with download URL', async () => {
      const receipt = await service.getReceiptById('rec_2026_04921');
      expect(receipt).toBeDefined();
      expect(receipt.receiptNumber).toBe('REC-2026-04921');
      expect(receipt.amount).toBe(16500);
      expect(receipt.downloadUrl).toContain('.pdf');
      expect(receipt.status).toBe('SUCCESS');
    });
  });

  describe('Concessions Workflow', () => {
    it('should apply for fee concession with validation', async () => {
      const payload = {
        studentId: 'stu_grade5a_001',
        discountPercentage: 15,
        reason: 'Merit scholarship for state mathematics olympiad',
      };

      const result = await service.applyConcession(payload);
      expect(result.id).toBeDefined();
      expect(result.discount_percentage).toBe(15);
      expect(result.status).toBe('PENDING');
    });

    it('should reject invalid discount percentage (>100 or <1)', async () => {
      await expect(
        service.applyConcession({
          studentId: 'stu_grade5a_001',
          discountPercentage: 150,
          reason: 'Invalid',
        })
      ).rejects.toThrow();
    });
  });
});
