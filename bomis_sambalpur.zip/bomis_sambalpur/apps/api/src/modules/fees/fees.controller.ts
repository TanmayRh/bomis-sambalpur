import {
  Controller,
  Get,
  Post,
  Param,
  Query,
  Body,
  Headers,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UserRole } from '@bomis/shared';
import { FeesService } from './fees.service';
import { Roles } from '../../common/decorators/roles.decorator';
import { Public } from '../../common/decorators/public.decorator';

@ApiTags('Fees & Financial Safety')
@ApiBearerAuth()
@Controller('fees')
export class FeesController {
  constructor(private readonly feesService: FeesService) {}

  @Get('structures')
  @Roles(
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.ACCOUNTANT,
    UserRole.PARENT
  )
  @ApiOperation({ summary: 'Get Fee Structures by Grade & Academic Year' })
  getStructures(
    @Query('grade') grade?: string,
    @Query('academicYear') academicYear?: string
  ) {
    return this.feesService.getStructures(grade, academicYear);
  }

  @Post('structures')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.ACCOUNTANT)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create Fee Structure' })
  createStructure(@Body() body: any) {
    return this.feesService.createStructure(body);
  }

  @Post('orders')
  @Roles(UserRole.PARENT, UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.ACCOUNTANT)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create Razorpay Payment Order (Enforces Idempotency-Key)' })
  createOrder(
    @Body() body: any,
    @Headers('idempotency-key') idempotencyKey?: string
  ) {
    return this.feesService.createRazorpayOrder(body, idempotencyKey);
  }

  @Public()
  @Post('webhook')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Razorpay Payment Webhook (HMAC-SHA256 Signature)' })
  handleWebhook(
    @Body() body: any,
    @Headers('x-razorpay-signature') signature?: string
  ) {
    return this.feesService.processWebhook(body, signature);
  }

  @Get('receipts/:id')
  @Roles(
    UserRole.PARENT,
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.ACCOUNTANT,
    UserRole.PRINCIPAL
  )
  @ApiOperation({ summary: 'Download PDF Fee Tax Receipt' })
  getReceipt(@Param('id') id: string) {
    return this.feesService.getReceiptById(id);
  }

  @Get('concessions')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL, UserRole.ACCOUNTANT)
  @ApiOperation({ summary: 'List Concessions' })
  getConcessions() {
    return this.feesService.getConcessions();
  }

  @Post('concessions')
  @Roles(UserRole.PARENT, UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.ACCOUNTANT)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Apply for Fee Concession' })
  applyConcession(@Body() body: any) {
    return this.feesService.applyConcession(body);
  }
}
