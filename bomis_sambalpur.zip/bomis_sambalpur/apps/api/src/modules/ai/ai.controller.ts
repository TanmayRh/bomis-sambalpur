import {
  Controller,
  Post,
  Body,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UserRole } from '@bomis/shared';
import { AiService } from './ai.service';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('AI Assistance Layer')
@ApiBearerAuth()
@Controller('ai')
export class AiController {
  constructor(private readonly aiService: AiService) {}

  @Post('study-buddy/chat')
  @Roles(
    UserRole.STUDENT,
    UserRole.PARENT,
    UserRole.TEACHER,
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL
  )
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Concept-explaining Study Buddy with syllabus grounding' })
  chat(@Body() body: any) {
    return this.aiService.studyBuddyChat(body);
  }

  @Post('lesson-planner/remarks')
  @Roles(
    UserRole.TEACHER,
    UserRole.PRINCIPAL,
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN
  )
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Draft report card remarks generator (Human-in-the-loop)' })
  generateRemarks(@Body() body: any) {
    return this.aiService.generateLessonRemarks(body);
  }

  @Post('voice-hpc/parse')
  @Roles(
    UserRole.TEACHER,
    UserRole.PRINCIPAL,
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN
  )
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Teacher Voice-to-Rubric AI Assistant for CBSE NEP 2020 Holistic Progress Cards' })
  parseVoiceHpc(@Body() body: any) {
    return this.aiService.parseVoiceHpcObservation(body);
  }
}
