import { Test, TestingModule } from '@nestjs/testing';
import { AiService } from './ai.service';

describe('AiService Unit Tests', () => {
  let service: AiService;

  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [AiService],
    }).compile();

    service = module.get<AiService>(AiService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('studyBuddyChat', () => {
    it('should generate grade-appropriate curriculum grounded response with NCERT citations', async () => {
      const payload = {
        prompt: 'Explain the water cycle and precipitation in simple terms',
        grade: 5,
        subject: 'General Science',
      };

      const result = await service.studyBuddyChat(payload);
      expect(result.response).toBeDefined();
      expect(result.response.length).toBeGreaterThan(20);
      expect(result.sources).toBeInstanceOf(Array);
      expect(result.sources.length).toBeGreaterThanOrEqual(1);
      expect(result.grade).toBe(5);
    });

    it('should reject empty or whitespace prompt with BadRequestException', async () => {
      await expect(
        service.studyBuddyChat({ prompt: '   ' })
      ).rejects.toThrow();
    });
  });

  describe('generateLessonRemarks', () => {
    it('should draft report card remarks with mandatory human-in-the-loop review flag', async () => {
      const payload = {
        studentName: 'Aarav Patel',
        subject: 'Mathematics',
        grade: 'Grade 5',
        strengths: 'exceptional problem-solving in fractions and geometric angles',
        areasForImprovement: 'consistent step-by-step working presentation',
      };

      const result = await service.generateLessonRemarks(payload);
      expect(result.draftRemarks).toBeDefined();
      expect(result.draftRemarks).toContain('Aarav Patel');
      expect(result.requiresTeacherApproval).toBe(true);
      expect(result.humanInTheLoop).toBe(true);
    });
  });
});
