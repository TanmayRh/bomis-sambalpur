import { Test, TestingModule } from '@nestjs/testing';
import { HealthController } from './health.controller';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';

describe('HealthController Unit Tests', () => {
  let controller: HealthController;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      controllers: [HealthController],
      providers: [PrismaService, MockStoreService, MockRedisService],
    }).compile();

    controller = module.get<HealthController>(HealthController);
    const prisma = module.get<PrismaService>(PrismaService);
    prisma.isMock = true;
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('getLiveness', () => {
    it('should return 200 OK with status ok and uptime', () => {
      const live = controller.getLiveness();
      expect(live).toBeDefined();
      expect(live.status).toBe('ok');
      expect(live.uptime).toBeGreaterThanOrEqual(0);
      expect(live.timestamp).toBeDefined();
    });
  });

  describe('getReadiness', () => {
    it('should return ready status with checks for database, redis, and minio', async () => {
      const ready = await controller.getReadiness();
      expect(ready).toBeDefined();
      expect(ready.status).toBe('ready');
      expect(ready.checks.database).toBe('up');
      expect(ready.checks.redis).toBe('up');
      expect(ready.checks.minio).toBe('up');
    });
  });
});
