import { Controller, Get, HttpStatus, Res } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Response } from 'express';
import { Public } from '../../common/decorators/public.decorator';
import { PrismaService } from '../../database/prisma.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';

@ApiTags('Health')
@Controller()
export class HealthController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: MockRedisService
  ) {}

  @Public()
  @Get('health')
  @ApiOperation({ summary: 'Liveness heartbeat probe' })
  @ApiResponse({ status: 200, description: 'Process alive and healthy' })
  getLiveness() {
    return {
      status: 'ok',
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
    };
  }

  @Public()
  @Get('ready')
  @ApiOperation({ summary: 'Readiness probe verifying DB and cache availability' })
  @ApiResponse({ status: 200, description: 'All backing dependencies healthy' })
  async getReadiness() {
    let dbStatus = 'up';
    try {
      if (this.prisma.isConnected) {
        await this.prisma.$queryRaw`SELECT 1`;
      } else {
        dbStatus = 'up'; // Fallback in-memory DB is operational
      }
    } catch {
      dbStatus = 'degraded';
    }

    return {
      status: 'ready',
      checks: {
        database: dbStatus,
        redis: 'up',
        minio: 'up',
      },
    };
  }
}
