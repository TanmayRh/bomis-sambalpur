import { Test, TestingModule } from '@nestjs/testing';
import { PeopleService } from './people.service';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';
import { CryptoService } from '../../common/crypto/crypto.service';
import { SEED_IDS } from '../../database/seed-fixtures';

describe('PeopleService Unit Tests', () => {
  let service: PeopleService;
  let mockStore: MockStoreService;
  let prisma: PrismaService;
  let cryptoService: CryptoService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        PeopleService,
        PrismaService,
        MockStoreService,
        MockRedisService,
        CryptoService,
      ],
    }).compile();

    service = module.get<PeopleService>(PeopleService);
    mockStore = module.get<MockStoreService>(MockStoreService);
    cryptoService = module.get<CryptoService>(CryptoService);
    prisma = module.get<PrismaService>(PrismaService);
    prisma.isMock = true;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('listStudents', () => {
    it('should list students filtered by grade and section', async () => {
      const result = await service.listStudents({ grade: 5, section: 'A', limit: 10 });
      expect(result).toBeDefined();
      expect(result.students).toBeInstanceOf(Array);
      expect(result.total).toBeGreaterThanOrEqual(1);

      const aarav = result.students.find((s) => s.id === SEED_IDS.STUDENT_AARAV);
      expect(aarav).toBeDefined();
      expect(aarav?.firstName).toBe('Aarav');
      expect(aarav?.lastName).toBe('Patel');
      expect(aarav?.grade).toBe(5);
    });

    it('should apply pagination parameters', async () => {
      const result = await service.listStudents({ page: 1, limit: 1 });
      expect(result.students.length).toBeLessThanOrEqual(1);
      expect(result.page).toBe(1);
      expect(result.limit).toBe(1);
    });
  });

  describe('getStudentById', () => {
    it('should retrieve student by UUID', async () => {
      const student = await service.getStudentById(SEED_IDS.STUDENT_AARAV);
      expect(student).toBeDefined();
      expect(student.id).toBe(SEED_IDS.STUDENT_AARAV);
      expect(student.firstName).toBe('Aarav');
      expect(student.emergencyContact).toBe('+919876543210');
    });

    it('should resolve symbolic ID "stu_grade5a_001" to Aarav Patel', async () => {
      const student = await service.getStudentById('stu_grade5a_001');
      expect(student).toBeDefined();
      expect(student.id).toBe(SEED_IDS.STUDENT_AARAV);
      expect(student.admissionNumber).toBe('BOMIS-2021-0042');
    });

    it('should throw NotFoundException for non-existent student', async () => {
      await expect(service.getStudentById('unknown_student_999')).rejects.toThrow();
    });
  });

  describe('createStudent', () => {
    it('should enroll a new student with DPDP AES-256-GCM encrypted fields and decrypt on retrieval', async () => {
      const payload = {
        admissionNumber: 'BOMIS-2026-TEST01',
        rollNumber: '35',
        firstName: 'Devansh',
        lastName: 'Pradhan',
        dateOfBirth: '2016-04-12',
        gender: 'MALE',
        grade: 4,
        section: 'A',
        bloodGroup: 'B+',
        emergencyContact: '+919437123456',
        house: 'KALINGA',
      };

      const result = await service.createStudent(payload);
      expect(result).toBeDefined();
      expect(result.id).toBeDefined();
      expect(result.admissionNumber).toBe('BOMIS-2026-TEST01');
      expect(result.firstName).toBe('Devansh');

      // Verify underlying storage is encrypted with version prefix v1:
      const rawInStore = mockStore.students.get(result.id);
      expect(rawInStore).toBeDefined();
      expect(rawInStore.blood_group_encrypted).toMatch(/^v1:[0-9a-f]{24}:[0-9a-f]{32}:[0-9a-f]+$/);
      expect(rawInStore.emergency_contact_encrypted).toMatch(/^v1:[0-9a-f]{24}:[0-9a-f]{32}:[0-9a-f]+$/);

      // Verify profile retrieval successfully decrypts encrypted PII
      const fetched = await service.getStudentById(result.id);
      expect(fetched.lastName).toBe('Pradhan');
      expect(fetched.bloodGroup).toBe('B+');
      expect(fetched.emergencyContact).toBe('+919437123456');
    });

    it('should reject duplicate admission number with ConflictException', async () => {
      const payload = {
        admissionNumber: 'BOMIS-2021-0042', // Same as Aarav
        firstName: 'Duplicate',
        lastName: 'Student',
      };
      await expect(service.createStudent(payload)).rejects.toThrow();
    });
  });

  describe('getLinkedSiblings', () => {
    it('should retrieve all children linked to parent Patel', async () => {
      const siblings = await service.getLinkedSiblings({ id: SEED_IDS.USER_PARENT_PATEL });
      expect(siblings).toBeInstanceOf(Array);
      expect(siblings.length).toBeGreaterThanOrEqual(2);

      const names = siblings.map((s) => s.firstName);
      expect(names).toContain('Aarav');
      expect(names).toContain('Ananya');
    });

    it('should return empty array and not leak other families children to unlinked guardian', async () => {
      const siblings = await service.getLinkedSiblings({ id: 'usr_unlinked_guardian_random' });
      expect(siblings).toEqual([]);
    });
  });

  describe('listStaff', () => {
    it('should return staff directory including teachers and admin', async () => {
      const staffList = await service.listStaff();
      expect(staffList).toBeInstanceOf(Array);
      expect(staffList.length).toBeGreaterThanOrEqual(4);

      const teacher = staffList.find((s) => s.id === SEED_IDS.STAFF_TEACHER_G5A);
      expect(teacher).toBeDefined();
      expect(teacher?.firstName).toBe('Arundhati');
    });
  });

  describe('bulkImport', () => {
    it('should bulk import multiple student records and return counts', async () => {
      const importBatch = [
        {
          admissionNumber: 'BOMIS-2026-BLK01',
          firstName: 'Siddharth',
          lastName: 'Mishra',
          grade: 5,
          section: 'A',
        },
        {
          admissionNumber: 'BOMIS-2026-BLK02',
          firstName: 'Ananya',
          lastName: 'Rath',
          grade: 5,
          section: 'A',
        },
      ];

      const result = await service.bulkImport(importBatch);
      expect(result.totalProcessed).toBe(2);
      expect(result.importedCount).toBe(2);
      expect(result.errors.length).toBe(0);
    });
  });
});
