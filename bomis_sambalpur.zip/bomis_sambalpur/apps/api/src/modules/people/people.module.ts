import { Module } from '@nestjs/common';
import { PeopleController } from './people.controller';
import { PeopleService } from './people.service';
import { CryptoService } from '../../common/crypto/crypto.service';

@Module({
  controllers: [PeopleController],
  providers: [PeopleService, CryptoService],
  exports: [PeopleService, CryptoService],
})
export class PeopleModule {}
