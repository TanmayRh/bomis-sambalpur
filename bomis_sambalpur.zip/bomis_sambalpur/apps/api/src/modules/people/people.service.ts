import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { randomUUID } from 'crypto';
import { PrismaService } from '../../database/prisma.service';
import { CryptoService } from '../../common/crypto/crypto.service';
import { SEED_IDS } from '../../database/seed-fixtures';

@Injectable()
export class PeopleService {
  private readonly logger = new Logger(PeopleService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly cryptoService: CryptoService
  ) {}

  /**
   * List students with filtering by grade, section, and pagination
   */
  async listStudents(params: {
    grade?: string | number;
    section?: string;
    classId?: string;
    sectionId?: string;
    page?: number;
    limit?: number;
  }) {
    const page = Number(params.page) || 1;
    const limit = Number(params.limit) || 30;
    const skip = (page - 1) * limit;

    const gradeFilter = params.grade !== undefined ? Number(params.grade) : undefined;
    const sectionFilter = params.section ? params.section.toUpperCase() : undefined;

    if (this.prisma.isMock) {
      let allStudents = Array.from(this.prisma.mockStore.students.values()).filter(
        (s) => !s.deleted_at
      );

      if (gradeFilter !== undefined && !isNaN(gradeFilter)) {
        allStudents = allStudents.filter(
          (s) => s.grade === gradeFilter || s.class_id === `c1000000-000${gradeFilter}-4000-8000-000000000001`
        );
      }

      if (sectionFilter) {
        allStudents = allStudents.filter(
          (s) => (s.section && s.section.toUpperCase() === sectionFilter) ||
                 (s.section_name && s.section_name.toUpperCase() === sectionFilter)
        );
      }

      const total = allStudents.length;
      const paginated = allStudents.slice(skip, skip + limit).map((s) => ({
        id: s.id,
        admissionNumber: s.admission_number,
        rollNumber: s.roll_number,
        firstName: s.first_name,
        lastName: s.last_name,
        grade: s.grade,
        section: s.section,
        classId: s.class_id,
        sectionId: s.section_id,
        gender: s.gender,
        house: s.house,
        emergencyContact: s.emergency_contact,
        isActive: s.is_active ?? true,
      }));

      return {
        students: paginated,
        total,
        page,
        limit,
      };
    }

    // Prisma DB Query
    const where: any = { deleted_at: null };
    if (gradeFilter) where.grade = gradeFilter;
    if (sectionFilter) where.section = sectionFilter;

    const [students, total] = await Promise.all([
      this.prisma.student.findMany({
        where,
        skip,
        take: limit,
      }),
      this.prisma.student.count({ where }),
    ]);

    return {
      students: students.map((s: any) => ({
        id: s.id,
        admissionNumber: s.admission_number,
        rollNumber: s.roll_number,
        firstName: s.first_name,
        lastName: s.last_name,
        grade: s.grade,
        section: s.section,
        classId: s.class_id,
        sectionId: s.section_id,
        gender: s.gender,
        house: s.house,
        emergencyContact: s.emergency_contact,
        isActive: s.is_active,
      })),
      total,
      page,
      limit,
    };
  }

  /**
   * Get single student profile by ID or symbolic key
   */
  async getStudentById(idOrSymbol: string) {
    const resolvedId = this.prisma.mockStore.resolveId(idOrSymbol);

    if (this.prisma.isMock) {
      let student = this.prisma.mockStore.students.get(resolvedId);
      if (!student) {
        for (const s of this.prisma.mockStore.students.values()) {
          if (s.admission_number === idOrSymbol || s.id === resolvedId) {
            student = s;
            break;
          }
        }
      }

      if (!student || student.deleted_at) {
        throw new NotFoundException({
          code: 'NOT_FOUND',
          message: `Student with ID [${idOrSymbol}] not found`,
        });
      }

      let bloodGroup = student.blood_group;
      if (student.blood_group_encrypted) {
        try {
          bloodGroup = this.cryptoService.decrypt(student.blood_group_encrypted, student.id);
        } catch {
          this.logger.warn(`Failed to decrypt blood group for student [${student.id}]`);
        }
      }

      let emergencyContact = student.emergency_contact;
      if (student.emergency_contact_encrypted) {
        try {
          emergencyContact = this.cryptoService.decrypt(student.emergency_contact_encrypted, student.id);
        } catch {
          this.logger.warn(`Failed to decrypt emergency contact for student [${student.id}]`);
        }
      }

      return {
        id: student.id,
        admissionNumber: student.admission_number,
        rollNumber: student.roll_number,
        firstName: student.first_name,
        lastName: student.last_name,
        grade: student.grade,
        section: student.section,
        classId: student.class_id,
        sectionId: student.section_id,
        dateOfBirth: student.date_of_birth,
        gender: student.gender,
        bloodGroup: bloodGroup || student.blood_group || 'O+',
        house: student.house || 'KALINGA',
        emergencyContact: emergencyContact || student.emergency_contact,
        schoolId: student.school_id,
      };
    }

    const student = await this.prisma.student.findFirst({
      where: { id: resolvedId, deleted_at: null },
      include: {
        class: true,
        section: true,
      },
    });

    if (!student) {
      throw new NotFoundException({
        code: 'NOT_FOUND',
        message: `Student with ID [${idOrSymbol}] not found`,
      });
    }

    let bloodGroup: string | null = null;
    if (student.blood_group_encrypted) {
      try {
        bloodGroup = this.cryptoService.decrypt(student.blood_group_encrypted, student.id);
      } catch {
        this.logger.warn(`Failed to decrypt blood group for DB student [${student.id}]`);
      }
    }

    let emergencyContact = student.emergency_contact;
    if (student.emergency_contact_encrypted) {
      try {
        emergencyContact = this.cryptoService.decrypt(student.emergency_contact_encrypted, student.id);
      } catch {
        this.logger.warn(`Failed to decrypt emergency contact for DB student [${student.id}]`);
      }
    }

    return {
      id: student.id,
      admissionNumber: student.admission_number,
      rollNumber: student.roll_number,
      firstName: student.first_name,
      lastName: student.last_name,
      grade: student.class?.grade_level || 5,
      section: student.section?.name || 'A',
      classId: student.class_id,
      sectionId: student.section_id,
      dateOfBirth: student.date_of_birth,
      gender: student.gender,
      bloodGroup: bloodGroup || 'O+',
      house: 'KALINGA',
      emergencyContact,
      schoolId: student.school_id,
    };
  }

  /**
   * Create a new student master profile
   */
  async createStudent(payload: any) {
    const admissionNumber =
      payload.admissionNumber || `BOMIS-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const studentId = randomUUID();

    // Check duplicate admission number in mockStore
    if (this.prisma.isMock) {
      for (const s of this.prisma.mockStore.students.values()) {
        if (s.admission_number === admissionNumber && !s.deleted_at) {
          throw new ConflictException({
            code: 'DUPLICATE_ENTITY',
            message: `Student with admission number [${admissionNumber}] already exists`,
          });
        }
      }

      const grade = payload.grade !== undefined ? Number(payload.grade) : 5;
      const section = payload.section || 'A';
      const classId =
        payload.classId ||
        (grade === 5 ? SEED_IDS.CLASS_GRADE_5 : `c1000000-000${grade}-4000-8000-000000000001`);
      const sectionId =
        payload.sectionId ||
        (grade === 5 ? SEED_IDS.SECTION_GRADE_5A : `s1000000-000${grade}-4000-8000-000000000001`);

      const bloodGroup = payload.bloodGroup || 'O+';
      const emergencyContact = payload.emergencyContact || '+919876543210';
      const bloodGroupEncrypted = this.cryptoService.encrypt(bloodGroup, studentId);
      const emergencyContactEncrypted = this.cryptoService.encrypt(emergencyContact, studentId);
      const medicalNotesEncrypted = payload.medicalNotes
        ? this.cryptoService.encrypt(payload.medicalNotes, studentId)
        : null;
      const aadhaarNumberEncrypted = payload.aadhaarNumber
        ? this.cryptoService.encrypt(payload.aadhaarNumber, studentId)
        : null;

      const newStudent = {
        id: studentId,
        school_id: payload.schoolId || SEED_IDS.SCHOOL,
        admission_number: admissionNumber,
        roll_number: String(payload.rollNumber || '25'),
        first_name: payload.firstName,
        last_name: payload.lastName,
        date_of_birth: new Date(payload.dateOfBirth || payload.dob || '2015-08-14'),
        gender: payload.gender || 'MALE',
        blood_group: bloodGroup,
        blood_group_encrypted: bloodGroupEncrypted,
        class_id: classId,
        section_id: sectionId,
        academic_year_id: payload.academicYearId || SEED_IDS.ACADEMIC_YEAR,
        emergency_contact: emergencyContact,
        emergency_contact_encrypted: emergencyContactEncrypted,
        medical_notes_encrypted: medicalNotesEncrypted,
        aadhaar_number_encrypted: aadhaarNumberEncrypted,
        grade,
        section,
        house: payload.house || 'KALINGA',
        is_active: true,
        deleted_at: null,
        created_at: new Date(),
      };

      this.prisma.mockStore.students.set(studentId, newStudent);
      this.logger.log(`Created student [${admissionNumber}] ID [${studentId}] with DPDP AES-256-GCM encryption`);

      return {
        id: newStudent.id,
        admissionNumber: newStudent.admission_number,
        rollNumber: newStudent.roll_number,
        firstName: newStudent.first_name,
        lastName: newStudent.last_name,
        grade: newStudent.grade,
        section: newStudent.section,
        classId: newStudent.class_id,
        sectionId: newStudent.section_id,
        emergencyContact: newStudent.emergency_contact,
        createdAt: newStudent.created_at.toISOString(),
      };
    }

    const bloodGroup = payload.bloodGroup || 'O+';
    const emergencyContact = payload.emergencyContact || '+919876543210';
    const bloodGroupEncrypted = this.cryptoService.encrypt(bloodGroup, studentId);
    const emergencyContactEncrypted = this.cryptoService.encrypt(emergencyContact, studentId);
    const medicalNotesEncrypted = payload.medicalNotes
      ? this.cryptoService.encrypt(payload.medicalNotes, studentId)
      : null;
    const aadhaarNumberEncrypted = payload.aadhaarNumber
      ? this.cryptoService.encrypt(payload.aadhaarNumber, studentId)
      : null;

    const grade = payload.grade !== undefined ? Number(payload.grade) : 5;
    const section = payload.section || 'A';
    const classId =
      payload.classId ||
      (grade === 5 ? SEED_IDS.CLASS_GRADE_5 : `c1000000-000${grade}-4000-8000-000000000001`);
    const sectionId =
      payload.sectionId ||
      (grade === 5 ? SEED_IDS.SECTION_GRADE_5A : `s1000000-000${grade}-4000-8000-000000000001`);

    // Prisma DB Insert: Aligned 100% with schema.prisma model Student
    const student = await this.prisma.student.create({
      data: {
        id: studentId,
        school_id: payload.schoolId || SEED_IDS.SCHOOL,
        admission_number: admissionNumber,
        roll_number: String(payload.rollNumber || '25'),
        first_name: payload.firstName,
        last_name: payload.lastName,
        date_of_birth: new Date(payload.dateOfBirth || payload.dob || '2015-08-14'),
        gender: (payload.gender || 'MALE') as any,
        class_id: classId,
        section_id: sectionId,
        academic_year_id: payload.academicYearId || SEED_IDS.ACADEMIC_YEAR,
        emergency_contact: emergencyContact,
        blood_group_encrypted: bloodGroupEncrypted,
        emergency_contact_encrypted: emergencyContactEncrypted,
        medical_notes_encrypted: medicalNotesEncrypted,
        aadhaar_number_encrypted: aadhaarNumberEncrypted,
        is_active: true,
      },
    });

    return {
      id: student.id,
      admissionNumber: student.admission_number,
      rollNumber: student.roll_number,
      firstName: student.first_name,
      lastName: student.last_name,
      grade,
      section,
      classId,
      sectionId,
      emergencyContact,
    };
  }

  /**
   * Fetch linked siblings for authenticated guardian/parent
   */
  async getLinkedSiblings(user: any) {
    if (this.prisma.isMock) {
      const userId = user?.id || user?.sub;
      if (!userId) {
        return [];
      }

      let guardianId: string | null = null;
      for (const g of this.prisma.mockStore.guardians.values()) {
        if (g.user_id === userId || g.id === userId) {
          guardianId = g.id;
          break;
        }
      }

      if (!guardianId) {
        return [];
      }

      const linkedStudentIds: string[] = [];
      for (const sg of this.prisma.mockStore.studentGuardians.values()) {
        if (sg.guardian_id === guardianId) {
          linkedStudentIds.push(sg.student_id);
        }
      }

      if (linkedStudentIds.length === 0) {
        return [];
      }

      const studentsToReturn = linkedStudentIds
        .map((id) => this.prisma.mockStore.students.get(id))
        .filter(Boolean)
        .map((s) => ({
          id: s.id,
          admissionNumber: s.admission_number,
          rollNumber: s.roll_number,
          firstName: s.first_name,
          lastName: s.last_name,
          grade: s.grade,
          section: s.section,
          classId: s.class_id,
          sectionId: s.section_id,
          bloodGroup: s.blood_group_encrypted
            ? this.cryptoService.decrypt(s.blood_group_encrypted, s.id)
            : s.blood_group || 'O+',
          emergencyContact: s.emergency_contact_encrypted
            ? this.cryptoService.decrypt(s.emergency_contact_encrypted, s.id)
            : s.emergency_contact || '+919876543210',
          relationship: 'Ward / Child',
        }));

      return studentsToReturn;
    }

    const userId = user?.id || user?.sub;
    if (!userId) {
      return [];
    }

    const guardian = await this.prisma.guardian.findFirst({
      where: { user_id: userId },
      include: {
        children: {
          include: {
            student: {
              include: {
                class: true,
                section: true,
              },
            },
          },
        },
      },
    });

    if (!guardian || !guardian.children || !guardian.children.length) {
      return [];
    }

    return guardian.children.map((sg: any) => ({
      id: sg.student.id,
      admissionNumber: sg.student.admission_number,
      rollNumber: sg.student.roll_number,
      firstName: sg.student.first_name,
      lastName: sg.student.last_name,
      grade: sg.student.class?.grade_level || 5,
      section: sg.student.section?.name || 'A',
      classId: sg.student.class_id,
      sectionId: sg.student.section_id,
      bloodGroup: sg.student.blood_group_encrypted
        ? this.cryptoService.decrypt(sg.student.blood_group_encrypted, sg.student.id)
        : 'O+',
      emergencyContact: sg.student.emergency_contact_encrypted
        ? this.cryptoService.decrypt(sg.student.emergency_contact_encrypted, sg.student.id)
        : sg.student.emergency_contact,
      relationship: sg.relation_type,
    }));
  }

  /**
   * List staff members directory
   */
  async listStaff() {
    if (this.prisma.isMock) {
      return Array.from(this.prisma.mockStore.staff.values()).map((stf) => ({
        id: stf.id,
        employeeId: stf.employee_id,
        firstName: stf.first_name,
        lastName: stf.last_name,
        designation: stf.designation,
        department: stf.department,
        email: stf.email,
        userId: stf.user_id,
      }));
    }

    const staffList = await this.prisma.staff.findMany({
      where: { deleted_at: null },
    });

    return staffList.map((stf: any) => ({
      id: stf.id,
      employeeId: stf.employee_id,
      firstName: stf.first_name,
      lastName: stf.last_name,
      designation: stf.designation,
      department: stf.department,
      email: stf.email,
      userId: stf.user_id,
    }));
  }

  /**
   * Bulk import students from JSON records or CSV
   */
  async bulkImport(records: any[]) {
    const raw: any = records;
    const list = Array.isArray(records)
      ? records
      : Array.isArray(raw?.students)
      ? raw.students
      : [];

    let importedCount = 0;
    const errors: any[] = [];

    for (let i = 0; i < list.length; i++) {
      try {
        await this.createStudent(list[i]);
        importedCount++;
      } catch (err: any) {
        errors.push({
          row: i + 1,
          error: err.message,
        });
      }
    }

    return {
      totalProcessed: list.length,
      importedCount,
      errors,
    };
  }
}
