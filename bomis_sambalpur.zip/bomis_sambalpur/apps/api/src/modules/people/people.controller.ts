import {
  Controller,
  Get,
  Post,
  Param,
  Query,
  Body,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UserRole } from '@bomis/shared';
import { PeopleService } from './people.service';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

@ApiTags('People Management')
@ApiBearerAuth()
@Controller('people')
export class PeopleController {
  constructor(private readonly peopleService: PeopleService) {}

  @Get('students')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL, UserRole.TEACHER)
  @ApiOperation({ summary: 'List students with grade/section filter' })
  listStudents(@Query() query: any) {
    return this.peopleService.listStudents(query);
  }

  @Post('students')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create student master profile' })
  createStudent(@Body() body: any) {
    return this.peopleService.createStudent(body);
  }

  @Get('guardians/siblings')
  @Roles(UserRole.PARENT, UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @ApiOperation({ summary: 'Fetch linked siblings for authenticated parent' })
  getLinkedSiblings(@CurrentUser() user: any) {
    return this.peopleService.getLinkedSiblings(user);
  }

  @Get('staff')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL)
  @ApiOperation({ summary: 'List staff directory' })
  listStaff() {
    return this.peopleService.listStaff();
  }

  @Post('students/bulk-import')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Bulk CSV / JSON student ingestion' })
  bulkImport(@Body() body: any) {
    return this.peopleService.bulkImport(body);
  }

  @Get('students/:id')
  @Roles(
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TEACHER,
    UserRole.PARENT
  )
  @ApiOperation({ summary: 'Get student profile by ID or symbolic key' })
  getStudentById(@Param('id') id: string) {
    return this.peopleService.getStudentById(id);
  }
}
