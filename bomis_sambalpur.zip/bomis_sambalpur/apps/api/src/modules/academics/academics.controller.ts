import {
  Controller,
  Get,
  Post,
  Body,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UserRole } from '@bomis/shared';
import { AcademicsService } from './academics.service';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('Academics & CBSE Grading')
@ApiBearerAuth()
@Controller('academics')
export class AcademicsController {
  constructor(private readonly academicsService: AcademicsService) {}

  @Get('terms')
  @Roles(
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TEACHER,
    UserRole.STUDENT,
    UserRole.PARENT
  )
  @ApiOperation({ summary: 'Get Academic Terms (CBSE Structure)' })
  getTerms() {
    return this.academicsService.getTerms();
  }

  @Post('terms')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create Academic Term' })
  createTerm(@Body() body: any) {
    return this.academicsService.createTerm(body);
  }

  @Post('marks/batch')
  @Roles(UserRole.TEACHER, UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Submit Marks Batch Entry (CBSE 9-Point Scale)' })
  submitMarks(@Body() body: any) {
    return this.academicsService.submitMarksBatch(body);
  }

  @Post('timetable/clash-check')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL, UserRole.TEACHER)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Timetable Clash Matrix Check' })
  checkClash(@Body() body: any) {
    return this.academicsService.checkTimetableClash(body);
  }

  @Post('substitutions')
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Teacher Absence Substitution Allocation' })
  createSubstitution(@Body() body: any) {
    return this.academicsService.createSubstitution(body);
  }
}
