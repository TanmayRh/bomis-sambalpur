import {
  Injectable,
  BadRequestException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { randomUUID } from 'crypto';
import { PrismaService } from '../../database/prisma.service';
import { SEED_IDS } from '../../database/seed-fixtures';

export interface CbseGradeCalculation {
  totalMarks: number;
  grade: 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2' | 'D' | 'E';
  gradePoint: number;
  remarks: string;
}

@Injectable()
export class AcademicsService {
  private readonly logger = new Logger(AcademicsService.name);

  // In-memory timetable schedule grid for clash checking: key = `${dayOfWeek}:${periodNumber}`
  private readonly scheduleGrid = new Map<string, Array<{ teacherId: string; roomId: string; sectionId?: string }>>();

  constructor(private readonly prisma: PrismaService) {
    this.seedScheduleGrid();
  }

  private seedScheduleGrid() {
    // Seed some period assignments (e.g. Teacher G5A booked on Monday period 1, but NOT period 3)
    this.scheduleGrid.set('MONDAY:1', [
      {
        teacherId: SEED_IDS.STAFF_TEACHER_G5A,
        roomId: 'Room 201',
        sectionId: SEED_IDS.SECTION_GRADE_5A,
      },
    ]);
  }

  /**
   * Pure CBSE 9-Point Grading Scale Calculator
   */
  public calculateCbseGrade(
    pt = 0,
    nb = 0,
    se = 0,
    exam = 0
  ): CbseGradeCalculation {
    if (pt < 0 || pt > 10) {
      throw new BadRequestException({
        code: 'VALIDATION_FAILED',
        message: 'Periodic Test score must be between 0 and 10',
      });
    }
    if (nb < 0 || nb > 5) {
      throw new BadRequestException({
        code: 'VALIDATION_FAILED',
        message: 'Notebook score must be between 0 and 5',
      });
    }
    if (se < 0 || se > 5) {
      throw new BadRequestException({
        code: 'VALIDATION_FAILED',
        message: 'Subject Enrichment score must be between 0 and 5',
      });
    }
    if (exam < 0 || exam > 80) {
      throw new BadRequestException({
        code: 'VALIDATION_FAILED',
        message: 'Term Exam score must be between 0 and 80',
      });
    }

    const totalMarks = Number((pt + nb + se + exam).toFixed(2));

    let grade: 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2' | 'D' | 'E' = 'E';
    let gradePoint = 0;
    let remarks = 'Needs Remedial Support';

    if (totalMarks >= 91.0) {
      grade = 'A1';
      gradePoint = 10.0;
      remarks = 'Outstanding';
    } else if (totalMarks >= 81.0) {
      grade = 'A2';
      gradePoint = 9.0;
      remarks = 'Excellent';
    } else if (totalMarks >= 71.0) {
      grade = 'B1';
      gradePoint = 8.0;
      remarks = 'Very Good';
    } else if (totalMarks >= 61.0) {
      grade = 'B2';
      gradePoint = 7.0;
      remarks = 'Good';
    } else if (totalMarks >= 51.0) {
      grade = 'C1';
      gradePoint = 6.0;
      remarks = 'Fair / Above Average';
    } else if (totalMarks >= 41.0) {
      grade = 'C2';
      gradePoint = 5.0;
      remarks = 'Average';
    } else if (totalMarks >= 33.0) {
      grade = 'D';
      gradePoint = 4.0;
      remarks = 'Pass';
    } else {
      grade = 'E';
      gradePoint = 0.0;
      remarks = 'Essential Repeat / Remedial';
    }

    return { totalMarks, grade, gradePoint, remarks };
  }

  /**
   * Get academic terms
   */
  async getTerms() {
    if (this.prisma.isMock) {
      return Array.from(this.prisma.mockStore.terms.values()).map((t) => ({
        id: t.id,
        name: t.name,
        term: t.term,
        startDate: t.start_date,
        endDate: t.end_date,
        isPublished: t.is_published ?? true,
      }));
    }

    const terms = await this.prisma.exam.findMany();
    return terms.map((t: any) => ({
      id: t.id,
      name: t.name,
      term: t.term,
      startDate: t.start_date,
      endDate: t.end_date,
      isPublished: t.is_published,
    }));
  }

  /**
   * Create an academic term
   */
  async createTerm(payload: any) {
    const termId = `trm_${randomUUID().substring(0, 8)}`;
    const term = {
      id: termId,
      school_id: SEED_IDS.SCHOOL,
      name: payload.name || 'Term 1 Exam',
      term: payload.term || 'TERM_1',
      start_date: new Date(payload.startDate || '2026-09-15'),
      end_date: new Date(payload.endDate || '2026-09-28'),
      is_published: payload.isPublished ?? false,
    };

    this.prisma.mockStore.terms.set(termId, term);

    if (!this.prisma.isMock) {
      try {
        await this.prisma.exam.create({
          data: {
            id: termId,
            school_id: SEED_IDS.SCHOOL,
            academic_year_id: SEED_IDS.ACADEMIC_YEAR,
            name: term.name,
            term: term.term as any,
            start_date: term.start_date,
            end_date: term.end_date,
            is_published: term.is_published,
          },
        });
      } catch (err: any) {
        this.logger.warn(`Failed to persist exam term to PostgreSQL: ${err.message}`);
      }
    }

    return term;
  }

  /**
   * Batch enter marks with CBSE 9-Point Scale Grading
   */
  async submitMarksBatch(payload: {
    termId: string;
    subjectId: string;
    classId?: string;
    sectionId?: string;
    records: Array<{
      studentId: string;
      periodicTest?: number;
      notebook?: number;
      subjectEnrichment?: number;
      examMarks?: number;
      remarks?: string;
    }>;
  }) {
    if (!payload.records || !payload.records.length) {
      return {
        recordedCount: 0,
        results: [],
      };
    }

    const results: any[] = [];
    const termId = this.prisma.mockStore.resolveId(payload.termId);
    const subjectId = this.prisma.mockStore.resolveId(payload.subjectId);

    for (const rec of payload.records) {
      const studentId = this.prisma.mockStore.resolveId(rec.studentId);
      const pt = Number(rec.periodicTest || 0);
      const nb = Number(rec.notebook || 0);
      const se = Number(rec.subjectEnrichment || 0);
      const exam = Number(rec.examMarks || 0);

      const grading = this.calculateCbseGrade(pt, nb, se, exam);

      const markRecord = {
        id: randomUUID(),
        term_id: termId,
        subject_id: subjectId,
        student_id: studentId,
        periodic_test: pt,
        notebook: nb,
        subject_enrichment: se,
        exam_marks: exam,
        total_marks: grading.totalMarks,
        grade: grading.grade,
        grade_point: grading.gradePoint,
        remarks: rec.remarks || grading.remarks,
        recorded_at: new Date(),
      };

      this.prisma.mockStore.marks.set(`${termId}:${subjectId}:${studentId}`, markRecord);

      results.push({
        studentId,
        totalMarks: grading.totalMarks,
        grade: grading.grade,
        gradePoint: grading.gradePoint,
        remarks: markRecord.remarks,
      });
    }

    if (!this.prisma.isMock) {
      try {
        for (const rec of payload.records) {
          const studentId = this.prisma.mockStore.resolveId(rec.studentId);
          const examMarks = Number(rec.examMarks || 0);
          const grading = this.calculateCbseGrade(
            Number(rec.periodicTest || 0),
            Number(rec.notebook || 0),
            Number(rec.subjectEnrichment || 0),
            examMarks
          );
          await this.prisma.marksEntry.create({
            data: {
              school_id: SEED_IDS.SCHOOL,
              exam_subject_id: subjectId,
              student_id: studentId,
              marks_obtained: grading.totalMarks,
              grade: grading.grade,
              remarks: rec.remarks || grading.remarks,
            },
          });
        }
      } catch (err: any) {
        this.logger.warn(`Failed to persist marks entries to PostgreSQL: ${err.message}`);
      }
    }

    this.logger.log(`Calculated and recorded marks for ${results.length} students on CBSE 9-point scale`);

    return {
      recordedCount: results.length,
      results,
    };
  }

  /**
   * Inspect timetable matrix to prevent teacher/room clash
   */
  async checkTimetableClash(payload: {
    teacherId: string;
    roomId: string;
    dayOfWeek: string;
    periodNumber: number;
  }) {
    const teacherId = this.prisma.mockStore.resolveId(payload.teacherId);
    const day = payload.dayOfWeek.toUpperCase();
    const period = Number(payload.periodNumber);
    const key = `${day}:${period}`;

    const existingSlots = this.scheduleGrid.get(key) || [];

    let hasClash = false;
    let conflictType: string | undefined;
    let details: any;

    for (const slot of existingSlots) {
      if (slot.teacherId === teacherId) {
        hasClash = true;
        conflictType = 'TEACHER_DOUBLE_BOOKED';
        details = { teacherId, periodNumber: period, dayOfWeek: day };
        break;
      }
      if (slot.roomId === payload.roomId) {
        hasClash = true;
        conflictType = 'ROOM_DOUBLE_BOOKED';
        details = { roomId: payload.roomId, periodNumber: period, dayOfWeek: day };
        break;
      }
    }

    return {
      hasClash,
      conflictType,
      details,
      dayOfWeek: day,
      periodNumber: period,
    };
  }

  /**
   * One-click teacher substitution
   */
  async createSubstitution(payload: {
    absentTeacherId: string;
    substituteTeacherId: string;
    date: string;
    periodNumber: number;
    sectionId?: string;
    subjectId?: string;
  }) {
    const absentId = this.prisma.mockStore.resolveId(payload.absentTeacherId);
    const substituteId = this.prisma.mockStore.resolveId(payload.substituteTeacherId);
    const period = Number(payload.periodNumber);

    const substitutionId = `sub_${randomUUID().substring(0, 8)}`;
    const subRecord = {
      id: substitutionId,
      school_id: SEED_IDS.SCHOOL,
      absent_teacher_id: absentId,
      substitute_teacher_id: substituteId,
      date: payload.date,
      period_number: period,
      section_id: payload.sectionId ? this.prisma.mockStore.resolveId(payload.sectionId) : null,
      subject_id: payload.subjectId ? this.prisma.mockStore.resolveId(payload.subjectId) : null,
      status: 'CONFIRMED',
      created_at: new Date(),
    };

    this.prisma.mockStore.substitutions.set(substitutionId, subRecord);

    if (!this.prisma.isMock) {
      try {
        await this.prisma.teacherAbsenceSubstitution.create({
          data: {
            id: substitutionId,
            school_id: SEED_IDS.SCHOOL,
            timetable_id: `tt_${randomUUID().substring(0, 8)}`,
            absent_staff_id: absentId,
            substitute_staff_id: substituteId,
            date: new Date(payload.date),
            status: 'APPROVED',
            remarks: `Period ${period} substitution`,
          },
        });
      } catch (err: any) {
        this.logger.warn(`Failed to persist teacher absence substitution to PostgreSQL: ${err.message}`);
      }
    }

    return {
      substitutionId,
      status: 'CONFIRMED',
      message: 'Teacher substitution scheduled successfully',
    };
  }
}
