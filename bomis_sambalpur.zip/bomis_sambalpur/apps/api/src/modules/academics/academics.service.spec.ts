import { Test, TestingModule } from '@nestjs/testing';
import { AcademicsService } from './academics.service';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';
import { SEED_IDS } from '../../database/seed-fixtures';

describe('AcademicsService Unit Tests', () => {
  let service: AcademicsService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AcademicsService,
        PrismaService,
        MockStoreService,
        MockRedisService,
      ],
    }).compile();

    service = module.get<AcademicsService>(AcademicsService);
    const prisma = module.get<PrismaService>(PrismaService);
    prisma.isMock = true;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('CBSE 9-Point Grading Scale Engine', () => {
    it('should assign A1 (10.0 GP) for scores >= 91.0%', () => {
      // PT: 9.5, NB: 4.5, SE: 4.5, Exam: 76.0 -> Total: 94.5%
      const res = service.calculateCbseGrade(9.5, 4.5, 4.5, 76.0);
      expect(res.totalMarks).toBe(94.5);
      expect(res.grade).toBe('A1');
      expect(res.gradePoint).toBe(10.0);
    });

    it('should assign A2 (9.0 GP) for scores between 81.0% and 90.9%', () => {
      const res = service.calculateCbseGrade(8.0, 4.0, 4.0, 70.0); // Total: 86.0%
      expect(res.grade).toBe('A2');
      expect(res.gradePoint).toBe(9.0);
    });

    it('should assign B1 (8.0 GP) for scores between 71.0% and 80.9%', () => {
      const res = service.calculateCbseGrade(7.0, 4.0, 4.0, 60.0); // Total: 75.0%
      expect(res.grade).toBe('B1');
      expect(res.gradePoint).toBe(8.0);
    });

    it('should assign B2 (7.0 GP) for scores between 61.0% and 70.9%', () => {
      const res = service.calculateCbseGrade(6.0, 3.5, 3.5, 52.0); // Total: 65.0%
      expect(res.grade).toBe('B2');
      expect(res.gradePoint).toBe(7.0);
    });

    it('should assign C1 (6.0 GP) for scores between 51.0% and 60.9%', () => {
      const res = service.calculateCbseGrade(5.0, 3.0, 3.0, 45.0); // Total: 56.0%
      expect(res.grade).toBe('C1');
      expect(res.gradePoint).toBe(6.0);
    });

    it('should assign C2 (5.0 GP) for scores between 41.0% and 50.9%', () => {
      const res = service.calculateCbseGrade(4.0, 2.5, 2.5, 36.0); // Total: 45.0%
      expect(res.grade).toBe('C2');
      expect(res.gradePoint).toBe(5.0);
    });

    it('should assign D (4.0 GP) for scores between 33.0% and 40.9%', () => {
      const res = service.calculateCbseGrade(3.0, 2.0, 2.0, 30.0); // Total: 37.0%
      expect(res.grade).toBe('D');
      expect(res.gradePoint).toBe(4.0);
    });

    it('should assign E (0.0 GP) for scores below 33.0%', () => {
      const res = service.calculateCbseGrade(2.0, 1.0, 1.0, 20.0); // Total: 24.0%
      expect(res.grade).toBe('E');
      expect(res.gradePoint).toBe(0.0);
    });

    it('should throw BadRequestException if periodicTest exceeds 10', () => {
      expect(() => service.calculateCbseGrade(12.0, 4.0, 4.0, 70.0)).toThrow();
    });

    it('should throw BadRequestException if examMarks exceeds 80', () => {
      expect(() => service.calculateCbseGrade(9.0, 4.0, 4.0, 85.0)).toThrow();
    });
  });

  describe('submitMarksBatch', () => {
    it('should process marks batch entry and compute CBSE grades', async () => {
      const payload = {
        termId: 'trm_2026_term_1',
        subjectId: 'sub_mathematics_001',
        records: [
          {
            studentId: 'stu_grade5a_001',
            periodicTest: 9.5,
            notebook: 4.5,
            subjectEnrichment: 4.5,
            examMarks: 76.0,
          },
        ],
      };

      const result = await service.submitMarksBatch(payload);
      expect(result.recordedCount).toBe(1);
      expect(result.results[0].grade).toBe('A1');
      expect(result.results[0].totalMarks).toBe(94.5);
    });
  });

  describe('checkTimetableClash', () => {
    it('should detect when teacher is already booked on same day and period', async () => {
      // Period 1 on Monday is booked for Teacher G5A in seeded schedule
      const clash = await service.checkTimetableClash({
        teacherId: SEED_IDS.STAFF_TEACHER_G5A,
        roomId: 'Room 999',
        dayOfWeek: 'MONDAY',
        periodNumber: 1,
      });

      expect(clash.hasClash).toBe(true);
      expect(clash.conflictType).toBe('TEACHER_DOUBLE_BOOKED');
    });

    it('should return no clash when resources are free', async () => {
      const noClash = await service.checkTimetableClash({
        teacherId: SEED_IDS.STAFF_TEACHER_G5A,
        roomId: 'room_lab_physics_01',
        dayOfWeek: 'MONDAY',
        periodNumber: 3, // Free period
      });

      expect(noClash.hasClash).toBe(false);
    });
  });

  describe('createSubstitution', () => {
    it('should assign substitute teacher for absent period', async () => {
      const payload = {
        absentTeacherId: SEED_IDS.STAFF_TEACHER_G5A,
        substituteTeacherId: 'm1000000-0003-4000-8000-000000000001',
        date: '2026-10-21',
        periodNumber: 2,
      };

      const result = await service.createSubstitution(payload);
      expect(result.substitutionId).toBeDefined();
      expect(result.status).toBe('CONFIRMED');
    });
  });
});
