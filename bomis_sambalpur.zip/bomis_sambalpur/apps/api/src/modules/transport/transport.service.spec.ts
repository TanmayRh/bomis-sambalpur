import { Test, TestingModule } from '@nestjs/testing';
import { TransportService } from './transport.service';
import { PrismaService } from '../../database/prisma.service';
import { MockStoreService } from '../../database/mock-store.service';
import { MockRedisService } from '../../common/redis/mock-redis.service';
import { SEED_IDS } from '../../database/seed-fixtures';

describe('TransportService Unit Tests', () => {
  let service: TransportService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TransportService,
        PrismaService,
        MockStoreService,
        MockRedisService,
      ],
    }).compile();

    service = module.get<TransportService>(TransportService);
    const prisma = module.get<PrismaService>(PrismaService);
    prisma.isMock = true;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getRoutes', () => {
    it('should return all 4 arterial school routes with geofenced stops', async () => {
      const routes = await service.getRoutes();
      expect(routes).toBeInstanceOf(Array);
      expect(routes.length).toBe(4);

      const routeCodes = routes.map((r) => r.code);
      expect(routeCodes).toContain('RT-BUDHARAJA-01');
      expect(routeCodes).toContain('RT-KHETRAJPUR-02');
      expect(routeCodes).toContain('RT-DHANUPALI-03');
      expect(routeCodes).toContain('RT-BURLA-04');
    });
  });

  describe('getBuses', () => {
    it('should return at least 4 pilot buses with OD-15 Sambalpur registration plates', async () => {
      const buses = await service.getBuses();
      expect(buses).toBeInstanceOf(Array);
      expect(buses.length).toBeGreaterThanOrEqual(4);

      // Verify each bus registration plate conforms to OD-15 (Sambalpur RTO)
      for (const bus of buses) {
        expect(bus.registrationNumber).toMatch(/^OD-15/);
      }

      // Verify pilot bus models include 3 small 24-seaters and 1 full-size 52-seater
      const fullSizeBus = buses.find((b) => b.capacity === 52);
      expect(fullSizeBus).toBeDefined();
      expect(fullSizeBus?.registrationNumber).toBe('OD-15-AC-2001');
    });
  });

  describe('recordBoardingScan', () => {
    it('should register student boarding QR scan at bus stop', async () => {
      const payload = {
        busId: 'bus_pilot_01',
        studentId: 'stu_grade5a_001',
        stopId: 'stop_sakhipada_01',
        action: 'BOARDED',
        lat: 21.4669,
        lng: 83.9812,
      };

      const result = await service.recordBoardingScan(payload);
      expect(result.scanId).toBeDefined();
      expect(result.action).toBe('BOARDED');
      expect(result.studentId).toBe(SEED_IDS.STUDENT_AARAV);
    });

    it('should reject scan if required fields are missing', async () => {
      await expect(
        service.recordBoardingScan({ busId: '', studentId: '', stopId: '', action: '', lat: 0, lng: 0 })
      ).rejects.toThrow();
    });
  });

  describe('recordGpsPing', () => {
    it('should ingest driver GPS telemetry and update vehicle coordinates', async () => {
      const payload = {
        busId: 'bus_pilot_01',
        latitude: 21.4675,
        longitude: 83.982,
        speed: 35,
        heading: 90,
      };

      const result = await service.recordGpsPing(payload);
      expect(result.recorded).toBe(true);
      expect(result.proximityAlertsSent).toBeGreaterThanOrEqual(1);
    });
  });
});
