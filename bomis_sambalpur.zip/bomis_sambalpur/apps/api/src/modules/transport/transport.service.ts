import {
  Injectable,
  NotFoundException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { randomUUID } from 'crypto';
import { PrismaService } from '../../database/prisma.service';
import { SEED_IDS } from '../../database/seed-fixtures';

@Injectable()
export class TransportService {
  private readonly logger = new Logger(TransportService.name);

  constructor(private readonly prisma: PrismaService) {}

  /**
   * List 4 arterial bus routes and stops
   */
  async getRoutes() {
    if (this.prisma.isMock) {
      return Array.from(this.prisma.mockStore.routes.values()).map((r) => ({
        id: r.id,
        name: r.name,
        code: r.code,
        startPoint: r.start_point,
        endPoint: r.end_point,
        stops: r.stops,
      }));
    }

    const routes = await this.prisma.transportRoute.findMany({
      include: { stops: true },
    });

    return routes.map((r: any) => ({
      id: r.id,
      name: r.name,
      code: r.code,
      startPoint: r.start_point,
      endPoint: r.end_point,
      stops: r.stops,
    }));
  }

  /**
   * List 4 pilot buses with OD-15 registration plates and telemetry
   */
  async getBuses() {
    if (this.prisma.isMock) {
      const buses = Array.from(this.prisma.mockStore.vehicles.values()).map((v) => ({
        id: v.id,
        registrationNumber: v.registration_number,
        busNumber: v.bus_number,
        capacity: v.capacity,
        model: v.model,
        status: v.status,
        currentRouteId: v.current_route_id,
        driverStaffId: v.driver_staff_id,
        telemetry: v.telemetry,
      }));

      return buses;
    }

    const vehicles = await this.prisma.vehicle.findMany();
    return vehicles.map((v: any) => ({
      id: v.id,
      registrationNumber: v.registration_number,
      busNumber: v.bus_number,
      capacity: v.capacity,
      model: v.model,
      status: v.status,
      currentRouteId: v.current_route_id,
      driverStaffId: v.driver_staff_id,
      telemetry: v.telemetry,
    }));
  }

  /**
   * Scan student boarding/deboarding QR at bus stop
   */
  async recordBoardingScan(payload: {
    busId: string;
    studentId: string;
    stopId: string;
    action: string;
    lat: number;
    lng: number;
    timestamp?: string;
  }) {
    if (!payload.busId || !payload.studentId || !payload.action) {
      throw new BadRequestException({
        code: 'VALIDATION_FAILED',
        message: 'busId, studentId, and action (BOARDED/DEBOARDED) are required',
      });
    }

    const busId = this.prisma.mockStore.resolveId(payload.busId);
    const studentId = this.prisma.mockStore.resolveId(payload.studentId);
    const stopId = this.prisma.mockStore.resolveId(payload.stopId);

    const scanId = `scan_${randomUUID().substring(0, 10)}`;
    const scanEvent = {
      id: scanId,
      busId,
      studentId,
      stopId,
      action: payload.action,
      latitude: payload.lat,
      longitude: payload.lng,
      scannedAt: payload.timestamp || new Date().toISOString(),
    };

    this.prisma.mockStore.boardingEvents.set(scanId, scanEvent);

    if (!this.prisma.isMock) {
      try {
        await this.prisma.boardingEvent.create({
          data: {
            id: scanId,
            school_id: SEED_IDS.SCHOOL,
            student_id: studentId,
            vehicle_id: busId,
            stop_id: stopId,
            scan_type: payload.action,
            status: payload.action === 'DEBOARD' ? 'DEBOARDED' : 'BOARDED',
            scanned_at: new Date(payload.timestamp || Date.now()),
          },
        });
      } catch (err: any) {
        this.logger.warn(`Failed to persist boarding event to PostgreSQL: ${err.message}`);
      }
    }

    this.logger.log(`Registered bus scan [${scanId}]: Student [${studentId}] ${payload.action} Bus [${busId}]`);

    return {
      scanId,
      busId,
      studentId,
      action: payload.action,
      stopId,
      message: 'Boarding scan registered successfully',
    };
  }

  /**
   * Ingest real-time vehicle GPS coordinates from driver app
   * Evaluates spherical Haversine distance from BOMIS Sambalpur campus (21.4984, 83.9781)
   * and triggers proximity alerts when within 1.5 km threshold.
   */
  async recordGpsPing(payload: {
    vehicleId?: string;
    busId?: string;
    routeId?: string;
    latitude: number;
    longitude: number;
    speed?: number;
    heading?: number;
    timestamp?: string;
  }) {
    const busId = this.prisma.mockStore.resolveId(payload.busId || payload.vehicleId || SEED_IDS.BUS_PILOT_01);

    const ping = {
      busId,
      latitude: payload.latitude,
      longitude: payload.longitude,
      speed: payload.speed ?? 30,
      heading: payload.heading ?? 45,
      timestamp: payload.timestamp || new Date().toISOString(),
    };

    this.prisma.mockStore.telemetry.set(busId, ping);

    if (!this.prisma.isMock) {
      try {
        await this.prisma.transportTelemetry.create({
          data: {
            school_id: SEED_IDS.SCHOOL,
            vehicle_id: busId,
            route_id: payload.routeId ? this.prisma.mockStore.resolveId(payload.routeId) : null,
            latitude: payload.latitude,
            longitude: payload.longitude,
            speed: payload.speed ?? 30,
            heading: payload.heading ?? 45,
            recorded_at: new Date(payload.timestamp || Date.now()),
          },
        });
      } catch (err: any) {
        this.logger.warn(`Failed to persist transport telemetry to PostgreSQL: ${err.message}`);
      }
    }

    // Update telemetry in vehicles map if exists
    if (this.prisma.mockStore.vehicles.has(busId)) {
      const v = this.prisma.mockStore.vehicles.get(busId);
      v.telemetry = {
        lat: payload.latitude,
        lng: payload.longitude,
        speed: payload.speed ?? 30,
        heading: payload.heading ?? 45,
        lastPing: new Date(),
      };
    }

    // Spherical Haversine distance calculation to BOMIS Sambalpur campus (lat: 21.4984, lng: 83.9781)
    const campusLat = 21.4984;
    const campusLng = 83.9781;
    const distanceToCampusKm = calculateHaversineDistanceKm(
      payload.latitude,
      payload.longitude,
      campusLat,
      campusLng
    );

    // If distance <= 1.5 km, proximityAlertsSent: 1; if distance > 1.5 km, proximityAlertsSent: 0
    let proximityAlertsSent = distanceToCampusKm <= 1.5 ? 1 : 0;

    // In addition to campus proximity, evaluate geofence against active route stops
    if (proximityAlertsSent === 0 && busId && this.prisma.isMock) {
      const v = this.prisma.mockStore.vehicles.get(busId);
      const routeId = payload.routeId || v?.current_route_id;
      if (routeId) {
        const route = this.prisma.mockStore.routes.get(routeId);
        if (route?.stops && Array.isArray(route.stops)) {
          for (const stop of route.stops) {
            if (typeof stop.lat === 'number' && typeof stop.lng === 'number') {
              const stopDist = calculateHaversineDistanceKm(
                payload.latitude,
                payload.longitude,
                stop.lat,
                stop.lng
              );
              if (stopDist <= 1.5) {
                proximityAlertsSent = 1;
                break;
              }
            }
          }
        }
      }
    }

    return {
      recorded: true,
      busId,
      distanceKm: Number(distanceToCampusKm.toFixed(3)),
      proximityAlertsSent,
    };
  }
}

/**
 * Calculates great-circle spherical distance between two coordinates using the Haversine formula
 * @param lat1 Latitude of point 1 (degrees)
 * @param lon1 Longitude of point 1 (degrees)
 * @param lat2 Latitude of point 2 (degrees)
 * @param lon2 Longitude of point 2 (degrees)
 * @returns Spherical distance in kilometers
 */
export function calculateHaversineDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's mean radius in kilometers
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const lat1Rad = (lat1 * Math.PI) / 180;
  const lat2Rad = (lat2 * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

  // Clamping for numerical stability (a <= 1.0)
  const clampedA = Math.min(1, Math.max(0, a));
  const c = 2 * Math.atan2(Math.sqrt(clampedA), Math.sqrt(Math.max(0, 1 - clampedA)));
  return R * c;
}
