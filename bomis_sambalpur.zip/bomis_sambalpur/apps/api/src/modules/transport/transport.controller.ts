import {
  Controller,
  Get,
  Post,
  Body,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UserRole } from '@bomis/shared';
import { TransportService } from './transport.service';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('Transport & Fleet Operations')
@ApiBearerAuth()
@Controller('transport')
export class TransportController {
  constructor(private readonly transportService: TransportService) {}

  @Get('routes')
  @Roles(
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TRANSPORT_STAFF,
    UserRole.PARENT,
    UserRole.TEACHER
  )
  @ApiOperation({ summary: 'List Bus Routes and Stops' })
  getRoutes() {
    return this.transportService.getRoutes();
  }

  @Get('buses')
  @Roles(
    UserRole.ADMIN,
    UserRole.SUPER_ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TRANSPORT_STAFF,
    UserRole.PARENT
  )
  @ApiOperation({ summary: 'List 4 Pilot Buses and Telemetry Status' })
  getBuses() {
    return this.transportService.getBuses();
  }

  @Post('boarding/scan')
  @Roles(UserRole.TRANSPORT_STAFF, UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Scan Student Boarding / Deboarding QR' })
  scanBoarding(@Body() body: any) {
    return this.transportService.recordBoardingScan(body);
  }

  @Post('gps-ping')
  @Roles(UserRole.TRANSPORT_STAFF, UserRole.ADMIN, UserRole.SUPER_ADMIN)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Broadcast Fleet Vehicle GPS Telemetry' })
  gpsPing(@Body() body: any) {
    return this.transportService.recordGpsPing(body);
  }
}
