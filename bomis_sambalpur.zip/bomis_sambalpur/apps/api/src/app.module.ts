import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
import { APP_GUARD, APP_INTERCEPTOR, APP_FILTER, APP_PIPE } from '@nestjs/core';

// Core and Database Modules
import { DatabaseModule } from './database/database.module';

// Domain Modules
import { HealthModule } from './modules/health/health.module';
import { AuthModule } from './modules/auth/auth.module';
import { PeopleModule } from './modules/people/people.module';
import { AttendanceModule } from './modules/attendance/attendance.module';
import { FeesModule } from './modules/fees/fees.module';
import { AcademicsModule } from './modules/academics/academics.module';
import { TransportModule } from './modules/transport/transport.module';
import { SafetyModule } from './modules/safety/safety.module';
import { AiModule } from './modules/ai/ai.module';
import { PulseModule } from './modules/pulse/pulse.module';
import { AdminModule } from './modules/admin/admin.module';

// Global Infrastructure
import { CorrelationContextMiddleware } from './common/context/correlation-context.middleware';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { RolesGuard } from './common/guards/roles.guard';
import { TransformInterceptor } from './common/interceptors/transform.interceptor';
import { LoggingInterceptor } from './common/interceptors/logging.interceptor';
import { HttpExceptionFilter } from './common/filters/http-exception.filter';
import { ZodValidationPipe } from './common/pipes/zod-validation.pipe';
import { PinoLoggerService } from './common/logger/pino-logger.service';

@Module({
  imports: [
    DatabaseModule,
    HealthModule,
    AuthModule,
    PeopleModule,
    AttendanceModule,
    FeesModule,
    AcademicsModule,
    TransportModule,
    SafetyModule,
    AiModule,
    PulseModule,
    AdminModule,
  ],
  controllers: [],
  providers: [
    // Global Exception Filter
    {
      provide: APP_FILTER,
      useClass: HttpExceptionFilter,
    },
    // Global Response Envelope & Logging Interceptors
    {
      provide: APP_INTERCEPTOR,
      useClass: TransformInterceptor,
    },
    {
      provide: APP_INTERCEPTOR,
      useClass: LoggingInterceptor,
    },
    // Global JWT Authentication Guard (Checks for Bearer token, bypassed by @Public())
    {
      provide: APP_GUARD,
      useClass: JwtAuthGuard,
    },
    // Global RBAC Roles Guard (Enforces @Roles(...) permissions)
    {
      provide: APP_GUARD,
      useClass: RolesGuard,
    },
    PinoLoggerService,
  ],
  exports: [
    PinoLoggerService,
    DatabaseModule,
    HealthModule,
    AuthModule,
    PeopleModule,
    AttendanceModule,
    FeesModule,
    AcademicsModule,
    TransportModule,
    SafetyModule,
    AiModule,
    PulseModule,
    AdminModule,
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(CorrelationContextMiddleware).forRoutes('*');
  }
}
