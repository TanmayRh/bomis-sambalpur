import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { PinoLoggerService } from './common/logger/pino-logger.service';
import { ZodValidationPipe } from './common/pipes/zod-validation.pipe';

async function bootstrap() {
  const pinoLogger = new PinoLoggerService();
  const app = await NestFactory.create(AppModule, {
    logger: pinoLogger,
  });

  app.useLogger(pinoLogger);
  app.useGlobalPipes(new ZodValidationPipe());

  // Global routing prefix with root exclusion for health & readiness probes
  app.setGlobalPrefix('api/v1', {
    exclude: ['health', 'ready'],
  });

  // Cross-Origin Resource Sharing
  app.enableCors({
    origin: '*',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true,
  });

  // Swagger OpenAPI 3.0 Documentation at /api/docs
  const config = new DocumentBuilder()
    .setTitle('BOMIS Sambalpur Unified School Platform API')
    .setDescription(
      'Modular Monolith Backend API for Birla Open Minds International School, Sambalpur. Implements CBSE academics, DPDP privacy, Razorpay payments, fleet telemetry, and rapid attendance.'
    )
    .setVersion('1.0.0')
    .addBearerAuth()
    .addApiKey({ type: 'apiKey', name: 'idempotency-key', in: 'header' }, 'Idempotency-Key')
    .addApiKey({ type: 'apiKey', name: 'x-correlation-id', in: 'header' }, 'Correlation-Id')
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document, {
    customSiteTitle: 'BOMIS Sambalpur API Documentation',
  });

  const port = process.env.PORT || 4000;
  await app.listen(port);
  console.log(`BOMIS Sambalpur API server listening on http://localhost:${port}/api/v1`);
  console.log(`Swagger OpenAPI Documentation available at http://localhost:${port}/api/docs`);
}

bootstrap();
