import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from './app.module';

describe('BOMIS Sambalpur Backend - AppModule Test Suite', () => {
  let moduleRef: TestingModule;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    moduleRef = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();
  });

  afterAll(async () => {
    if (moduleRef) {
      await moduleRef.close();
    }
  });

  it('should compile the NestJS root testing module successfully', () => {
    expect(moduleRef).toBeDefined();
  });

  it('should instantiate AppModule and verify its dependency graph', () => {
    const appModule = moduleRef.get<AppModule>(AppModule);
    expect(appModule).toBeDefined();
    expect(appModule).toBeInstanceOf(AppModule);
  });

  it('should have PinoLoggerService registered in dependency graph', () => {
    const { PinoLoggerService } = require('./common/logger/pino-logger.service');
    const logger = moduleRef.get(PinoLoggerService);
    expect(logger).toBeDefined();
  });
});
