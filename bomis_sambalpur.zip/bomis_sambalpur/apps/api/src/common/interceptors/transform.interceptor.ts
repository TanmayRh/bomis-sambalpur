import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  StreamableFile,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Request, Response } from 'express';
import { ApiResponse } from '@bomis/shared';
import { traceStorage } from '../context/request-context';
import { BYPASS_ENVELOPE_KEY } from '../decorators/bypass-envelope.decorator';

@Injectable()
export class TransformInterceptor<T>
  implements NestInterceptor<T, ApiResponse<T> | T | StreamableFile>
{
  constructor(private reflector?: Reflector) {}

  intercept(
    context: ExecutionContext,
    next: CallHandler
  ): Observable<ApiResponse<T> | T | StreamableFile> {
    const http = context.switchToHttp();
    const request = http.getRequest<Request>();
    const response = http.getResponse<Response>();

    // Check if route has @BypassEnvelope() decorator
    if (this.reflector) {
      const bypass = this.reflector.getAllAndOverride<boolean>(
        BYPASS_ENVELOPE_KEY,
        [context.getHandler(), context.getClass()]
      );
      if (bypass) {
        return next.handle();
      }
    }

    const trace = traceStorage.getStore();
    const correlationId =
      trace?.correlationId ||
      (request.headers['x-correlation-id'] as string) ||
      (request.headers['x-request-id'] as string) ||
      (response.getHeader('x-correlation-id') as string) ||
      `corr-gen-${Date.now()}`;

    // Ensure response header is set
    response.setHeader('x-correlation-id', correlationId);

    return next.handle().pipe(
      map((data) => {
        // Bypass for StreamableFile
        if (data instanceof StreamableFile) {
          return data;
        }

        // Bypass for binary stream content types
        const contentType = (response.getHeader('content-type') as string) || '';
        if (
          contentType.includes('application/pdf') ||
          contentType.includes('text/csv') ||
          contentType.includes('application/octet-stream')
        ) {
          return data;
        }

        // Avoid double-wrapping
        if (
          data &&
          typeof data === 'object' &&
          'success' in data &&
          'timestamp' in data &&
          'correlationId' in data
        ) {
          return data;
        }

        const envelope: ApiResponse<T> = {
          success: true,
          data: data !== undefined ? data : null,
          error: null,
          timestamp: new Date().toISOString(),
          correlationId,
        };

        return envelope;
      })
    );
  }
}
