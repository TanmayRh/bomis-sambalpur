import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { getCorrelationId } from '../context/request-context';

export const CorrelationId = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest();
    const headerVal =
      request.headers['x-correlation-id'] || request.headers['x-request-id'];
    return (headerVal as string) || getCorrelationId();
  }
);
