import { Injectable, LoggerService } from '@nestjs/common';
import pino, { Logger } from 'pino';
import { getCorrelationId } from '../context/request-context';

@Injectable()
export class PinoLoggerService implements LoggerService {
  private readonly logger: Logger;

  constructor() {
    this.logger = pino({
      level: process.env.LOG_LEVEL || 'info',
      base: {
        service: 'bomis-api',
      },
      formatters: {
        level(label: string) {
          return { level: label };
        },
      },
      timestamp: pino.stdTimeFunctions.isoTime,
    });
  }

  log(message: any, ...optionalParams: any[]) {
    const correlationId = getCorrelationId();
    const context = typeof optionalParams[0] === 'string' ? optionalParams[0] : undefined;
    this.logger.info(
      { correlationId, context },
      typeof message === 'object' ? JSON.stringify(message) : String(message)
    );
  }

  error(message: any, ...optionalParams: any[]) {
    const correlationId = getCorrelationId();
    const context = typeof optionalParams[0] === 'string' ? optionalParams[0] : undefined;
    const trace = optionalParams[1];
    this.logger.error(
      { correlationId, context, trace },
      typeof message === 'object' ? JSON.stringify(message) : String(message)
    );
  }

  warn(message: any, ...optionalParams: any[]) {
    const correlationId = getCorrelationId();
    const context = typeof optionalParams[0] === 'string' ? optionalParams[0] : undefined;
    this.logger.warn(
      { correlationId, context },
      typeof message === 'object' ? JSON.stringify(message) : String(message)
    );
  }

  debug?(message: any, ...optionalParams: any[]) {
    const correlationId = getCorrelationId();
    const context = typeof optionalParams[0] === 'string' ? optionalParams[0] : undefined;
    this.logger.debug(
      { correlationId, context },
      typeof message === 'object' ? JSON.stringify(message) : String(message)
    );
  }

  verbose?(message: any, ...optionalParams: any[]) {
    const correlationId = getCorrelationId();
    const context = typeof optionalParams[0] === 'string' ? optionalParams[0] : undefined;
    this.logger.trace(
      { correlationId, context },
      typeof message === 'object' ? JSON.stringify(message) : String(message)
    );
  }
}
