import { PinoLoggerService } from './pino-logger.service';
import { traceStorage } from '../context/request-context';

describe('PinoLoggerService Unit Tests', () => {
  let logger: PinoLoggerService;

  beforeEach(() => {
    logger = new PinoLoggerService();
  });

  it('should be defined', () => {
    expect(logger).toBeDefined();
  });

  it('should log messages with trace correlation ID from AsyncLocalStorage', () => {
    const logSpy = jest.spyOn((logger as any).logger, 'info');

    traceStorage.run(
      {
        correlationId: 'test-trace-id-12345',
        schoolId: 'school-1',
        startTime: Date.now(),
      },
      () => {
        logger.log('Test message from service', 'TestContext');
        expect(logSpy).toHaveBeenCalledWith(
          expect.objectContaining({
            correlationId: 'test-trace-id-12345',
            context: 'TestContext',
          }),
          'Test message from service'
        );
      }
    );
  });

  it('should log errors with correlation ID and trace', () => {
    const errorSpy = jest.spyOn((logger as any).logger, 'error');

    logger.error('Test error message', 'TestContext', 'stack trace details');
    expect(errorSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        context: 'TestContext',
        trace: 'stack trace details',
      }),
      'Test error message'
    );
  });

  it('should log warnings with correlation ID', () => {
    const warnSpy = jest.spyOn((logger as any).logger, 'warn');

    logger.warn('Test warning message', 'TestContext');
    expect(warnSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        context: 'TestContext',
      }),
      'Test warning message'
    );
  });
});
