import { Injectable, Optional } from '@nestjs/common';
import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
  CipherGCM,
  DecipherGCM,
} from 'crypto';

export interface CryptoOptions {
  keyRegistry?: Record<string, string>; // e.g. { v1: 'hex32...', v2: 'hex32...' }
  activeVersion?: string; // default 'v1'
}

/**
 * Enterprise-grade AES-256-GCM Field-Level Encryption Service
 * Compliant with Digital Personal Data Protection (DPDP) Act 2023.
 *
 * Parameters:
 * - Cipher: aes-256-gcm
 * - Key Size: 256 bits (32 bytes)
 * - IV: 96 bits (12 bytes) random per encryption
 * - Auth Tag: 128 bits (16 bytes)
 * - Format: version:iv_hex:tag_hex:ciphertext_hex (e.g. v1:...)
 * - Optional Additional Authenticated Data (AAD) tenant binding
 */
@Injectable()
export class CryptoService {
  private readonly keyRegistry: Map<string, Buffer>;
  private readonly activeVersion: string;

  constructor(@Optional() options?: CryptoOptions) {
    this.keyRegistry = new Map();
    this.activeVersion = options?.activeVersion || 'v1';

    if (options?.keyRegistry && Object.keys(options.keyRegistry).length > 0) {
      for (const [ver, keyHex] of Object.entries(options.keyRegistry)) {
        this.registerKey(ver, keyHex);
      }
    } else {
      const envKey =
        process.env.APP_ENCRYPTION_KEY ||
        '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';
      this.registerKey('v1', envKey);
    }
  }

  /**
   * Registers a 256-bit (32-byte / 64-hex-char) key for a specific version
   */
  public registerKey(version: string, keyHex: string): void {
    const keyBuf = Buffer.from(keyHex, 'hex');
    if (keyBuf.length !== 32) {
      throw new Error(
        `Encryption key for version [${version}] must be exactly 32 bytes (64 hex characters). Received ${keyBuf.length} bytes.`
      );
    }
    this.keyRegistry.set(version, keyBuf);
  }

  /**
   * Encrypts plaintext string using AES-256-GCM with version prefix.
   * Output format: `${version}:${iv_hex}:${tag_hex}:${ciphertext_hex}`
   */
  public encrypt(plaintext: string | null | undefined, aad?: string): string | null {
    if (plaintext === null || plaintext === undefined || plaintext === '') {
      return null;
    }

    const key = this.keyRegistry.get(this.activeVersion);
    if (!key) {
      throw new Error(`Active key version [${this.activeVersion}] is not registered`);
    }

    // 12-byte (96-bit) IV for AES-GCM
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', key, iv) as CipherGCM;

    if (aad) {
      cipher.setAAD(Buffer.from(aad, 'utf8'));
    }

    const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();

    return `${this.activeVersion}:${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
  }

  /**
   * Decrypts versioned ciphertext string using AES-256-GCM.
   * Supports automatic multi-version key lookup for zero-downtime rotation.
   */
  public decrypt(ciphertext: string | null | undefined, aad?: string): string | null {
    if (ciphertext === null || ciphertext === undefined || ciphertext === '') {
      return null;
    }

    const parts = ciphertext.split(':');
    if (parts.length !== 4) {
      throw new Error(
        'Invalid encrypted format. Expected format: version:iv:tag:ciphertext'
      );
    }

    const [version, ivHex, tagHex, encryptedHex] = parts;

    const key = this.keyRegistry.get(version);
    if (!key) {
      throw new Error(`Encryption key for version [${version}] is not available in key registry`);
    }

    const iv = Buffer.from(ivHex, 'hex');
    const tag = Buffer.from(tagHex, 'hex');
    const encrypted = Buffer.from(encryptedHex, 'hex');

    if (iv.length !== 12) {
      throw new Error(`Invalid IV length: expected 12 bytes, got ${iv.length}`);
    }
    if (tag.length !== 16) {
      throw new Error(`Invalid auth tag length: expected 16 bytes, got ${tag.length}`);
    }

    const decipher = createDecipheriv('aes-256-gcm', key, iv) as DecipherGCM;
    decipher.setAuthTag(tag);

    if (aad) {
      decipher.setAAD(Buffer.from(aad, 'utf8'));
    }

    try {
      const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
      return decrypted.toString('utf8');
    } catch (err: any) {
      throw new Error(
        `Decryption failed: integrity authentication mismatch or corrupted ciphertext (${err.message})`
      );
    }
  }
}
