import { CryptoService } from './crypto.service';

describe('BOMIS Sambalpur - CryptoService (AES-256-GCM Field-Level Encryption)', () => {
  const TEST_KEY_V1 = '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';
  const TEST_KEY_V2 = 'fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210';

  let cryptoService: CryptoService;

  beforeEach(() => {
    cryptoService = new CryptoService({
      keyRegistry: {
        v1: TEST_KEY_V1,
        v2: TEST_KEY_V2,
      },
      activeVersion: 'v1',
    });
  });

  describe('Roundtrip Encryption and Decryption', () => {
    it('should correctly encrypt and decrypt medical blood group', () => {
      const plaintext = 'O+ (Positive)';
      const encrypted = cryptoService.encrypt(plaintext);

      expect(encrypted).not.toBeNull();
      expect(encrypted).toMatch(/^v1:[0-9a-f]{24}:[0-9a-f]{32}:[0-9a-f]+$/);

      const decrypted = cryptoService.decrypt(encrypted);
      expect(decrypted).toBe(plaintext);
    });

    it('should correctly encrypt and decrypt multi-line medical notes', () => {
      const notes =
        'Student has severe peanut allergy and mild asthma. In case of anaphylaxis, administer EpiPen located in infirmary.';
      const encrypted = cryptoService.encrypt(notes);
      const decrypted = cryptoService.decrypt(encrypted);
      expect(decrypted).toBe(notes);
    });

    it('should correctly encrypt and decrypt 12-digit Indian Aadhaar number', () => {
      const aadhaar = '9876 5432 1098';
      const encrypted = cryptoService.encrypt(aadhaar);
      const decrypted = cryptoService.decrypt(encrypted);
      expect(decrypted).toBe(aadhaar);
    });
  });

  describe('Probabilistic Encryption (IV Uniqueness)', () => {
    it('should produce different ciphertexts and IVs for identical plaintext inputs', () => {
      const plaintext = 'Confidential Income Data: INR 12,00,000';
      const enc1 = cryptoService.encrypt(plaintext)!;
      const enc2 = cryptoService.encrypt(plaintext)!;

      expect(enc1).not.toBe(enc2);

      const [, iv1] = enc1.split(':');
      const [, iv2] = enc2.split(':');
      expect(iv1).not.toBe(iv2);

      expect(cryptoService.decrypt(enc1)).toBe(plaintext);
      expect(cryptoService.decrypt(enc2)).toBe(plaintext);
    });
  });

  describe('Integrity & Tampering Defense', () => {
    it('should reject ciphertext with flipped bits', () => {
      const plaintext = 'Medical History Confidential';
      const encrypted = cryptoService.encrypt(plaintext)!;
      const parts = encrypted.split(':');

      // Tamper ciphertext
      const originalHex = parts[3]!;
      const tamperedHex =
        originalHex[0] === 'a' ? 'b' + originalHex.slice(1) : 'a' + originalHex.slice(1);
      const tampered = `${parts[0]}:${parts[1]}:${parts[2]}:${tamperedHex}`;

      expect(() => cryptoService.decrypt(tampered)).toThrow(/Decryption failed/);
    });

    it('should reject ciphertext with tampered authentication tag', () => {
      const plaintext = 'Medical Notes';
      const encrypted = cryptoService.encrypt(plaintext)!;
      const parts = encrypted.split(':');

      // Tamper tag
      const originalTag = parts[2]!;
      const tamperedTag =
        originalTag[0] === '0' ? '1' + originalTag.slice(1) : '0' + originalTag.slice(1);
      const tampered = `${parts[0]}:${parts[1]}:${tamperedTag}:${parts[3]}`;

      expect(() => cryptoService.decrypt(tampered)).toThrow(/Decryption failed/);
    });
  });

  describe('Additional Authenticated Data (AAD) Tenant Binding', () => {
    it('should succeed when tenant AAD matches during encryption and decryption', () => {
      const aad = 'tenant:e4b3c2a1-0001:entity:stu-001';
      const plaintext = 'Restricted Health Report';

      const encrypted = cryptoService.encrypt(plaintext, aad);
      const decrypted = cryptoService.decrypt(encrypted, aad);

      expect(decrypted).toBe(plaintext);
    });

    it('should reject decryption when AAD is swapped (cross-tenant attack defense)', () => {
      const tenantAAD1 = 'tenant:e4b3c2a1-0001:entity:stu-001';
      const tenantAAD2 = 'tenant:e4b3c2a1-0002:entity:stu-001';
      const plaintext = 'Restricted Health Report';

      const encrypted = cryptoService.encrypt(plaintext, tenantAAD1);

      expect(() => cryptoService.decrypt(encrypted, tenantAAD2)).toThrow(/Decryption failed/);
    });
  });

  describe('Key Versioning & Zero-Downtime Key Rotation', () => {
    it('should decrypt v1 records even when active key is changed to v2', () => {
      // Encrypt under v1
      const text = 'Historic Student Record';
      const v1Encrypted = cryptoService.encrypt(text)!;
      expect(v1Encrypted.startsWith('v1:')).toBe(true);

      // Rotate active version to v2
      const rotatedService = new CryptoService({
        keyRegistry: {
          v1: TEST_KEY_V1,
          v2: TEST_KEY_V2,
        },
        activeVersion: 'v2',
      });

      // Encrypt new record under v2
      const v2Encrypted = rotatedService.encrypt('New Student Record')!;
      expect(v2Encrypted.startsWith('v2:')).toBe(true);

      // Successfully decrypt old v1 record
      expect(rotatedService.decrypt(v1Encrypted)).toBe(text);
      // Successfully decrypt new v2 record
      expect(rotatedService.decrypt(v2Encrypted)).toBe('New Student Record');
    });

    it('should throw an error when decrypting with an unknown key version', () => {
      const unknownVersion = `v99:${'a'.repeat(24)}:${'b'.repeat(32)}:${'c'.repeat(32)}`;
      expect(() => cryptoService.decrypt(unknownVersion)).toThrow(
        /Encryption key for version \[v99\] is not available/
      );
    });
  });

  describe('Edge Cases & Input Validation', () => {
    it('should safely return null for null, undefined, or empty string', () => {
      expect(cryptoService.encrypt(null)).toBeNull();
      expect(cryptoService.encrypt(undefined)).toBeNull();
      expect(cryptoService.encrypt('')).toBeNull();

      expect(cryptoService.decrypt(null)).toBeNull();
      expect(cryptoService.decrypt(undefined)).toBeNull();
      expect(cryptoService.decrypt('')).toBeNull();
    });

    it('should reject malformed encrypted strings', () => {
      expect(() => cryptoService.decrypt('invalid-string')).toThrow(
        /Invalid encrypted format/
      );
      expect(() => cryptoService.decrypt('v1:only:three')).toThrow(
        /Invalid encrypted format/
      );
    });

    it('should throw when registering an invalid length key', () => {
      expect(() => cryptoService.registerKey('v3', 'shortkey')).toThrow(
        /must be exactly 32 bytes/
      );
    });
  });
});
