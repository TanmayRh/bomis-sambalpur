import { BadRequestException } from '@nestjs/common';
import { z } from 'zod';
import { ZodValidationPipe } from './zod-validation.pipe';

describe('ZodValidationPipe Unit Tests', () => {
  const TestSchema = z.object({
    name: z.string().min(2),
    age: z.number().positive(),
  });

  it('should pass through when no schema is present', () => {
    const pipe = new ZodValidationPipe();
    const data = { foo: 'bar' };
    const result = pipe.transform(data);
    expect(result).toBe(data);
  });

  it('should validate and return valid data using constructor schema', () => {
    const pipe = new ZodValidationPipe(TestSchema);
    const validData = { name: 'Aarav', age: 10 };
    const result = pipe.transform(validData);
    expect(result).toEqual(validData);
  });

  it('should throw BadRequestException when validation fails', () => {
    const pipe = new ZodValidationPipe(TestSchema);
    const invalidData = { name: 'A', age: -5 };

    expect(() => pipe.transform(invalidData)).toThrow(BadRequestException);
  });

  it('should validate using metatype schema when available', () => {
    const pipe = new ZodValidationPipe();
    class DtoWithSchema {
      static schema = TestSchema;
    }

    const validData = { name: 'Ananya', age: 7 };
    const result = pipe.transform(validData, {
      type: 'body',
      metatype: DtoWithSchema,
    });
    expect(result).toEqual(validData);
  });
});
