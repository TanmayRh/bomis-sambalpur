import {
  PipeTransform,
  Injectable,
  ArgumentMetadata,
  BadRequestException,
  Optional,
} from '@nestjs/common';
import { ZodSchema, ZodError } from 'zod';

@Injectable()
export class ZodValidationPipe implements PipeTransform {
  constructor(@Optional() private schema?: any) {}

  transform(value: any, metadata?: ArgumentMetadata) {
    const targetSchema = this.schema || (metadata?.metatype as any)?.schema;
    if (!targetSchema) {
      return value;
    }

    try {
      return targetSchema.parse(value);
    } catch (error) {
      if (error instanceof ZodError) {
        throw new BadRequestException({
          code: 'VALIDATION_FAILED',
          message: 'Input validation failed',
          details: error.errors.map((err) => ({
            field: err.path.join('.'),
            message: err.message,
            code: err.code,
          })),
        });
      }
      throw new BadRequestException({
        code: 'VALIDATION_FAILED',
        message: 'Input validation failed',
      });
    }
  }
}

export const UseZod = (schema: ZodSchema<any>) => new ZodValidationPipe(schema);
