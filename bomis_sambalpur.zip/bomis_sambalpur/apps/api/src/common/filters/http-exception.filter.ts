import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { ApiResponse } from '@bomis/shared';
import { ZodError } from 'zod';
import { traceStorage } from '../context/request-context';

@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const trace = traceStorage.getStore();
    const correlationId =
      trace?.correlationId ||
      (request.headers['x-correlation-id'] as string) ||
      (request.headers['x-request-id'] as string) ||
      (response.getHeader('x-correlation-id') as string) ||
      `corr-gen-${Date.now()}`;

    // Ensure outgoing header has correlation ID
    response.setHeader('x-correlation-id', correlationId);

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let errorCode = 'INTERNAL_SERVER_ERROR';
    let errorMessage = 'An unexpected server error occurred';
    let errorDetails: unknown = null;

    if (exception instanceof ZodError) {
      status = HttpStatus.BAD_REQUEST;
      errorCode = 'VALIDATION_FAILED';
      errorMessage = 'Input validation failed';
      errorDetails = exception.errors.map((err) => ({
        path: err.path.join('.'),
        message: err.message,
        code: err.code,
      }));
    } else if (exception instanceof HttpException) {
      status = exception.getStatus();
      const exceptionResponse = exception.getResponse();

      if (typeof exceptionResponse === 'string') {
        errorMessage = exceptionResponse;
        errorCode = this.mapStatusToErrorCode(status);
      } else if (
        typeof exceptionResponse === 'object' &&
        exceptionResponse !== null
      ) {
        const respObj = exceptionResponse as Record<string, any>;
        errorMessage = respObj.message || exception.message;
        errorCode =
          respObj.code ||
          respObj.error ||
          this.mapStatusToErrorCode(status);
        errorDetails = respObj.details || null;
      }

      if (!errorCode || errorCode === 'INTERNAL_SERVER_ERROR') {
        errorCode = this.mapStatusToErrorCode(status);
      }
    } else if (exception instanceof Error) {
      errorMessage = exception.message;
      this.logger.error(
        `[${correlationId}] Unhandled Exception: ${exception.message}`,
        exception.stack
      );
    }

    const envelope: ApiResponse<null> = {
      success: false,
      data: null,
      error: {
        code: errorCode,
        message: Array.isArray(errorMessage)
          ? errorMessage.join('; ')
          : errorMessage,
        details: errorDetails,
      },
      timestamp: new Date().toISOString(),
      correlationId,
    };

    response.status(status).json(envelope);
  }

  private mapStatusToErrorCode(status: number): string {
    switch (status) {
      case HttpStatus.BAD_REQUEST:
        return 'VALIDATION_FAILED';
      case HttpStatus.UNAUTHORIZED:
        return 'UNAUTHORIZED';
      case HttpStatus.FORBIDDEN:
        return 'FORBIDDEN';
      case HttpStatus.NOT_FOUND:
        return 'NOT_FOUND';
      case HttpStatus.CONFLICT:
        return 'CONFLICT';
      case HttpStatus.UNPROCESSABLE_ENTITY:
        return 'UNPROCESSABLE_ENTITY';
      case HttpStatus.TOO_MANY_REQUESTS:
        return 'TOO_MANY_REQUESTS';
      case HttpStatus.SERVICE_UNAVAILABLE:
        return 'SERVICE_UNAVAILABLE';
      default:
        return 'INTERNAL_SERVER_ERROR';
    }
  }
}
