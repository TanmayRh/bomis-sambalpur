import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { UserRole } from '@bomis/shared';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (isPublic) {
      return true;
    }

    const requiredRoles = this.reflector.getAllAndOverride<(UserRole | string)[]>(
      ROLES_KEY,
      [context.getHandler(), context.getClass()]
    );

    if (!requiredRoles || requiredRoles.length === 0) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user || !user.role) {
      throw new ForbiddenException({
        code: 'INSUFFICIENT_PERMISSIONS',
        message: 'Access denied: User role could not be verified',
      });
    }

    // SUPER_ADMIN has universal access
    if (user.role === UserRole.SUPER_ADMIN || user.role === 'SUPER_ADMIN') {
      return true;
    }

    const normalizedUserRole =
      user.role === 'DRIVER_TRANSPORT'
        ? UserRole.TRANSPORT_STAFF
        : (user.role as UserRole);

    const hasRole = requiredRoles.some((r) => {
      if (r === normalizedUserRole || r === user.role) {
        return true;
      }
      if (
        (r === UserRole.TRANSPORT_STAFF || r === 'TRANSPORT_STAFF') &&
        (user.role === 'DRIVER_TRANSPORT' || user.role === 'TRANSPORT_STAFF')
      ) {
        return true;
      }
      return false;
    });

    if (!hasRole) {
      throw new ForbiddenException({
        code: 'INSUFFICIENT_PERMISSIONS',
        message: `Role [${user.role}] is not authorized to access this resource`,
      });
    }

    return true;
  }
}
