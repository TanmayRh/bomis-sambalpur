import { ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { RolesGuard } from './roles.guard';
import { UserRole } from '@bomis/shared';

describe('RolesGuard & RBAC Negative Gates Unit Tests', () => {
  let guard: RolesGuard;
  let reflector: Reflector;

  beforeEach(() => {
    reflector = new Reflector();
    guard = new RolesGuard(reflector);
  });

  function createMockExecutionContext(userRole?: string | UserRole, isPublic = false): ExecutionContext {
    return {
      switchToHttp: () => ({
        getRequest: () => ({
          user: userRole ? { id: 'u1', role: userRole } : null,
        }),
      }),
      getHandler: () => ({}),
      getClass: () => ({}),
    } as any;
  }

  describe('Postman Folder 08 RBAC Negative Gates', () => {
    it('Negative Gate 1: should reject STUDENT from modifying marks (403 Forbidden)', () => {
      // Endpoint: POST /api/v1/academics/marks/batch
      jest.spyOn(reflector, 'getAllAndOverride').mockImplementation((key) => {
        if (key === 'roles') {
          return [UserRole.TEACHER, UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL];
        }
        return false;
      });

      const context = createMockExecutionContext(UserRole.STUDENT);
      expect(() => guard.canActivate(context)).toThrow(ForbiddenException);
    });

    it('Negative Gate 2: should reject TRANSPORT_STAFF (driver) from viewing fee structures (403 Forbidden)', () => {
      // Endpoint: GET /api/v1/fees/structures
      jest.spyOn(reflector, 'getAllAndOverride').mockImplementation((key) => {
        if (key === 'roles') {
          return [UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.PRINCIPAL, UserRole.ACCOUNTANT, UserRole.PARENT];
        }
        return false;
      });

      const context = createMockExecutionContext(UserRole.TRANSPORT_STAFF);
      expect(() => guard.canActivate(context)).toThrow(ForbiddenException);

      const driverContext = createMockExecutionContext('DRIVER_TRANSPORT');
      expect(() => guard.canActivate(driverContext)).toThrow(ForbiddenException);
    });

    it('Negative Gate 3: should reject PARENT from accessing admin audit logs (403 Forbidden)', () => {
      // Endpoint: GET /api/v1/admin/audit-logs
      jest.spyOn(reflector, 'getAllAndOverride').mockImplementation((key) => {
        if (key === 'roles') {
          return [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.ACCOUNTANT];
        }
        return false;
      });

      const context = createMockExecutionContext(UserRole.PARENT);
      expect(() => guard.canActivate(context)).toThrow(ForbiddenException);
    });
  });

  describe('Permitted Roles & SuperAdmin Pass-Through', () => {
    it('should permit SUPER_ADMIN access to any protected resource regardless of roles required', () => {
      jest.spyOn(reflector, 'getAllAndOverride').mockImplementation((key) => {
        if (key === 'roles') return [UserRole.ACCOUNTANT];
        return false;
      });

      const context = createMockExecutionContext(UserRole.SUPER_ADMIN);
      expect(guard.canActivate(context)).toBe(true);
    });

    it('should permit user when user role is in required roles list', () => {
      jest.spyOn(reflector, 'getAllAndOverride').mockImplementation((key) => {
        if (key === 'roles') return [UserRole.ADMIN, UserRole.PRINCIPAL];
        return false;
      });

      const context = createMockExecutionContext(UserRole.ADMIN);
      expect(guard.canActivate(context)).toBe(true);
    });

    it('should allow access if endpoint is marked @Public()', () => {
      jest.spyOn(reflector, 'getAllAndOverride').mockImplementation((key) => {
        if (key === 'isPublic') return true;
        return [UserRole.ADMIN];
      });

      const context = createMockExecutionContext(undefined, true);
      expect(guard.canActivate(context)).toBe(true);
    });
  });
});
