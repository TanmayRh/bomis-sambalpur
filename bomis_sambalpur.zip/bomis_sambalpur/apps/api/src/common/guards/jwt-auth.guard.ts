import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import * as jwt from 'jsonwebtoken';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';

export const JWT_SECRET = process.env.JWT_SECRET || 'bomis_jwt_secret_sambalpur_2026';

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (isPublic) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const authHeader = request.headers['authorization'];

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException({
        code: 'UNAUTHORIZED',
        message: 'Missing or malformed Authorization header with Bearer token',
      });
    }

    const token = authHeader.substring(7).trim();
    if (!token) {
      throw new UnauthorizedException({
        code: 'UNAUTHORIZED',
        message: 'Empty Bearer token',
      });
    }

    try {
      const decoded = jwt.verify(token, JWT_SECRET) as Record<string, any>;
      const user = {
        id: decoded.sub || decoded.id || decoded.userId,
        userId: decoded.sub || decoded.id || decoded.userId,
        email: decoded.email,
        phone: decoded.phone,
        role: decoded.role,
        schoolId: decoded.schoolId || 'e4b3c2a1-0001-4000-8000-000000000001',
        jti: decoded.jti,
      };

      request.user = user;
      return true;
    } catch (err: any) {
      throw new UnauthorizedException({
        code: 'UNAUTHORIZED',
        message: `Invalid or expired access token: ${err.message}`,
      });
    }
  }
}
