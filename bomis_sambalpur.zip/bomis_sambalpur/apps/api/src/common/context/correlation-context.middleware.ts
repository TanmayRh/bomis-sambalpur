import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { randomUUID } from 'crypto';
import { traceStorage, RequestTraceContext } from './request-context';

export const SEED_SCHOOL_ID = 'e4b3c2a1-0001-4000-8000-000000000001';
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function resolveSchoolId(rawHeaderOrToken?: string): string {
  if (!rawHeaderOrToken || rawHeaderOrToken.trim() === '') {
    return SEED_SCHOOL_ID;
  }
  if (UUID_REGEX.test(rawHeaderOrToken)) {
    return rawHeaderOrToken;
  }
  if (
    rawHeaderOrToken === 'sch_bomis_sambalpur_001' ||
    rawHeaderOrToken === 'BOMIS-SBP' ||
    rawHeaderOrToken === 'default'
  ) {
    return SEED_SCHOOL_ID;
  }
  return SEED_SCHOOL_ID;
}

@Injectable()
export class CorrelationContextMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction): void {
    const rawCorrId =
      (req.headers['x-correlation-id'] as string) ||
      (req.headers['x-request-id'] as string);

    const correlationId =
      rawCorrId && rawCorrId.trim() !== ''
        ? rawCorrId.trim()
        : `corr-${randomUUID()}`;

    const rawSchoolId = (req.headers['x-school-id'] as string) || undefined;
    const schoolId = resolveSchoolId(rawSchoolId);

    // Echo correlation ID back on response header immediately
    res.setHeader('x-correlation-id', correlationId);

    const context: RequestTraceContext = {
      correlationId,
      schoolId,
      startTime: Date.now(),
    };

    traceStorage.run(context, () => {
      next();
    });
  }
}
