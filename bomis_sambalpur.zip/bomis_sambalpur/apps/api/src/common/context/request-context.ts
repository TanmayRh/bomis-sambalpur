import { AsyncLocalStorage } from 'async_hooks';

export interface RequestTraceContext {
  correlationId: string;
  schoolId: string;
  userId?: string;
  userRole?: string;
  startTime: number;
}

export const traceStorage = new AsyncLocalStorage<RequestTraceContext>();

export function getTraceContext(): RequestTraceContext | undefined {
  return traceStorage.getStore();
}

export function getCorrelationId(): string {
  const store = traceStorage.getStore();
  return store?.correlationId || `corr-${Date.now()}`;
}

export function getSchoolId(): string {
  const store = traceStorage.getStore();
  return store?.schoolId || 'e4b3c2a1-0001-4000-8000-000000000001';
}
