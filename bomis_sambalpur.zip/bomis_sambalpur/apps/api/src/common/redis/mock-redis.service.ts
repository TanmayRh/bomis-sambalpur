import { Injectable, Logger } from '@nestjs/common';

export interface CacheEntry<T = any> {
  value: T;
  expiresAt: number;
}

@Injectable()
export class MockRedisService {
  private readonly logger = new Logger(MockRedisService.name);
  private readonly store = new Map<string, CacheEntry>();
  private readonly locks = new Map<string, number>();

  async get<T = string>(key: string): Promise<T | null> {
    const entry = this.store.get(key);
    if (!entry) {
      return null;
    }
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return entry.value as T;
  }

  async set(key: string, value: any, ttlSeconds = 300): Promise<void> {
    const expiresAt = Date.now() + ttlSeconds * 1000;
    this.store.set(key, { value, expiresAt });
  }

  async del(key: string): Promise<void> {
    this.store.delete(key);
  }

  /**
   * Distributed lock simulation (SETNX with TTL)
   * Returns true if lock acquired, false if already locked.
   */
  async acquireLock(lockKey: string, ttlSeconds = 30): Promise<boolean> {
    const now = Date.now();
    const existing = this.locks.get(lockKey);
    if (existing && now < existing) {
      return false; // Still locked
    }
    this.locks.set(lockKey, now + ttlSeconds * 1000);
    return true;
  }

  async releaseLock(lockKey: string): Promise<void> {
    this.locks.delete(lockKey);
  }

  /**
   * Idempotency cache check
   */
  async getIdempotentResult<T = any>(key: string): Promise<T | null> {
    return this.get<T>(`idemp:${key}`);
  }

  async setIdempotentResult(key: string, result: any, ttlSeconds = 86400): Promise<void> {
    await this.set(`idemp:${key}`, result, ttlSeconds);
  }
}
