import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { MockStoreService } from './mock-store.service';
import { MockRedisService } from '../common/redis/mock-redis.service';
import { CryptoService } from '../common/crypto/crypto.service';

@Global()
@Module({
  providers: [MockStoreService, PrismaService, MockRedisService, CryptoService],
  exports: [MockStoreService, PrismaService, MockRedisService, CryptoService],
})
export class DatabaseModule {}
