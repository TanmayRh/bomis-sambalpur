import {
  Injectable,
  OnModuleInit,
  OnModuleDestroy,
  Logger,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { MockStoreService } from './mock-store.service';
import { resolveSchoolId } from '../common/context/correlation-context.middleware';

@Injectable()
export class PrismaService
  extends PrismaClient
  implements OnModuleInit, OnModuleDestroy
{
  private readonly logger = new Logger(PrismaService.name);
  public isConnected = false;
  public isMock = false;

  constructor(public readonly mockStore: MockStoreService) {
    super({
      log:
        process.env.NODE_ENV === 'development'
          ? ['error', 'warn']
          : ['error'],
    });
  }

  async onModuleInit() {
    if (process.env.USE_MOCK_DB === 'true') {
      this.isMock = true;
      this.logger.log('PrismaService: USE_MOCK_DB is true. Activated In-Memory Mock Store.');
      return;
    }

    try {
      // 1500ms connection probe timeout to prevent hanging when offline
      await Promise.race([
        this.$connect(),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('PostgreSQL connection timeout (1500ms)')), 1500)
        ),
      ]);
      this.isConnected = true;
      this.isMock = false;
      this.logger.log('PrismaService: Connected to PostgreSQL database successfully.');
    } catch (err: any) {
      this.isMock = true;
      this.isConnected = false;
      this.logger.warn(
        `PrismaService: PostgreSQL unavailable (${err.message}). Seamlessly activated In-Memory Mock Store.`
      );
    }
  }

  async onModuleDestroy() {
    if (this.isConnected) {
      await this.$disconnect();
    }
  }

  /**
   * Dual-Layer Tenant Isolation: Interactive PostgreSQL Transaction with kernel RLS
   */
  async withTenantTransaction<T>(
    schoolId: string,
    callback: (tx: any) => Promise<T>
  ): Promise<T> {
    const tenantId = resolveSchoolId(schoolId);
    if (this.isMock) {
      return await callback(this);
    }

    return await this.$transaction(async (tx) => {
      await tx.$executeRawUnsafe(
        `SET LOCAL app.current_school_id = '${tenantId}';`
      );
      return await callback(tx);
    });
  }
}
