import * as bcrypt from 'bcrypt';

export const SEED_IDS = {
  SCHOOL: 'e4b3c2a1-0001-4000-8000-000000000001',
  ACADEMIC_YEAR: 'e4b3c2a1-0002-4000-8000-000000000001',
  CLASS_GRADE_5: 'c1000000-0005-4000-8000-000000000001',
  SECTION_GRADE_5A: 's1000000-0005-4000-8000-000000000001',
  USER_SUPERADMIN: 'u1000000-0000-4000-8000-000000000001',
  USER_ADMIN: 'u1000000-0003-4000-8000-000000000001',
  USER_PRINCIPAL: 'u1000000-0002-4000-8000-000000000001',
  USER_ACCOUNTANT: 'u1000000-0004-4000-8000-000000000001',
  USER_TEACHER_G5A: 'u1000000-0010-4000-8000-000000000001',
  STAFF_TEACHER_G5A: 'm1000000-0010-4000-8000-000000000001',
  USER_PARENT_PATEL: 'u1000000-0101-4000-8000-000000000001',
  GUARDIAN_PATEL: 'g1000000-0001-4000-8000-000000000001',
  STUDENT_AARAV: 'b1000000-0005-4000-8000-000000000001',
  STUDENT_ANANYA: 'b1000000-0002-4000-8000-000000000001',
  USER_STUDENT_AARAV: 'u1000000-0501-4000-8000-000000000001',
  USER_DRIVER_BHOI: 'u1000000-0020-4000-8000-000000000001',
  STAFF_DRIVER_BHOI: 'm1000000-0020-4000-8000-000000000001',
  BUS_PILOT_01: 'v1000000-0001-4000-8000-000000000001',
  BUS_PILOT_02: 'v1000000-0002-4000-8000-000000000001',
  BUS_PILOT_03: 'v1000000-0003-4000-8000-000000000001',
  BUS_PILOT_04: 'v1000000-0004-4000-8000-000000000001',
  ROUTE_BUDHARAJA: 'r1000000-0001-4000-8000-000000000001',
  ROUTE_KHETRAJPUR: 'r1000000-0002-4000-8000-000000000001',
  ROUTE_DHANUPALI: 'r1000000-0003-4000-8000-000000000001',
  ROUTE_BURLA: 'r1000000-0004-4000-8000-000000000001',
  STOP_SAKHIPADA: 'p1000000-0001-4000-8000-000000000002',
  TERM_1: 't1000000-0001-4000-8000-000000000001',
  TERM_2: 't1000000-0002-4000-8000-000000000001',
};

export const SYMBOLIC_ID_MAP: Record<string, string> = {
  sch_bomis_sambalpur_001: SEED_IDS.SCHOOL,
  'BOMIS-SBP': SEED_IDS.SCHOOL,
  stu_grade5a_001: SEED_IDS.STUDENT_AARAV,
  cls_grade_5: SEED_IDS.CLASS_GRADE_5,
  sec_grade_5_a: SEED_IDS.SECTION_GRADE_5A,
  usr_teacher_g5a_001: SEED_IDS.STAFF_TEACHER_G5A,
  grd_parent_001: SEED_IDS.GUARDIAN_PATEL,
  bus_pilot_01: SEED_IDS.BUS_PILOT_01,
  rt_khetrajpur_campus: SEED_IDS.ROUTE_KHETRAJPUR,
  trm_2026_term_1: SEED_IDS.TERM_1,
  sub_mathematics_001: 'sub_math_g5_001',
  stop_sakhipada_01: SEED_IDS.STOP_SAKHIPADA,
};

export function resolveEntityId(idOrSymbol?: string): string {
  if (!idOrSymbol) return '';
  return SYMBOLIC_ID_MAP[idOrSymbol] || idOrSymbol;
}

export const STAFF_PASSWORD_HASH = bcrypt.hashSync('Admin@Sambalpur2026', 10);
export const PARENT_PASSWORD_HASH = bcrypt.hashSync('Bomis@Sambalpur2026', 10);

export function buildInitialData() {
  const S = SEED_IDS.SCHOOL;
  const school = {
    id: S,
    name: 'Birla Open Minds International School, Sambalpur',
    code: 'BOMIS-SBP',
    affiliation_number: '1530284',
    address: 'NH-53 Bypass Road, Near Remed Chhak',
    city: 'Sambalpur',
    state: 'Odisha',
    postal_code: '768006',
    phone: '+919437000001',
    email: 'info@bomis-sambalpur.edu.in',
    status: 'ACTIVE',
  };

  const academicYear = {
    id: SEED_IDS.ACADEMIC_YEAR,
    school_id: S,
    name: '2026-2027',
    start_date: new Date('2026-04-01T00:00:00.000Z'),
    end_date: new Date('2027-03-31T23:59:59.999Z'),
    is_current: true,
  };

  const classes: any[] = [];
  const sections: any[] = [];
  for (let g = 1; g <= 8; g++) {
    const cid = g === 5 ? SEED_IDS.CLASS_GRADE_5 : `c1000000-000${g}-4000-8000-000000000001`;
    const sid = g === 5 ? SEED_IDS.SECTION_GRADE_5A : `s1000000-000${g}-4000-8000-000000000001`;
    classes.push({ id: cid, school_id: S, name: `Grade ${g}`, code: `G${g}`, grade_level: g, order_index: g });
    sections.push({ id: sid, school_id: S, class_id: cid, name: 'A', capacity: 35, room_number: `Room ${g <= 4 ? 100 + g : 200 + (g - 4)}`, class_teacher_id: g === 5 ? SEED_IDS.STAFF_TEACHER_G5A : null });
  }

  const subjects = [
    { id: 'sub_math_g5_001', school_id: S, name: 'Mathematics', code: 'MTH-101', is_scholastic: true },
    { id: 'sub_eng_g5_001', school_id: S, name: 'English Communicative', code: 'ENG-101', is_scholastic: true },
    { id: 'sub_hin_g5_001', school_id: S, name: 'Hindi Course B', code: 'HIN-101', is_scholastic: true },
    { id: 'sub_odi_g5_001', school_id: S, name: 'Odia Language', code: 'ODI-101', is_scholastic: true },
    { id: 'sub_sci_g5_001', school_id: S, name: 'General Science', code: 'SCI-101', is_scholastic: true },
    { id: 'sub_sst_g5_001', school_id: S, name: 'Social Studies', code: 'SST-101', is_scholastic: true },
  ];

  const users: any[] = [
    { id: SEED_IDS.USER_SUPERADMIN, school_id: S, email: 'superadmin@bomis-sambalpur.edu.in', phone: '+919437000000', password_hash: STAFF_PASSWORD_HASH, role: 'SUPER_ADMIN', status: 'ACTIVE', first_name: 'Platform', last_name: 'SuperAdmin' },
    { id: SEED_IDS.USER_ADMIN, school_id: S, email: 'admin@bomis-sambalpur.edu.in', phone: '+919437000003', password_hash: STAFF_PASSWORD_HASH, role: 'ADMIN', status: 'ACTIVE', first_name: 'Amit Kumar', last_name: 'Senapati' },
    { id: SEED_IDS.USER_PRINCIPAL, school_id: S, email: 'principal@bomis-sambalpur.edu.in', phone: '+919437000002', password_hash: STAFF_PASSWORD_HASH, role: 'PRINCIPAL', status: 'ACTIVE', first_name: 'Dr. Minati', last_name: 'Mohanty' },
    { id: SEED_IDS.USER_ACCOUNTANT, school_id: S, email: 'accountant@bomis-sambalpur.edu.in', phone: '+919437000004', password_hash: STAFF_PASSWORD_HASH, role: 'ACCOUNTANT', status: 'ACTIVE', first_name: 'Birendra Nath', last_name: 'Sahu' },
    { id: SEED_IDS.USER_TEACHER_G5A, school_id: S, email: 'arundhati.dash@bomis-sambalpur.edu.in', phone: '+919437100005', password_hash: STAFF_PASSWORD_HASH, role: 'TEACHER', status: 'ACTIVE', first_name: 'Arundhati', last_name: 'Dash' },
    { id: SEED_IDS.USER_PARENT_PATEL, school_id: S, email: 'rajesh.patel@example.com', phone: '+919876543210', password_hash: PARENT_PASSWORD_HASH, role: 'PARENT', status: 'ACTIVE', first_name: 'Dr. Rajesh Kumar', last_name: 'Patel' },
    { id: SEED_IDS.USER_STUDENT_AARAV, school_id: S, email: 'aarav.patel@student.bomis-sambalpur.edu.in', phone: '+919876543211', password_hash: PARENT_PASSWORD_HASH, role: 'STUDENT', status: 'ACTIVE', first_name: 'Aarav', last_name: 'Patel' },
    { id: SEED_IDS.USER_DRIVER_BHOI, school_id: S, email: 'driver.bhoi@bomis-sambalpur.edu.in', phone: '+919437200001', password_hash: STAFF_PASSWORD_HASH, role: 'TRANSPORT_STAFF', status: 'ACTIVE', first_name: 'Maheswar', last_name: 'Bhoi' },
  ];

  const staff: any[] = [
    { id: SEED_IDS.STAFF_TEACHER_G5A, school_id: S, user_id: SEED_IDS.USER_TEACHER_G5A, employee_id: 'STF-BOMIS-010', designation: 'TGT Mathematics', department: 'Academics', first_name: 'Arundhati', last_name: 'Dash', email: 'arundhati.dash@bomis-sambalpur.edu.in' },
    { id: 'm1000000-0003-4000-8000-000000000001', school_id: S, user_id: SEED_IDS.USER_ADMIN, employee_id: 'STF-BOMIS-003', designation: 'Campus Administrator', department: 'Administration', first_name: 'Amit Kumar', last_name: 'Senapati', email: 'admin@bomis-sambalpur.edu.in' },
    { id: 'm1000000-0002-4000-8000-000000000001', school_id: S, user_id: SEED_IDS.USER_PRINCIPAL, employee_id: 'STF-BOMIS-002', designation: 'Principal', department: 'Executive', first_name: 'Dr. Minati', last_name: 'Mohanty', email: 'principal@bomis-sambalpur.edu.in' },
    { id: 'm1000000-0004-4000-8000-000000000001', school_id: S, user_id: SEED_IDS.USER_ACCOUNTANT, employee_id: 'STF-BOMIS-004', designation: 'Senior Accountant', department: 'Accounts', first_name: 'Birendra Nath', last_name: 'Sahu', email: 'accountant@bomis-sambalpur.edu.in' },
    { id: SEED_IDS.STAFF_DRIVER_BHOI, school_id: S, user_id: SEED_IDS.USER_DRIVER_BHOI, employee_id: 'DRV-BOMIS-001', designation: 'Senior Fleet Pilot', department: 'Transport', first_name: 'Maheswar', last_name: 'Bhoi', email: 'driver.bhoi@bomis-sambalpur.edu.in' },
  ];

  const guardians: any[] = [
    { id: SEED_IDS.GUARDIAN_PATEL, school_id: S, user_id: SEED_IDS.USER_PARENT_PATEL, first_name: 'Rajesh Kumar', last_name: 'Patel', relationship: 'Father', emergency_phone: '+919876543210' },
  ];

  const students: any[] = [
    { id: SEED_IDS.STUDENT_AARAV, school_id: S, admission_number: 'BOMIS-2021-0042', roll_number: '1', first_name: 'Aarav', last_name: 'Patel', date_of_birth: new Date('2015-08-14'), gender: 'MALE', class_id: SEED_IDS.CLASS_GRADE_5, section_id: SEED_IDS.SECTION_GRADE_5A, academic_year_id: academicYear.id, emergency_contact: '+919876543210', blood_group: 'O+', grade: 5, section: 'A', house: 'KALINGA', is_active: true, deleted_at: null },
    { id: SEED_IDS.STUDENT_ANANYA, school_id: S, admission_number: 'BOMIS-2024-0118', roll_number: '4', first_name: 'Ananya', last_name: 'Patel', date_of_birth: new Date('2018-11-20'), gender: 'FEMALE', class_id: 'c1000000-0002-4000-8000-000000000001', section_id: 's1000000-0002-4000-8000-000000000001', academic_year_id: academicYear.id, emergency_contact: '+919876543210', blood_group: 'B+', grade: 2, section: 'A', house: 'KALINGA', is_active: true, deleted_at: null },
  ];

  const studentGuardians: any[] = [
    { id: 'sg-001', school_id: S, student_id: SEED_IDS.STUDENT_AARAV, guardian_id: SEED_IDS.GUARDIAN_PATEL, relation_type: 'Father', is_primary_contact: true, can_pickup: true },
    { id: 'sg-002', school_id: S, student_id: SEED_IDS.STUDENT_ANANYA, guardian_id: SEED_IDS.GUARDIAN_PATEL, relation_type: 'Father', is_primary_contact: true, can_pickup: true },
  ];

  const terms: any[] = [
    { id: SEED_IDS.TERM_1, school_id: S, academic_year_id: academicYear.id, name: 'Term 1 Exam (Autumn 2026)', term: 'TERM_1', start_date: new Date('2026-09-15'), end_date: new Date('2026-09-28'), is_published: true },
    { id: SEED_IDS.TERM_2, school_id: S, academic_year_id: academicYear.id, name: 'Term 2 Exam (Spring 2027)', term: 'TERM_2', start_date: new Date('2027-02-15'), end_date: new Date('2027-02-28'), is_published: false },
  ];

  const routes: any[] = [
    { id: SEED_IDS.ROUTE_BUDHARAJA, school_id: S, name: 'Route 1 - Budharaja Shuttle', code: 'RT-BUDHARAJA-01', start_point: 'Budharaja Fatak', end_point: 'BOMIS Campus Gate', stops: [{ id: 'st-01', name: 'Budharaja Fatak', lat: 21.4825, lng: 83.9782, order: 1 }, { id: SEED_IDS.STOP_SAKHIPADA, name: 'Sakhipada Chhak', lat: 21.4669, lng: 83.9812, order: 2 }, { id: 'st-03', name: 'Ainthapali Chowk', lat: 21.493, lng: 83.987, order: 3 }, { id: 'st-04', name: 'BOMIS Campus Gate', lat: 21.4938, lng: 83.9855, order: 4 }] },
    { id: SEED_IDS.ROUTE_KHETRAJPUR, school_id: S, name: 'Route 2 - Khetrajpur Express', code: 'RT-KHETRAJPUR-02', start_point: 'Khetrajpur Station', end_point: 'BOMIS Campus Gate', stops: [{ id: 'st-05', name: 'Khetrajpur Railway Station', lat: 21.4812, lng: 83.9554, order: 1 }, { id: 'st-06', name: 'Modipara Chowk', lat: 21.4745, lng: 83.968, order: 2 }, { id: 'st-07', name: 'Golebazar Market', lat: 21.464, lng: 83.972, order: 3 }, { id: 'st-08', name: 'BOMIS Campus Gate', lat: 21.4938, lng: 83.9855, order: 4 }] },
    { id: SEED_IDS.ROUTE_DHANUPALI, school_id: S, name: 'Route 3 - Dhanupali & Brooks Hill', code: 'RT-DHANUPALI-03', start_point: 'Dhanupali Market', end_point: 'BOMIS Campus Gate', stops: [{ id: 'st-09', name: 'Dhanupali Chhak', lat: 21.4468, lng: 83.985, order: 1 }, { id: 'st-10', name: 'Brooks Hill Overbridge', lat: 21.458, lng: 83.979, order: 2 }, { id: 'st-11', name: 'Bareipali Gate', lat: 21.505, lng: 83.992, order: 3 }, { id: 'st-12', name: 'BOMIS Campus Gate', lat: 21.4938, lng: 83.9855, order: 4 }] },
    { id: SEED_IDS.ROUTE_BURLA, school_id: S, name: 'Route 4 - Burla University Corridor', code: 'RT-BURLA-04', start_point: 'Burla Medical College', end_point: 'BOMIS Campus Gate', stops: [{ id: 'st-13', name: 'Burla Medical College Chhak', lat: 21.498, lng: 83.871, order: 1 }, { id: 'st-14', name: 'VSSUT Engineering Campus Gate', lat: 21.503, lng: 83.877, order: 2 }, { id: 'st-15', name: 'Sambalpur University PG Gate', lat: 21.5085, lng: 83.882, order: 3 }, { id: 'st-16', name: 'Remed Bypass Chowk', lat: 21.501, lng: 83.935, order: 4 }, { id: 'st-17', name: 'BOMIS Campus Gate', lat: 21.4938, lng: 83.9855, order: 5 }] },
  ];

  const vehicles: any[] = [
    { id: SEED_IDS.BUS_PILOT_01, school_id: S, registration_number: 'OD-15-AB-1001', bus_number: 'Bus 01', capacity: 24, model: 'Tata Winger School Bus (2024)', driver_staff_id: SEED_IDS.STAFF_DRIVER_BHOI, current_route_id: SEED_IDS.ROUTE_BUDHARAJA, status: 'ACTIVE', telemetry: { lat: 21.4669, lng: 83.9812, speed: 28, heading: 45, lastPing: new Date() } },
    { id: SEED_IDS.BUS_PILOT_02, school_id: S, registration_number: 'OD-15-AB-1002', bus_number: 'Bus 02', capacity: 24, model: 'Force Traveller Smart School (2024)', driver_staff_id: SEED_IDS.STAFF_DRIVER_BHOI, current_route_id: SEED_IDS.ROUTE_KHETRAJPUR, status: 'ACTIVE', telemetry: { lat: 21.4812, lng: 83.9554, speed: 32, heading: 90, lastPing: new Date() } },
    { id: SEED_IDS.BUS_PILOT_03, school_id: S, registration_number: 'OD-15-AB-1003', bus_number: 'Bus 03', capacity: 24, model: 'Mahindra Tourister School (2023)', driver_staff_id: SEED_IDS.STAFF_DRIVER_BHOI, current_route_id: SEED_IDS.ROUTE_DHANUPALI, status: 'ACTIVE', telemetry: { lat: 21.4468, lng: 83.985, speed: 25, heading: 180, lastPing: new Date() } },
    { id: SEED_IDS.BUS_PILOT_04, school_id: S, registration_number: 'OD-15-AC-2001', bus_number: 'Bus 04', capacity: 52, model: 'Ashok Leyland Sunshine (2025)', driver_staff_id: SEED_IDS.STAFF_DRIVER_BHOI, current_route_id: SEED_IDS.ROUTE_BURLA, status: 'ACTIVE', telemetry: { lat: 21.498, lng: 83.871, speed: 40, heading: 270, lastPing: new Date() } },
  ];

  const feeStructures: any[] = [
    { id: 'fs-01', school_id: S, class_id: SEED_IDS.CLASS_GRADE_5, grade: 5, academic_year: '2026-2027', category: 'Tuition Fee', total_amount: 45000, frequency: 'TERM' },
    { id: 'fs-02', school_id: S, class_id: SEED_IDS.CLASS_GRADE_5, grade: 5, academic_year: '2026-2027', category: 'Science & Computer Lab Fee', total_amount: 8000, frequency: 'TERM' },
    { id: 'fs-03', school_id: S, class_id: SEED_IDS.CLASS_GRADE_5, grade: 5, academic_year: '2026-2027', category: 'Annual Activity & Sports Fee', total_amount: 4500, frequency: 'ANNUAL' },
    { id: 'fs-04', school_id: S, class_id: SEED_IDS.CLASS_GRADE_5, grade: 5, academic_year: '2026-2027', category: 'Transport Fee (Budharaja Slab 0-5km)', total_amount: 12000, frequency: 'TERM' },
  ];

  return { school, academicYear, classes, sections, subjects, users, staff, guardians, students, studentGuardians, terms, routes, vehicles, feeStructures };
}
