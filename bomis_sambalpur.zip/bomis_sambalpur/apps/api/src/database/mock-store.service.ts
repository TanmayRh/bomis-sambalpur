import { Injectable, Logger } from '@nestjs/common';
import { randomUUID } from 'crypto';
import {
  SEED_IDS,
  buildInitialData,
  resolveEntityId,
} from './seed-fixtures';
import { CryptoService } from '../common/crypto/crypto.service';

@Injectable()
export class MockStoreService {
  private readonly logger = new Logger(MockStoreService.name);

  // In-memory collections
  public readonly schools = new Map<string, any>();
  public readonly academicYears = new Map<string, any>();
  public readonly classes = new Map<string, any>();
  public readonly sections = new Map<string, any>();
  public readonly subjects = new Map<string, any>();
  public readonly users = new Map<string, any>();
  public readonly staff = new Map<string, any>();
  public readonly guardians = new Map<string, any>();
  public readonly students = new Map<string, any>();
  public readonly studentGuardians = new Map<string, any>();
  public readonly terms = new Map<string, any>();
  public readonly routes = new Map<string, any>();
  public readonly vehicles = new Map<string, any>();
  public readonly feeStructures = new Map<string, any>();
  public readonly feeInstallments = new Map<string, any>();
  public readonly payments = new Map<string, any>();
  public readonly attendance = new Map<string, any>();
  public readonly marks = new Map<string, any>();
  public readonly substitutions = new Map<string, any>();
  public readonly boardingEvents = new Map<string, any>();
  public readonly telemetry = new Map<string, any>();
  public readonly visitorPasses = new Map<string, any>();
  public readonly incidents = new Map<string, any>();
  public readonly concessions = new Map<string, any>();
  public readonly leaves = new Map<string, any>();
  public readonly refreshTokens = new Map<string, any>();
  public readonly auditLogs = new Map<string, any>();
  public readonly pickupAuthorizations = new Map<string, any>();

  constructor() {
    this.seedDefaults();
  }

  private seedDefaults() {
    const data = buildInitialData();

    this.schools.set(data.school.id, data.school);
    this.academicYears.set(data.academicYear.id, data.academicYear);

    for (const c of data.classes) this.classes.set(c.id, c);
    for (const s of data.sections) this.sections.set(s.id, s);
    for (const sub of data.subjects) this.subjects.set(sub.id, sub);
    for (const u of data.users) this.users.set(u.id, u);
    for (const stf of data.staff) this.staff.set(stf.id, stf);
    for (const g of data.guardians) this.guardians.set(g.id, g);
    const cryptoService = new CryptoService();
    for (const stu of data.students) {
      if (stu.id === SEED_IDS.STUDENT_AARAV) {
        stu.blood_group_encrypted = cryptoService.encrypt('O+', SEED_IDS.STUDENT_AARAV);
        stu.emergency_contact_encrypted = cryptoService.encrypt('+919876543210', SEED_IDS.STUDENT_AARAV);
      } else if (stu.id === SEED_IDS.STUDENT_ANANYA) {
        stu.blood_group_encrypted = cryptoService.encrypt('B+', SEED_IDS.STUDENT_ANANYA);
        stu.emergency_contact_encrypted = cryptoService.encrypt('+919876543210', SEED_IDS.STUDENT_ANANYA);
      }
      this.students.set(stu.id, stu);
    }
    for (const sg of data.studentGuardians) this.studentGuardians.set(sg.id, sg);
    for (const t of data.terms) this.terms.set(t.id, t);
    for (const r of data.routes) this.routes.set(r.id, r);
    for (const v of data.vehicles) this.vehicles.set(v.id, v);
    for (const fs of data.feeStructures) this.feeStructures.set(fs.id, fs);

    // Initial Installment for Patel family
    this.feeInstallments.set('inst-2026-002', {
      id: 'inst-2026-002',
      school_id: SEED_IDS.SCHOOL,
      student_id: SEED_IDS.STUDENT_AARAV,
      installment_number: 2,
      amount: 16500,
      due_amount: 16500,
      due_date: new Date('2026-11-10'),
      status: 'PENDING',
    });

    // Initial Sample Receipt for Postman assertions
    this.payments.set('rec_2026_04921', {
      id: 'rec_2026_04921',
      receipt_id: 'rec_2026_04921',
      receipt_number: 'REC-2026-04921',
      school_id: SEED_IDS.SCHOOL,
      student_id: SEED_IDS.STUDENT_AARAV,
      amount: 16500,
      status: 'SUCCESS',
      created_at: new Date('2026-10-10'),
      download_url: 'https://storage.bomis-sambalpur.edu.in/receipts/rec_2026_04921.pdf',
    });

    // Initial Visitor Pass for Postman assertions
    this.visitorPasses.set('vis_pass_2026_001', {
      id: 'vis_pass_2026_001',
      school_id: SEED_IDS.SCHOOL,
      visitor_name: 'Ramesh Sharma',
      visitor_phone: '+919988776655',
      purpose: 'PTM Meeting with Grade 5 Teacher',
      host_staff_id: SEED_IDS.STAFF_TEACHER_G5A,
      expected_date: '2026-10-17',
      status: 'PRE_APPROVED',
      qr_code_data: 'BOMIS:PASS:vis_pass_2026_001:2026-10-17',
      created_at: new Date(),
    });

    // Active Child Pickup Dismissal Authorization for Aarav Patel
    this.pickupAuthorizations.set(SEED_IDS.STUDENT_AARAV, {
      id: 'auth_pickup_001',
      student_id: SEED_IDS.STUDENT_AARAV,
      guardian_id: SEED_IDS.GUARDIAN_PATEL,
      otp: '482910',
      status: 'ACTIVE',
      expires_at: new Date(Date.now() + 30 * 60 * 1000), // 30 minutes validity
      created_at: new Date(),
    });

    // Genuine Seeded Attendance Records for October 2026 (22 Working Days: 20 PRESENT, 1 HALF_DAY, 1 ABSENT)
    for (let day = 1; day <= 22; day++) {
      const dayStr = String(day).padStart(2, '0');
      const dateStr = `2026-10-${dayStr}`;
      let status = 'PRESENT';
      let remarks: string | undefined = 'Regular attendance';
      if (day === 15) {
        status = 'HALF_DAY';
        remarks = 'Early medical departure';
      } else if (day === 16) {
        status = 'ABSENT';
        remarks = 'Medical leave reported by parent';
      }

      this.attendance.set(`${SEED_IDS.STUDENT_AARAV}:${dateStr}`, {
        id: `att_oct_${dayStr}`,
        school_id: SEED_IDS.SCHOOL,
        student_id: SEED_IDS.STUDENT_AARAV,
        date: dateStr,
        status,
        remarks,
        recorded_at: new Date(`${dateStr}T08:30:00Z`),
      });
    }

    // Dynamic Seeded Audit Logs
    this.auditLogs.set('aud-001', {
      id: 'aud-001',
      schoolId: SEED_IDS.SCHOOL,
      school_id: SEED_IDS.SCHOOL,
      userId: SEED_IDS.USER_ADMIN,
      user_id: SEED_IDS.USER_ADMIN,
      action: 'LOGIN',
      entityType: 'User',
      entity_type: 'User',
      entityId: SEED_IDS.USER_ADMIN,
      entity_id: SEED_IDS.USER_ADMIN,
      details: 'Admin authenticated successfully',
      timestamp: '2026-10-18T08:30:00.000Z',
      created_at: new Date('2026-10-18T08:30:00.000Z'),
    });

    this.auditLogs.set('aud-002', {
      id: 'aud-002',
      schoolId: SEED_IDS.SCHOOL,
      school_id: SEED_IDS.SCHOOL,
      userId: SEED_IDS.USER_ADMIN,
      user_id: SEED_IDS.USER_ADMIN,
      action: 'UPDATE',
      entityType: 'FeeStructure',
      entity_type: 'FeeStructure',
      entityId: 'fs-01',
      entity_id: 'fs-01',
      details: 'Updated Term 1 tuition fee structure',
      timestamp: '2026-10-18T09:15:00.000Z',
      created_at: new Date('2026-10-18T09:15:00.000Z'),
    });

    this.logger.log('In-Memory Mock Store initialized with deterministic fixtures.');
  }

  // Helper resolvers
  public resolveId(idOrSymbol?: string): string {
    return resolveEntityId(idOrSymbol);
  }
}
