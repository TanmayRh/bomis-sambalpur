import { Test, TestingModule } from '@nestjs/testing';
import {
  BadRequestException,
  UnauthorizedException,
  NotFoundException,
  ConflictException,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import * as crypto from 'crypto';
import * as jwt from 'jsonwebtoken';

import { AuthService } from './modules/auth/auth.service';
import { FeesService } from './modules/fees/fees.service';
import {
  TransportService,
  calculateHaversineDistanceKm,
} from './modules/transport/transport.service';

import { PrismaService } from './database/prisma.service';
import { MockStoreService } from './database/mock-store.service';
import { MockRedisService } from './common/redis/mock-redis.service';
import { SEED_IDS } from './database/seed-fixtures';
import { JWT_SECRET } from './common/guards/jwt-auth.guard';

describe('Adversarial Stress & Tier 5 Hardening Suite - Milestone M6', () => {
  let authService: AuthService;
  let feesService: FeesService;
  let transportService: TransportService;
  let prisma: PrismaService;
  let redis: MockRedisService;

  beforeAll(async () => {
    process.env.USE_MOCK_DB = 'true';
    process.env.JWT_SECRET = 'bomis_jwt_secret_sambalpur_2026_dev_key_min32';
    process.env.RAZORPAY_WEBHOOK_SECRET = 'bomis_razorpay_secret_sambalpur_2026';

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        FeesService,
        TransportService,
        PrismaService,
        MockStoreService,
        MockRedisService,
      ],
    }).compile();

    authService = module.get<AuthService>(AuthService);
    feesService = module.get<FeesService>(FeesService);
    transportService = module.get<TransportService>(TransportService);
    prisma = module.get<PrismaService>(PrismaService);
    redis = module.get<MockRedisService>(MockRedisService);

    prisma.isMock = true;
  });

  // =========================================================================
  // 1. Session Token Revocation & Single-Use Rotation Stress Tests
  // =========================================================================
  describe('1. Session Token Revocation & Single-Use Rotation (AuthService)', () => {
    it('1A: should exchange active refresh token for a new token pair', async () => {
      const login = await authService.loginStaff(
        'admin@bomis-sambalpur.edu.in',
        'Admin@Sambalpur2026'
      );
      expect(login.refreshToken).toBeDefined();

      const rotated = await authService.rotateRefreshToken(login.refreshToken);
      expect(rotated.accessToken).toBeDefined();
      expect(rotated.refreshToken).toBeDefined();
      expect(rotated.refreshToken).not.toBe(login.refreshToken);
    });

    it('1B: single-use enforcement - should blacklist consumed refresh token upon rotation', async () => {
      const login = await authService.loginStaff(
        'principal@bomis-sambalpur.edu.in',
        'Principal@Sambalpur2026'
      );
      const originalRefreshToken = login.refreshToken;

      // First rotation succeeds
      const firstRotation = await authService.rotateRefreshToken(originalRefreshToken);
      expect(firstRotation.accessToken).toBeDefined();

      // Second attempt using the consumed refresh token MUST throw UnauthorizedException with TOKEN_REVOKED
      await expect(
        authService.rotateRefreshToken(originalRefreshToken)
      ).rejects.toThrow(
        expect.objectContaining({
          response: expect.objectContaining({
            code: 'TOKEN_REVOKED',
            message: 'Refresh token has been revoked',
          }),
        })
      );
    });

    it('1C: logout revocation - should blacklist token and reject subsequent refresh rotation', async () => {
      const login = await authService.loginStaff(
        'teacher.g5a@bomis-sambalpur.edu.in',
        'Teacher@Sambalpur2026'
      );
      const tokenToRevoke = login.refreshToken;

      // User logs out
      const logoutResult = await authService.logout(login.user, tokenToRevoke);
      expect(logoutResult.message).toContain('Session revoked');

      // Attempting to rotate the logged-out refresh token MUST be rejected immediately
      await expect(
        authService.rotateRefreshToken(tokenToRevoke)
      ).rejects.toThrow(
        expect.objectContaining({
          response: expect.objectContaining({
            code: 'TOKEN_REVOKED',
            message: 'Refresh token has been revoked',
          }),
        })
      );
    });

    it('1D: should reject pre-blacklisted token in Redis', async () => {
      const dummyToken = jwt.sign(
        { sub: SEED_IDS.USER_ACCOUNTANT, familyId: 'fam-revoked-001' },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      // Pre-blacklist in Redis
      await redis.set(`blacklist:${dummyToken}`, 'revoked', 604800);

      await expect(
        authService.rotateRefreshToken(dummyToken)
      ).rejects.toThrow(
        expect.objectContaining({
          response: expect.objectContaining({
            code: 'TOKEN_REVOKED',
            message: 'Refresh token has been revoked',
          }),
        })
      );
    });

    it('1E: should reject missing or empty refresh token string with BadRequestException', async () => {
      await expect(authService.rotateRefreshToken('')).rejects.toThrow(
        BadRequestException
      );
    });

    it('1F: should reject malformed or tampered refresh token with UnauthorizedException', async () => {
      await expect(
        authService.rotateRefreshToken('tampered.jwt.payload')
      ).rejects.toThrow(UnauthorizedException);
    });
  });

  // =========================================================================
  // 2. Mobile OTP Flood Defense & Failed Attempt Lockout Stress Tests
  // =========================================================================
  describe('2. Mobile OTP Flood Defense & Failed Attempt Lockout (AuthService)', () => {
    const testPhone = '+919876500001';
    const lockedPhone = '+919876500002';

    beforeEach(async () => {
      await redis.del(`otp_count:${testPhone}`);
      await redis.del(`otp:${testPhone}`);
      await redis.del(`otp_failed:${testPhone}`);
      await redis.del(`otp_count:${lockedPhone}`);
      await redis.del(`otp:${lockedPhone}`);
      await redis.del(`otp_failed:${lockedPhone}`);
    });

    it('2A: should dispatch OTP successfully on initial valid requests', async () => {
      const res = await authService.sendOtp(testPhone);
      expect(res.expiresInSeconds).toBe(300);
      expect(res.message).toBe('OTP sent successfully');

      const cachedOtp = await redis.get(`otp:${testPhone}`);
      expect(cachedOtp).toBe('123456');
    });

    it('2B: should reject invalid Indian mobile numbers with BadRequestException', async () => {
      await expect(authService.sendOtp('9876543210')).rejects.toThrow(
        BadRequestException
      );
      await expect(authService.sendOtp('+1234567890')).rejects.toThrow(
        BadRequestException
      );
    });

    it('2C: sliding window rate limit - should throw 429 RATE_LIMIT_EXCEEDED when OTP requests exceed 5 in 15m', async () => {
      // Send 5 OTP requests (allowed limit)
      for (let i = 1; i <= 5; i++) {
        const res = await authService.sendOtp(testPhone);
        expect(res.message).toBe('OTP sent successfully');
      }

      // 6th OTP request within 15 minutes MUST be rejected with HTTP 429
      await expect(authService.sendOtp(testPhone)).rejects.toThrow(
        expect.objectContaining({
          status: 429,
          response: expect.objectContaining({
            code: 'RATE_LIMIT_EXCEEDED',
            message: 'Too many OTP requests. Please wait 15 minutes.',
          }),
        })
      );
    });

    it('2D: failed attempt lockout - 5 incorrect OTP attempts lock account for 15m and return 429 ACCOUNT_LOCKED', async () => {
      await authService.sendOtp(lockedPhone);

      // Submit 4 incorrect OTP attempts (returns 401 Unauthorized)
      for (let attempt = 1; attempt <= 4; attempt++) {
        await expect(
          authService.verifyOtp(lockedPhone, '000000')
        ).rejects.toThrow(UnauthorizedException);
      }

      // 5th incorrect attempt MUST trigger lockout with HTTP 429 and ACCOUNT_LOCKED
      await expect(
        authService.verifyOtp(lockedPhone, '000000')
      ).rejects.toThrow(
        expect.objectContaining({
          status: 429,
          response: expect.objectContaining({
            code: 'ACCOUNT_LOCKED',
            message: 'Too many failed OTP attempts. Account locked for 15 minutes.',
          }),
        })
      );

      // Verify OTP key was purged in Redis to invalidate active credentials
      const otpInRedis = await redis.get(`otp:${lockedPhone}`);
      expect(otpInRedis).toBeNull();
    });

    it('2E: should immediately reject subsequent verifyOtp calls when account is locked out', async () => {
      // Pre-set 5 failed attempts in Redis
      await redis.set(`otp_failed:${lockedPhone}`, 5, 900);

      // Even when provided with what would otherwise be a valid OTP, call is rejected with 429
      await expect(
        authService.verifyOtp(lockedPhone, '123456')
      ).rejects.toThrow(
        expect.objectContaining({
          status: 429,
          response: expect.objectContaining({
            code: 'ACCOUNT_LOCKED',
            message: 'Too many failed OTP attempts. Account locked for 15 minutes.',
          }),
        })
      );
    });

    it('2F: successful OTP verification clears failed attempts and active OTP key', async () => {
      // Simulate 2 previous failed attempts
      await redis.set(`otp_failed:${testPhone}`, 2, 900);
      await authService.sendOtp(testPhone);

      // Verify with correct OTP
      const authResult = await authService.verifyOtp(testPhone, '123456');
      expect(authResult.accessToken).toBeDefined();

      // Check that both OTP and failed attempts keys were cleared
      const activeOtp = await redis.get(`otp:${testPhone}`);
      const failedCount = await redis.get(`otp_failed:${testPhone}`);
      expect(activeOtp).toBeNull();
      expect(failedCount).toBeNull();
    });
  });

  // =========================================================================
  // 3. Razorpay Webhook Timestamp Expiry, Replay & Timing-Safe Verification
  // =========================================================================
  describe('3. Razorpay Webhook Timestamp Expiry, Replay & Cryptographic HMAC (FeesService)', () => {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET || 'bomis_razorpay_secret_sambalpur_2026';

    function signPayload(payload: any, customSecret = secret): string {
      return crypto
        .createHmac('sha256', customSecret)
        .update(JSON.stringify(payload))
        .digest('hex');
    }

    it('3A: should reject webhook when x-razorpay-signature header is missing', async () => {
      const payload = {
        event: 'payment.captured',
        created_at: Math.floor(Date.now() / 1000),
      };
      await expect(feesService.processWebhook(payload, undefined)).rejects.toThrow(
        BadRequestException
      );
    });

    it('3B: constant-time verification - should reject forged HMAC signature', async () => {
      const payload = {
        event: 'payment.captured',
        created_at: Math.floor(Date.now() / 1000),
      };
      const forgedSig = crypto.randomBytes(32).toString('hex');

      await expect(feesService.processWebhook(payload, forgedSig)).rejects.toThrow(
        expect.objectContaining({
          response: expect.objectContaining({
            code: 'INVALID_WEBHOOK_SIGNATURE',
            message: 'Cryptographic HMAC signature verification failed',
          }),
        })
      );
    });

    it('3C: constant-time verification - should reject signature length mismatch without timing leak', async () => {
      const payload = {
        event: 'payment.captured',
        created_at: Math.floor(Date.now() / 1000),
      };
      const shortSig = 'tooshort';

      await expect(feesService.processWebhook(payload, shortSig)).rejects.toThrow(
        expect.objectContaining({
          response: expect.objectContaining({
            code: 'INVALID_WEBHOOK_SIGNATURE',
          }),
        })
      );
    });

    it('3D: timestamp freshness - should reject expired webhook timestamp (> 300s old)', async () => {
      const expiredTimestamp = Math.floor(Date.now() / 1000) - 305; // 305 seconds old
      const payload = {
        event: 'payment.captured',
        created_at: expiredTimestamp,
        payload: {
          payment: {
            entity: {
              id: 'pay_expired_001',
              order_id: 'order_authentic_001',
              amount: 1650000,
            },
          },
        },
      };

      const validSig = signPayload(payload);

      await expect(feesService.processWebhook(payload, validSig)).rejects.toThrow(
        expect.objectContaining({
          response: expect.objectContaining({
            code: 'WEBHOOK_TIMESTAMP_EXPIRED',
            message: 'Webhook timestamp expired',
          }),
        })
      );
    });

    it('3E: timestamp freshness - should reject webhook timestamp with excessive future drift (> 60s ahead)', async () => {
      const futureTimestamp = Math.floor(Date.now() / 1000) + 120; // 120 seconds in future
      const payload = {
        event: 'payment.captured',
        created_at: futureTimestamp,
        payload: {
          payment: {
            entity: {
              id: 'pay_future_001',
              order_id: 'order_authentic_001',
              amount: 1650000,
            },
          },
        },
      };

      const validSig = signPayload(payload);

      await expect(feesService.processWebhook(payload, validSig)).rejects.toThrow(
        expect.objectContaining({
          response: expect.objectContaining({
            code: 'WEBHOOK_TIMESTAMP_EXPIRED',
            message: 'Webhook timestamp expired',
          }),
        })
      );
    });

    it('3F: should successfully process fresh authentic webhook with valid order', async () => {
      const freshTimestamp = Math.floor(Date.now() / 1000) - 10; // 10s old (well within 300s window)
      const payload = {
        event: 'payment.captured',
        created_at: freshTimestamp,
        payload: {
          payment: {
            entity: {
              id: 'pay_fresh_tier5_001',
              order_id: 'order_authentic_001',
              amount: 1650000,
              currency: 'INR',
              status: 'captured',
            },
          },
        },
      };

      const validSig = signPayload(payload);
      const result = await feesService.processWebhook(payload, validSig);

      expect(result.processed).toBe(true);
      expect(result.paymentId).toBe('pay_fresh_tier5_001');
    });

    it('3G: duplicate event replay defense - should detect replay and return duplicate: true without re-processing', async () => {
      const freshTimestamp = Math.floor(Date.now() / 1000) - 5;
      const replayPayload = {
        event: 'payment.captured',
        created_at: freshTimestamp,
        payload: {
          payment: {
            entity: {
              id: 'pay_replay_test_001',
              order_id: 'order_authentic_001',
              amount: 1650000,
            },
          },
        },
      };

      const validSig = signPayload(replayPayload);

      // First delivery: processes successfully
      const firstResult = await feesService.processWebhook(replayPayload, validSig);
      expect(firstResult.processed).toBe(true);
      expect(firstResult.duplicate).toBeUndefined();

      // Second delivery (Replay attack): MUST return duplicate: true
      const replayResult = await feesService.processWebhook(replayPayload, validSig);
      expect(replayResult.processed).toBe(true);
      expect(replayResult.duplicate).toBe(true);
      expect(replayResult.message).toBe('Event already processed');
    });

    it('3H: unrecognized order defense - should throw NotFoundException instead of assigning to Aarav Patel', async () => {
      const freshTimestamp = Math.floor(Date.now() / 1000);
      const orphanPayload = {
        event: 'payment.captured',
        created_at: freshTimestamp,
        payload: {
          payment: {
            entity: {
              id: 'pay_orphan_test_999',
              order_id: 'order_non_existent_random_888',
              amount: 1400000, // Fee meant for Ananya Patel
            },
          },
        },
      };

      const validSig = signPayload(orphanPayload);

      await expect(feesService.processWebhook(orphanPayload, validSig)).rejects.toThrow(
        expect.objectContaining({
          response: expect.objectContaining({
            code: 'ORDER_NOT_FOUND',
            message: 'Unrecognized order ID in webhook',
          }),
        })
      );
    });
  });

  // =========================================================================
  // 4. Financial Idempotency Concurrency & Distributed Lock Stress Tests
  // =========================================================================
  describe('4. Financial Idempotency Concurrency & Mutex Lock (FeesService)', () => {
    it('4A: should throw BadRequestException if Idempotency-Key header is missing', async () => {
      const payload = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 2,
        amountPaise: 1650000,
      };
      await expect(feesService.createRazorpayOrder(payload, undefined)).rejects.toThrow(
        BadRequestException
      );
    });

    it('4B: should acquire lock, create order, cache idempotency result, and release lock', async () => {
      const idempotencyKey = 'idemp-lock-test-001';
      const payload = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 2,
        amountPaise: 1650000,
        paymentMethod: 'UPI',
      };

      const order = await feesService.createRazorpayOrder(payload, idempotencyKey);
      expect(order).toBeDefined();
      expect(order.razorpayOrderId).toBeDefined();
      expect(order.amount).toBe(16500);

      // Verify the lock was properly released in finally block
      const isLockAvailable = await redis.acquireLock(`lock:fees:idemp:${idempotencyKey}`, 10);
      expect(isLockAvailable).toBe(true);
      await redis.releaseLock(`lock:fees:idemp:${idempotencyKey}`);
    });

    it('4C: replay with identical payload should return cached order without creating new order', async () => {
      const idempotencyKey = 'idemp-replay-cached-002';
      const payload = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 2,
        amountPaise: 1650000,
        paymentMethod: 'UPI',
      };

      const order1 = await feesService.createRazorpayOrder(payload, idempotencyKey);
      const order2 = await feesService.createRazorpayOrder(payload, idempotencyKey);

      expect(order1.razorpayOrderId).toBe(order2.razorpayOrderId);
      expect(order1.createdAt).toBe(order2.createdAt);
    });

    it('4D: replay with conflicting payload should throw ConflictException (409)', async () => {
      const idempotencyKey = 'idemp-conflict-003';
      const payload1 = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 2,
        amountPaise: 1650000,
      };
      const payload2 = {
        studentId: 'stu_grade5a_001',
        installmentNumber: 3, // different installment
        amountPaise: 1650000,
      };

      await feesService.createRazorpayOrder(payload1, idempotencyKey);

      await expect(feesService.createRazorpayOrder(payload2, idempotencyKey)).rejects.toThrow(
        ConflictException
      );
    });

    it('4E: concurrency collision defense - active lock should prevent race condition and throw ConflictException', async () => {
      const idempotencyKey = 'idemp-concurrency-race-004';
      const lockKey = `lock:fees:idemp:${idempotencyKey}`;

      // Simulate a concurrent worker currently holding the lock
      await redis.acquireLock(lockKey, 30);

      try {
        const payload = {
          studentId: 'stu_grade5a_001',
          installmentNumber: 2,
          amountPaise: 1650000,
        };

        // Simultaneous order attempt MUST fail with ConflictException CONCURRENT_REQUEST
        await expect(
          feesService.createRazorpayOrder(payload, idempotencyKey)
        ).rejects.toThrow(
          expect.objectContaining({
            response: expect.objectContaining({
              code: 'CONCURRENT_REQUEST',
              message: 'A concurrent request with the same Idempotency-Key is currently being processed',
            }),
          })
        );
      } finally {
        await redis.releaseLock(lockKey);
      }
    });
  });

  // =========================================================================
  // 5. Spherical Haversine Geofence Proximity Calculations (TransportService)
  // =========================================================================
  describe('5. Spherical Haversine Geofence Proximity Calculations (TransportService)', () => {
    // BOMIS Sambalpur campus coordinates
    const campusLat = 21.4984;
    const campusLng = 83.9781;

    it('5A: telemetry ping at exact BOMIS Sambalpur campus should calculate 0.000 km and trigger proximityAlertsSent: 1', async () => {
      const pingPayload = {
        latitude: campusLat,
        longitude: campusLng,
        speed: 15,
        heading: 90,
      };

      const result = await transportService.recordGpsPing(pingPayload);
      expect(result.recorded).toBe(true);
      expect(result.distanceKm).toBe(0);
      expect(result.proximityAlertsSent).toBe(1);
    });

    it('5B: approaching bus within 1.5 km (~0.73 km north) should trigger proximityAlertsSent: 1', async () => {
      const approachingPayload = {
        latitude: 21.505,
        longitude: campusLng,
        speed: 30,
        heading: 180,
      };

      const result = await transportService.recordGpsPing(approachingPayload);
      expect(result.distanceKm).toBeLessThanOrEqual(1.5);
      expect(result.proximityAlertsSent).toBe(1);
    });

    it('5C: boundary test at ~1.49 km from campus should trigger proximityAlertsSent: 1', async () => {
      // Offset latitude by ~0.0134 degrees ≈ 1.49 km
      const boundaryWithin = {
        latitude: campusLat + 0.0134,
        longitude: campusLng,
      };

      const dist = calculateHaversineDistanceKm(
        boundaryWithin.latitude,
        boundaryWithin.longitude,
        campusLat,
        campusLng
      );
      expect(dist).toBeLessThanOrEqual(1.5);

      const result = await transportService.recordGpsPing(boundaryWithin);
      expect(result.proximityAlertsSent).toBe(1);
    });

    it('5D: telemetry ping beyond 1.5 km boundary (~2.4 km north) should set proximityAlertsSent: 0', async () => {
      const boundaryOutside = {
        latitude: campusLat + 0.022, // ~2.44 km
        longitude: campusLng,
      };

      const dist = calculateHaversineDistanceKm(
        boundaryOutside.latitude,
        boundaryOutside.longitude,
        campusLat,
        campusLng
      );
      expect(dist).toBeGreaterThan(1.5);

      const result = await transportService.recordGpsPing(boundaryOutside);
      expect(result.proximityAlertsSent).toBe(0);
    });

    it('5E: remote depot telemetry ping (~31 km away) should calculate ~31 km and set proximityAlertsSent: 0', async () => {
      const remoteDepot = {
        latitude: 21.7,
        longitude: 84.2,
        speed: 0,
      };

      const dist = calculateHaversineDistanceKm(
        remoteDepot.latitude,
        remoteDepot.longitude,
        campusLat,
        campusLng
      );
      expect(dist).toBeGreaterThan(25);

      const result = await transportService.recordGpsPing(remoteDepot);
      expect(result.distanceKm).toBeGreaterThan(25);
      expect(result.proximityAlertsSent).toBe(0);
    });

    it('5F: calculateHaversineDistanceKm pure mathematical engine verification & numerical stability', () => {
      // Same point distance is 0
      expect(calculateHaversineDistanceKm(campusLat, campusLng, campusLat, campusLng)).toBe(0);

      // Known Sambalpur landmark distance:
      // Budharaja Fatak (21.4825, 83.9782) to Sakhipada Chhak (21.4669, 83.9812)
      const d = calculateHaversineDistanceKm(21.4825, 83.9782, 21.4669, 83.9812);
      expect(d).toBeCloseTo(1.761, 1);

      // Numerical stability for antipodal points (clamps a <= 1.0 without NaN)
      const antipodalDist = calculateHaversineDistanceKm(0, 0, 0, 180);
      expect(Number.isFinite(antipodalDist)).toBe(true);
      expect(antipodalDist).toBeCloseTo(20015, 0); // Half of earth's circumference ≈ 20,015 km
    });
  });
});
