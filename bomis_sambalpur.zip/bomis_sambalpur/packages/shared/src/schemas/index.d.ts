import { z } from 'zod';
import { Gender, AttendanceStatus, PaymentMethod, FeeFrequency, ConsentType, ConsentStatus } from '../enums/index.js';
export declare const MobileOtpRequestSchema: z.ZodObject<{
    phone: z.ZodString;
    schoolId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    phone: string;
    schoolId?: string | undefined;
}, {
    phone: string;
    schoolId?: string | undefined;
}>;
export declare const VerifyOtpSchema: z.ZodObject<{
    phone: z.ZodString;
    code: z.ZodString;
}, "strip", z.ZodTypeAny, {
    phone: string;
    code: string;
}, {
    phone: string;
    code: string;
}>;
export declare const StaffLoginSchema: z.ZodObject<{
    email: z.ZodString;
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    email: string;
    password: string;
}, {
    email: string;
    password: string;
}>;
export declare const RefreshTokenSchema: z.ZodObject<{
    refreshToken: z.ZodString;
}, "strip", z.ZodTypeAny, {
    refreshToken: string;
}, {
    refreshToken: string;
}>;
export declare const LogoutSchema: z.ZodObject<{
    refreshToken: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    refreshToken?: string | undefined;
}, {
    refreshToken?: string | undefined;
}>;
export declare const CreateStudentSchema: z.ZodObject<{
    schoolId: z.ZodString;
    admissionNumber: z.ZodString;
    rollNumber: z.ZodString;
    firstName: z.ZodString;
    lastName: z.ZodString;
    dateOfBirth: z.ZodString;
    gender: z.ZodNativeEnum<typeof Gender>;
    classId: z.ZodString;
    sectionId: z.ZodString;
    emergencyContact: z.ZodString;
}, "strip", z.ZodTypeAny, {
    schoolId: string;
    admissionNumber: string;
    rollNumber: string;
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    gender: Gender;
    classId: string;
    sectionId: string;
    emergencyContact: string;
}, {
    schoolId: string;
    admissionNumber: string;
    rollNumber: string;
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    gender: Gender;
    classId: string;
    sectionId: string;
    emergencyContact: string;
}>;
export declare const AttendanceRecordSchema: z.ZodObject<{
    studentId: z.ZodString;
    status: z.ZodNativeEnum<typeof AttendanceStatus>;
    remarks: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    status: AttendanceStatus;
    studentId: string;
    remarks?: string | undefined;
}, {
    status: AttendanceStatus;
    studentId: string;
    remarks?: string | undefined;
}>;
export declare const AttendanceMarkBatchSchema: z.ZodObject<{
    schoolId: z.ZodString;
    sectionId: z.ZodString;
    date: z.ZodString;
    records: z.ZodArray<z.ZodObject<{
        studentId: z.ZodString;
        status: z.ZodNativeEnum<typeof AttendanceStatus>;
        remarks: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        status: AttendanceStatus;
        studentId: string;
        remarks?: string | undefined;
    }, {
        status: AttendanceStatus;
        studentId: string;
        remarks?: string | undefined;
    }>, "many">;
    offlineBatchId: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    date: string;
    schoolId: string;
    sectionId: string;
    records: {
        status: AttendanceStatus;
        studentId: string;
        remarks?: string | undefined;
    }[];
    offlineBatchId?: string | undefined;
}, {
    date: string;
    schoolId: string;
    sectionId: string;
    records: {
        status: AttendanceStatus;
        studentId: string;
        remarks?: string | undefined;
    }[];
    offlineBatchId?: string | undefined;
}>;
export declare const RapidAttendanceBatchSchema: z.ZodObject<{
    date: z.ZodString;
    classId: z.ZodString;
    sectionId: z.ZodString;
    defaultStatus: z.ZodDefault<z.ZodNativeEnum<typeof AttendanceStatus>>;
    exceptions: z.ZodDefault<z.ZodArray<z.ZodObject<{
        studentId: z.ZodString;
        status: z.ZodNativeEnum<typeof AttendanceStatus>;
        remarks: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        status: AttendanceStatus;
        studentId: string;
        remarks?: string | undefined;
    }, {
        status: AttendanceStatus;
        studentId: string;
        remarks?: string | undefined;
    }>, "many">>;
}, "strip", z.ZodTypeAny, {
    date: string;
    classId: string;
    sectionId: string;
    defaultStatus: AttendanceStatus;
    exceptions: {
        status: AttendanceStatus;
        studentId: string;
        remarks?: string | undefined;
    }[];
}, {
    date: string;
    classId: string;
    sectionId: string;
    defaultStatus?: AttendanceStatus | undefined;
    exceptions?: {
        status: AttendanceStatus;
        studentId: string;
        remarks?: string | undefined;
    }[] | undefined;
}>;
export declare const OfflineSyncEventSchema: z.ZodObject<{
    id: z.ZodString;
    actionType: z.ZodEnum<["ATTENDANCE_BATCH", "BOARDING_SCAN", "GPS_PING"]>;
    idempotencyKey: z.ZodString;
    timestamp: z.ZodNumber;
    payload: z.ZodRecord<z.ZodString, z.ZodUnknown>;
}, "strip", z.ZodTypeAny, {
    id: string;
    actionType: "ATTENDANCE_BATCH" | "BOARDING_SCAN" | "GPS_PING";
    idempotencyKey: string;
    timestamp: number;
    payload: Record<string, unknown>;
}, {
    id: string;
    actionType: "ATTENDANCE_BATCH" | "BOARDING_SCAN" | "GPS_PING";
    idempotencyKey: string;
    timestamp: number;
    payload: Record<string, unknown>;
}>;
export declare const OfflineSyncBatchSchema: z.ZodObject<{
    events: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        actionType: z.ZodEnum<["ATTENDANCE_BATCH", "BOARDING_SCAN", "GPS_PING"]>;
        idempotencyKey: z.ZodString;
        timestamp: z.ZodNumber;
        payload: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, "strip", z.ZodTypeAny, {
        id: string;
        actionType: "ATTENDANCE_BATCH" | "BOARDING_SCAN" | "GPS_PING";
        idempotencyKey: string;
        timestamp: number;
        payload: Record<string, unknown>;
    }, {
        id: string;
        actionType: "ATTENDANCE_BATCH" | "BOARDING_SCAN" | "GPS_PING";
        idempotencyKey: string;
        timestamp: number;
        payload: Record<string, unknown>;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    events: {
        id: string;
        actionType: "ATTENDANCE_BATCH" | "BOARDING_SCAN" | "GPS_PING";
        idempotencyKey: string;
        timestamp: number;
        payload: Record<string, unknown>;
    }[];
}, {
    events: {
        id: string;
        actionType: "ATTENDANCE_BATCH" | "BOARDING_SCAN" | "GPS_PING";
        idempotencyKey: string;
        timestamp: number;
        payload: Record<string, unknown>;
    }[];
}>;
export declare const InitiatePaymentSchema: z.ZodObject<{
    schoolId: z.ZodString;
    studentId: z.ZodString;
    installmentId: z.ZodString;
    amount: z.ZodNumber;
    paymentMethod: z.ZodNativeEnum<typeof PaymentMethod>;
    idempotencyKey: z.ZodString;
}, "strip", z.ZodTypeAny, {
    amount: number;
    schoolId: string;
    studentId: string;
    idempotencyKey: string;
    installmentId: string;
    paymentMethod: PaymentMethod;
}, {
    amount: number;
    schoolId: string;
    studentId: string;
    idempotencyKey: string;
    installmentId: string;
    paymentMethod: PaymentMethod;
}>;
export declare const CreateRazorpayOrderSchema: z.ZodObject<{
    studentId: z.ZodString;
    installmentNumber: z.ZodNumber;
    amountPaise: z.ZodNumber;
    paymentMethod: z.ZodEnum<["UPI", "NETBANKING", "CARD", "RAZORPAY_UPI", "RAZORPAY_NETBANKING", "RAZORPAY_CARD"]>;
}, "strip", z.ZodTypeAny, {
    studentId: string;
    paymentMethod: "RAZORPAY_UPI" | "RAZORPAY_NETBANKING" | "RAZORPAY_CARD" | "UPI" | "NETBANKING" | "CARD";
    installmentNumber: number;
    amountPaise: number;
}, {
    studentId: string;
    paymentMethod: "RAZORPAY_UPI" | "RAZORPAY_NETBANKING" | "RAZORPAY_CARD" | "UPI" | "NETBANKING" | "CARD";
    installmentNumber: number;
    amountPaise: number;
}>;
export declare const RazorpayWebhookSchema: z.ZodObject<{
    entity: z.ZodLiteral<"event">;
    event: z.ZodString;
    payload: z.ZodObject<{
        payment: z.ZodObject<{
            entity: z.ZodObject<{
                id: z.ZodString;
                order_id: z.ZodString;
                amount: z.ZodNumber;
                currency: z.ZodString;
                status: z.ZodString;
                method: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                id: string;
                status: string;
                amount: number;
                currency: string;
                order_id: string;
                method: string;
            }, {
                id: string;
                status: string;
                amount: number;
                currency: string;
                order_id: string;
                method: string;
            }>;
        }, "strip", z.ZodTypeAny, {
            entity: {
                id: string;
                status: string;
                amount: number;
                currency: string;
                order_id: string;
                method: string;
            };
        }, {
            entity: {
                id: string;
                status: string;
                amount: number;
                currency: string;
                order_id: string;
                method: string;
            };
        }>;
    }, "strip", z.ZodTypeAny, {
        payment: {
            entity: {
                id: string;
                status: string;
                amount: number;
                currency: string;
                order_id: string;
                method: string;
            };
        };
    }, {
        payment: {
            entity: {
                id: string;
                status: string;
                amount: number;
                currency: string;
                order_id: string;
                method: string;
            };
        };
    }>;
}, "strip", z.ZodTypeAny, {
    payload: {
        payment: {
            entity: {
                id: string;
                status: string;
                amount: number;
                currency: string;
                order_id: string;
                method: string;
            };
        };
    };
    entity: "event";
    event: string;
}, {
    payload: {
        payment: {
            entity: {
                id: string;
                status: string;
                amount: number;
                currency: string;
                order_id: string;
                method: string;
            };
        };
    };
    entity: "event";
    event: string;
}>;
export declare const CreateFeeStructureSchema: z.ZodObject<{
    schoolId: z.ZodString;
    classId: z.ZodString;
    academicYear: z.ZodString;
    category: z.ZodString;
    totalAmount: z.ZodNumber;
    frequency: z.ZodNativeEnum<typeof FeeFrequency>;
}, "strip", z.ZodTypeAny, {
    academicYear: string;
    schoolId: string;
    classId: string;
    category: string;
    totalAmount: number;
    frequency: FeeFrequency;
}, {
    academicYear: string;
    schoolId: string;
    classId: string;
    category: string;
    totalAmount: number;
    frequency: FeeFrequency;
}>;
export declare const ConcessionApplicationSchema: z.ZodObject<{
    studentId: z.ZodString;
    discountPercentage: z.ZodNumber;
    reason: z.ZodString;
}, "strip", z.ZodTypeAny, {
    studentId: string;
    discountPercentage: number;
    reason: string;
}, {
    studentId: string;
    discountPercentage: number;
    reason: string;
}>;
export declare const MarksRecordSchema: z.ZodObject<{
    studentId: z.ZodString;
    periodicTest: z.ZodDefault<z.ZodNumber>;
    notebook: z.ZodDefault<z.ZodNumber>;
    subjectEnrichment: z.ZodDefault<z.ZodNumber>;
    examMarks: z.ZodDefault<z.ZodNumber>;
    grade: z.ZodOptional<z.ZodString>;
    remarks: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    studentId: string;
    periodicTest: number;
    notebook: number;
    subjectEnrichment: number;
    examMarks: number;
    remarks?: string | undefined;
    grade?: string | undefined;
}, {
    studentId: string;
    remarks?: string | undefined;
    periodicTest?: number | undefined;
    notebook?: number | undefined;
    subjectEnrichment?: number | undefined;
    examMarks?: number | undefined;
    grade?: string | undefined;
}>;
export declare const MarksBatchEntrySchema: z.ZodObject<{
    termId: z.ZodString;
    subjectId: z.ZodString;
    classId: z.ZodString;
    sectionId: z.ZodString;
    records: z.ZodArray<z.ZodObject<{
        studentId: z.ZodString;
        periodicTest: z.ZodDefault<z.ZodNumber>;
        notebook: z.ZodDefault<z.ZodNumber>;
        subjectEnrichment: z.ZodDefault<z.ZodNumber>;
        examMarks: z.ZodDefault<z.ZodNumber>;
        grade: z.ZodOptional<z.ZodString>;
        remarks: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        studentId: string;
        periodicTest: number;
        notebook: number;
        subjectEnrichment: number;
        examMarks: number;
        remarks?: string | undefined;
        grade?: string | undefined;
    }, {
        studentId: string;
        remarks?: string | undefined;
        periodicTest?: number | undefined;
        notebook?: number | undefined;
        subjectEnrichment?: number | undefined;
        examMarks?: number | undefined;
        grade?: string | undefined;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    classId: string;
    sectionId: string;
    records: {
        studentId: string;
        periodicTest: number;
        notebook: number;
        subjectEnrichment: number;
        examMarks: number;
        remarks?: string | undefined;
        grade?: string | undefined;
    }[];
    termId: string;
    subjectId: string;
}, {
    classId: string;
    sectionId: string;
    records: {
        studentId: string;
        remarks?: string | undefined;
        periodicTest?: number | undefined;
        notebook?: number | undefined;
        subjectEnrichment?: number | undefined;
        examMarks?: number | undefined;
        grade?: string | undefined;
    }[];
    termId: string;
    subjectId: string;
}>;
export declare const TimetableClashCheckSchema: z.ZodObject<{
    teacherId: z.ZodString;
    roomId: z.ZodString;
    dayOfWeek: z.ZodEnum<["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"]>;
    periodNumber: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    teacherId: string;
    roomId: string;
    dayOfWeek: "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY";
    periodNumber: number;
}, {
    teacherId: string;
    roomId: string;
    dayOfWeek: "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY";
    periodNumber: number;
}>;
export declare const TeacherSubstitutionSchema: z.ZodObject<{
    absentTeacherId: z.ZodString;
    substituteTeacherId: z.ZodString;
    date: z.ZodString;
    periodNumber: z.ZodNumber;
    sectionId: z.ZodString;
    subjectId: z.ZodString;
}, "strip", z.ZodTypeAny, {
    date: string;
    sectionId: string;
    subjectId: string;
    periodNumber: number;
    absentTeacherId: string;
    substituteTeacherId: string;
}, {
    date: string;
    sectionId: string;
    subjectId: string;
    periodNumber: number;
    absentTeacherId: string;
    substituteTeacherId: string;
}>;
export declare const CreateHomeworkSchema: z.ZodObject<{
    classId: z.ZodString;
    sectionId: z.ZodString;
    subjectId: z.ZodString;
    title: z.ZodString;
    description: z.ZodString;
    dueDate: z.ZodString;
    attachments: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}, "strip", z.ZodTypeAny, {
    title: string;
    classId: string;
    sectionId: string;
    subjectId: string;
    description: string;
    dueDate: string;
    attachments?: string[] | undefined;
}, {
    title: string;
    classId: string;
    sectionId: string;
    subjectId: string;
    description: string;
    dueDate: string;
    attachments?: string[] | undefined;
}>;
export declare const GpsLocationUpdateSchema: z.ZodObject<{
    schoolId: z.ZodString;
    vehicleId: z.ZodString;
    routeId: z.ZodString;
    latitude: z.ZodNumber;
    longitude: z.ZodNumber;
    speed: z.ZodOptional<z.ZodNumber>;
    heading: z.ZodOptional<z.ZodNumber>;
    timestamp: z.ZodString;
}, "strip", z.ZodTypeAny, {
    schoolId: string;
    timestamp: string;
    vehicleId: string;
    routeId: string;
    latitude: number;
    longitude: number;
    speed?: number | undefined;
    heading?: number | undefined;
}, {
    schoolId: string;
    timestamp: string;
    vehicleId: string;
    routeId: string;
    latitude: number;
    longitude: number;
    speed?: number | undefined;
    heading?: number | undefined;
}>;
export declare const StudentBoardingLogSchema: z.ZodObject<{
    schoolId: z.ZodString;
    studentId: z.ZodString;
    vehicleId: z.ZodString;
    stopId: z.ZodString;
    scanType: z.ZodEnum<["BOARD", "DEBOARD"]>;
    scannedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    schoolId: string;
    studentId: string;
    vehicleId: string;
    stopId: string;
    scanType: "BOARD" | "DEBOARD";
    scannedAt: string;
}, {
    schoolId: string;
    studentId: string;
    vehicleId: string;
    stopId: string;
    scanType: "BOARD" | "DEBOARD";
    scannedAt: string;
}>;
export declare const BoardingScanPayloadSchema: z.ZodObject<{
    busId: z.ZodString;
    studentId: z.ZodString;
    stopId: z.ZodString;
    action: z.ZodEnum<["BOARDED", "DEBOARDED", "BOARD", "DEBOARD"]>;
    lat: z.ZodNumber;
    lng: z.ZodNumber;
    timestamp: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    studentId: string;
    stopId: string;
    busId: string;
    action: "BOARDED" | "DEBOARDED" | "BOARD" | "DEBOARD";
    lat: number;
    lng: number;
    timestamp?: string | undefined;
}, {
    studentId: string;
    stopId: string;
    busId: string;
    action: "BOARDED" | "DEBOARDED" | "BOARD" | "DEBOARD";
    lat: number;
    lng: number;
    timestamp?: string | undefined;
}>;
export declare const CreateVisitorPassSchema: z.ZodObject<{
    visitorName: z.ZodString;
    visitorPhone: z.ZodString;
    purpose: z.ZodString;
    hostStaffId: z.ZodString;
    expectedDate: z.ZodString;
}, "strip", z.ZodTypeAny, {
    purpose: string;
    visitorName: string;
    visitorPhone: string;
    hostStaffId: string;
    expectedDate: string;
}, {
    purpose: string;
    visitorName: string;
    visitorPhone: string;
    hostStaffId: string;
    expectedDate: string;
}>;
export declare const VerifyChildPickupSchema: z.ZodObject<{
    studentId: z.ZodString;
    pickupOtp: z.ZodString;
    gateNumber: z.ZodString;
}, "strip", z.ZodTypeAny, {
    studentId: string;
    pickupOtp: string;
    gateNumber: string;
}, {
    studentId: string;
    pickupOtp: string;
    gateNumber: string;
}>;
export declare const AnonymousIncidentReportSchema: z.ZodObject<{
    incidentType: z.ZodString;
    grade: z.ZodNumber;
    location: z.ZodString;
    description: z.ZodString;
    timestamp: z.ZodUnion<[z.ZodString, z.ZodString]>;
}, "strip", z.ZodTypeAny, {
    timestamp: string;
    grade: number;
    description: string;
    incidentType: string;
    location: string;
}, {
    timestamp: string;
    grade: number;
    description: string;
    incidentType: string;
    location: string;
}>;
export declare const ConsentRecordSchema: z.ZodObject<{
    userId: z.ZodString;
    consentType: z.ZodNativeEnum<typeof ConsentType>;
    version: z.ZodDefault<z.ZodString>;
    status: z.ZodDefault<z.ZodNativeEnum<typeof ConsentStatus>>;
    ipAddress: z.ZodOptional<z.ZodString>;
    userAgent: z.ZodOptional<z.ZodString>;
    proofHash: z.ZodString;
}, "strip", z.ZodTypeAny, {
    version: string;
    status: ConsentStatus;
    userId: string;
    consentType: ConsentType;
    proofHash: string;
    ipAddress?: string | undefined;
    userAgent?: string | undefined;
}, {
    userId: string;
    consentType: ConsentType;
    proofHash: string;
    version?: string | undefined;
    status?: ConsentStatus | undefined;
    ipAddress?: string | undefined;
    userAgent?: string | undefined;
}>;
export declare const DataErasureRequestSchema: z.ZodObject<{
    userId: z.ZodString;
    reason: z.ZodString;
    confirmPermanentErasure: z.ZodLiteral<true>;
}, "strip", z.ZodTypeAny, {
    reason: string;
    userId: string;
    confirmPermanentErasure: true;
}, {
    reason: string;
    userId: string;
    confirmPermanentErasure: true;
}>;
export declare const PaginationQuerySchema: z.ZodObject<{
    page: z.ZodDefault<z.ZodNumber>;
    pageSize: z.ZodDefault<z.ZodNumber>;
    search: z.ZodOptional<z.ZodString>;
    sortBy: z.ZodOptional<z.ZodString>;
    sortOrder: z.ZodDefault<z.ZodEnum<["asc", "desc"]>>;
}, "strip", z.ZodTypeAny, {
    page: number;
    pageSize: number;
    sortOrder: "asc" | "desc";
    search?: string | undefined;
    sortBy?: string | undefined;
}, {
    page?: number | undefined;
    pageSize?: number | undefined;
    search?: string | undefined;
    sortBy?: string | undefined;
    sortOrder?: "asc" | "desc" | undefined;
}>;
//# sourceMappingURL=index.d.ts.map