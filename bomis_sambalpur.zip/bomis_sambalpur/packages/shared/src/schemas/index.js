"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaginationQuerySchema = exports.DataErasureRequestSchema = exports.ConsentRecordSchema = exports.AnonymousIncidentReportSchema = exports.VerifyChildPickupSchema = exports.CreateVisitorPassSchema = exports.BoardingScanPayloadSchema = exports.StudentBoardingLogSchema = exports.GpsLocationUpdateSchema = exports.CreateHomeworkSchema = exports.TeacherSubstitutionSchema = exports.TimetableClashCheckSchema = exports.MarksBatchEntrySchema = exports.MarksRecordSchema = exports.ConcessionApplicationSchema = exports.CreateFeeStructureSchema = exports.RazorpayWebhookSchema = exports.CreateRazorpayOrderSchema = exports.InitiatePaymentSchema = exports.OfflineSyncBatchSchema = exports.OfflineSyncEventSchema = exports.RapidAttendanceBatchSchema = exports.AttendanceMarkBatchSchema = exports.AttendanceRecordSchema = exports.CreateStudentSchema = exports.LogoutSchema = exports.RefreshTokenSchema = exports.StaffLoginSchema = exports.VerifyOtpSchema = exports.MobileOtpRequestSchema = void 0;
const zod_1 = require("zod");
const index_js_1 = require("../enums/index.js");
// ============================================================================
// Auth Schemas
// ============================================================================
exports.MobileOtpRequestSchema = zod_1.z.object({
    phone: zod_1.z.string().regex(/^\+91[6-9]\d{9}$/, 'Invalid Indian mobile number (+91XXXXXXXXXX)'),
    schoolId: zod_1.z.string().uuid().optional(),
});
exports.VerifyOtpSchema = zod_1.z.object({
    phone: zod_1.z.string().regex(/^\+91[6-9]\d{9}$/, 'Invalid Indian mobile number (+91XXXXXXXXXX)'),
    code: zod_1.z.string().length(6, 'OTP must be 6 digits'),
});
exports.StaffLoginSchema = zod_1.z.object({
    email: zod_1.z.string().email('Invalid email address'),
    password: zod_1.z.string().min(8, 'Password must be at least 8 characters'),
});
exports.RefreshTokenSchema = zod_1.z.object({
    refreshToken: zod_1.z.string().min(1, 'Refresh token required'),
});
exports.LogoutSchema = zod_1.z.object({
    refreshToken: zod_1.z.string().optional(),
});
// ============================================================================
// Student & People Schemas
// ============================================================================
exports.CreateStudentSchema = zod_1.z.object({
    schoolId: zod_1.z.string().uuid(),
    admissionNumber: zod_1.z.string().min(1, 'Admission number required'),
    rollNumber: zod_1.z.string().min(1, 'Roll number required'),
    firstName: zod_1.z.string().min(1, 'First name required'),
    lastName: zod_1.z.string().min(1, 'Last name required'),
    dateOfBirth: zod_1.z.string().datetime(),
    gender: zod_1.z.nativeEnum(index_js_1.Gender),
    classId: zod_1.z.string().uuid(),
    sectionId: zod_1.z.string().uuid(),
    emergencyContact: zod_1.z.string().regex(/^\+91[6-9]\d{9}$/),
});
// ============================================================================
// Attendance & Offline Sync Schemas
// ============================================================================
exports.AttendanceRecordSchema = zod_1.z.object({
    studentId: zod_1.z.string().uuid(),
    status: zod_1.z.nativeEnum(index_js_1.AttendanceStatus),
    remarks: zod_1.z.string().max(255).optional(),
});
exports.AttendanceMarkBatchSchema = zod_1.z.object({
    schoolId: zod_1.z.string().uuid(),
    sectionId: zod_1.z.string().uuid(),
    date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be YYYY-MM-DD'),
    records: zod_1.z.array(exports.AttendanceRecordSchema).min(1, 'At least one attendance record required'),
    offlineBatchId: zod_1.z.string().uuid().optional(),
});
exports.RapidAttendanceBatchSchema = zod_1.z.object({
    date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be YYYY-MM-DD'),
    classId: zod_1.z.string().uuid(),
    sectionId: zod_1.z.string().uuid(),
    defaultStatus: zod_1.z.nativeEnum(index_js_1.AttendanceStatus).default(index_js_1.AttendanceStatus.PRESENT),
    exceptions: zod_1.z
        .array(zod_1.z.object({
        studentId: zod_1.z.string().uuid(),
        status: zod_1.z.nativeEnum(index_js_1.AttendanceStatus),
        remarks: zod_1.z.string().max(255).optional(),
    }))
        .default([]),
});
exports.OfflineSyncEventSchema = zod_1.z.object({
    id: zod_1.z.string(),
    actionType: zod_1.z.enum(['ATTENDANCE_BATCH', 'BOARDING_SCAN', 'GPS_PING']),
    idempotencyKey: zod_1.z.string().min(1),
    timestamp: zod_1.z.number().int().positive(),
    payload: zod_1.z.record(zod_1.z.unknown()),
});
exports.OfflineSyncBatchSchema = zod_1.z.object({
    events: zod_1.z.array(exports.OfflineSyncEventSchema).min(1, 'At least one sync event required'),
});
// ============================================================================
// Fees & Razorpay Payment Schemas
// ============================================================================
exports.InitiatePaymentSchema = zod_1.z.object({
    schoolId: zod_1.z.string().uuid(),
    studentId: zod_1.z.string().uuid(),
    installmentId: zod_1.z.string().uuid(),
    amount: zod_1.z.number().positive('Amount must be greater than zero'),
    paymentMethod: zod_1.z.nativeEnum(index_js_1.PaymentMethod),
    idempotencyKey: zod_1.z.string().uuid('Unique Idempotency-Key required'),
});
exports.CreateRazorpayOrderSchema = zod_1.z.object({
    studentId: zod_1.z.string().uuid(),
    installmentNumber: zod_1.z.number().int().positive(),
    amountPaise: zod_1.z.number().int().positive(),
    paymentMethod: zod_1.z.enum([
        'UPI',
        'NETBANKING',
        'CARD',
        'RAZORPAY_UPI',
        'RAZORPAY_NETBANKING',
        'RAZORPAY_CARD',
    ]),
});
exports.RazorpayWebhookSchema = zod_1.z.object({
    entity: zod_1.z.literal('event'),
    event: zod_1.z.string(),
    payload: zod_1.z.object({
        payment: zod_1.z.object({
            entity: zod_1.z.object({
                id: zod_1.z.string(),
                order_id: zod_1.z.string(),
                amount: zod_1.z.number(),
                currency: zod_1.z.string(),
                status: zod_1.z.string(),
                method: zod_1.z.string(),
            }),
        }),
    }),
});
exports.CreateFeeStructureSchema = zod_1.z.object({
    schoolId: zod_1.z.string().uuid(),
    classId: zod_1.z.string().uuid(),
    academicYear: zod_1.z.string().regex(/^\d{4}-\d{4}$/, 'Academic year format: YYYY-YYYY'),
    category: zod_1.z.string().min(1),
    totalAmount: zod_1.z.number().positive(),
    frequency: zod_1.z.nativeEnum(index_js_1.FeeFrequency),
});
exports.ConcessionApplicationSchema = zod_1.z.object({
    studentId: zod_1.z.string().uuid(),
    discountPercentage: zod_1.z.number().min(1).max(100),
    reason: zod_1.z.string().min(3),
});
// ============================================================================
// Academics, Homework, Timetable & CBSE Grading Schemas
// ============================================================================
exports.MarksRecordSchema = zod_1.z.object({
    studentId: zod_1.z.string().uuid(),
    periodicTest: zod_1.z.number().min(0).max(10).default(0),
    notebook: zod_1.z.number().min(0).max(5).default(0),
    subjectEnrichment: zod_1.z.number().min(0).max(5).default(0),
    examMarks: zod_1.z.number().min(0).max(80).default(0),
    grade: zod_1.z.string().optional(),
    remarks: zod_1.z.string().max(255).optional(),
});
exports.MarksBatchEntrySchema = zod_1.z.object({
    termId: zod_1.z.string().min(1),
    subjectId: zod_1.z.string().min(1),
    classId: zod_1.z.string().uuid(),
    sectionId: zod_1.z.string().uuid(),
    records: zod_1.z.array(exports.MarksRecordSchema).min(1, 'At least one student marks record required'),
});
exports.TimetableClashCheckSchema = zod_1.z.object({
    teacherId: zod_1.z.string().uuid(),
    roomId: zod_1.z.string().min(1),
    dayOfWeek: zod_1.z.enum(['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY']),
    periodNumber: zod_1.z.number().int().min(1).max(10),
});
exports.TeacherSubstitutionSchema = zod_1.z.object({
    absentTeacherId: zod_1.z.string().uuid(),
    substituteTeacherId: zod_1.z.string().uuid(),
    date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date format: YYYY-MM-DD'),
    periodNumber: zod_1.z.number().int().min(1).max(10),
    sectionId: zod_1.z.string().uuid(),
    subjectId: zod_1.z.string().uuid(),
});
exports.CreateHomeworkSchema = zod_1.z.object({
    classId: zod_1.z.string().uuid(),
    sectionId: zod_1.z.string().uuid(),
    subjectId: zod_1.z.string().uuid(),
    title: zod_1.z.string().min(1).max(200),
    description: zod_1.z.string().min(1),
    dueDate: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date format: YYYY-MM-DD'),
    attachments: zod_1.z.array(zod_1.z.string().url()).optional(),
});
// ============================================================================
// Transport Fleet Schemas
// ============================================================================
exports.GpsLocationUpdateSchema = zod_1.z.object({
    schoolId: zod_1.z.string().uuid(),
    vehicleId: zod_1.z.string().uuid(),
    routeId: zod_1.z.string().uuid(),
    latitude: zod_1.z.number().min(-90).max(90),
    longitude: zod_1.z.number().min(-180).max(180),
    speed: zod_1.z.number().min(0).optional(),
    heading: zod_1.z.number().min(0).max(360).optional(),
    timestamp: zod_1.z.string().datetime(),
});
exports.StudentBoardingLogSchema = zod_1.z.object({
    schoolId: zod_1.z.string().uuid(),
    studentId: zod_1.z.string().uuid(),
    vehicleId: zod_1.z.string().uuid(),
    stopId: zod_1.z.string().uuid(),
    scanType: zod_1.z.enum(['BOARD', 'DEBOARD']),
    scannedAt: zod_1.z.string().datetime(),
});
exports.BoardingScanPayloadSchema = zod_1.z.object({
    busId: zod_1.z.string().min(1),
    studentId: zod_1.z.string().uuid(),
    stopId: zod_1.z.string().min(1),
    action: zod_1.z.enum(['BOARDED', 'DEBOARDED', 'BOARD', 'DEBOARD']),
    lat: zod_1.z.number().min(-90).max(90),
    lng: zod_1.z.number().min(-180).max(180),
    timestamp: zod_1.z.string().datetime().optional(),
});
// ============================================================================
// Safety & Visitor Management Schemas
// ============================================================================
exports.CreateVisitorPassSchema = zod_1.z.object({
    visitorName: zod_1.z.string().min(1, 'Visitor name is required'),
    visitorPhone: zod_1.z
        .string()
        .regex(/^\+91[6-9]\d{9}$/, 'Valid Indian mobile number (+91XXXXXXXXXX) required'),
    purpose: zod_1.z.string().min(1, 'Visit purpose required'),
    hostStaffId: zod_1.z.string().min(1, 'Host faculty / staff ID required'),
    expectedDate: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date format: YYYY-MM-DD'),
});
exports.VerifyChildPickupSchema = zod_1.z.object({
    studentId: zod_1.z.string().uuid(),
    pickupOtp: zod_1.z.string().length(6, 'Pickup OTP must be exactly 6 digits'),
    gateNumber: zod_1.z.string().min(1, 'Gate number/identifier required'),
});
exports.AnonymousIncidentReportSchema = zod_1.z.object({
    incidentType: zod_1.z.string().min(1),
    grade: zod_1.z.number().int().min(1).max(12),
    location: zod_1.z.string().min(1),
    description: zod_1.z.string().min(10, 'Please provide sufficient incident description'),
    timestamp: zod_1.z
        .string()
        .datetime()
        .or(zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/)),
});
// ============================================================================
// DPDP Act Consent & Data Privacy Schemas
// ============================================================================
exports.ConsentRecordSchema = zod_1.z.object({
    userId: zod_1.z.string().uuid(),
    consentType: zod_1.z.nativeEnum(index_js_1.ConsentType),
    version: zod_1.z.string().default('v1.0'),
    status: zod_1.z.nativeEnum(index_js_1.ConsentStatus).default(index_js_1.ConsentStatus.GRANTED),
    ipAddress: zod_1.z.string().ip().optional(),
    userAgent: zod_1.z.string().optional(),
    proofHash: zod_1.z.string().min(16),
});
exports.DataErasureRequestSchema = zod_1.z.object({
    userId: zod_1.z.string().uuid(),
    reason: zod_1.z.string().min(5),
    confirmPermanentErasure: zod_1.z.literal(true, {
        errorMap: () => ({ message: 'You must confirm permanent erasure' }),
    }),
});
// ============================================================================
// Pagination Query Schema
// ============================================================================
exports.PaginationQuerySchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).default(1),
    pageSize: zod_1.z.coerce.number().int().min(1).max(100).default(20),
    search: zod_1.z.string().optional(),
    sortBy: zod_1.z.string().optional(),
    sortOrder: zod_1.z.enum(['asc', 'desc']).default('asc'),
});
//# sourceMappingURL=index.js.map