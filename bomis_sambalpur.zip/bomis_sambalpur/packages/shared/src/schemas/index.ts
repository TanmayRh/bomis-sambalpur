import { z } from 'zod';
import {
  Gender,
  AttendanceStatus,
  PaymentMethod,
  FeeFrequency,
  ConsentType,
  ConsentStatus,
} from '../enums/index.js';

// ============================================================================
// Auth Schemas
// ============================================================================

export const MobileOtpRequestSchema = z.object({
  phone: z.string().regex(/^\+91[6-9]\d{9}$/, 'Invalid Indian mobile number (+91XXXXXXXXXX)'),
  schoolId: z.string().uuid().optional(),
});

export const VerifyOtpSchema = z.object({
  phone: z.string().regex(/^\+91[6-9]\d{9}$/, 'Invalid Indian mobile number (+91XXXXXXXXXX)'),
  code: z.string().length(6, 'OTP must be 6 digits'),
});

export const StaffLoginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
});

export const RefreshTokenSchema = z.object({
  refreshToken: z.string().min(1, 'Refresh token required'),
});

export const LogoutSchema = z.object({
  refreshToken: z.string().optional(),
});

// ============================================================================
// Student & People Schemas
// ============================================================================

export const CreateStudentSchema = z.object({
  schoolId: z.string().uuid(),
  admissionNumber: z.string().min(1, 'Admission number required'),
  rollNumber: z.string().min(1, 'Roll number required'),
  firstName: z.string().min(1, 'First name required'),
  lastName: z.string().min(1, 'Last name required'),
  dateOfBirth: z.string().datetime(),
  gender: z.nativeEnum(Gender),
  classId: z.string().uuid(),
  sectionId: z.string().uuid(),
  emergencyContact: z.string().regex(/^\+91[6-9]\d{9}$/),
});

// ============================================================================
// Attendance & Offline Sync Schemas
// ============================================================================

export const AttendanceRecordSchema = z.object({
  studentId: z.string().uuid(),
  status: z.nativeEnum(AttendanceStatus),
  remarks: z.string().max(255).optional(),
});

export const AttendanceMarkBatchSchema = z.object({
  schoolId: z.string().uuid(),
  sectionId: z.string().uuid(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be YYYY-MM-DD'),
  records: z.array(AttendanceRecordSchema).min(1, 'At least one attendance record required'),
  offlineBatchId: z.string().uuid().optional(),
});

export const RapidAttendanceBatchSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be YYYY-MM-DD'),
  classId: z.string().uuid(),
  sectionId: z.string().uuid(),
  defaultStatus: z.nativeEnum(AttendanceStatus).default(AttendanceStatus.PRESENT),
  exceptions: z
    .array(
      z.object({
        studentId: z.string().uuid(),
        status: z.nativeEnum(AttendanceStatus),
        remarks: z.string().max(255).optional(),
      })
    )
    .default([]),
});

export const OfflineSyncEventSchema = z.object({
  id: z.string(),
  actionType: z.enum(['ATTENDANCE_BATCH', 'BOARDING_SCAN', 'GPS_PING']),
  idempotencyKey: z.string().min(1),
  timestamp: z.number().int().positive(),
  payload: z.record(z.unknown()),
});

export const OfflineSyncBatchSchema = z.object({
  events: z.array(OfflineSyncEventSchema).min(1, 'At least one sync event required'),
});

// ============================================================================
// Fees & Razorpay Payment Schemas
// ============================================================================

export const InitiatePaymentSchema = z.object({
  schoolId: z.string().uuid(),
  studentId: z.string().uuid(),
  installmentId: z.string().uuid(),
  amount: z.number().positive('Amount must be greater than zero'),
  paymentMethod: z.nativeEnum(PaymentMethod),
  idempotencyKey: z.string().uuid('Unique Idempotency-Key required'),
});

export const CreateRazorpayOrderSchema = z.object({
  studentId: z.string().uuid(),
  installmentNumber: z.number().int().positive(),
  amountPaise: z.number().int().positive(),
  paymentMethod: z.enum([
    'UPI',
    'NETBANKING',
    'CARD',
    'RAZORPAY_UPI',
    'RAZORPAY_NETBANKING',
    'RAZORPAY_CARD',
  ]),
});

export const RazorpayWebhookSchema = z.object({
  entity: z.literal('event'),
  event: z.string(),
  payload: z.object({
    payment: z.object({
      entity: z.object({
        id: z.string(),
        order_id: z.string(),
        amount: z.number(),
        currency: z.string(),
        status: z.string(),
        method: z.string(),
      }),
    }),
  }),
});

export const CreateFeeStructureSchema = z.object({
  schoolId: z.string().uuid(),
  classId: z.string().uuid(),
  academicYear: z.string().regex(/^\d{4}-\d{4}$/, 'Academic year format: YYYY-YYYY'),
  category: z.string().min(1),
  totalAmount: z.number().positive(),
  frequency: z.nativeEnum(FeeFrequency),
});

export const ConcessionApplicationSchema = z.object({
  studentId: z.string().uuid(),
  discountPercentage: z.number().min(1).max(100),
  reason: z.string().min(3),
});

// ============================================================================
// Academics, Homework, Timetable & CBSE Grading Schemas
// ============================================================================

export const MarksRecordSchema = z.object({
  studentId: z.string().uuid(),
  periodicTest: z.number().min(0).max(10).default(0),
  notebook: z.number().min(0).max(5).default(0),
  subjectEnrichment: z.number().min(0).max(5).default(0),
  examMarks: z.number().min(0).max(80).default(0),
  grade: z.string().optional(),
  remarks: z.string().max(255).optional(),
});

export const MarksBatchEntrySchema = z.object({
  termId: z.string().min(1),
  subjectId: z.string().min(1),
  classId: z.string().uuid(),
  sectionId: z.string().uuid(),
  records: z.array(MarksRecordSchema).min(1, 'At least one student marks record required'),
});

export const TimetableClashCheckSchema = z.object({
  teacherId: z.string().uuid(),
  roomId: z.string().min(1),
  dayOfWeek: z.enum(['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY']),
  periodNumber: z.number().int().min(1).max(10),
});

export const TeacherSubstitutionSchema = z.object({
  absentTeacherId: z.string().uuid(),
  substituteTeacherId: z.string().uuid(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date format: YYYY-MM-DD'),
  periodNumber: z.number().int().min(1).max(10),
  sectionId: z.string().uuid(),
  subjectId: z.string().uuid(),
});

export const CreateHomeworkSchema = z.object({
  classId: z.string().uuid(),
  sectionId: z.string().uuid(),
  subjectId: z.string().uuid(),
  title: z.string().min(1).max(200),
  description: z.string().min(1),
  dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date format: YYYY-MM-DD'),
  attachments: z.array(z.string().url()).optional(),
});

// ============================================================================
// Transport Fleet Schemas
// ============================================================================

export const GpsLocationUpdateSchema = z.object({
  schoolId: z.string().uuid(),
  vehicleId: z.string().uuid(),
  routeId: z.string().uuid(),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  speed: z.number().min(0).optional(),
  heading: z.number().min(0).max(360).optional(),
  timestamp: z.string().datetime(),
});

export const StudentBoardingLogSchema = z.object({
  schoolId: z.string().uuid(),
  studentId: z.string().uuid(),
  vehicleId: z.string().uuid(),
  stopId: z.string().uuid(),
  scanType: z.enum(['BOARD', 'DEBOARD']),
  scannedAt: z.string().datetime(),
});

export const BoardingScanPayloadSchema = z.object({
  busId: z.string().min(1),
  studentId: z.string().uuid(),
  stopId: z.string().min(1),
  action: z.enum(['BOARDED', 'DEBOARDED', 'BOARD', 'DEBOARD']),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  timestamp: z.string().datetime().optional(),
});

// ============================================================================
// Safety & Visitor Management Schemas
// ============================================================================

export const CreateVisitorPassSchema = z.object({
  visitorName: z.string().min(1, 'Visitor name is required'),
  visitorPhone: z
    .string()
    .regex(/^\+91[6-9]\d{9}$/, 'Valid Indian mobile number (+91XXXXXXXXXX) required'),
  purpose: z.string().min(1, 'Visit purpose required'),
  hostStaffId: z.string().min(1, 'Host faculty / staff ID required'),
  expectedDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date format: YYYY-MM-DD'),
});

export const VerifyChildPickupSchema = z.object({
  studentId: z.string().uuid(),
  pickupOtp: z.string().length(6, 'Pickup OTP must be exactly 6 digits'),
  gateNumber: z.string().min(1, 'Gate number/identifier required'),
});

export const AnonymousIncidentReportSchema = z.object({
  incidentType: z.string().min(1),
  grade: z.number().int().min(1).max(12),
  location: z.string().min(1),
  description: z.string().min(10, 'Please provide sufficient incident description'),
  timestamp: z
    .string()
    .datetime()
    .or(z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/)),
});

// ============================================================================
// DPDP Act Consent & Data Privacy Schemas
// ============================================================================

export const ConsentRecordSchema = z.object({
  userId: z.string().uuid(),
  consentType: z.nativeEnum(ConsentType),
  version: z.string().default('v1.0'),
  status: z.nativeEnum(ConsentStatus).default(ConsentStatus.GRANTED),
  ipAddress: z.string().ip().optional(),
  userAgent: z.string().optional(),
  proofHash: z.string().min(16),
});

export const DataErasureRequestSchema = z.object({
  userId: z.string().uuid(),
  reason: z.string().min(5),
  confirmPermanentErasure: z.literal(true, {
    errorMap: () => ({ message: 'You must confirm permanent erasure' }),
  }),
});

// ============================================================================
// Pagination Query Schema
// ============================================================================

export const PaginationQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  search: z.string().optional(),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('asc'),
});
