"use strict";
/**
 * Canonical Domain Enums for BOMIS Sambalpur Unified School Platform
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.BoardingAction = exports.SafetyIncidentType = exports.DayOfWeek = exports.CBSEGrade = exports.VisitorPassStatus = exports.ConcessionStatus = exports.AuditAction = exports.ConsentStatus = exports.ConsentType = exports.BoardingStatus = exports.BusTripType = exports.ExamTerm = exports.HomeworkStatus = exports.PaymentMethod = exports.PaymentStatus = exports.FeeFrequency = exports.AttendanceStatus = exports.Gender = exports.UserStatus = exports.UserRole = void 0;
var UserRole;
(function (UserRole) {
    UserRole["SUPER_ADMIN"] = "SUPER_ADMIN";
    UserRole["ADMIN"] = "ADMIN";
    UserRole["PRINCIPAL"] = "PRINCIPAL";
    UserRole["TEACHER"] = "TEACHER";
    UserRole["ACCOUNTANT"] = "ACCOUNTANT";
    UserRole["STUDENT"] = "STUDENT";
    UserRole["PARENT"] = "PARENT";
    UserRole["TRANSPORT_STAFF"] = "TRANSPORT_STAFF";
    UserRole["DRIVER_TRANSPORT"] = "TRANSPORT_STAFF";
})(UserRole || (exports.UserRole = UserRole = {}));
var UserStatus;
(function (UserStatus) {
    UserStatus["ACTIVE"] = "ACTIVE";
    UserStatus["INACTIVE"] = "INACTIVE";
    UserStatus["SUSPENDED"] = "SUSPENDED";
    UserStatus["PENDING_VERIFICATION"] = "PENDING_VERIFICATION";
})(UserStatus || (exports.UserStatus = UserStatus = {}));
var Gender;
(function (Gender) {
    Gender["MALE"] = "MALE";
    Gender["FEMALE"] = "FEMALE";
    Gender["OTHER"] = "OTHER";
})(Gender || (exports.Gender = Gender = {}));
var AttendanceStatus;
(function (AttendanceStatus) {
    AttendanceStatus["PRESENT"] = "PRESENT";
    AttendanceStatus["ABSENT"] = "ABSENT";
    AttendanceStatus["LATE"] = "LATE";
    AttendanceStatus["HALF_DAY"] = "HALF_DAY";
    AttendanceStatus["EXCUSED"] = "EXCUSED";
})(AttendanceStatus || (exports.AttendanceStatus = AttendanceStatus = {}));
var FeeFrequency;
(function (FeeFrequency) {
    FeeFrequency["ONE_TIME"] = "ONE_TIME";
    FeeFrequency["ANNUAL"] = "ANNUAL";
    FeeFrequency["TERM"] = "TERM";
    FeeFrequency["MONTHLY"] = "MONTHLY";
    FeeFrequency["CUSTOM"] = "CUSTOM";
})(FeeFrequency || (exports.FeeFrequency = FeeFrequency = {}));
var PaymentStatus;
(function (PaymentStatus) {
    PaymentStatus["PENDING"] = "PENDING";
    PaymentStatus["SUCCESS"] = "SUCCESS";
    PaymentStatus["FAILED"] = "FAILED";
    PaymentStatus["REFUNDED"] = "REFUNDED";
})(PaymentStatus || (exports.PaymentStatus = PaymentStatus = {}));
var PaymentMethod;
(function (PaymentMethod) {
    PaymentMethod["RAZORPAY_UPI"] = "RAZORPAY_UPI";
    PaymentMethod["RAZORPAY_NETBANKING"] = "RAZORPAY_NETBANKING";
    PaymentMethod["RAZORPAY_CARD"] = "RAZORPAY_CARD";
    PaymentMethod["CASH"] = "CASH";
    PaymentMethod["CHEQUE"] = "CHEQUE";
    PaymentMethod["BANK_TRANSFER"] = "BANK_TRANSFER";
})(PaymentMethod || (exports.PaymentMethod = PaymentMethod = {}));
var HomeworkStatus;
(function (HomeworkStatus) {
    HomeworkStatus["ASSIGNED"] = "ASSIGNED";
    HomeworkStatus["SUBMITTED"] = "SUBMITTED";
    HomeworkStatus["REVIEWED"] = "REVIEWED";
    HomeworkStatus["RESUBMISSION_REQUESTED"] = "RESUBMISSION_REQUESTED";
})(HomeworkStatus || (exports.HomeworkStatus = HomeworkStatus = {}));
var ExamTerm;
(function (ExamTerm) {
    ExamTerm["TERM_1"] = "TERM_1";
    ExamTerm["TERM_2"] = "TERM_2";
    ExamTerm["UNIT_TEST_1"] = "UNIT_TEST_1";
    ExamTerm["UNIT_TEST_2"] = "UNIT_TEST_2";
    ExamTerm["MID_TERM"] = "MID_TERM";
    ExamTerm["FINAL"] = "FINAL";
})(ExamTerm || (exports.ExamTerm = ExamTerm = {}));
var BusTripType;
(function (BusTripType) {
    BusTripType["MORNING_PICKUP"] = "MORNING_PICKUP";
    BusTripType["AFTERNOON_DROP"] = "AFTERNOON_DROP";
    BusTripType["SPECIAL_EVENT"] = "SPECIAL_EVENT";
})(BusTripType || (exports.BusTripType = BusTripType = {}));
var BoardingStatus;
(function (BoardingStatus) {
    BoardingStatus["SCHEDULED"] = "SCHEDULED";
    BoardingStatus["BOARDED"] = "BOARDED";
    BoardingStatus["DEBOARDED"] = "DEBOARDED";
    BoardingStatus["ABSENT"] = "ABSENT";
})(BoardingStatus || (exports.BoardingStatus = BoardingStatus = {}));
var ConsentType;
(function (ConsentType) {
    ConsentType["DATA_PROCESSING"] = "DATA_PROCESSING";
    ConsentType["HEALTH_RECORDS"] = "HEALTH_RECORDS";
    ConsentType["MEDIA_RELEASE"] = "MEDIA_RELEASE";
    ConsentType["TRANSPORT_TRACKING"] = "TRANSPORT_TRACKING";
    ConsentType["SMS_NOTIFICATIONS"] = "SMS_NOTIFICATIONS";
})(ConsentType || (exports.ConsentType = ConsentType = {}));
var ConsentStatus;
(function (ConsentStatus) {
    ConsentStatus["GRANTED"] = "GRANTED";
    ConsentStatus["REVOKED"] = "REVOKED";
    ConsentStatus["EXPIRED"] = "EXPIRED";
})(ConsentStatus || (exports.ConsentStatus = ConsentStatus = {}));
var AuditAction;
(function (AuditAction) {
    AuditAction["CREATE"] = "CREATE";
    AuditAction["UPDATE"] = "UPDATE";
    AuditAction["DELETE"] = "DELETE";
    AuditAction["LOGIN"] = "LOGIN";
    AuditAction["LOGOUT"] = "LOGOUT";
    AuditAction["CONSENT_CHANGE"] = "CONSENT_CHANGE";
    AuditAction["PAYMENT"] = "PAYMENT";
    AuditAction["DATA_ERASURE"] = "DATA_ERASURE";
})(AuditAction || (exports.AuditAction = AuditAction = {}));
var ConcessionStatus;
(function (ConcessionStatus) {
    ConcessionStatus["PENDING"] = "PENDING";
    ConcessionStatus["APPROVED"] = "APPROVED";
    ConcessionStatus["REJECTED"] = "REJECTED";
})(ConcessionStatus || (exports.ConcessionStatus = ConcessionStatus = {}));
var VisitorPassStatus;
(function (VisitorPassStatus) {
    VisitorPassStatus["PRE_APPROVED"] = "PRE_APPROVED";
    VisitorPassStatus["ACTIVE_ON_CAMPUS"] = "ACTIVE_ON_CAMPUS";
    VisitorPassStatus["CHECKED_OUT"] = "CHECKED_OUT";
    VisitorPassStatus["EXPIRED"] = "EXPIRED";
    VisitorPassStatus["DENIED"] = "DENIED";
})(VisitorPassStatus || (exports.VisitorPassStatus = VisitorPassStatus = {}));
var CBSEGrade;
(function (CBSEGrade) {
    CBSEGrade["A1"] = "A1";
    CBSEGrade["A2"] = "A2";
    CBSEGrade["B1"] = "B1";
    CBSEGrade["B2"] = "B2";
    CBSEGrade["C1"] = "C1";
    CBSEGrade["C2"] = "C2";
    CBSEGrade["D"] = "D";
    CBSEGrade["E"] = "E";
    CBSEGrade["A"] = "A";
    CBSEGrade["B"] = "B";
    CBSEGrade["C"] = "C";
})(CBSEGrade || (exports.CBSEGrade = CBSEGrade = {}));
var DayOfWeek;
(function (DayOfWeek) {
    DayOfWeek["MONDAY"] = "MONDAY";
    DayOfWeek["TUESDAY"] = "TUESDAY";
    DayOfWeek["WEDNESDAY"] = "WEDNESDAY";
    DayOfWeek["THURSDAY"] = "THURSDAY";
    DayOfWeek["FRIDAY"] = "FRIDAY";
    DayOfWeek["SATURDAY"] = "SATURDAY";
    DayOfWeek["SUNDAY"] = "SUNDAY";
})(DayOfWeek || (exports.DayOfWeek = DayOfWeek = {}));
var SafetyIncidentType;
(function (SafetyIncidentType) {
    SafetyIncidentType["BULLYING"] = "BULLYING";
    SafetyIncidentType["HARASSMENT"] = "HARASSMENT";
    SafetyIncidentType["VANDALISM"] = "VANDALISM";
    SafetyIncidentType["THEFT"] = "THEFT";
    SafetyIncidentType["SAFETY_HAZARD"] = "SAFETY_HAZARD";
    SafetyIncidentType["OTHER"] = "OTHER";
})(SafetyIncidentType || (exports.SafetyIncidentType = SafetyIncidentType = {}));
var BoardingAction;
(function (BoardingAction) {
    BoardingAction["BOARD"] = "BOARD";
    BoardingAction["DEBOARD"] = "DEBOARD";
    BoardingAction["BOARDED"] = "BOARDED";
    BoardingAction["DEBOARDED"] = "DEBOARDED";
})(BoardingAction || (exports.BoardingAction = BoardingAction = {}));
//# sourceMappingURL=index.js.map