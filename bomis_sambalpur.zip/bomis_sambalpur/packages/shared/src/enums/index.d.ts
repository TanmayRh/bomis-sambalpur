/**
 * Canonical Domain Enums for BOMIS Sambalpur Unified School Platform
 */
export declare enum UserRole {
    SUPER_ADMIN = "SUPER_ADMIN",
    ADMIN = "ADMIN",
    PRINCIPAL = "PRINCIPAL",
    TEACHER = "TEACHER",
    ACCOUNTANT = "ACCOUNTANT",
    STUDENT = "STUDENT",
    PARENT = "PARENT",
    TRANSPORT_STAFF = "TRANSPORT_STAFF",
    DRIVER_TRANSPORT = "TRANSPORT_STAFF"
}
export declare enum UserStatus {
    ACTIVE = "ACTIVE",
    INACTIVE = "INACTIVE",
    SUSPENDED = "SUSPENDED",
    PENDING_VERIFICATION = "PENDING_VERIFICATION"
}
export declare enum Gender {
    MALE = "MALE",
    FEMALE = "FEMALE",
    OTHER = "OTHER"
}
export declare enum AttendanceStatus {
    PRESENT = "PRESENT",
    ABSENT = "ABSENT",
    LATE = "LATE",
    HALF_DAY = "HALF_DAY",
    EXCUSED = "EXCUSED"
}
export declare enum FeeFrequency {
    ONE_TIME = "ONE_TIME",
    ANNUAL = "ANNUAL",
    TERM = "TERM",
    MONTHLY = "MONTHLY",
    CUSTOM = "CUSTOM"
}
export declare enum PaymentStatus {
    PENDING = "PENDING",
    SUCCESS = "SUCCESS",
    FAILED = "FAILED",
    REFUNDED = "REFUNDED"
}
export declare enum PaymentMethod {
    RAZORPAY_UPI = "RAZORPAY_UPI",
    RAZORPAY_NETBANKING = "RAZORPAY_NETBANKING",
    RAZORPAY_CARD = "RAZORPAY_CARD",
    CASH = "CASH",
    CHEQUE = "CHEQUE",
    BANK_TRANSFER = "BANK_TRANSFER"
}
export declare enum HomeworkStatus {
    ASSIGNED = "ASSIGNED",
    SUBMITTED = "SUBMITTED",
    REVIEWED = "REVIEWED",
    RESUBMISSION_REQUESTED = "RESUBMISSION_REQUESTED"
}
export declare enum ExamTerm {
    TERM_1 = "TERM_1",
    TERM_2 = "TERM_2",
    UNIT_TEST_1 = "UNIT_TEST_1",
    UNIT_TEST_2 = "UNIT_TEST_2",
    MID_TERM = "MID_TERM",
    FINAL = "FINAL"
}
export declare enum BusTripType {
    MORNING_PICKUP = "MORNING_PICKUP",
    AFTERNOON_DROP = "AFTERNOON_DROP",
    SPECIAL_EVENT = "SPECIAL_EVENT"
}
export declare enum BoardingStatus {
    SCHEDULED = "SCHEDULED",
    BOARDED = "BOARDED",
    DEBOARDED = "DEBOARDED",
    ABSENT = "ABSENT"
}
export declare enum ConsentType {
    DATA_PROCESSING = "DATA_PROCESSING",
    HEALTH_RECORDS = "HEALTH_RECORDS",
    MEDIA_RELEASE = "MEDIA_RELEASE",
    TRANSPORT_TRACKING = "TRANSPORT_TRACKING",
    SMS_NOTIFICATIONS = "SMS_NOTIFICATIONS"
}
export declare enum ConsentStatus {
    GRANTED = "GRANTED",
    REVOKED = "REVOKED",
    EXPIRED = "EXPIRED"
}
export declare enum AuditAction {
    CREATE = "CREATE",
    UPDATE = "UPDATE",
    DELETE = "DELETE",
    LOGIN = "LOGIN",
    LOGOUT = "LOGOUT",
    CONSENT_CHANGE = "CONSENT_CHANGE",
    PAYMENT = "PAYMENT",
    DATA_ERASURE = "DATA_ERASURE"
}
export declare enum ConcessionStatus {
    PENDING = "PENDING",
    APPROVED = "APPROVED",
    REJECTED = "REJECTED"
}
export declare enum VisitorPassStatus {
    PRE_APPROVED = "PRE_APPROVED",
    ACTIVE_ON_CAMPUS = "ACTIVE_ON_CAMPUS",
    CHECKED_OUT = "CHECKED_OUT",
    EXPIRED = "EXPIRED",
    DENIED = "DENIED"
}
export declare enum CBSEGrade {
    A1 = "A1",
    A2 = "A2",
    B1 = "B1",
    B2 = "B2",
    C1 = "C1",
    C2 = "C2",
    D = "D",
    E = "E",
    A = "A",
    B = "B",
    C = "C"
}
export declare enum DayOfWeek {
    MONDAY = "MONDAY",
    TUESDAY = "TUESDAY",
    WEDNESDAY = "WEDNESDAY",
    THURSDAY = "THURSDAY",
    FRIDAY = "FRIDAY",
    SATURDAY = "SATURDAY",
    SUNDAY = "SUNDAY"
}
export declare enum SafetyIncidentType {
    BULLYING = "BULLYING",
    HARASSMENT = "HARASSMENT",
    VANDALISM = "VANDALISM",
    THEFT = "THEFT",
    SAFETY_HAZARD = "SAFETY_HAZARD",
    OTHER = "OTHER"
}
export declare enum BoardingAction {
    BOARD = "BOARD",
    DEBOARD = "DEBOARD",
    BOARDED = "BOARDED",
    DEBOARDED = "DEBOARDED"
}
//# sourceMappingURL=index.d.ts.map