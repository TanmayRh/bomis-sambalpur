"use strict";
/**
 * Standardized API Response and Envelope Contracts
 * Conforms strictly to R1 / AC-2 specification
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=index.js.map