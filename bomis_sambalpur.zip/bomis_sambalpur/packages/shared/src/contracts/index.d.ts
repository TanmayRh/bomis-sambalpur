/**
 * Standardized API Response and Envelope Contracts
 * Conforms strictly to R1 / AC-2 specification
 */
export interface ApiErrorDetail {
    code: string;
    message: string;
    details?: unknown;
}
export interface ApiResponse<T = unknown> {
    success: boolean;
    data: T | null;
    error?: ApiErrorDetail | null;
    timestamp: string;
    correlationId: string;
}
export interface PaginationMeta {
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
}
export interface PaginatedData<T> {
    items: T[];
    pagination: PaginationMeta;
}
//# sourceMappingURL=index.d.ts.map