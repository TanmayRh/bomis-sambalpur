import { UserRole } from '../enums/index.js';

export const Permissions = {
  // Users & Staff
  USERS_READ: 'users:read',
  USERS_CREATE: 'users:create',
  USERS_UPDATE: 'users:update',
  USERS_DELETE: 'users:delete',

  // Students Master
  STUDENTS_READ: 'students:read',
  STUDENTS_CREATE: 'students:create',
  STUDENTS_UPDATE: 'students:update',
  STUDENTS_DELETE: 'students:delete',

  // Attendance
  ATTENDANCE_MARK: 'attendance:mark',
  ATTENDANCE_READ: 'attendance:read',
  ATTENDANCE_OVERRIDE: 'attendance:override',

  // Fees & Payments
  FEES_READ: 'fees:read',
  FEES_MANAGE: 'fees:manage',
  FEES_PAY: 'fees:pay',
  FEES_APPROVE_CONCESSION: 'fees:approve_concession',
  FEES_RECONCILE: 'fees:reconcile',

  // Homework & Diary
  HOMEWORK_READ: 'homework:read',
  HOMEWORK_CREATE: 'homework:create',
  HOMEWORK_SUBMIT: 'homework:submit',
  HOMEWORK_GRADE: 'homework:grade',

  // Timetable
  TIMETABLE_READ: 'timetable:read',
  TIMETABLE_MANAGE: 'timetable:manage',
  TIMETABLE_SUBSTITUTE: 'timetable:substitute',

  // Exams & Marks
  EXAMS_READ: 'exams:read',
  EXAMS_MANAGE: 'exams:manage',
  MARKS_ENTRY: 'marks:entry',
  MARKS_APPROVE: 'marks:approve',

  // Transport & GPS
  TRANSPORT_READ: 'transport:read',
  TRANSPORT_MANAGE: 'transport:manage',
  TRANSPORT_BROADCAST_GPS: 'transport:broadcast_gps',
  TRANSPORT_SCAN_BOARDING: 'transport:scan_boarding',

  // Audit & DPDP
  AUDIT_READ: 'audit:read',
  DPDP_MANAGE_CONSENT: 'dpdp:manage_consent',
  DPDP_REQUEST_ERASURE: 'dpdp:request_erasure',

  // Safety & Gate Security
  SAFETY_VISITOR_MANAGE: 'safety:visitor_manage',
  SAFETY_PICKUP_VERIFY: 'safety:pickup_verify',
  SAFETY_INCIDENT_VIEW: 'safety:incident_view',

  // Notices & Digital Circulars
  NOTICES_READ: 'notices:read',
  NOTICES_MANAGE: 'notices:manage',

  // AI Assist
  AI_STUDY_BUDDY: 'ai:study_buddy',
  AI_LESSON_PLANNER: 'ai:lesson_planner',
} as const;

export type Permission = (typeof Permissions)[keyof typeof Permissions];

export const RolePermissionsMap: Record<UserRole, readonly Permission[]> = {
  [UserRole.SUPER_ADMIN]: Object.values(Permissions),

  [UserRole.ADMIN]: [
    Permissions.USERS_READ,
    Permissions.USERS_CREATE,
    Permissions.USERS_UPDATE,
    Permissions.STUDENTS_READ,
    Permissions.STUDENTS_CREATE,
    Permissions.STUDENTS_UPDATE,
    Permissions.ATTENDANCE_READ,
    Permissions.ATTENDANCE_OVERRIDE,
    Permissions.FEES_READ,
    Permissions.FEES_MANAGE,
    Permissions.FEES_APPROVE_CONCESSION,
    Permissions.HOMEWORK_READ,
    Permissions.TIMETABLE_READ,
    Permissions.TIMETABLE_MANAGE,
    Permissions.EXAMS_READ,
    Permissions.EXAMS_MANAGE,
    Permissions.MARKS_APPROVE,
    Permissions.TRANSPORT_READ,
    Permissions.TRANSPORT_MANAGE,
    Permissions.AUDIT_READ,
    Permissions.SAFETY_VISITOR_MANAGE,
    Permissions.SAFETY_PICKUP_VERIFY,
    Permissions.SAFETY_INCIDENT_VIEW,
    Permissions.NOTICES_READ,
    Permissions.NOTICES_MANAGE,
  ],

  [UserRole.PRINCIPAL]: [
    Permissions.USERS_READ,
    Permissions.STUDENTS_READ,
    Permissions.ATTENDANCE_READ,
    Permissions.ATTENDANCE_OVERRIDE,
    Permissions.FEES_READ,
    Permissions.FEES_APPROVE_CONCESSION,
    Permissions.HOMEWORK_READ,
    Permissions.TIMETABLE_READ,
    Permissions.TIMETABLE_SUBSTITUTE,
    Permissions.EXAMS_READ,
    Permissions.MARKS_APPROVE,
    Permissions.TRANSPORT_READ,
    Permissions.AUDIT_READ,
    Permissions.SAFETY_VISITOR_MANAGE,
    Permissions.SAFETY_PICKUP_VERIFY,
    Permissions.SAFETY_INCIDENT_VIEW,
    Permissions.NOTICES_READ,
    Permissions.NOTICES_MANAGE,
    Permissions.AI_LESSON_PLANNER,
  ],

  [UserRole.TEACHER]: [
    Permissions.STUDENTS_READ,
    Permissions.ATTENDANCE_MARK,
    Permissions.ATTENDANCE_READ,
    Permissions.HOMEWORK_READ,
    Permissions.HOMEWORK_CREATE,
    Permissions.HOMEWORK_GRADE,
    Permissions.TIMETABLE_READ,
    Permissions.EXAMS_READ,
    Permissions.MARKS_ENTRY,
    Permissions.TRANSPORT_READ,
    Permissions.NOTICES_READ,
    Permissions.AI_LESSON_PLANNER,
  ],

  [UserRole.ACCOUNTANT]: [
    Permissions.STUDENTS_READ,
    Permissions.FEES_READ,
    Permissions.FEES_MANAGE,
    Permissions.FEES_RECONCILE,
    Permissions.AUDIT_READ,
    Permissions.NOTICES_READ,
  ],

  [UserRole.STUDENT]: [
    Permissions.HOMEWORK_READ,
    Permissions.HOMEWORK_SUBMIT,
    Permissions.TIMETABLE_READ,
    Permissions.EXAMS_READ,
    Permissions.ATTENDANCE_READ,
    Permissions.DPDP_MANAGE_CONSENT,
    Permissions.NOTICES_READ,
    Permissions.AI_STUDY_BUDDY,
  ],

  [UserRole.PARENT]: [
    Permissions.STUDENTS_READ,
    Permissions.ATTENDANCE_READ,
    Permissions.FEES_READ,
    Permissions.FEES_PAY,
    Permissions.HOMEWORK_READ,
    Permissions.TIMETABLE_READ,
    Permissions.EXAMS_READ,
    Permissions.TRANSPORT_READ,
    Permissions.DPDP_MANAGE_CONSENT,
    Permissions.DPDP_REQUEST_ERASURE,
    Permissions.SAFETY_PICKUP_VERIFY,
    Permissions.NOTICES_READ,
    Permissions.AI_STUDY_BUDDY,
  ],

  [UserRole.TRANSPORT_STAFF]: [
    Permissions.TRANSPORT_READ,
    Permissions.TRANSPORT_BROADCAST_GPS,
    Permissions.TRANSPORT_SCAN_BOARDING,
    Permissions.SAFETY_PICKUP_VERIFY,
    Permissions.NOTICES_READ,
  ],
};

export function hasPermission(role: UserRole, permission: Permission): boolean {
  const allowed = RolePermissionsMap[role];
  return allowed ? allowed.includes(permission) : false;
}
