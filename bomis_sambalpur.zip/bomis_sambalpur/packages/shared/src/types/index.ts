import { z } from 'zod';
import {
  MobileOtpRequestSchema,
  VerifyOtpSchema,
  StaffLoginSchema,
  RefreshTokenSchema,
  LogoutSchema,
  CreateStudentSchema,
  AttendanceRecordSchema,
  AttendanceMarkBatchSchema,
  RapidAttendanceBatchSchema,
  OfflineSyncEventSchema,
  OfflineSyncBatchSchema,
  InitiatePaymentSchema,
  CreateRazorpayOrderSchema,
  RazorpayWebhookSchema,
  CreateFeeStructureSchema,
  ConcessionApplicationSchema,
  MarksRecordSchema,
  MarksBatchEntrySchema,
  TimetableClashCheckSchema,
  TeacherSubstitutionSchema,
  CreateHomeworkSchema,
  GpsLocationUpdateSchema,
  StudentBoardingLogSchema,
  BoardingScanPayloadSchema,
  CreateVisitorPassSchema,
  VerifyChildPickupSchema,
  AnonymousIncidentReportSchema,
  ConsentRecordSchema,
  DataErasureRequestSchema,
  PaginationQuerySchema,
} from '../schemas/index.js';

// Auth Types
export type MobileOtpRequest = z.infer<typeof MobileOtpRequestSchema>;
export type VerifyOtp = z.infer<typeof VerifyOtpSchema>;
export type StaffLogin = z.infer<typeof StaffLoginSchema>;
export type RefreshTokenInput = z.infer<typeof RefreshTokenSchema>;
export type LogoutInput = z.infer<typeof LogoutSchema>;

// Student & People Types
export type CreateStudent = z.infer<typeof CreateStudentSchema>;

// Attendance & Offline Sync Types
export type AttendanceRecord = z.infer<typeof AttendanceRecordSchema>;
export type AttendanceMarkBatch = z.infer<typeof AttendanceMarkBatchSchema>;
export type RapidAttendanceBatch = z.infer<typeof RapidAttendanceBatchSchema>;
export type OfflineSyncEvent = z.infer<typeof OfflineSyncEventSchema>;
export type OfflineSyncBatch = z.infer<typeof OfflineSyncBatchSchema>;

// Payment & Fees Types
export type InitiatePayment = z.infer<typeof InitiatePaymentSchema>;
export type CreateRazorpayOrder = z.infer<typeof CreateRazorpayOrderSchema>;
export type RazorpayWebhook = z.infer<typeof RazorpayWebhookSchema>;
export type CreateFeeStructure = z.infer<typeof CreateFeeStructureSchema>;
export type ConcessionApplication = z.infer<typeof ConcessionApplicationSchema>;

// Academics, Homework & CBSE Grading Types
export type MarksRecord = z.infer<typeof MarksRecordSchema>;
export type MarksBatchEntry = z.infer<typeof MarksBatchEntrySchema>;
export type TimetableClashCheck = z.infer<typeof TimetableClashCheckSchema>;
export type TeacherSubstitution = z.infer<typeof TeacherSubstitutionSchema>;
export type CreateHomework = z.infer<typeof CreateHomeworkSchema>;

// Transport Types
export type GpsLocationUpdate = z.infer<typeof GpsLocationUpdateSchema>;
export type StudentBoardingLog = z.infer<typeof StudentBoardingLogSchema>;
export type BoardingScanPayload = z.infer<typeof BoardingScanPayloadSchema>;

// Safety & Visitor Types
export type CreateVisitorPass = z.infer<typeof CreateVisitorPassSchema>;
export type VerifyChildPickup = z.infer<typeof VerifyChildPickupSchema>;
export type AnonymousIncidentReport = z.infer<typeof AnonymousIncidentReportSchema>;

// DPDP Consent & Privacy Types
export type ConsentRecord = z.infer<typeof ConsentRecordSchema>;
export type DataErasureRequest = z.infer<typeof DataErasureRequestSchema>;

// Pagination Types
export type PaginationQuery = z.infer<typeof PaginationQuerySchema>;
