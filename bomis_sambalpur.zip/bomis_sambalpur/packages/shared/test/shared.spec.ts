import {
  UserRole,
  Permissions,
  hasPermission,
  MobileOtpRequestSchema,
  VerifyOtpSchema,
  StaffLoginSchema,
  RefreshTokenSchema,
  LogoutSchema,
  CreateStudentSchema,
  AttendanceMarkBatchSchema,
  RapidAttendanceBatchSchema,
  OfflineSyncBatchSchema,
  InitiatePaymentSchema,
  CreateRazorpayOrderSchema,
  RazorpayWebhookSchema,
  CreateFeeStructureSchema,
  ConcessionApplicationSchema,
  MarksBatchEntrySchema,
  TimetableClashCheckSchema,
  TeacherSubstitutionSchema,
  CreateHomeworkSchema,
  GpsLocationUpdateSchema,
  StudentBoardingLogSchema,
  BoardingScanPayloadSchema,
  CreateVisitorPassSchema,
  VerifyChildPickupSchema,
  AnonymousIncidentReportSchema,
  ConsentRecordSchema,
  DataErasureRequestSchema,
  PaginationQuerySchema,
  Gender,
  AttendanceStatus,
  PaymentMethod,
  FeeFrequency,
  ConsentType,
  ConsentStatus,
  CBSEGrade,
  DayOfWeek,
  SafetyIncidentType,
  BoardingAction,
} from '../src/index';

describe('BOMIS Sambalpur - @bomis/shared Test Suite', () => {
  describe('Canonical UserRole Enum & Aliases', () => {
    it('should define all 8 canonical roles correctly', () => {
      expect(UserRole.SUPER_ADMIN).toBe('SUPER_ADMIN');
      expect(UserRole.ADMIN).toBe('ADMIN');
      expect(UserRole.PRINCIPAL).toBe('PRINCIPAL');
      expect(UserRole.TEACHER).toBe('TEACHER');
      expect(UserRole.ACCOUNTANT).toBe('ACCOUNTANT');
      expect(UserRole.STUDENT).toBe('STUDENT');
      expect(UserRole.PARENT).toBe('PARENT');
      expect(UserRole.TRANSPORT_STAFF).toBe('TRANSPORT_STAFF');
    });

    it('should support DRIVER_TRANSPORT as backward compatibility alias for TRANSPORT_STAFF', () => {
      expect(UserRole.DRIVER_TRANSPORT).toBe('TRANSPORT_STAFF');
      expect(UserRole.DRIVER_TRANSPORT).toBe(UserRole.TRANSPORT_STAFF);
    });

    it('should support supplemental domain enums', () => {
      expect(CBSEGrade.A1).toBe('A1');
      expect(DayOfWeek.MONDAY).toBe('MONDAY');
      expect(SafetyIncidentType.BULLYING).toBe('BULLYING');
      expect(BoardingAction.BOARD).toBe('BOARD');
    });
  });

  describe('RBAC Permission Matrix', () => {
    it('SUPER_ADMIN should have exhaustive access across all permissions', () => {
      expect(hasPermission(UserRole.SUPER_ADMIN, Permissions.USERS_CREATE)).toBe(true);
      expect(hasPermission(UserRole.SUPER_ADMIN, Permissions.FEES_MANAGE)).toBe(true);
      expect(hasPermission(UserRole.SUPER_ADMIN, Permissions.TRANSPORT_MANAGE)).toBe(true);
      expect(hasPermission(UserRole.SUPER_ADMIN, Permissions.ATTENDANCE_OVERRIDE)).toBe(true);
      expect(hasPermission(UserRole.SUPER_ADMIN, Permissions.DPDP_REQUEST_ERASURE)).toBe(true);
      expect(hasPermission(UserRole.SUPER_ADMIN, Permissions.SAFETY_VISITOR_MANAGE)).toBe(true);
      expect(hasPermission(UserRole.SUPER_ADMIN, Permissions.NOTICES_MANAGE)).toBe(true);
      expect(hasPermission(UserRole.SUPER_ADMIN, Permissions.AI_STUDY_BUDDY)).toBe(true);
    });

    it('ADMIN and PRINCIPAL should have administrative management & safety permissions', () => {
      expect(hasPermission(UserRole.ADMIN, Permissions.USERS_CREATE)).toBe(true);
      expect(hasPermission(UserRole.ADMIN, Permissions.STUDENTS_UPDATE)).toBe(true);
      expect(hasPermission(UserRole.ADMIN, Permissions.FEES_APPROVE_CONCESSION)).toBe(true);
      expect(hasPermission(UserRole.ADMIN, Permissions.SAFETY_VISITOR_MANAGE)).toBe(true);
      expect(hasPermission(UserRole.ADMIN, Permissions.SAFETY_PICKUP_VERIFY)).toBe(true);
      expect(hasPermission(UserRole.ADMIN, Permissions.SAFETY_INCIDENT_VIEW)).toBe(true);
      expect(hasPermission(UserRole.ADMIN, Permissions.NOTICES_MANAGE)).toBe(true);

      expect(hasPermission(UserRole.PRINCIPAL, Permissions.USERS_READ)).toBe(true);
      expect(hasPermission(UserRole.PRINCIPAL, Permissions.TIMETABLE_SUBSTITUTE)).toBe(true);
      expect(hasPermission(UserRole.PRINCIPAL, Permissions.MARKS_APPROVE)).toBe(true);
      expect(hasPermission(UserRole.PRINCIPAL, Permissions.SAFETY_VISITOR_MANAGE)).toBe(true);
      expect(hasPermission(UserRole.PRINCIPAL, Permissions.AI_LESSON_PLANNER)).toBe(true);
    });

    it('TEACHER should have academic, attendance, and lesson planner permissions', () => {
      expect(hasPermission(UserRole.TEACHER, Permissions.ATTENDANCE_MARK)).toBe(true);
      expect(hasPermission(UserRole.TEACHER, Permissions.HOMEWORK_CREATE)).toBe(true);
      expect(hasPermission(UserRole.TEACHER, Permissions.MARKS_ENTRY)).toBe(true);
      expect(hasPermission(UserRole.TEACHER, Permissions.AI_LESSON_PLANNER)).toBe(true);
      expect(hasPermission(UserRole.TEACHER, Permissions.NOTICES_READ)).toBe(true);
      expect(hasPermission(UserRole.TEACHER, Permissions.FEES_MANAGE)).toBe(false);
      expect(hasPermission(UserRole.TEACHER, Permissions.USERS_CREATE)).toBe(false);
    });

    it('ACCOUNTANT should have fee and reconciliation permissions but no teaching or GPS rights', () => {
      expect(hasPermission(UserRole.ACCOUNTANT, Permissions.FEES_READ)).toBe(true);
      expect(hasPermission(UserRole.ACCOUNTANT, Permissions.FEES_MANAGE)).toBe(true);
      expect(hasPermission(UserRole.ACCOUNTANT, Permissions.FEES_RECONCILE)).toBe(true);
      expect(hasPermission(UserRole.ACCOUNTANT, Permissions.NOTICES_READ)).toBe(true);
      expect(hasPermission(UserRole.ACCOUNTANT, Permissions.HOMEWORK_CREATE)).toBe(false);
      expect(hasPermission(UserRole.ACCOUNTANT, Permissions.TRANSPORT_BROADCAST_GPS)).toBe(false);
    });

    it('STUDENT and PARENT should have bounded self-service and AI study buddy permissions', () => {
      expect(hasPermission(UserRole.STUDENT, Permissions.HOMEWORK_SUBMIT)).toBe(true);
      expect(hasPermission(UserRole.STUDENT, Permissions.ATTENDANCE_READ)).toBe(true);
      expect(hasPermission(UserRole.STUDENT, Permissions.AI_STUDY_BUDDY)).toBe(true);
      expect(hasPermission(UserRole.STUDENT, Permissions.FEES_MANAGE)).toBe(false);

      expect(hasPermission(UserRole.PARENT, Permissions.FEES_PAY)).toBe(true);
      expect(hasPermission(UserRole.PARENT, Permissions.STUDENTS_READ)).toBe(true);
      expect(hasPermission(UserRole.PARENT, Permissions.DPDP_REQUEST_ERASURE)).toBe(true);
      expect(hasPermission(UserRole.PARENT, Permissions.SAFETY_PICKUP_VERIFY)).toBe(true);
      expect(hasPermission(UserRole.PARENT, Permissions.AI_STUDY_BUDDY)).toBe(true);
      expect(hasPermission(UserRole.PARENT, Permissions.USERS_DELETE)).toBe(false);
    });

    it('TRANSPORT_STAFF should have transport operations and pickup verification permissions', () => {
      expect(hasPermission(UserRole.TRANSPORT_STAFF, Permissions.TRANSPORT_READ)).toBe(true);
      expect(hasPermission(UserRole.TRANSPORT_STAFF, Permissions.TRANSPORT_BROADCAST_GPS)).toBe(true);
      expect(hasPermission(UserRole.TRANSPORT_STAFF, Permissions.TRANSPORT_SCAN_BOARDING)).toBe(true);
      expect(hasPermission(UserRole.TRANSPORT_STAFF, Permissions.SAFETY_PICKUP_VERIFY)).toBe(true);
      expect(hasPermission(UserRole.TRANSPORT_STAFF, Permissions.USERS_READ)).toBe(false);
      expect(hasPermission(UserRole.TRANSPORT_STAFF, Permissions.FEES_READ)).toBe(false);
    });
  });

  describe('Zod Validation Schemas', () => {
    describe('MobileOtpRequestSchema', () => {
      it('should accept valid Indian mobile numbers in E.164 format', () => {
        const validPayload = { phone: '+919876543210' };
        expect(() => MobileOtpRequestSchema.parse(validPayload)).not.toThrow();
      });

      it('should reject invalid or malformed phone numbers', () => {
        expect(() => MobileOtpRequestSchema.parse({ phone: '9876543210' })).toThrow();
        expect(() => MobileOtpRequestSchema.parse({ phone: '+12345678901' })).toThrow();
        expect(() => MobileOtpRequestSchema.parse({ phone: '+915876543210' })).toThrow();
      });
    });

    describe('VerifyOtpSchema', () => {
      it('should validate 6-digit OTP code', () => {
        const valid = { phone: '+919876543210', code: '123456' };
        expect(() => VerifyOtpSchema.parse(valid)).not.toThrow();
      });

      it('should reject non-6-digit OTP code', () => {
        expect(() => VerifyOtpSchema.parse({ phone: '+919876543210', code: '123' })).toThrow();
        expect(() => VerifyOtpSchema.parse({ phone: '+919876543210', code: '1234567' })).toThrow();
      });
    });

    describe('StaffLoginSchema', () => {
      it('should accept valid staff email and minimum 8-char password', () => {
        const valid = {
          email: 'principal@sambalpur.openminds.edu.in',
          password: 'Password123#',
        };
        expect(() => StaffLoginSchema.parse(valid)).not.toThrow();
      });

      it('should reject invalid email or short password', () => {
        expect(() => StaffLoginSchema.parse({ email: 'invalid-email', password: 'Password123#' })).toThrow();
        expect(() => StaffLoginSchema.parse({ email: 'admin@school.com', password: 'short' })).toThrow();
      });
    });

    describe('RefreshTokenSchema & LogoutSchema', () => {
      it('should validate non-empty refresh token', () => {
        expect(() => RefreshTokenSchema.parse({ refreshToken: 'valid-token-string' })).not.toThrow();
        expect(() => RefreshTokenSchema.parse({ refreshToken: '' })).toThrow();
      });

      it('should validate logout input', () => {
        expect(() => LogoutSchema.parse({})).not.toThrow();
        expect(() => LogoutSchema.parse({ refreshToken: 'some-token' })).not.toThrow();
      });
    });

    describe('CreateStudentSchema', () => {
      const validStudent = {
        schoolId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
        admissionNumber: 'BOMIS/2026/001',
        rollNumber: '101',
        firstName: 'Aarav',
        lastName: 'Patel',
        dateOfBirth: '2015-05-12T00:00:00.000Z',
        gender: Gender.MALE,
        classId: 'b2c3d4e5-f6a7-8b9c-0d1e-2f3a4b5c6d7e',
        sectionId: 'c3d4e5f6-a7b8-9c0d-1e2f-3a4b5c6d7e8f',
        emergencyContact: '+919876543210',
      };

      it('should validate complete student profile', () => {
        expect(() => CreateStudentSchema.parse(validStudent)).not.toThrow();
      });

      it('should reject when required fields are missing or invalid', () => {
        expect(() => CreateStudentSchema.parse({ ...validStudent, admissionNumber: '' })).toThrow();
        expect(() => CreateStudentSchema.parse({ ...validStudent, dateOfBirth: 'invalid-date' })).toThrow();
      });
    });

    describe('AttendanceMarkBatchSchema & RapidAttendanceBatchSchema', () => {
      const validBatch = {
        schoolId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
        sectionId: 'c3d4e5f6-a7b8-9c0d-1e2f-3a4b5c6d7e8f',
        date: '2026-10-17',
        records: [
          {
            studentId: 'd4e5f6a7-b8c9-0d1e-2f3a-4b5c6d7e8f9a',
            status: AttendanceStatus.PRESENT,
          },
        ],
      };

      it('should validate well-formed attendance batch', () => {
        expect(() => AttendanceMarkBatchSchema.parse(validBatch)).not.toThrow();
      });

      it('should validate rapid attendance batch format', () => {
        const rapid = {
          date: '2026-10-17',
          classId: 'b2c3d4e5-f6a7-8b9c-0d1e-2f3a4b5c6d7e',
          sectionId: 'c3d4e5f6-a7b8-9c0d-1e2f-3a4b5c6d7e8f',
          defaultStatus: AttendanceStatus.PRESENT,
          exceptions: [
            {
              studentId: 'd4e5f6a7-b8c9-0d1e-2f3a-4b5c6d7e8f9a',
              status: AttendanceStatus.ABSENT,
              remarks: 'Fever',
            },
          ],
        };
        expect(() => RapidAttendanceBatchSchema.parse(rapid)).not.toThrow();
      });
    });

    describe('OfflineSyncBatchSchema', () => {
      it('should validate offline sync event batches', () => {
        const batch = {
          events: [
            {
              id: 'event-001',
              actionType: 'ATTENDANCE_BATCH',
              idempotencyKey: 'idemp-1234',
              timestamp: Date.now(),
              payload: { classId: 'cls-1', count: 30 },
            },
          ],
        };
        expect(() => OfflineSyncBatchSchema.parse(batch)).not.toThrow();
      });
    });

    describe('Fee & Razorpay Schemas', () => {
      it('should validate InitiatePaymentSchema', () => {
        const validPayment = {
          schoolId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          studentId: 'd4e5f6a7-b8c9-0d1e-2f3a-4b5c6d7e8f9a',
          installmentId: 'f6a7b8c9-d0e1-2f3a-4b5c-6d7e8f9a0b1c',
          amount: 25000,
          paymentMethod: PaymentMethod.RAZORPAY_UPI,
          idempotencyKey: '7a8b9c0d-1e2f-3a4b-5c6d-7e8f9a0b1c2d',
        };
        expect(() => InitiatePaymentSchema.parse(validPayment)).not.toThrow();
      });

      it('should validate CreateRazorpayOrderSchema and webhook payload', () => {
        const order = {
          studentId: 'd4e5f6a7-b8c9-0d1e-2f3a-4b5c6d7e8f9a',
          installmentNumber: 1,
          amountPaise: 1650000,
          paymentMethod: 'UPI',
        };
        expect(() => CreateRazorpayOrderSchema.parse(order)).not.toThrow();

        const webhook = {
          entity: 'event',
          event: 'payment.captured',
          payload: {
            payment: {
              entity: {
                id: 'pay_123',
                order_id: 'order_123',
                amount: 1650000,
                currency: 'INR',
                status: 'captured',
                method: 'upi',
              },
            },
          },
        };
        expect(() => RazorpayWebhookSchema.parse(webhook)).not.toThrow();
      });

      it('should validate fee structure and concession application', () => {
        const structure = {
          schoolId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          classId: 'b2c3d4e5-f6a7-8b9c-0d1e-2f3a4b5c6d7e',
          academicYear: '2026-2027',
          category: 'Tuition Fee',
          totalAmount: 66000,
          frequency: FeeFrequency.TERM,
        };
        expect(() => CreateFeeStructureSchema.parse(structure)).not.toThrow();

        const concession = {
          studentId: 'd4e5f6a7-b8c9-0d1e-2f3a-4b5c6d7e8f9a',
          discountPercentage: 25,
          reason: 'Sibling discount',
        };
        expect(() => ConcessionApplicationSchema.parse(concession)).not.toThrow();
      });
    });

    describe('Academics & Timetable Schemas', () => {
      it('should validate marks batch entry', () => {
        const marksBatch = {
          termId: 'term-1',
          subjectId: 'sub-math-01',
          classId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          sectionId: 'b2c3d4e5-f6a7-8b9c-0d1e-2f3a4b5c6d7e',
          records: [
            {
              studentId: 'c3d4e5f6-a7b8-9c0d-1e2f-3a4b5c6d7e8f',
              periodicTest: 9,
              notebook: 5,
              subjectEnrichment: 4.5,
              examMarks: 72,
              grade: 'A1',
            },
          ],
        };
        expect(() => MarksBatchEntrySchema.parse(marksBatch)).not.toThrow();
      });

      it('should validate timetable clash check and teacher substitution', () => {
        const clashCheck = {
          teacherId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          roomId: 'Room 201',
          dayOfWeek: 'MONDAY',
          periodNumber: 3,
        };
        expect(() => TimetableClashCheckSchema.parse(clashCheck)).not.toThrow();

        const sub = {
          absentTeacherId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          substituteTeacherId: 'b2c3d4e5-f6a7-8b9c-0d1e-2f3a4b5c6d7e',
          date: '2026-10-18',
          periodNumber: 2,
          sectionId: 'c3d4e5f6-a7b8-9c0d-1e2f-3a4b5c6d7e8f',
          subjectId: 'd4e5f6a7-b8c9-0d1e-2f3a-4b5c6d7e8f9a',
        };
        expect(() => TeacherSubstitutionSchema.parse(sub)).not.toThrow();
      });

      it('should validate homework creation', () => {
        const hw = {
          classId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          sectionId: 'b2c3d4e5-f6a7-8b9c-0d1e-2f3a4b5c6d7e',
          subjectId: 'c3d4e5f6-a7b8-9c0d-1e2f-3a4b5c6d7e8f',
          title: 'Maths Chapter 3 Practice',
          description: 'Solve questions 1 through 10 from page 45',
          dueDate: '2026-10-20',
          attachments: ['https://storage.bomis-sambalpur.edu.in/hw/ex3.pdf'],
        };
        expect(() => CreateHomeworkSchema.parse(hw)).not.toThrow();
      });
    });

    describe('Transport & Telematics Schemas', () => {
      it('should validate real vehicle GPS telematics ping', () => {
        const validLocation = {
          schoolId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          vehicleId: 'b2c3d4e5-f6a7-8b9c-0d1e-2f3a4b5c6d7e',
          routeId: 'c3d4e5f6-a7b8-9c0d-1e2f-3a4b5c6d7e8f',
          latitude: 21.4669,
          longitude: 83.9812,
          speed: 42.5,
          heading: 180,
          timestamp: '2026-10-17T08:30:00.000Z',
        };
        expect(() => GpsLocationUpdateSchema.parse(validLocation)).not.toThrow();
      });

      it('should validate boarding scan payload', () => {
        const scan = {
          busId: 'bus_pilot_01',
          studentId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          stopId: 'stop_sakhipada_01',
          action: 'BOARD',
          lat: 21.4669,
          lng: 83.9812,
        };
        expect(() => BoardingScanPayloadSchema.parse(scan)).not.toThrow();
      });
    });

    describe('Safety & Visitor Schemas', () => {
      it('should validate visitor pass creation', () => {
        const pass = {
          visitorName: 'Sanjay Mohapatra',
          visitorPhone: '+919876543210',
          purpose: 'Vendor meeting regarding lab equipment',
          hostStaffId: 'staff-101',
          expectedDate: '2026-10-20',
        };
        expect(() => CreateVisitorPassSchema.parse(pass)).not.toThrow();
      });

      it('should validate child pickup verification with 6-digit OTP', () => {
        const pickup = {
          studentId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          pickupOtp: '654321',
          gateNumber: 'Gate-1',
        };
        expect(() => VerifyChildPickupSchema.parse(pickup)).not.toThrow();
      });

      it('should validate anonymous incident report', () => {
        const report = {
          incidentType: 'BULLYING',
          grade: 7,
          location: 'Playground East Wing',
          description: 'Observed repeated verbal bullying during recess time.',
          timestamp: '2026-10-18T10:15:00.000Z',
        };
        expect(() => AnonymousIncidentReportSchema.parse(report)).not.toThrow();
      });
    });

    describe('DPDP Consent & Data Privacy Schemas', () => {
      it('should validate consent record with proof hash', () => {
        const consent = {
          userId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          consentType: ConsentType.DATA_PROCESSING,
          version: 'v1.0',
          status: ConsentStatus.GRANTED,
          proofHash: 'a1b2c3d4e5f67890abcdef1234567890',
        };
        expect(() => ConsentRecordSchema.parse(consent)).not.toThrow();
      });

      it('should validate data erasure request with confirmed permanent flag', () => {
        const erasure = {
          userId: 'a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
          reason: 'Student transferred to another school',
          confirmPermanentErasure: true,
        };
        expect(() => DataErasureRequestSchema.parse(erasure)).not.toThrow();
      });
    });

    describe('PaginationQuerySchema', () => {
      it('should parse and coerce query params with defaults', () => {
        const parsed = PaginationQuerySchema.parse({});
        expect(parsed.page).toBe(1);
        expect(parsed.pageSize).toBe(20);
        expect(parsed.sortOrder).toBe('asc');
      });
    });
  });
});
