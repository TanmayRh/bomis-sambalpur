import { colors, typography, borderRadius } from '../tokens/index.js';

export const bomisTailwindPreset = {
  theme: {
    extend: {
      colors: {
        bomis: {
          navy: colors.primary,
          coral: colors.accent,
        },
        status: colors.status,
      },
      fontFamily: typography.fontFamily,
      borderRadius,
    },
  },
};
