/**
 * Official BOMIS Sambalpur Brand Design Tokens
 * Primary: Navy (#0F2942)
 * Accent: Warm Coral (#FF6B4A)
 */

export const colors = {
  // Primary Navy scale
  primary: {
    50: '#F4F8FA',
    100: '#EBF2F8',
    200: '#D2E3F0',
    300: '#A4C6E1',
    400: '#6FA4CE',
    500: '#3D7FB5',
    600: '#254E7A',
    700: '#1A3A5C',
    800: '#0F2942', // BOMIS Official Brand Navy
    900: '#071726',
    DEFAULT: '#0F2942',
  },

  // Accent Warm Coral scale
  accent: {
    50: '#FFF5F2',
    100: '#FFEAE5',
    200: '#FFD4CB',
    300: '#FFAFA0',
    400: '#FF886E',
    500: '#FF6B4A', // BOMIS Official Accent Coral
    600: '#E05232',
    700: '#BA3E23',
    800: '#94311B',
    900: '#6E2514',
    DEFAULT: '#FF6B4A',
  },

  // Functional Semantics
  status: {
    success: '#10B981', // Attendance Present, Paid
    warning: '#F59E0B', // Late, Partial, Pending
    danger: '#EF4444',  // Absent, Overdue, SOS
    info: '#3B82F6',    // Notices, Circulars
  },

  // Neutrals
  neutral: {
    50: '#F8FAFC',
    100: '#F1F5F9',
    200: '#E2E8F0',
    300: '#CBD5E1',
    400: '#94A3B8',
    500: '#64748B',
    600: '#475569',
    700: '#334155',
    800: '#1E293B',
    900: '#0F172A',
  },
} as const;

export const typography = {
  fontFamily: {
    heading: ['Outfit', 'Plus Jakarta Sans', 'sans-serif'],
    body: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
    mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
  },
  fontSize: {
    xs: '0.75rem',    // 12px
    sm: '0.875rem',   // 14px
    base: '1rem',      // 16px
    lg: '1.125rem',   // 18px
    xl: '1.25rem',    // 20px
    '2xl': '1.5rem',  // 24px
    '3xl': '1.875rem',// 30px
    '4xl': '2.25rem', // 36px
  },
} as const;

export const borderRadius = {
  sm: '4px',
  md: '8px',
  lg: '12px',
  xl: '16px',
  full: '9999px',
} as const;

export const spacing = {
  0: '0px',
  1: '0.25rem',  // 4px
  2: '0.5rem',   // 8px
  3: '0.75rem',  // 12px
  4: '1rem',     // 16px
  5: '1.25rem',  // 20px
  6: '1.5rem',   // 24px
  8: '2rem',     // 32px
  10: '2.5rem',  // 40px
  12: '3rem',    // 48px
  16: '4rem',    // 64px
} as const;

