import { UserRole, AttendanceStatus } from '@bomis/shared';

/**
 * Role Badges Token Map
 * Visual styling and border contrast for all 8 canonical RBAC roles
 */
export const roleBadgeColors: Record<UserRole, { bg: string; text: string; border: string }> = {
  [UserRole.SUPER_ADMIN]: { bg: '#071726', text: '#FFFFFF', border: '#1A3A5C' },
  [UserRole.ADMIN]: { bg: '#0F2942', text: '#FFFFFF', border: '#254E7A' },
  [UserRole.PRINCIPAL]: { bg: '#1A3A5C', text: '#FFFFFF', border: '#3D7FB5' },
  [UserRole.TEACHER]: { bg: '#EBF2F8', text: '#0F2942', border: '#A4C6E1' },
  [UserRole.ACCOUNTANT]: { bg: '#ECFDF5', text: '#065F46', border: '#A7F3D0' },
  [UserRole.STUDENT]: { bg: '#F4F8FA', text: '#254E7A', border: '#D2E3F0' },
  [UserRole.PARENT]: { bg: '#FFF5F2', text: '#94311B', border: '#FFD4CB' },
  [UserRole.TRANSPORT_STAFF]: { bg: '#FEF3C7', text: '#92400E', border: '#FDE68A' },
};

/**
 * Attendance Status Pill Map
 * Semantic status colors, readable text labels, and backgrounds
 */
export const attendanceStatusStyles: Record<
  AttendanceStatus,
  { bg: string; text: string; label: string }
> = {
  [AttendanceStatus.PRESENT]: { bg: '#ECFDF5', text: '#065F46', label: 'Present' },
  [AttendanceStatus.ABSENT]: { bg: '#FEF2F2', text: '#991B1B', label: 'Absent' },
  [AttendanceStatus.LATE]: { bg: '#FFFBEB', text: '#92400E', label: 'Late' },
  [AttendanceStatus.HALF_DAY]: { bg: '#EFF6FF', text: '#1E40AF', label: 'Half Day' },
  [AttendanceStatus.EXCUSED]: { bg: '#F3F4F6', text: '#374151', label: 'Excused' },
};

/**
 * Standard Button Variant Classes (Tailwind CSS Utility Strings)
 */
export const buttonVariants = {
  primary:
    'bg-bomis-navy hover:bg-bomis-navy-700 text-white font-medium shadow-sm transition-colors rounded-lg px-4 py-2',
  accent:
    'bg-bomis-coral hover:bg-bomis-coral-600 text-white font-medium shadow-sm transition-colors rounded-lg px-4 py-2',
  outline:
    'border border-bomis-navy text-bomis-navy hover:bg-bomis-navy-50 font-medium transition-colors rounded-lg px-4 py-2',
  ghost:
    'text-bomis-navy hover:bg-bomis-navy-50 font-medium transition-colors rounded-lg px-4 py-2',
} as const;
