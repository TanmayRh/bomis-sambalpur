import {
  colors,
  typography,
  borderRadius,
  spacing,
  roleBadgeColors,
  attendanceStatusStyles,
  buttonVariants,
  bomisTailwindPreset,
} from '../src/index';
import { UserRole, AttendanceStatus } from '@bomis/shared';

describe('BOMIS Sambalpur - @bomis/ui Brand Design Tokens & Primitives', () => {
  describe('Primary Brand Palette (BOMIS Navy)', () => {
    it('should define official BOMIS Navy as #0F2942 in default and 800 scale', () => {
      expect(colors.primary.DEFAULT).toBe('#0F2942');
      expect(colors.primary[800]).toBe('#0F2942');
    });

    it('should include full gradient spectrum from 50 to 900', () => {
      expect(colors.primary[50]).toBe('#F4F8FA');
      expect(colors.primary[100]).toBe('#EBF2F8');
      expect(colors.primary[200]).toBe('#D2E3F0');
      expect(colors.primary[300]).toBe('#A4C6E1');
      expect(colors.primary[400]).toBe('#6FA4CE');
      expect(colors.primary[500]).toBe('#3D7FB5');
      expect(colors.primary[600]).toBe('#254E7A');
      expect(colors.primary[700]).toBe('#1A3A5C');
      expect(colors.primary[900]).toBe('#071726');
    });
  });

  describe('Accent Brand Palette (Warm Coral)', () => {
    it('should define official Warm Coral as #FF6B4A in default and 500 scale', () => {
      expect(colors.accent.DEFAULT).toBe('#FF6B4A');
      expect(colors.accent[500]).toBe('#FF6B4A');
    });

    it('should include warm coral scale shades', () => {
      expect(colors.accent[50]).toBe('#FFF5F2');
      expect(colors.accent[100]).toBe('#FFEAE5');
      expect(colors.accent[200]).toBe('#FFD4CB');
      expect(colors.accent[300]).toBe('#FFAFA0');
      expect(colors.accent[400]).toBe('#FF886E');
      expect(colors.accent[600]).toBe('#E05232');
      expect(colors.accent[700]).toBe('#BA3E23');
      expect(colors.accent[800]).toBe('#94311B');
      expect(colors.accent[900]).toBe('#6E2514');
    });
  });

  describe('Semantic Status & Neutral Tokens', () => {
    it('should specify status colors for school workflows', () => {
      expect(colors.status.success).toBe('#10B981'); // Attendance present / paid
      expect(colors.status.warning).toBe('#F59E0B'); // Late / pending
      expect(colors.status.danger).toBe('#EF4444');  // Absent / overdue
      expect(colors.status.info).toBe('#3B82F6');    // Circulars / notices
    });

    it('should define neutral slate scale', () => {
      expect(colors.neutral[50]).toBe('#F8FAFC');
      expect(colors.neutral[100]).toBe('#F1F5F9');
      expect(colors.neutral[900]).toBe('#0F172A');
    });
  });

  describe('Typography, Spacing & Layout Tokens', () => {
    it('should specify font families for heading, body, and monospace code', () => {
      expect(typography.fontFamily.heading).toContain('Outfit');
      expect(typography.fontFamily.body).toContain('Inter');
      expect(typography.fontFamily.mono).toContain('JetBrains Mono');
    });

    it('should specify font sizes from xs to 4xl', () => {
      expect(typography.fontSize.xs).toBe('0.75rem');
      expect(typography.fontSize.base).toBe('1rem');
      expect(typography.fontSize['4xl']).toBe('2.25rem');
    });

    it('should specify border radius metrics', () => {
      expect(borderRadius.sm).toBe('4px');
      expect(borderRadius.md).toBe('8px');
      expect(borderRadius.lg).toBe('12px');
      expect(borderRadius.xl).toBe('16px');
      expect(borderRadius.full).toBe('9999px');
    });

    it('should specify spacing scale values', () => {
      expect(spacing[0]).toBe('0px');
      expect(spacing[1]).toBe('0.25rem');
      expect(spacing[4]).toBe('1rem');
      expect(spacing[8]).toBe('2rem');
      expect(spacing[16]).toBe('4rem');
    });
  });

  describe('Shared Component Primitives & Style Maps', () => {
    it('should define role badge colors for all 8 canonical roles', () => {
      const roles = [
        UserRole.SUPER_ADMIN,
        UserRole.ADMIN,
        UserRole.PRINCIPAL,
        UserRole.TEACHER,
        UserRole.ACCOUNTANT,
        UserRole.STUDENT,
        UserRole.PARENT,
        UserRole.TRANSPORT_STAFF,
      ];

      for (const role of roles) {
        const badge = roleBadgeColors[role];
        expect(badge).toBeDefined();
        expect(badge.bg).toMatch(/^#[0-9A-Fa-f]{6}$/);
        expect(badge.text).toMatch(/^#[0-9A-Fa-f]{6}$/);
        expect(badge.border).toMatch(/^#[0-9A-Fa-f]{6}$/);
      }
    });

    it('should define attendance status styles with labels and colors', () => {
      const statuses = [
        AttendanceStatus.PRESENT,
        AttendanceStatus.ABSENT,
        AttendanceStatus.LATE,
        AttendanceStatus.HALF_DAY,
        AttendanceStatus.EXCUSED,
      ];

      for (const status of statuses) {
        const style = attendanceStatusStyles[status];
        expect(style).toBeDefined();
        expect(style.label).toBeTruthy();
        expect(style.bg).toMatch(/^#[0-9A-Fa-f]{6}$/);
        expect(style.text).toMatch(/^#[0-9A-Fa-f]{6}$/);
      }
    });

    it('should define button variant Tailwind classes', () => {
      expect(buttonVariants.primary).toContain('bg-bomis-navy');
      expect(buttonVariants.accent).toContain('bg-bomis-coral');
      expect(buttonVariants.outline).toContain('border-bomis-navy');
      expect(buttonVariants.ghost).toContain('text-bomis-navy');
    });

    it('should export bomisTailwindPreset with brand extensions', () => {
      expect(bomisTailwindPreset.theme.extend.colors.bomis.navy).toEqual(colors.primary);
      expect(bomisTailwindPreset.theme.extend.colors.bomis.coral).toEqual(colors.accent);
      expect(bomisTailwindPreset.theme.extend.fontFamily).toEqual(typography.fontFamily);
      expect(bomisTailwindPreset.theme.extend.borderRadius).toEqual(borderRadius);
    });
  });
});
