const fs = require('fs');
const path = require('path');

const pagePath = path.join(__dirname, '..', 'apps', 'web', 'src', 'app', 'page.tsx');
let content = fs.readFileSync(pagePath, 'utf8');

// 1. Update Lucide imports
const oldImports = `import {
  Bell,
  Bus,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock,
  Menu,
  Phone,
  QrCode,
  Volume2,
  X,
  AlertTriangle,
} from 'lucide-react';`;

const newImports = `import {
  Bell,
  Bus,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  Menu,
  Phone,
  QrCode,
  Volume2,
  X,
  AlertTriangle,
  BookOpen,
  Calendar,
  GraduationCap,
  Receipt,
  Users,
  FileText,
  Utensils,
  MapPin,
  Download,
  Send,
  Sparkles,
} from 'lucide-react';`;

content = content.replace(oldImports, newImports);

// 2. Add ActiveDrawer type
const typeInsertionTarget = `export type DemoScenario =
  | 'NORMAL_COMMUTE'
  | 'MONSOON_CLOSURE'
  | 'UPI_IN_PROGRESS'
  | 'SIBLING_ASYMMETRY'
  | 'INFIRMARY_SOS'
  | 'SIMPLE_ELDER_VIEW';`;

const newTypes = `export type DemoScenario =
  | 'NORMAL_COMMUTE'
  | 'MONSOON_CLOSURE'
  | 'UPI_IN_PROGRESS'
  | 'SIBLING_ASYMMETRY'
  | 'INFIRMARY_SOS'
  | 'SIMPLE_ELDER_VIEW';

export type ActiveDrawer =
  | null
  | 'DIARY'
  | 'ATTENDANCE'
  | 'EXAMS'
  | 'FEES'
  | 'PTM'
  | 'CIRCULARS'
  | 'CANTEEN'
  | 'TRANSPORT';`;

content = content.replace(typeInsertionTarget, newTypes);

// 3. Add states for the new everyday school services
const stateInsertionTarget = `  // Emergency Alerts Chip
  const [hasTurnedOnAlerts, setHasTurnedOnAlerts] = React.useState(false);`;

const newStates = `  // Emergency Alerts Chip
  const [hasTurnedOnAlerts, setHasTurnedOnAlerts] = React.useState(false);

  // Active Interactive Drawer (100x Better than traditional school apps)
  const [activeDrawer, setActiveDrawer] = React.useState<ActiveDrawer>(null);

  // Homework & Diary Interactive State
  const [diaryChild, setDiaryChild] = React.useState<'aarav' | 'ananya'>('aarav');
  const [completedHw, setCompletedHw] = React.useState<Record<string, boolean>>({
    m1: false, // Math Fractions
    s1: false, // Hirakud diorama sketch
    h1: true,  // Language reading
    e1: false, // Ananya EVS
    en1: true, // Ananya English
  });
  const [diarySigned, setDiarySigned] = React.useState(false);

  // Attendance & 1-Tap Leave State
  const [leaveChild, setLeaveChild] = React.useState<'aarav' | 'ananya' | 'both'>('aarav');
  const [leaveReason, setLeaveReason] = React.useState<'fever' | 'family' | 'travel'>('fever');
  const [leaveSubmitted, setLeaveSubmitted] = React.useState(false);

  // PTM Appointment Booking State
  const [ptmTeacher, setPtmTeacher] = React.useState<'dash' | 'mohanty'>('dash');
  const [ptmSlot, setPtmSlot] = React.useState<string>('10:20 AM - 10:35 AM');
  const [ptmMode, setPtmMode] = React.useState<'campus' | 'video'>('campus');
  const [ptmConfirmed, setPtmConfirmed] = React.useState(false);

  // Voice Rubric & Circular Audio State
  const [isPlayingHpcVoice, setIsPlayingHpcVoice] = React.useState(false);
  const [receiptDownloaded, setReceiptDownloaded] = React.useState(false);`;

content = content.replace(stateInsertionTarget, newStates);

// 4. Insert Everyday School Services Shelf right after OneThing (before DayStream)
const oneThingEndTarget = `            {/* ------------------------------------------------------------------
                5. DAY STREAM (Time-Ordered Vertical Progression)
                ------------------------------------------------------------------ */}`;

const everydayServicesSection = `            {/* ------------------------------------------------------------------
                4B. EVERYDAY SCHOOL SERVICES (100x Better than Traditional School ERPs)
                Consolidates Diary, Attendance, Exams, Fees, PTM, Notices in 1 tap
                ------------------------------------------------------------------ */}
            <section aria-label="Everyday Services" className="space-y-2 pt-1">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500">
                  {t('home.services', locale)}
                </span>
                <span className="text-[11px] text-indigo-700 font-bold bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200">
                  {locale === 'or' ? 'ସମସ୍ତ ସୁବିଧା ଏକାଠି' : locale === 'hi' ? 'सभी सेवाएँ एक जगह' : 'All-in-One'}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {/* 1. Daily Diary & Homework */}
                <button
                  onClick={() => setActiveDrawer('DIARY')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <BookOpen className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.diary', locale)}</span>
                  <span className="text-[10px] text-slate-500 font-medium mt-0.5">2 tasks tonight</span>
                </button>

                {/* 2. Attendance & Leave */}
                <button
                  onClick={() => setActiveDrawer('ATTENDANCE')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.attendance', locale)}</span>
                  <span className="text-[10px] text-emerald-700 font-medium mt-0.5">96.4% Present</span>
                </button>

                {/* 3. Exams & Report Card */}
                <button
                  onClick={() => setActiveDrawer('EXAMS')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <GraduationCap className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.exams', locale)}</span>
                  <span className="text-[10px] text-indigo-700 font-medium mt-0.5">Exam in 4 days</span>
                </button>

                {/* 4. Fees & 80C Receipts */}
                <button
                  onClick={() => setActiveDrawer('FEES')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <Receipt className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.fees', locale)}</span>
                  <span className="text-[10px] text-emerald-700 font-medium mt-0.5">₹0 Due · Paid</span>
                </button>

                {/* 5. Book PTM Slot */}
                <button
                  onClick={() => setActiveDrawer('PTM')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <Users className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.ptm', locale)}</span>
                  <span className="text-[10px] text-slate-500 font-medium mt-0.5">Sat 8 Nov</span>
                </button>

                {/* 6. School Notices & Audio */}
                <button
                  onClick={() => setActiveDrawer('CIRCULARS')}
                  className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl flex flex-col items-center text-center shadow-2xs hover:shadow transition group text-left cursor-pointer"
                >
                  <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center mb-1.5 group-hover:scale-105 transition">
                    <FileText className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">{t('service.circulars', locale)}</span>
                  <span className="text-[10px] text-rose-700 font-medium mt-0.5">Winter Uniform</span>
                </button>
              </div>
            </section>

            {/* ------------------------------------------------------------------
                5. DAY STREAM (Time-Ordered Vertical Progression)
                ------------------------------------------------------------------ */}`;

content = content.replace(oneThingEndTarget, everydayServicesSection);

// 5. Update MoreSheet to link directly to each drawer
const oldMoreSheetContent = `            {/* Section 1: Academic Marks & Reports */}
            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                Report Cards & Progress
              </span>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-800">CBSE Term 1 Progress Card</h4>
                  <p className="text-[11px] text-slate-500">Aarav (Grade 5A) • Holistic Progress Card (HPC)</p>
                </div>
                <button
                  onClick={() => alert('Opening CBSE Term 1 Holistic Progress Card (HPC)...')}
                  className="text-xs font-bold text-indigo-700 hover:underline"
                >
                  View Report Card
                </button>
              </div>
            </div>

            {/* Section 2: Fee History & Tax Receipts */}
            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                Fee Receipts & Tax Proofs
              </span>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-800">Tuition Fee History</h4>
                  <p className="text-[11px] text-slate-500">Term 1: Paid • Term 2: Due Dec 15</p>
                </div>
                <button
                  onClick={() => alert('Official GST Tax Receipt #BOMIS-2026-REC-001 downloaded.')}
                  className="text-xs font-bold text-indigo-700 hover:underline"
                >
                  Download Receipt
                </button>
              </div>
            </div>`;

const newMoreSheetContent = `            {/* Section 1: Quick Access to Core Modules */}
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                Quick Access Modules
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('DIARY'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <BookOpen className="h-4 w-4 text-blue-600 shrink-0" />
                  <span>{t('service.diary', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('ATTENDANCE'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <Calendar className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span>{t('service.attendance', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('EXAMS'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <GraduationCap className="h-4 w-4 text-indigo-600 shrink-0" />
                  <span>{t('service.exams', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('FEES'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <Receipt className="h-4 w-4 text-amber-600 shrink-0" />
                  <span>{t('service.fees', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('PTM'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <Users className="h-4 w-4 text-purple-600 shrink-0" />
                  <span>{t('service.ptm', locale)}</span>
                </button>
                <button
                  onClick={() => { setIsMoreOpen(false); setActiveDrawer('CIRCULARS'); }}
                  className="p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 text-left font-bold text-slate-800 flex items-center gap-2 cursor-pointer"
                >
                  <FileText className="h-4 w-4 text-rose-600 shrink-0" />
                  <span>{t('service.circulars', locale)}</span>
                </button>
              </div>
            </div>`;

content = content.replace(oldMoreSheetContent, newMoreSheetContent);

// 6. Append the Interactive Slide-Up Drawers Component right before final closing </div>
const closingDivTarget = `      {/* ------------------------------------------------------------------------
          MORE SHEET (Bottom Sheet replacing messy multi-tab navigation)
          ------------------------------------------------------------------------ */}
      {isMoreOpen && (`;

const drawersCode = `      {/* ------------------------------------------------------------------------
          INTERACTIVE SERVICE DRAWERS (100x Better than Traditional ERPs)
          Full Rich Features: Diary, Attendance, Exams, Fees, PTM, Notices
          ------------------------------------------------------------------------ */}
      {activeDrawer && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end justify-center p-0"
        >
          <div className="bg-white w-full max-w-lg rounded-t-3xl shadow-2xl p-5 space-y-4 max-h-[88vh] overflow-y-auto animate-in slide-in-from-bottom duration-200 border-t border-slate-200">
            {/* Header with Title and Close Button */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                {activeDrawer === 'DIARY' && <BookOpen className="h-5 w-5 text-blue-600" />}
                {activeDrawer === 'ATTENDANCE' && <Calendar className="h-5 w-5 text-emerald-600" />}
                {activeDrawer === 'EXAMS' && <GraduationCap className="h-5 w-5 text-indigo-600" />}
                {activeDrawer === 'FEES' && <Receipt className="h-5 w-5 text-amber-600" />}
                {activeDrawer === 'PTM' && <Users className="h-5 w-5 text-purple-600" />}
                {activeDrawer === 'CIRCULARS' && <FileText className="h-5 w-5 text-rose-600" />}
                <h3 className="text-base font-black text-slate-900">
                  {activeDrawer === 'DIARY' && t('service.diary', locale)}
                  {activeDrawer === 'ATTENDANCE' && t('service.attendance', locale)}
                  {activeDrawer === 'EXAMS' && t('service.exams', locale)}
                  {activeDrawer === 'FEES' && t('service.fees', locale)}
                  {activeDrawer === 'PTM' && t('service.ptm', locale)}
                  {activeDrawer === 'CIRCULARS' && t('service.circulars', locale)}
                </h3>
              </div>
              <button
                onClick={() => setActiveDrawer(null)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* ==================================================================
                DRAWER 1: DAILY DIARY & HOMEWORK
                ================================================================== */}
            {activeDrawer === 'DIARY' && (
              <div className="space-y-4">
                {/* Sibling Switcher Tabs */}
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                  <button
                    onClick={() => setDiaryChild('aarav')}
                    className={\`py-2 text-xs font-bold rounded-lg transition cursor-pointer \${
                      diaryChild === 'aarav'
                        ? 'bg-white text-blue-700 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }\`}
                  >
                    👦 Aarav Patel (Grade 5A)
                  </button>
                  <button
                    onClick={() => setDiaryChild('ananya')}
                    className={\`py-2 text-xs font-bold rounded-lg transition cursor-pointer \${
                      diaryChild === 'ananya'
                        ? 'bg-white text-purple-700 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }\`}
                  >
                    👧 Ananya Patel (Grade 2A)
                  </button>
                </div>

                {/* Progress bar */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-slate-800">Tonight's Homework Progress</span>
                    <p className="text-[11px] text-slate-500">
                      {diaryChild === 'aarav'
                        ? \`\${[completedHw.m1, completedHw.s1, completedHw.h1].filter(Boolean).length} of 3 tasks completed\`
                        : \`\${[completedHw.e1, completedHw.en1].filter(Boolean).length} of 2 tasks completed\`}
                    </p>
                  </div>
                  <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-200">
                    {diaryChild === 'aarav' && [completedHw.m1, completedHw.s1, completedHw.h1].every(Boolean)
                      ? '🎉 All Done!'
                      : 'In Progress'}
                  </span>
                </div>

                {/* Homework Task Cards */}
                {diaryChild === 'aarav' ? (
                  <div className="space-y-2.5">
                    {/* Math */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-black uppercase text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                            Mathematics · Ms. Arundhati Dash
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1">Exercise 4.2 Fractions (Q1 to Q5)</h4>
                          <p className="text-[11px] text-slate-600 mt-0.5">
                            Solve in Classwork notebook. Simplify mixed fractions to lowest terms.
                          </p>
                        </div>
                        <button
                          onClick={() => setCompletedHw({ ...completedHw, m1: !completedHw.m1 })}
                          className={\`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 \${
                            completedHw.m1
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                          }\`}
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>{completedHw.m1 ? 'Done' : 'Mark Done'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Science */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-black uppercase text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                            Science · Mr. Subhasis Panda
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1">Hirakud Dam Spillway Gates Sketch</h4>
                          <p className="text-[11px] text-slate-600 mt-0.5">
                            Draw and label the sluice gates in the EVS project file.
                          </p>
                          <p className="text-[11px] text-indigo-700 italic mt-1">
                            💡 Parent Tip: Ask Aarav how his group designed the diorama today!
                          </p>
                        </div>
                        <button
                          onClick={() => setCompletedHw({ ...completedHw, s1: !completedHw.s1 })}
                          className={\`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 \${
                            completedHw.s1
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                          }\`}
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>{completedHw.s1 ? 'Done' : 'Mark Done'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Language */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-black uppercase text-amber-600 bg-amber-50 px-2 py-0.5 rounded">
                            {locale === 'or' ? 'ଓଡ଼ିଆ ସାହିତ୍ୟ' : 'Hindi / Odia Reading'} · Mrs. Rekha Sharma
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1">
                            {locale === 'or' ? 'ଅଧ୍ୟାୟ ୬: ସାହସୀ ବାଳକ (ପୃଷ୍ଠା ୪୨)' : 'Chapter 6: Courage (Page 42-45)'}
                          </h4>
                          <p className="text-[11px] text-slate-600 mt-0.5">Read 2 paragraphs aloud with correct pronunciation.</p>
                        </div>
                        <button
                          onClick={() => setCompletedHw({ ...completedHw, h1: !completedHw.h1 })}
                          className={\`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 \${
                            completedHw.h1
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                          }\`}
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>{completedHw.h1 ? 'Done' : 'Mark Done'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {/* Ananya Tasks */}
                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-black uppercase text-purple-600 bg-purple-50 px-2 py-0.5 rounded">
                          EVS · Mrs. Mohanty
                        </span>
                        <h4 className="text-xs font-bold text-slate-900 mt-1">Butterfly Life-Cycle Coloring Sheet</h4>
                        <p className="text-[11px] text-slate-600 mt-0.5">Color the 4 stages: Egg, Caterpillar, Pupa, Butterfly.</p>
                      </div>
                      <button
                        onClick={() => setCompletedHw({ ...completedHw, e1: !completedHw.e1 })}
                        className={\`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 \${
                          completedHw.e1
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                        }\`}
                      >
                        <Check className="h-3.5 w-3.5" />
                        <span>{completedHw.e1 ? 'Done' : 'Mark Done'}</span>
                      </button>
                    </div>

                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-black uppercase text-purple-600 bg-purple-50 px-2 py-0.5 rounded">
                          English Phonics · Ms. Tanya
                        </span>
                        <h4 className="text-xs font-bold text-slate-900 mt-1">Phonics Workbook Page 18</h4>
                        <p className="text-[11px] text-slate-600 mt-0.5">Trace and match words ending with 'ight'.</p>
                      </div>
                      <button
                        onClick={() => setCompletedHw({ ...completedHw, en1: !completedHw.en1 })}
                        className={\`px-3 py-1.5 text-xs font-bold rounded-lg border transition cursor-pointer flex items-center gap-1 \${
                          completedHw.en1
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                        }\`}
                      >
                        <Check className="h-3.5 w-3.5" />
                        <span>{completedHw.en1 ? 'Done' : 'Mark Done'}</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Parent Acknowledgment Action */}
                <div className="pt-2">
                  <button
                    onClick={() => {
                      setDiarySigned(true);
                      alert('Signed! Class teacher has been informed that parent checked tonight\\'s diary.');
                    }}
                    className={\`w-full py-3 rounded-xl font-bold text-xs shadow transition cursor-pointer flex items-center justify-center gap-2 \${
                      diarySigned
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#0F2942] hover:bg-slate-800 text-white'
                    }\`}
                  >
                    <CheckCircle2 className="h-4 w-4" />
                    <span>{diarySigned ? '✓ Verified & Signed by Parent' : 'Sign & Acknowledge Homework'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* ==================================================================
                DRAWER 2: ATTENDANCE & 1-TAP LEAVE APPLICATION
                ================================================================== */}
            {activeDrawer === 'ATTENDANCE' && (
              <div className="space-y-4">
                {/* Metric Summary */}
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800">
                      Term 1 Attendance Record
                    </span>
                    <h3 className="text-2xl font-black text-emerald-950 mt-0.5">96.4%</h3>
                    <p className="text-[11px] text-emerald-800 font-medium">
                      68 of 70 days present • CBSE minimum is 75%
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 bg-white px-3 py-1 rounded-full border border-emerald-200">
                      <Check className="h-3 w-3" /> Safe Zone
                    </span>
                  </div>
                </div>

                {/* 1-Tap Absence Application Form */}
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">🤒</span>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Notify School & Driver of Absence</h4>
                      <p className="text-[11px] text-slate-500">
                        Auto-updates attendance ledger and stops bus from waiting at your gate
                      </p>
                    </div>
                  </div>

                  {leaveSubmitted ? (
                    <div className="p-3 bg-emerald-100/70 border border-emerald-300 rounded-xl text-xs text-emerald-900 font-medium space-y-1 animate-in fade-in">
                      <p className="font-bold flex items-center gap-1.5">
                        <CheckCircle2 className="h-4 w-4 text-emerald-700" />
                        Absence Registered for Tomorrow
                      </p>
                      <p className="text-[11px]">
                        Teacher Ms. Arundhati Dash and Driver Maheswar Bhoi (OD-15) have been alerted. Bus #3 will skip Sakhipada stop.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3 pt-1">
                      {/* Select Child */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-700">Child:</label>
                        <div className="grid grid-cols-3 gap-2">
                          {(['aarav', 'ananya', 'both'] as const).map((c) => (
                            <button
                              key={c}
                              onClick={() => setLeaveChild(c)}
                              className={\`py-1.5 px-2 text-xs font-bold rounded-lg border transition cursor-pointer \${
                                leaveChild === c
                                  ? 'bg-indigo-600 text-white border-indigo-600'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                              }\`}
                            >
                              {c === 'aarav' ? 'Aarav (5A)' : c === 'ananya' ? 'Ananya (2A)' : 'Both Siblings'}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Select Reason */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-700">Reason:</label>
                        <div className="grid grid-cols-3 gap-2 text-xs">
                          {(
                            [
                              { key: 'fever', label: '🤒 Fever / Cold' },
                              { key: 'family', label: '👨‍👩‍👧 Family Function' },
                              { key: 'travel', label: '🚗 Travel / Away' },
                            ] as const
                          ).map((r) => (
                            <button
                              key={r.key}
                              onClick={() => setLeaveReason(r.key)}
                              className={\`py-2 px-1 text-center font-bold rounded-lg border transition cursor-pointer text-[11px] \${
                                leaveReason === r.key
                                  ? 'bg-indigo-600 text-white border-indigo-600'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                              }\`}
                            >
                              {r.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={() => setLeaveSubmitted(true)}
                        className="w-full py-2.5 bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Send className="h-3.5 w-3.5" />
                        <span>Send 1-Tap Absence Notification</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ==================================================================
                DRAWER 3: EXAMS, SYLLABUS & CBSE HOLISTIC PROGRESS CARD (HPC)
                ================================================================== */}
            {activeDrawer === 'EXAMS' && (
              <div className="space-y-4">
                {/* Upcoming Assessment Countdown */}
                <div className="bg-indigo-50 border border-indigo-200 rounded-2xl p-4 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider text-indigo-700">
                      Upcoming Assessment
                    </span>
                    <span className="text-xs font-bold text-indigo-900 bg-white px-2 py-0.5 rounded-full border border-indigo-200">
                      Starts in 4 Days
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-indigo-950">
                    Periodic Assessment 2 (Nov 4 – Nov 8, 2026)
                  </h4>
                  <p className="text-xs text-indigo-800">
                    Grade 5A & Grade 2A syllabus schedules are finalized by CBSE Academic Cell.
                  </p>
                </div>

                {/* Exam Date Sheet */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                    Date Sheet & Syllabus Topics
                  </span>
                  <div className="space-y-1.5 text-xs">
                    {[
                      { date: 'Mon, Nov 4', subject: 'Mathematics', topics: 'Fractions, Decimals, Perimeter' },
                      { date: 'Tue, Nov 5', subject: 'Science', topics: 'Water cycle, Dam Spillways, Force & Motion' },
                      { date: 'Wed, Nov 6', subject: 'English', topics: 'Unseen Passage, Informal Letter, Tenses' },
                      { date: 'Thu, Nov 7', subject: 'Social Studies', topics: 'Odisha River Basins, Monuments' },
                      { date: 'Fri, Nov 8', subject: 'Hindi / Odia', topics: 'Ch 5 & 6 Comprehension, Grammar' },
                    ].map((row, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-800">{row.subject}</span>
                            <span className="text-[10px] text-slate-500 font-mono">({row.date})</span>
                          </div>
                          <p className="text-[11px] text-slate-500">{row.topics}</p>
                        </div>
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          Syllabus Set
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CBSE Holistic Progress Card (HPC) & Teacher Audio Note */}
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                        Term 1 Holistic Progress Card (HPC)
                      </span>
                      <h4 className="text-xs font-bold text-slate-900 mt-0.5">Aarav Patel · Grade 5A</h4>
                    </div>
                    <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                      Distinction (92.4%)
                    </span>
                  </div>

                  {/* Teacher Voice Rubric Clip */}
                  <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-base">🎙️</span>
                        <div>
                          <p className="text-xs font-bold text-slate-800">Teacher Voice Rubric Note</p>
                          <p className="text-[10px] text-slate-500">Ms. Arundhati Dash (Grade 5A Class Teacher)</p>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setIsPlayingHpcVoice(true);
                          speakText(
                            locale === 'or'
                              ? 'ନମସ୍କାର। ବିଜ୍ଞାନ ପ୍ରକଳ୍ପରେ ଆରଭ ବହୁତ ଭଲ ସହଯୋଗ କରିଛି। ତାର ଗ୍ରୁପ୍ କାର୍ଯ୍ୟ ଏବଂ ଉତ୍ସାହ ପ୍ରଶଂସନୀୟ।'
                              : locale === 'hi'
                              ? 'नमस्ते। आरव ने इस सत्र विज्ञान प्रोजेक्ट में बहुत उत्कृष्ट कार्य किया है। उनकी टीम भावना सराहनीय है।'
                              : 'Namaste. Aarav showed wonderful curiosity in the Hirakud dam model project this term. His peer collaboration is outstanding.'
                          );
                        }}
                        className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-lg border border-indigo-200 flex items-center gap-1 cursor-pointer"
                      >
                        <Volume2 className="h-3.5 w-3.5" />
                        <span>Play Audio</span>
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-600 italic bg-slate-50 p-2 rounded-lg border border-slate-100">
                      "Aarav showed wonderful curiosity in the Hirakud dam model project this term. His peer collaboration and mathematical reasoning are outstanding."
                    </p>
                  </div>

                  {/* Download Official PDF */}
                  <button
                    onClick={() => alert('Official CBSE Term 1 Holistic Progress Card (HPC) PDF downloaded.')}
                    className="w-full py-2.5 bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Download Official CBSE Marksheet (PDF)</span>
                  </button>
                </div>
              </div>
            )}

            {/* ==================================================================
                DRAWER 4: SCHOOL FEES, ESCROW SHIELD & 80C RECEIPTS
                ================================================================== */}
            {activeDrawer === 'FEES' && (
              <div className="space-y-4">
                {/* Fee Status Card */}
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800">
                      Quarter 3 Status (Oct – Dec 2026)
                    </span>
                    <h3 className="text-xl font-black text-emerald-950 mt-0.5">₹0 Dues Pending</h3>
                    <p className="text-[11px] text-emerald-800 font-medium">
                      All tuition & transport paid · Next due Dec 15 (Q4)
                    </p>
                  </div>
                  <span className="text-xs font-bold text-emerald-800 bg-white px-3 py-1 rounded-full border border-emerald-200">
                    ✓ Paid in Full
                  </span>
                </div>

                {/* Itemized Fee Breakdown */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                    Quarter 3 Fee Breakdown
                  </span>
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2 text-xs">
                    <div className="flex justify-between text-slate-700">
                      <span>Tuition & Smart Learning Lab (Grade 5A)</span>
                      <strong className="text-slate-900 font-mono">₹14,000</strong>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span>AC Bus Route #3 Fleet (OD-15)</span>
                      <strong className="text-slate-900 font-mono">₹3,500</strong>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span>Nutritional Recess Meal Subscription</span>
                      <strong className="text-slate-900 font-mono">₹1,000</strong>
                    </div>
                    <div className="border-t border-slate-200 pt-2 flex justify-between font-bold text-slate-900">
                      <span>Total Paid via UPI</span>
                      <span className="text-emerald-700 font-mono">₹18,500</span>
                    </div>
                  </div>
                </div>

                {/* 80C Tax Proof Download */}
                <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Official GST 80C Tax Receipt</h4>
                    <p className="text-[11px] text-slate-500">Receipt #BOMIS-2026-REC-001 • Eligible for Income Tax rebate</p>
                  </div>
                  <button
                    onClick={() => {
                      setReceiptDownloaded(true);
                      alert('GST 80C Tax Receipt #BOMIS-2026-REC-001 downloaded to your device.');
                    }}
                    className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-lg border border-indigo-200 flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>{receiptDownloaded ? 'Downloaded' : 'Download'}</span>
                  </button>
                </div>

                {/* Calm Escrow Shield Information */}
                <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-1.5 text-xs text-amber-950">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Shield className="h-4 w-4 text-amber-700" />
                    <span>BOMIS Calm Escrow Shield Guarantee</span>
                  </div>
                  <p className="text-[11px] text-amber-900 leading-relaxed">
                    If your bank times out during UPI payments at 11:59 PM, our system automatically issues a 48-Hour Provisional Clearance Pass (#PROV-8821). Your child will NEVER be barred from classes or exams due to bank gateway delays.
                  </p>
                </div>
              </div>
            )}

            {/* ==================================================================
                DRAWER 5: PTM (PARENT-TEACHER MEETING) 1-TAP BOOKING
                ================================================================== */}
            {activeDrawer === 'PTM' && (
              <div className="space-y-4">
                {/* Upcoming PTM Banner */}
                <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 space-y-1">
                  <span className="text-[10px] font-black uppercase tracking-wider text-purple-700">
                    Term 1 Parent-Teacher Conference
                  </span>
                  <h4 className="text-sm font-black text-purple-950">Saturday, Nov 8, 2026</h4>
                  <p className="text-xs text-purple-800">
                    10-minute one-on-one session with your child's class teacher to review progress.
                  </p>
                </div>

                {ptmConfirmed ? (
                  <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl space-y-2 text-xs animate-in fade-in">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold">
                      <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                      <span>Appointment Confirmed!</span>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-emerald-200 space-y-1 text-slate-700">
                      <p><strong>Teacher:</strong> {ptmTeacher === 'dash' ? 'Ms. Arundhati Dash (Grade 5A)' : 'Mrs. Mohanty (Grade 2A)'}</p>
                      <p><strong>Time:</strong> Saturday, Nov 8 · {ptmSlot}</p>
                      <p><strong>Format:</strong> {ptmMode === 'campus' ? 'Room 204 (Academic Block)' : 'Google Meet Video Link'}</p>
                      <p className="font-mono font-bold text-indigo-700 pt-1">Gate Pass Code: #PTM-442</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Teacher Selector */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700">Select Teacher:</label>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <button
                          onClick={() => setPtmTeacher('dash')}
                          className={\`p-2.5 rounded-xl border text-left transition cursor-pointer \${
                            ptmTeacher === 'dash'
                              ? 'bg-purple-50 border-purple-500 text-purple-950 font-bold'
                              : 'bg-white border-slate-200 text-slate-700'
                          }\`}
                        >
                          <p className="font-bold">Ms. Arundhati Dash</p>
                          <p className="text-[10px] text-slate-500">Grade 5A Class Teacher</p>
                        </button>
                        <button
                          onClick={() => setPtmTeacher('mohanty')}
                          className={\`p-2.5 rounded-xl border text-left transition cursor-pointer \${
                            ptmTeacher === 'mohanty'
                              ? 'bg-purple-50 border-purple-500 text-purple-950 font-bold'
                              : 'bg-white border-slate-200 text-slate-700'
                          }\`}
                        >
                          <p className="font-bold">Mrs. Mohanty</p>
                          <p className="text-[10px] text-slate-500">Grade 2A Class Teacher</p>
                        </button>
                      </div>
                    </div>

                    {/* Mode Selector */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700">Meeting Format:</label>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <button
                          onClick={() => setPtmMode('campus')}
                          className={\`py-2 px-3 rounded-lg border font-bold transition cursor-pointer \${
                            ptmMode === 'campus'
                              ? 'bg-indigo-600 text-white border-indigo-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }\`}
                        >
                          🏫 In-Person at Campus
                        </button>
                        <button
                          onClick={() => setPtmMode('video')}
                          className={\`py-2 px-3 rounded-lg border font-bold transition cursor-pointer \${
                            ptmMode === 'video'
                              ? 'bg-indigo-600 text-white border-indigo-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                          }\`}
                        >
                          📹 Google Meet Video
                        </button>
                      </div>
                    </div>

                    {/* Slot Selector */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-700">Available Time Slots (Saturday):</label>
                      <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                        {['10:00 AM - 10:15 AM', '10:20 AM - 10:35 AM', '10:40 AM - 10:55 AM', '11:00 AM - 11:15 AM'].map(
                          (slot) => (
                            <button
                              key={slot}
                              onClick={() => setPtmSlot(slot)}
                              className={\`py-2 px-2 rounded-lg border font-bold transition cursor-pointer \${
                                ptmSlot === slot
                                  ? 'bg-purple-600 text-white border-purple-600'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                              }\`}
                            >
                              {slot}
                            </button>
                          )
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => setPtmConfirmed(true)}
                      className="w-full py-2.5 bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer"
                    >
                      Confirm PTM Appointment
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* ==================================================================
                DRAWER 6: SCHOOL CIRCULARS & NOTICES (TRI-LINGUAL AUDIO)
                ================================================================== */}
            {activeDrawer === 'CIRCULARS' && (
              <div className="space-y-4">
                {/* Latest Circular */}
                <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider text-rose-700">
                      Official Circular #BOMIS-2026-CIR-088
                    </span>
                    <span className="text-[10px] font-bold text-slate-500">Oct 26, 2026</span>
                  </div>
                  <h4 className="text-sm font-black text-rose-950">
                    Winter Uniform Transition & Annual Athletics Selections
                  </h4>
                  <p className="text-xs text-rose-900 leading-relaxed">
                    Winter navy blue blazers and sweaters are mandatory starting Nov 15. Annual Sports Day selections for Grade 1–8 will take place on Nov 12 at the athletics grounds.
                  </p>

                  {/* Audio Read-Out */}
                  <div className="pt-1 flex items-center gap-2">
                    <span className="text-[11px] font-bold text-slate-600">Listen:</span>
                    <button
                      onClick={() =>
                        speakText(
                          'Circular 88. Winter navy blue blazers and sweaters are mandatory starting November 15. Annual sports day selections will begin on November 12.'
                        )
                      }
                      className="px-2.5 py-1 bg-white hover:bg-rose-100 text-rose-900 font-bold text-[11px] rounded-lg border border-rose-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="h-3 w-3 text-rose-600" />
                      <span>English</span>
                    </button>
                    <button
                      onClick={() =>
                        speakText(
                          'ପରିପତ୍ର ୮୮. ନଭେମ୍ବର ୧୫ ତାରିଖରୁ ଶୀତକାଳୀନ ୟୁନିଫର୍ମ ଏବଂ ସ୍ୱେଟର ବାଧ୍ୟତାମୂଳକ। ନଭେମ୍ବର ୧୨ ତାରିଖରେ ବାର୍ଷିକ କ୍ରୀଡ଼ା ପ୍ରତିଯୋଗିତା ଅନୁଷ୍ଠିତ ହେବ।'
                        )
                      }
                      className="px-2.5 py-1 bg-white hover:bg-rose-100 text-rose-900 font-bold text-[11px] rounded-lg border border-rose-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="h-3 w-3 text-rose-600" />
                      <span>ଓଡ଼ିଆ</span>
                    </button>
                    <button
                      onClick={() =>
                        speakText(
                          'परिपत्र 88. 15 नवंबर से शीतकालीन यूनिफॉर्म और स्वेटर अनिवार्य है। 12 नवंबर से वार्षिक खेलकूद चयन शुरू होगा।'
                        )
                      }
                      className="px-2.5 py-1 bg-white hover:bg-rose-100 text-rose-900 font-bold text-[11px] rounded-lg border border-rose-200 flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="h-3 w-3 text-rose-600" />
                      <span>हिन्दी</span>
                    </button>
                  </div>
                </div>

                {/* Past Notices List */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                    Recent Notices Archive
                  </span>
                  <div className="space-y-1.5 text-xs">
                    {[
                      {
                        title: 'Diwali Break Schedule & Science Model Exhibition',
                        date: 'Oct 20, 2026',
                        summary: 'School closed Oct 28 - Nov 1. Reopens Nov 2.',
                      },
                      {
                        title: 'Hirakud Nature Trail Educational Excursion',
                        date: 'Oct 10, 2026',
                        summary: 'Grade 5 field visit permissions and safety protocol.',
                      },
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between"
                      >
                        <div>
                          <h5 className="font-bold text-slate-800">{item.title}</h5>
                          <p className="text-[11px] text-slate-500 mt-0.5">{item.summary}</p>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 shrink-0 ml-2">{item.date}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Download PDF button */}
                <button
                  onClick={() => alert('Official Circular #BOMIS-2026-CIR-088 PDF downloaded.')}
                  className="w-full py-2.5 bg-[#0F2942] hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download Official Circular (PDF)</span>
                </button>
              </div>
            )}

            {/* Close Drawer Button */}
            <div className="pt-1">
              <button
                onClick={() => setActiveDrawer(null)}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------------------
          MORE SHEET (Bottom Sheet replacing messy multi-tab navigation)
          ------------------------------------------------------------------------ */}
      {isMoreOpen && (`;

content = content.replace(closingDivTarget, drawersCode);

fs.writeFileSync(pagePath, content, 'utf8');
console.log('Successfully enhanced page.tsx with Everyday School Services!');
