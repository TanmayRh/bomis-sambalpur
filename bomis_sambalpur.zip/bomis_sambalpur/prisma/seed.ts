/**
 * ==============================================================================
 * BOMIS Sambalpur Unified School Platform - Master Database Seed Generator
 * Conforms to: AC-6, R1-R5, DPDP Act 2023, and Newman Test Suite
 * ==============================================================================
 */

import {
  PrismaClient,
  UserRole,
  UserStatus,
  Gender,
  FeeFrequency,
  PaymentStatus,
  PaymentMethod,
  ConsentType,
  ConsentStatus,
  AuditAction,
  BusTripType,
  ExamTerm,
} from '@prisma/client';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';

const prisma = new PrismaClient();

// Constant Deterministic UUIDs for Newman & Postman Compatibility
export const SEED_IDS = {
  SCHOOL: 'e4b3c2a1-0001-4000-8000-000000000001',
  ACADEMIC_YEAR: 'e4b3c2a1-0002-4000-8000-000000000001',
  CLASS_GRADE_5: 'c1000000-0005-4000-8000-000000000001',
  SECTION_GRADE_5A: 's1000000-0005-4000-8000-000000000001',
  USER_TEACHER_G5A: 'u1000000-0010-4000-8000-000000000001',
  STAFF_TEACHER_G5A: 'm1000000-0010-4000-8000-000000000001',
  USER_PARENT_PATEL: 'u1000000-0101-4000-8000-000000000001',
  GUARDIAN_PATEL: 'g1000000-0001-4000-8000-000000000001',
  STUDENT_AARAV: 'b1000000-0005-4000-8000-000000000001',
  STUDENT_ANANYA: 'b1000000-0002-4000-8000-000000000001',
  BUS_PILOT_01: 'v1000000-0001-4000-8000-000000000001',
  BUS_PILOT_02: 'v1000000-0002-4000-8000-000000000001',
  BUS_PILOT_03: 'v1000000-0003-4000-8000-000000000001',
  BUS_PILOT_04: 'v1000000-0004-4000-8000-000000000001',
  ROUTE_BUDHARAJA: 'r1000000-0001-4000-8000-000000000001',
  ROUTE_KHETRAJPUR: 'r1000000-0002-4000-8000-000000000001',
  ROUTE_DHANUPALI: 'r1000000-0003-4000-8000-000000000001',
  ROUTE_BURLA: 'r1000000-0004-4000-8000-000000000001',
  STOP_SAKHIPADA: 'p1000000-0001-4000-8000-000000000002',
};

// Password Hash Cache for Fast Idempotent Execution
const hashCache = new Map<string, string>();
function getHash(password: string): string {
  if (!hashCache.has(password)) {
    hashCache.set(password, bcrypt.hashSync(password, 10));
  }
  return hashCache.get(password)!;
}

// AES-256-GCM Field-Level Encryption Helper for DPDP Compliant Seed Storage
function encryptField(text: string): string {
  const keyHex =
    process.env.APP_ENCRYPTION_KEY ||
    '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';
  const key = Buffer.from(keyHex, 'hex');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
}

// SHA-256 HMAC Consent Proof Hash Helper
function computeConsentProof(
  userId: string,
  schoolId: string,
  consentType: string,
  version: string
): string {
  const payload = `${userId}:${schoolId}:${consentType}:${version}:GRANTED`;
  return crypto.createHmac('sha256', 'bomis_consent_secret_2026').update(payload).digest('hex');
}

async function main() {
  console.log('================================================================');
  console.log('🚀 Seeding BOMIS Sambalpur Unified School Platform Database');
  console.log('================================================================');

  // 1. Seed Root School
  const school = await prisma.school.upsert({
    where: { id: SEED_IDS.SCHOOL },
    update: {},
    create: {
      id: SEED_IDS.SCHOOL,
      name: 'Birla Open Minds International School, Sambalpur',
      code: 'BOMIS-SBP',
      affiliation_number: '1530284',
      address: 'NH-53 Bypass Road, Near Remed Chhak',
      city: 'Sambalpur',
      state: 'Odisha',
      postal_code: '768006',
      phone: '+919437000001',
      email: 'info@bomis-sambalpur.edu.in',
      website: 'https://bomis-sambalpur.edu.in',
      logo_url: 'https://storage.bomis-sambalpur.edu.in/assets/logo.png',
      status: 'ACTIVE',
    },
  });
  console.log(`✓ Root School seeded: ${school.name} (${school.code})`);

  // 2. Seed Academic Year
  const academicYear = await prisma.academicYear.upsert({
    where: { id: SEED_IDS.ACADEMIC_YEAR },
    update: {},
    create: {
      id: SEED_IDS.ACADEMIC_YEAR,
      school_id: school.id,
      name: '2026-2027',
      start_date: new Date('2026-04-01T00:00:00.000Z'),
      end_date: new Date('2027-03-31T23:59:59.999Z'),
      is_current: true,
    },
  });
  console.log(`✓ Academic Year seeded: ${academicYear.name}`);

  // 3. Seed CBSE Examination Terms
  const term1 = await prisma.exam.upsert({
    where: {
      school_id_academic_year_id_name: {
        school_id: school.id,
        academic_year_id: academicYear.id,
        name: 'Term 1 Exam (Autumn 2026)',
      },
    },
    update: {},
    create: {
      school_id: school.id,
      academic_year_id: academicYear.id,
      name: 'Term 1 Exam (Autumn 2026)',
      term: ExamTerm.TERM_1,
      start_date: new Date('2026-09-15T09:00:00.000Z'),
      end_date: new Date('2026-09-28T12:00:00.000Z'),
      is_published: true,
    },
  });
  console.log(`✓ Academic Term seeded: ${term1.name}`);

  // 4. Seed Classes (Grades 1 through 8) & Section A
  const classes: Record<number, any> = {};
  const sections: Record<number, any> = {};

  for (let grade = 1; grade <= 8; grade++) {
    const classId =
      grade === 5
        ? SEED_IDS.CLASS_GRADE_5
        : `c1000000-000${grade}-4000-8000-000000000001`;
    const sectionId =
      grade === 5
        ? SEED_IDS.SECTION_GRADE_5A
        : `s1000000-000${grade}-4000-8000-000000000001`;

    const cls = await prisma.class.upsert({
      where: { id: classId },
      update: {},
      create: {
        id: classId,
        school_id: school.id,
        name: `Grade ${grade}`,
        code: `G${grade}`,
        grade_level: grade,
        order_index: grade,
      },
    });
    classes[grade] = cls;

    const sec = await prisma.section.upsert({
      where: { id: sectionId },
      update: {},
      create: {
        id: sectionId,
        school_id: school.id,
        class_id: cls.id,
        name: 'A',
        capacity: 35,
        room_number: `Room ${grade <= 4 ? 100 + grade : 200 + (grade - 4)}`,
      },
    });
    sections[grade] = sec;
  }
  console.log('✓ Academic Classes (Grades 1-8) & Sections A seeded');

  // 5. Seed CBSE Subjects
  const subjectDefs = [
    { name: 'English Communicative', code: 'ENG-101', isScholastic: true },
    { name: 'Hindi Course B', code: 'HIN-101', isScholastic: true },
    { name: 'Odia Language', code: 'ODI-101', isScholastic: true },
    { name: 'Mathematics', code: 'MTH-101', isScholastic: true },
    { name: 'General Science', code: 'SCI-101', isScholastic: true },
    { name: 'Social Studies', code: 'SST-101', isScholastic: true },
    { name: 'Computer Science & AI', code: 'CSC-101', isScholastic: true },
  ];

  const subjects: Record<string, any> = {};
  for (const s of subjectDefs) {
    const sub = await prisma.subject.upsert({
      where: { school_id_code: { school_id: school.id, code: s.code } },
      update: {},
      create: {
        school_id: school.id,
        name: s.name,
        code: s.code,
        is_scholastic: s.isScholastic,
      },
    });
    subjects[s.code] = sub;
  }
  console.log('✓ CBSE Curriculum Subjects seeded');

  // 6. Seed 8 RBAC Users & Master Profiles
  // Default pass for staff: Admin@Sambalpur2026
  const staffHash = getHash('Admin@Sambalpur2026');
  const parentHash = getHash('Bomis@Sambalpur2026');

  // 6.1 Super Admin
  await prisma.user.upsert({
    where: { school_id_email: { school_id: school.id, email: 'superadmin@bomis-sambalpur.edu.in' } },
    update: {},
    create: {
      school_id: school.id,
      email: 'superadmin@bomis-sambalpur.edu.in',
      phone: '+919437000000',
      password_hash: staffHash,
      role: UserRole.SUPER_ADMIN,
      status: UserStatus.ACTIVE,
      first_name: 'Platform',
      last_name: 'SuperAdmin',
    },
  });

  // 6.2 Campus Admin (Matches Newman tests)
  await prisma.user.upsert({
    where: { school_id_email: { school_id: school.id, email: 'admin@bomis-sambalpur.edu.in' } },
    update: {},
    create: {
      school_id: school.id,
      email: 'admin@bomis-sambalpur.edu.in',
      phone: '+919437000003',
      password_hash: staffHash,
      role: UserRole.ADMIN,
      status: UserStatus.ACTIVE,
      first_name: 'Amit Kumar',
      last_name: 'Senapati',
    },
  });

  // 6.3 Principal
  await prisma.user.upsert({
    where: { school_id_email: { school_id: school.id, email: 'principal@bomis-sambalpur.edu.in' } },
    update: {},
    create: {
      school_id: school.id,
      email: 'principal@bomis-sambalpur.edu.in',
      phone: '+919437000002',
      password_hash: staffHash,
      role: UserRole.PRINCIPAL,
      status: UserStatus.ACTIVE,
      first_name: 'Dr. Minati',
      last_name: 'Mohanty',
    },
  });

  // 6.4 Accountant
  await prisma.user.upsert({
    where: { school_id_email: { school_id: school.id, email: 'accountant@bomis-sambalpur.edu.in' } },
    update: {},
    create: {
      school_id: school.id,
      email: 'accountant@bomis-sambalpur.edu.in',
      phone: '+919437000004',
      password_hash: staffHash,
      role: UserRole.ACCOUNTANT,
      status: UserStatus.ACTIVE,
      first_name: 'Birendra Nath',
      last_name: 'Sahu',
    },
  });

  // 6.5 Grade 5A Class Teacher (Mrs. Arundhati Dash)
  const teacherUser = await prisma.user.upsert({
    where: { id: SEED_IDS.USER_TEACHER_G5A },
    update: {},
    create: {
      id: SEED_IDS.USER_TEACHER_G5A,
      school_id: school.id,
      email: 'arundhati.dash@bomis-sambalpur.edu.in',
      phone: '+919437100005',
      password_hash: staffHash,
      role: UserRole.TEACHER,
      status: UserStatus.ACTIVE,
      first_name: 'Arundhati',
      last_name: 'Dash',
    },
  });

  const teacherStaff = await prisma.staff.upsert({
    where: { id: SEED_IDS.STAFF_TEACHER_G5A },
    update: {},
    create: {
      id: SEED_IDS.STAFF_TEACHER_G5A,
      school_id: school.id,
      user_id: teacherUser.id,
      employee_id: 'STF-BOMIS-010',
      designation: 'TGT Mathematics',
      department: 'Academics',
      joining_date: new Date('2021-06-01T00:00:00.000Z'),
      pan_number_encrypted: encryptField('ABCDE1234F'),
      aadhaar_number_encrypted: encryptField('123456789012'),
    },
  });

  // Assign class teacher to Grade 5A
  await prisma.section.update({
    where: { id: sections[5].id },
    data: { class_teacher_id: teacherStaff.id },
  });

  // Assign Subject Teacher
  await prisma.teacherAssignment.upsert({
    where: {
      school_id_staff_id_section_id_subject_id_academic_year_id: {
        school_id: school.id,
        staff_id: teacherStaff.id,
        section_id: sections[5].id,
        subject_id: subjects['MTH-101'].id,
        academic_year_id: academicYear.id,
      },
    },
    update: {},
    create: {
      school_id: school.id,
      staff_id: teacherStaff.id,
      class_id: classes[5].id,
      section_id: sections[5].id,
      subject_id: subjects['MTH-101'].id,
      academic_year_id: academicYear.id,
    },
  });

  // 6.6 Transport Staff / Drivers (4 Drivers for 4 Pilot Buses)
  const driverUsers: any[] = [];
  const driverStaff: any[] = [];

  const driverData = [
    { name: 'Maheswar Bhoi', phone: '+919437200001', code: 'DRV-BOMIS-001', email: 'driver.bhoi@bomis-sambalpur.edu.in' },
    { name: 'Niranjan Jhankar', phone: '+919437200002', code: 'DRV-BOMIS-002', email: 'driver.jhankar@bomis-sambalpur.edu.in' },
    { name: 'Kailash Chandra Bag', phone: '+919437200003', code: 'DRV-BOMIS-003', email: 'driver.bag@bomis-sambalpur.edu.in' },
    { name: 'Ganeswar Padhan', phone: '+919437200004', code: 'DRV-BOMIS-004', email: 'driver.padhan@bomis-sambalpur.edu.in' },
  ];

  for (let i = 0; i < driverData.length; i++) {
    const d = driverData[i];
    const [first, ...rest] = d.name.split(' ');
    const u = await prisma.user.upsert({
      where: { school_id_phone: { school_id: school.id, phone: d.phone } },
      update: {},
      create: {
        school_id: school.id,
        email: d.email,
        phone: d.phone,
        password_hash: staffHash,
        role: UserRole.TRANSPORT_STAFF,
        status: UserStatus.ACTIVE,
        first_name: first,
        last_name: rest.join(' '),
      },
    });
    driverUsers.push(u);

    const s = await prisma.staff.upsert({
      where: { school_id_employee_id: { school_id: school.id, employee_id: d.code } },
      update: {},
      create: {
        school_id: school.id,
        user_id: u.id,
        employee_id: d.code,
        designation: 'Senior Fleet Pilot',
        department: 'Transport',
        joining_date: new Date('2022-04-01T00:00:00.000Z'),
      },
    });
    driverStaff.push(s);
  }
  console.log('✓ Master Staff & Drivers seeded across roles');

  // 7. Seed 4 Transport Routes and 14 Geofenced Stops
  const routesData = [
    {
      id: SEED_IDS.ROUTE_BUDHARAJA,
      name: 'Route 1 - Budharaja Shuttle',
      code: 'RT-BUDHARAJA-01',
      start: 'Budharaja Fatak',
      end: 'BOMIS Campus Gate',
      stops: [
        { name: 'Budharaja Fatak', lat: 21.4825, lng: 83.9782, order: 1, pickup: '07:15', drop: '14:45' },
        { name: 'Sakhipada Chhak', lat: 21.4669, lng: 83.9812, order: 2, pickup: '07:25', drop: '14:35', id: SEED_IDS.STOP_SAKHIPADA },
        { name: 'Ainthapali Chowk', lat: 21.493, lng: 83.987, order: 3, pickup: '07:35', drop: '14:25' },
        { name: 'BOMIS Campus Gate', lat: 21.4938, lng: 83.9855, order: 4, pickup: '07:45', drop: '14:15' },
      ],
    },
    {
      id: SEED_IDS.ROUTE_KHETRAJPUR,
      name: 'Route 2 - Khetrajpur Express',
      code: 'RT-KHETRAJPUR-02',
      start: 'Khetrajpur Station',
      end: 'BOMIS Campus Gate',
      stops: [
        { name: 'Khetrajpur Railway Station', lat: 21.4812, lng: 83.9554, order: 1, pickup: '07:10', drop: '14:50' },
        { name: 'Modipara Chowk', lat: 21.4745, lng: 83.968, order: 2, pickup: '07:22', drop: '14:38' },
        { name: 'Golebazar Market', lat: 21.464, lng: 83.972, order: 3, pickup: '07:32', drop: '14:28' },
        { name: 'BOMIS Campus Gate', lat: 21.4938, lng: 83.9855, order: 4, pickup: '07:45', drop: '14:15' },
      ],
    },
    {
      id: SEED_IDS.ROUTE_DHANUPALI,
      name: 'Route 3 - Dhanupali & Brooks Hill',
      code: 'RT-DHANUPALI-03',
      start: 'Dhanupali Market',
      end: 'BOMIS Campus Gate',
      stops: [
        { name: 'Dhanupali Chhak', lat: 21.4468, lng: 83.985, order: 1, pickup: '07:05', drop: '14:55' },
        { name: 'Brooks Hill Overbridge', lat: 21.458, lng: 83.979, order: 2, pickup: '07:18', drop: '14:42' },
        { name: 'Bareipali Gate', lat: 21.505, lng: 83.992, order: 3, pickup: '07:32', drop: '14:28' },
        { name: 'BOMIS Campus Gate', lat: 21.4938, lng: 83.9855, order: 4, pickup: '07:45', drop: '14:15' },
      ],
    },
    {
      id: SEED_IDS.ROUTE_BURLA,
      name: 'Route 4 - Burla University Corridor',
      code: 'RT-BURLA-04',
      start: 'Burla Medical College',
      end: 'BOMIS Campus Gate',
      stops: [
        { name: 'Burla Medical College Chhak', lat: 21.498, lng: 83.871, order: 1, pickup: '07:00', drop: '15:00' },
        { name: 'VSSUT Engineering Campus Gate', lat: 21.503, lng: 83.877, order: 2, pickup: '07:12', drop: '14:48' },
        { name: 'Sambalpur University PG Gate', lat: 21.5085, lng: 83.882, order: 3, pickup: '07:20', drop: '14:40' },
        { name: 'Remed Bypass Chowk', lat: 21.501, lng: 83.935, order: 4, pickup: '07:32', drop: '14:28' },
        { name: 'BOMIS Campus Gate', lat: 21.4938, lng: 83.9855, order: 5, pickup: '07:45', drop: '14:15' },
      ],
    },
  ];

  const createdRoutes: any[] = [];
  const createdStops: Record<string, any> = {};

  for (const rd of routesData) {
    const route = await prisma.transportRoute.upsert({
      where: { id: rd.id },
      update: {},
      create: {
        id: rd.id,
        school_id: school.id,
        name: rd.name,
        code: rd.code,
        start_point: rd.start,
        end_point: rd.end,
      },
    });
    createdRoutes.push(route);

    for (const st of rd.stops) {
      const stopId = (st as any).id || undefined;
      const createdStop = await prisma.transportStop.upsert({
        where: {
          school_id_route_id_stop_order: {
            school_id: school.id,
            route_id: route.id,
            stop_order: st.order,
          },
        },
        update: {},
        create: {
          ...(stopId ? { id: stopId } : {}),
          school_id: school.id,
          route_id: route.id,
          name: st.name,
          latitude: st.lat,
          longitude: st.lng,
          stop_order: st.order,
          pickup_time: st.pickup,
          drop_time: st.drop,
          geofence_radius_meters: 100,
        },
      });
      createdStops[st.name] = createdStop;
    }
  }
  console.log('✓ 4 Arterial Transport Routes & 15 Geofenced Stops seeded');

  // 8. Seed 4 Pilot Buses (OD-15 Sambalpur RTO plates)
  const busConfigs = [
    {
      id: SEED_IDS.BUS_PILOT_01,
      plate: 'OD-15-AB-1001',
      busNo: 'Bus 01',
      capacity: 24,
      model: 'Tata Winger School Bus (2024)',
      driverId: driverStaff[0].id,
      routeId: SEED_IDS.ROUTE_BUDHARAJA,
    },
    {
      id: SEED_IDS.BUS_PILOT_02,
      plate: 'OD-15-AB-1002',
      busNo: 'Bus 02',
      capacity: 24,
      model: 'Force Traveller Smart School (2024)',
      driverId: driverStaff[1].id,
      routeId: SEED_IDS.ROUTE_KHETRAJPUR,
    },
    {
      id: SEED_IDS.BUS_PILOT_03,
      plate: 'OD-15-AB-1003',
      busNo: 'Bus 03',
      capacity: 24,
      model: 'Mahindra Tourister School (2023)',
      driverId: driverStaff[2].id,
      routeId: SEED_IDS.ROUTE_DHANUPALI,
    },
    {
      id: SEED_IDS.BUS_PILOT_04,
      plate: 'OD-15-AC-2001',
      busNo: 'Bus 04',
      capacity: 52,
      model: 'Ashok Leyland Sunshine (2025)',
      driverId: driverStaff[3].id,
      routeId: SEED_IDS.ROUTE_BURLA,
    },
  ];

  for (const b of busConfigs) {
    await prisma.vehicle.upsert({
      where: { id: b.id },
      update: {},
      create: {
        id: b.id,
        school_id: school.id,
        registration_number: b.plate,
        bus_number: b.busNo,
        capacity: b.capacity,
        model: b.model,
        driver_staff_id: b.driverId,
        current_route_id: b.routeId,
        status: 'ACTIVE',
      },
    });
  }
  console.log('✓ 4 Pilot Buses (3 Small 24-Seater, 1 Full-Size 52-Seater) seeded with OD-15 plates');

  // 9. Seed Patel Family (Primary Newman Test Family with Siblings in 5A and 2A)
  const patelUser = await prisma.user.upsert({
    where: { id: SEED_IDS.USER_PARENT_PATEL },
    update: {},
    create: {
      id: SEED_IDS.USER_PARENT_PATEL,
      school_id: school.id,
      phone: '+919876543210',
      email: 'rajesh.patel@example.com',
      password_hash: parentHash,
      role: UserRole.PARENT,
      status: UserStatus.ACTIVE,
      first_name: 'Dr. Rajesh Kumar',
      last_name: 'Patel',
    },
  });

  const patelGuardian = await prisma.guardian.upsert({
    where: { id: SEED_IDS.GUARDIAN_PATEL },
    update: {},
    create: {
      id: SEED_IDS.GUARDIAN_PATEL,
      school_id: school.id,
      user_id: patelUser.id,
      first_name: 'Rajesh Kumar',
      last_name: 'Patel',
      relationship: 'Father',
      occupation: 'Senior Physician, VSS Medical College',
      aadhaar_number_encrypted: encryptField('987654321098'),
      annual_income_encrypted: encryptField('2400000'),
      emergency_phone: '+919876543210',
    },
  });

  // 9.1 Sibling 1: Aarav Patel (Grade 5A - Newman Primary Test Student)
  const aarav = await prisma.student.upsert({
    where: { id: SEED_IDS.STUDENT_AARAV },
    update: {},
    create: {
      id: SEED_IDS.STUDENT_AARAV,
      school_id: school.id,
      admission_number: 'BOMIS-2021-0042',
      roll_number: '1',
      first_name: 'Aarav',
      last_name: 'Patel',
      date_of_birth: new Date('2015-08-14T00:00:00.000Z'),
      gender: Gender.MALE,
      class_id: classes[5].id,
      section_id: sections[5].id,
      academic_year_id: academicYear.id,
      emergency_contact: '+919876543210',
      blood_group_encrypted: encryptField('O+'),
      medical_notes_encrypted: encryptField('Allergic to peanuts and dust'),
      aadhaar_number_encrypted: encryptField('567812349012'),
      address: 'Plot 142, Budharaja Hills Road, Sambalpur 768004',
      is_active: true,
    },
  });

  // Link Aarav to Dr. Rajesh Patel
  await prisma.studentGuardian.upsert({
    where: {
      school_id_student_id_guardian_id: {
        school_id: school.id,
        student_id: aarav.id,
        guardian_id: patelGuardian.id,
      },
    },
    update: {},
    create: {
      school_id: school.id,
      student_id: aarav.id,
      guardian_id: patelGuardian.id,
      relation_type: 'Father',
      is_primary_contact: true,
      can_pickup: true,
    },
  });

  // Assign Aarav to Pilot Bus 1 (Sakhipada Stop)
  await prisma.studentTransport.upsert({
    where: {
      school_id_student_id_trip_type_academic_year_id: {
        school_id: school.id,
        student_id: aarav.id,
        trip_type: BusTripType.MORNING_PICKUP,
        academic_year_id: academicYear.id,
      },
    },
    update: {},
    create: {
      school_id: school.id,
      student_id: aarav.id,
      route_id: SEED_IDS.ROUTE_BUDHARAJA,
      stop_id: SEED_IDS.STOP_SAKHIPADA,
      vehicle_id: SEED_IDS.BUS_PILOT_01,
      trip_type: BusTripType.MORNING_PICKUP,
      academic_year_id: academicYear.id,
    },
  });

  // 9.2 Sibling 2: Ananya Patel (Grade 2A)
  const ananya = await prisma.student.upsert({
    where: { id: SEED_IDS.STUDENT_ANANYA },
    update: {},
    create: {
      id: SEED_IDS.STUDENT_ANANYA,
      school_id: school.id,
      admission_number: 'BOMIS-2024-0118',
      roll_number: '2',
      first_name: 'Ananya',
      last_name: 'Patel',
      date_of_birth: new Date('2018-11-20T00:00:00.000Z'),
      gender: Gender.FEMALE,
      class_id: classes[2].id,
      section_id: sections[2].id,
      academic_year_id: academicYear.id,
      emergency_contact: '+919876543210',
      blood_group_encrypted: encryptField('O+'),
      medical_notes_encrypted: encryptField('Mild asthma in winter'),
      address: 'Plot 142, Budharaja Hills Road, Sambalpur 768004',
      is_active: true,
    },
  });

  // Link Ananya to Dr. Rajesh Patel (Multi-Child Sibling Junction)
  await prisma.studentGuardian.upsert({
    where: {
      school_id_student_id_guardian_id: {
        school_id: school.id,
        student_id: ananya.id,
        guardian_id: patelGuardian.id,
      },
    },
    update: {},
    create: {
      school_id: school.id,
      student_id: ananya.id,
      guardian_id: patelGuardian.id,
      relation_type: 'Father',
      is_primary_contact: true,
      can_pickup: true,
    },
  });

  console.log('✓ Multi-Child Sibling Linkage seeded: Dr. Rajesh Patel (Children in Grade 5A & 2A)');

  // 10. Seed Fee Categories, Structures & Installments
  const feeCategory = await prisma.feeCategory.upsert({
    where: { school_id_code: { school_id: school.id, code: 'TUITION_FEE' } },
    update: {},
    create: {
      school_id: school.id,
      name: 'Tuition Fee (Quarterly)',
      code: 'TUITION_FEE',
      description: 'Core instructional fee',
    },
  });

  const feeStructure = await prisma.feeStructure.upsert({
    where: {
      school_id_academic_year_id_class_id_fee_category_id: {
        school_id: school.id,
        academic_year_id: academicYear.id,
        class_id: classes[5].id,
        fee_category_id: feeCategory.id,
      },
    },
    update: {},
    create: {
      school_id: school.id,
      academic_year_id: academicYear.id,
      class_id: classes[5].id,
      fee_category_id: feeCategory.id,
      amount: 66000.0,
      frequency: FeeFrequency.TERM,
    },
  });

  // Aarav's Installments (Quarterly 16,500 = 1,650,000 paise)
  await prisma.feeInstallment.upsert({
    where: { id: 'f1000000-0001-4000-8000-000000000001' },
    update: {},
    create: {
      id: 'f1000000-0001-4000-8000-000000000001',
      school_id: school.id,
      student_id: aarav.id,
      fee_structure_id: feeStructure.id,
      academic_year_id: academicYear.id,
      installment_number: 1,
      title: 'Quarter 1 Tuition Fee (Apr - Jun)',
      due_date: new Date('2026-04-10T00:00:00.000Z'),
      base_amount: 16500.0,
      net_amount: 16500.0,
      paid_amount: 16500.0,
      status: PaymentStatus.SUCCESS,
    },
  });

  await prisma.feeInstallment.upsert({
    where: { id: 'f1000000-0002-4000-8000-000000000002' },
    update: {},
    create: {
      id: 'f1000000-0002-4000-8000-000000000002',
      school_id: school.id,
      student_id: aarav.id,
      fee_structure_id: feeStructure.id,
      academic_year_id: academicYear.id,
      installment_number: 2,
      title: 'Quarter 2 Tuition Fee (Jul - Sep)',
      due_date: new Date('2026-07-10T00:00:00.000Z'),
      base_amount: 16500.0,
      net_amount: 16500.0,
      paid_amount: 0.0,
      status: PaymentStatus.PENDING,
    },
  });
  console.log('✓ Fee Structures & Quarter 1/2 Installments seeded for Grade 5A');

  // 11. Seed DPDP Consent Ledger with SHA-256 HMAC Proofs (Idempotent)
  const consents = [
    ConsentType.DATA_PROCESSING,
    ConsentType.TRANSPORT_TRACKING,
    ConsentType.HEALTH_RECORDS,
  ];

  for (const ct of consents) {
    const existing = await prisma.consent.findFirst({
      where: {
        school_id: school.id,
        user_id: patelUser.id,
        consent_type: ct,
      },
    });
    if (!existing) {
      const proof = computeConsentProof(patelUser.id, school.id, ct, 'v1.0');
      await prisma.consent.create({
        data: {
          school_id: school.id,
          user_id: patelUser.id,
          consent_type: ct,
          version: 'v1.0',
          status: ConsentStatus.GRANTED,
          proof_hash: proof,
          ip_address: '103.24.112.45',
          user_agent: 'BOMIS Mobile App Android 14',
        },
      });
    }
  }
  console.log('✓ DPDP Granular Consent Records seeded with SHA-256 HMAC proofs');

  // 12. Seed System Baseline Audit Log (Idempotent)
  const existingAudit = await prisma.auditLog.findFirst({
    where: {
      school_id: school.id,
      entity_type: 'School',
      entity_id: school.id,
    },
  });
  if (!existingAudit) {
    await prisma.auditLog.create({
      data: {
        school_id: school.id,
        action: AuditAction.CREATE,
        entity_type: 'School',
        entity_id: school.id,
        after_state: { name: school.name, code: school.code },
        ip_address: '127.0.0.1',
        user_agent: 'BOMIS Seed Automation Runner',
      },
    });
  }
  console.log('✓ Immutable Audit Log baseline recorded');

  console.log('================================================================');
  console.log('✨ Seed database execution completed successfully (AC-6 PASS)');
  console.log('================================================================');
}

main()
  .catch((e) => {
    console.error('❌ Error executing database seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
