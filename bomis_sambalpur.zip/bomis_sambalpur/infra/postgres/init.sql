-- ==============================================================================
-- BOMIS Sambalpur Database Initialization Script
-- Executed on first container start in PostgreSQL 16
-- ==============================================================================

-- Enable UUID and Cryptographic extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Set timezone to Asia/Kolkata (Indian Standard Time)
ALTER DATABASE bomis_db SET timezone TO 'Asia/Kolkata';

-- Grant required permissions to application user
GRANT ALL PRIVILEGES ON DATABASE bomis_db TO bomis_admin;
