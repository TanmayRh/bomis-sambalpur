-- ==============================================================================
-- BOMIS Sambalpur Database Row-Level Security (RLS) & Immutability Rules
-- Applies to all 35 tenant-scoped tables
-- Conforms to ADR-0002 and DPDP Act 2023
-- ==============================================================================

DO $$
DECLARE
  tbl text;
  tenant_tables text[] := ARRAY[
    'users',
    'refresh_tokens',
    'students',
    'guardians',
    'student_guardians',
    'staff',
    'academic_years',
    'classes',
    'sections',
    'subjects',
    'teacher_assignments',
    'attendances',
    'staff_attendances',
    'fee_categories',
    'fee_structures',
    'fee_concessions',
    'fee_installments',
    'payments',
    'homeworks',
    'homework_submissions',
    'timetables',
    'teacher_absence_substitutions',
    'exams',
    'exam_subjects',
    'marks_entries',
    'transport_routes',
    'transport_stops',
    'vehicles',
    'student_transports',
    'transport_telemetries',
    'boarding_events',
    'notice_circulars',
    'visitor_passes',
    'consents',
    'audit_logs'
  ];
BEGIN
  FOREACH tbl IN ARRAY tenant_tables LOOP
    -- Only alter if the table exists in public schema
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = tbl) THEN
      -- Enable Row-Level Security
      EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY;', tbl);
      EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY;', tbl);

      -- Drop existing policy if present
      EXECUTE format('DROP POLICY IF EXISTS tenant_isolation_policy ON %I;', tbl);

      -- Create Tenant Isolation Policy
      -- Enforces that school_id matches session-local 'app.current_school_id'
      -- Allows superadmin or migration bypass when 'app.bypass_rls' is 'on'
      EXECUTE format('
        CREATE POLICY tenant_isolation_policy ON %I
        FOR ALL
        USING (
          current_setting(''app.bypass_rls'', true) = ''on''
          OR
          school_id = NULLIF(current_setting(''app.current_school_id'', true), '''')::uuid
        )
        WITH CHECK (
          current_setting(''app.bypass_rls'', true) = ''on''
          OR
          school_id = NULLIF(current_setting(''app.current_school_id'', true), '''')::uuid
        );
      ', tbl);
    END IF;
  END LOOP;
END $$;

-- ==============================================================================
-- Immutable Audit Log Engine Rules (Append-Only Enforcement)
-- Blocks UPDATE and DELETE operations at the PostgreSQL kernel level
-- ==============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'audit_logs') THEN
    DROP RULE IF EXISTS audit_logs_no_update ON "audit_logs";
    CREATE RULE audit_logs_no_update AS
      ON UPDATE TO "audit_logs"
      DO INSTEAD NOTHING;

    DROP RULE IF EXISTS audit_logs_no_delete ON "audit_logs";
    CREATE RULE audit_logs_no_delete AS
      ON DELETE TO "audit_logs"
      DO INSTEAD NOTHING;
  END IF;
END $$;
