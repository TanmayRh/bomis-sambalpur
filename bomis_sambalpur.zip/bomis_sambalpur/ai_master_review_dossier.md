# 🏛️ BOMIS Sambalpur Unified School Platform
## Master AI Architecture Dossier & Multi-Disciplinary Review Pack

> **File Purpose:** A comprehensive, single-file prompt and technical dossier designed to be copied and pasted directly into frontier LLMs (**Claude 3.5 Sonnet**, **GPT-4o / o1**, **Gemini 1.5/2.0 Pro**, **DeepSeek-R1**) to conduct a deep-dive audit, pressure-test architectural assumptions, and extract high-value roadmap suggestions.  
> **School:** Birla Open Minds International School (BOMIS), Sambalpur, Odisha, India.  
> **Pilot Scope:** Grades 1–8, 4 school buses (OD-15 fleet), 8 roles, CBSE CCE / NEP 2020, DPDP Act 2023.

---

## 📋 PART 1: COPY-PASTE MASTER PROMPT FOR YOUR EXTERNAL AI

*(Copy the fenced block below and paste it as your first message to ChatGPT, Claude, or Gemini)*

```markdown
You are an elite, multidisciplinary School Technology Advisory Board convened to conduct an exhaustive product & technical review of the BOMIS Sambalpur Unified Operating Platform (Birla Open Minds International School, Sambalpur, Odisha, India).

The platform has just been upgraded to a single-link native PWA operating at http://localhost:3000 with a NestJS 10 backend at http://localhost:4000. Read the complete technical architecture and feature catalog provided below.

### YOUR 4 EVALUATION PERSONAS:
1. 👩‍👧‍👦 Persona 1: The Anxious Indian Parent (PTA Lead, Sambalpur) — Mother of Aarav (Grade 5A) & Ananya (Grade 2A). Evaluates morning stress relief, bus panic reduction, language accessibility (Odia/Hindi/English), grandparent delegation, and daily emotional connection.
2. 🎓 Persona 2: The Veteran CBSE Principal (20+ yrs in Indian K-12) — Evaluates NEP 2020 Holistic Progress Card (HPC) compliance, teacher workload burnout protections, zero-data-entry workflows, substitution management, and board examination preparedness.
3. 🛡️ Persona 3: DPDP Act (2023) Legal & Security Auditor — Evaluates compliance with Section 9 (Processing of Minor Data), verifiable parental consent, biometric/Aadhaar tokenization, photo facial consent shields, and audit immutability.
4. 💻 Persona 4: Principal Cloud & Distributed Systems Architect — Evaluates Next.js 14 / NestJS 10 monorepo performance, 7:45 AM attendance & GPS telemetry spikes, dead-reckoning offline fallbacks, service workers, and Redis caching.

### YOUR INSTRUCTIONS:
Execute your evaluation across 4 structured phases:

1. PHASE 1: SCORECARD MATRIX & DOMAIN CRITIQUES
   - Grade each of the 4 domains out of 10.0.
   - For each persona, deliver "What I Love" (top 2 highlights) and "Where It Hurts" (top 2 critical frictions or unhandled edge cases).

2. PHASE 2: ADVERSARIAL ROUNDTABLE DEBATE
   - Simulate a realistic, spirited dialogue between the 4 personas where they debate tradeoffs (e.g., Parent's desire for real-time visibility vs Teacher's workload; Security auditor's strict identity checks vs Grandparent ease-of-use at the gate).

3. PHASE 3: 5 NOVEL 10x SUGGESTIONS & ROADMAP EXPANSION
   - Propose 5 brand-new, innovative features or architectural upgrades that would make this platform 10x more delightful, safe, or operationally efficient for Indian K-12 schools. Each suggestion must include:
     * Feature Name & Target User
     * Problem Solved & Pedagogical / Emotional Value
     * Technical Implementation Blueprint (API endpoints, UI/UX interaction, data schema)

4. PHASE 4: THE 3 "KILLER EDGE CASES" TO HARDEN IMMEDIATELY
   - Identify 3 high-risk real-world scenarios in Sambalpur (e.g. flash floods near Mahanadi, teacher mass absence, contested child custody pickup) and specify how the system should handle them gracefully.
```

---

## 🏗️ PART 2: COMPREHENSIVE ARCHITECTURE & FEATURE DOSSIER

### 1. Monorepo & Technology Stack
* **Web Client (`apps/web`)**: Next.js 14 (App Router), React 18, TypeScript, Tailwind CSS, Lucide Icons, Framer Motion, TanStack Query.
* **Backend API (`apps/api`)**: NestJS 10 modular monolith, TypeScript, Pino structured logger with correlation IDs, Zod validation pipes, Prisma ORM with in-memory deterministic mock store (`USE_MOCK_DB=true`).
* **PWA & Offline Shell**: `public/manifest.json`, vector crest `/icon.svg`, and network-first Service Worker `/sw.js` with offline cache fallback.
* **Security & DPDP Compliance**: Field-level AES-256-GCM encryption for child identifiers, parental consent ledger, tokenized phone masking, RBAC with 8 roles.

---

### 2. Live Feature Catalog

#### 📱 A. Single-Link Native App Architecture (`http://localhost:3000`)
* **Zero Fragmented Sites**: Eliminates separate portal bookmarks. Parents, teachers, and staff enter through a single link.
* **First-Time Admission Link Gate**:
  - Requires Student Admission Number (e.g., `BOMIS-2021-0042`), Student Full Name, Parent Mobile, and PIN.
  - 1-Click Demo quick-fills: Aarav Patel (Grade 5A), Ananya Patel (Grade 2A), and Staff Portal.
  - Animated SIS database lookup sequence validating cohort and roll number.
* **Persistent Mobile Session**: Stored in `localStorage` (`bomis_parent_app_session`) providing native app persistence across app launches.
* **Switch Admission**: In-app button to toggle between siblings or switch student profiles instantly.
* **PWA Install Guide**: Modal providing step-by-step installation instructions for Android (Chrome `⋮`), iOS (Safari `[↑]`), and Desktop.

#### 🌅 B. Morning Assembly: Thought & Word of the Day (Daily Calendar Rotation)
* **Automatic Day Sync**: Syncs dynamically based on calendar day (Sunday–Saturday).
* **Thought of the Day**:
  - Inspirational reflections from Dr. A.P.J. Abdul Kalam, Swami Vivekananda, Albert Einstein, Rabindranath Tagore, Mahatma Gandhi, Nelson Mandela, and Melody Beattie.
  - Actionable life lessons tailored for elementary and middle school students.
* **Word of the Day**:
  - High-frequency CBSE vocabulary words: *Resilience*, *Empathy*, *Curiosity*, *Perseverance*, *Integrity*, *Collaboration*, *Gratitude*.
  - Phonetic transcriptions (`/rɪˈzɪl.jəns/`) and parts of speech.
  - **🇮🇳 Hindi & 🌸 Odia Translations**: Regional bridges (*लचीलापन / ସହନଶୀଳତା*).
  - **🔊 Audio Pronunciation**: Built-in speech synthesis button (`speakWord`) to hear correct diction.
  - **⭐ Interactive Practice Challenge**: Interactive button awarding **+5 House Points** for conversational usage.
  - **🥣 Breakfast Conversation Prompt**: Question for parents to ask at breakfast before boarding the school bus.

#### 🎙️ C. Teacher Voice-to-Rubric Assistant (Voice HPC — Zero Data Entry)
* **Teacher Frictional Dilemma**: Solves teacher burnout by eliminating repetitive typing of narrative remarks after teaching 6 periods.
* **Multilingual Spoken Dictation**: Class teachers hold the mic button and speak in **English**, **Hindi (हिन्दी)**, or **Odia (ଓଡ଼ିଆ)** with live audio waveform simulation.
* **CBSE NEP 2020 Holistic Progress Card (HPC) 360° Rubrics**:
  - Automatically parses natural language into 4 official CBSE rubric dimensions:
    1. *Collaboration*: Level 4 Exemplary (Peer Mentorship).
    2. *Scientific Temper*: Level 4 Exemplary (Hydraulic modeling / hypothesis).
    3. *Communication*: Level 3 Proficient (Articulated thoughts clearly).
    4. *Empathy & Values*: Level 4 Exemplary (Supported peer learning voluntarily).
  - Maps to Cognitive, Affective (Socio-Emotional), and Psychomotor execution domains.
* **Automated Parent Evening Digest Integration (3:30 PM)**:
  - Generates the daily story headline and digest bullets.
  - Formulates the **"Ask Aarav at Dinner"** conversation starter (*"Ask Aarav how his team designed the spillway gates for the Hirakud diorama model today!"*).
  - Automatically awards +5 House Points to the student's house (Tagore House).
* **Human-in-the-Loop Sign-off**: Editable text preview with mandatory teacher verification before official commit.
* **Dedicated Backend API**: `POST /api/v1/ai/voice-hpc/parse` secured with JWT Bearer token.

#### 🍱 D. Smart Canteen "Allergy Interlock" & Fast-Lane Recess Token
* **Allergy Guardrail**: Displays child's verified allergy flag (*Mild Peanut Allergy - Infirmary Alerted*).
* **Interactive POS Tap Simulator**:
  - Tapping **"🥜 Peanut Chikki (₹20)"** ➡️ Flashes **HARD ALLERGY INTERLOCK BLOCKED** dialog, refusing the transaction and sending an alert to the school nurse.
  - Tapping **"🍌 Banana Chips (₹15)"** ➡️ Approves instantly as safe & nut-free.
* **⚡ Fast-Lane Recess Token**: Generates **"🎟️ Token: FAST-LANE #042"** (Lunch packed & ready at Window 1, skipping the 20-minute recess queue).

#### 📲 E. 1-Tap WhatsApp Grandparent (Dada Ji) Pickup Pass & Gate Photo Match
* **Expiring One-Time Pass**: Parents tap **"Delegate to Dada Ji"** to generate a dynamic 15-minute expiring link.
* **No-App Experience for Elders**: Dispatched via WhatsApp Business API link (`https://bomis.edu.in/gate/pass?token=831294`). Grandparents open the QR pass on any standard smartphone without app installation or login credentials.
* **Security Gate Tablet Photo Match View**:
  - Guard's tablet shows side-by-side verified photos of the student and the registered guardian (Dada Ji / Rajesh Sharma).
  - Guard taps **"Verify & Release Child"**, which instantly triggers an SMS/WhatsApp notification to the mother: *"Aarav was safely picked up by Rajesh Sharma (Dada Ji) at Gate 1."*

#### 🛡️ F. DPDP Act (2023) Section 9 Group Photo Consent & AI Face-Shield
* **Verifiable Parental Consent**: Tracks parental social media photo consent (28/28 on file).
* **AI Face-Shield Simulator**:
  - Clicking **"Test Opt-Out Filter"** simulates a parent revoking consent.
  - Instantly renders a protective face-blur filter over the child's image in class stories, ensuring zero legal exposure for the school under Section 9 of the DPDP Act 2023.

#### 🛰️ G. Sambalpur Monsoon Signal Drop & Dead-Reckoning Bus Radar
* **Local Geography**: Monitors 4 routes across Sambalpur, Burla, Hirakud, and Khetrajpur.
* **Dead-Reckoning Fallback**:
  - When cellular data drops along low-signal monsoon corridors, the radar switches to **Dead-Reckoning Mode**.
  - Smoothly interpolates the bus marker along the pre-mapped polyline route at 24 km/h with an amber indicator, keeping parents informed and eliminating panicked calls to the school front desk.

---

### 3. Role-Based Access Control (RBAC) & Credentials

| Role | Email / ID | Password | Access Highlights |
| :--- | :--- | :--- | :--- |
| **Parent** | Adm: `BOMIS-2021-0042` / `+919876543210` | PIN: `1234` | Full Parent App, Daily Inspiration, Bus Radar, Canteen, Fees, Gate Pass |
| **Teacher** | `arundhati.dash@bomis-sambalpur.edu.in` | `Admin@Sambalpur2026` | Rapid Class Attendance (<10s), Voice HPC Assistant, CBSE Marks Entry |
| **Principal** | `principal@bomis-sambalpur.edu.in` | `Admin@Sambalpur2026` | School Pulse Dashboard, Bus Fleet Status, Fee Collection Reconciliation |
| **Campus Admin** | `admin@bomis-sambalpur.edu.in` | `Admin@Sambalpur2026` | User Management, DPDP Right-to-Erasure Workflow, Immutable Audit Logs |
| **Accountant** | `accountant@bomis-sambalpur.edu.in` | `Admin@Sambalpur2026` | Razorpay Reconciliation, Concession Approvals, GST Tax Receipts |
