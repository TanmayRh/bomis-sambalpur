# Mobile Architecture & Multi-Role UI Screen Blueprint
**Milestone 5 (M5) — React Native Expo Mobile App**
**Target Package**: `apps/mobile/` (`@bomis/mobile`)
**Explorer Agent**: `explorer_m5_1`

---

## 1. Observation

Direct examination of the monorepo codebase yielded the following verified baseline facts:

### 1.1 Existing Mobile Workspace Files
- **`apps/mobile/package.json`**:
  - Name: `"@bomis/mobile"`, Version: `"0.1.0"`, Description: `"React Native (Expo SDK 51) Multi-Role Mobile App for BOMIS Sambalpur"`.
  - Dependencies: `"@bomis/shared": "workspace:*"`, `"@bomis/ui": "workspace:*"`, `"expo": "~51.0.0"`, `"expo-status-bar": "~1.12.1"`, `"react": "18.2.0"`, `"react-native": "0.74.1"`, `"zod": "^3.23.8"`.
  - DevDependencies: `"@babel/core": "^7.20.0"`, `"@types/react": "~18.2.45"`, `"babel-preset-expo": "~11.0.0"`, `"rimraf": "^5.0.7"`, `"typescript": "^5.4.5"`.
  - Scripts: `start`, `dev`, `android`, `ios`, `web`, `build`, `lint`, `test`, `typecheck`, `clean`.
- **`apps/mobile/app.json`**:
  - Expo configuration specifying name `"BOMIS Sambalpur"`, slug `"bomis-sambalpur-app"`, bundleIdentifier & Android package `"in.edu.bomissambalpur.app"`, splash & adaptive icon backgroundColor `"#0F2942"`.
- **`apps/mobile/tsconfig.json`**:
  - Extends `"../../tsconfig.base.json"`, compilerOptions: `jsx: "react-native"`, `module: "esnext"`, `moduleResolution: "bundler"`, `composite: true`.
- **`apps/mobile/App.tsx`**:
  - Minimal placeholder currently rendering a static welcome card with colors `#0F2942` and `#FF6B4A`. Requires replacement with the full multi-role navigation and screen suite.

### 1.2 Brand Design Tokens (`packages/ui/src/tokens/index.ts` & `components/index.ts`)
- **Primary Navy Palette**:
  - `#0F2942` (BOMIS Official Brand Navy — `primary[800]` / `primary.DEFAULT`).
  - Scales: `50: #F4F8FA`, `100: #EBF2F8`, `200: #D2E3F0`, `300: #A4C6E1`, `500: #3D7FB5`, `800: #0F2942`, `900: #071726`.
- **Accent Coral Palette**:
  - `#FF6B4A` (BOMIS Official Accent Coral — `accent[500]` / `accent.DEFAULT`).
  - Scales: `50: #FFF5F2`, `100: #FFEAE5`, `200: #FFD4CB`, `500: #FF6B4A`, `600: #E05232`.
- **Semantic Status Palette**:
  - `status.success`: `#10B981` (Present, Paid, On-time)
  - `status.warning`: `#F59E0B` (Late, Partial, Pending, Geofence Approaching)
  - `status.danger`: `#EF4444` (Absent, Overdue, Expired OTP, SOS)
  - `status.info`: `#3B82F6` (Notices, Half Day, Timetable)
- **Neutrals**:
  - `50: #F8FAFC` (App background), `100: #F1F5F9`, `200: #E2E8F0` (Borders/Dividers), `500: #64748B` (Secondary text), `800: #1E293B`, `900: #0F172A` (Headings).
- **Role Badges Token Map (`roleBadgeColors`)**:
  - `TEACHER`: `{ bg: '#EBF2F8', text: '#0F2942', border: '#A4C6E1' }`
  - `STUDENT`: `{ bg: '#F4F8FA', text: '#254E7A', border: '#D2E3F0' }`
  - `PARENT`: `{ bg: '#FFF5F2', text: '#94311B', border: '#FFD4CB' }`
  - `TRANSPORT_STAFF`: `{ bg: '#FEF3C7', text: '#92400E', border: '#FDE68A' }`

### 1.3 Seed Personas & Domain Fixtures (`prisma/seed.ts` & `seed-fixtures.ts`)
1. **Parent Persona**:
   - `Dr. Rajesh Kumar Patel` (User ID: `u1000000-0101-4000-8000-000000000001`, Guardian ID: `g1000000-0001-4000-8000-000000000001`).
   - Phone: `+919876543210`, Email: `rajesh.patel@example.com`.
   - Linked Children:
     - **Child 1 (Aarav Patel)**: Student ID `b1000000-0005-4000-8000-000000000001`, Grade 5A, Roll #1, Admission `BOMIS-2021-0042`, Emergency Contact `+919876543210`, Assigned Bus `Bus 01` (Tata Winger), Stop `Sakhipada Chhak`.
     - **Child 2 (Ananya Patel)**: Student ID `b1000000-0002-4000-8000-000000000001`, Grade 2A, Roll #4, Admission `BOMIS-2024-0118`.
2. **Student Persona**:
   - `Aarav Patel` (User ID: `u1000000-0501-4000-8000-000000000001`, Student ID: `b1000000-0005-4000-8000-000000000001`).
   - Phone: `+919876543211`, Email: `aarav.patel@student.bomis-sambalpur.edu.in`.
   - Blood Group: `O+`, House: `KALINGA`, Medical Notes: `Allergic to peanuts and dust`.
3. **Teacher Persona**:
   - `Mrs. Arundhati Dash` (User ID: `u1000000-0010-4000-8000-000000000001`, Staff ID: `m1000000-0010-4000-8000-000000000001`, Employee Code: `STF-BOMIS-010`).
   - Phone: `+919437100005`, Email: `arundhati.dash@bomis-sambalpur.edu.in`.
   - Role: Class Teacher Grade 5A & TGT Mathematics.
4. **Driver Persona**:
   - `Maheswar Bhoi` (User ID: `u1000000-0020-4000-8000-000000000001`, Staff ID: `m1000000-0020-4000-8000-000000000001`, Employee Code: `DRV-BOMIS-001`).
   - Phone: `+919437200001`, Email: `driver.bhoi@bomis-sambalpur.edu.in`.
   - Role: Senior Fleet Pilot, Assigned Bus: `Bus 01` (`OD-15-AB-1001`, Capacity 24), Route: `Route 1 - Budharaja Shuttle` (`RT-BUDHARAJA-01`).

### 1.4 Authoritative Backend API Contracts (`apps/api/src/modules/`)
- **Standard Envelope**:
  `{ success: boolean, data: T, error?: { code: string, message: string }, timestamp: string, correlationId: string }`.
- **Auth Endpoints**:
  - `POST /api/v1/auth/otp/send`: `{ phone: string, schoolId?: string }` -> `{ expiresInSeconds: 300, message: "OTP sent successfully" }`. Dev mock OTP: `123456`.
  - `POST /api/v1/auth/otp/verify`: `{ phone: string, code: string }` -> `{ accessToken, refreshToken, user: { id, phone, email, role, firstName, lastName } }`.
  - `POST /api/v1/auth/staff/login`: `{ email: string, password: string }` -> JWT token pair.
- **Attendance & Offline Sync Endpoints**:
  - `POST /api/v1/attendance`: Rapid attendance batch (`{ date, classId, sectionId, defaultStatus: "PRESENT", exceptions: [{ studentId, status }] }`).
  - `POST /api/v1/sync/batch`: Deduplicated offline outbox event dispatch (`{ events: [{ id, actionType: "ATTENDANCE_BATCH" | "BOARDING_SCAN", idempotencyKey, timestamp, payload }] }`).
  - `GET /api/v1/attendance/students/:id`: Returns monthly stats (`{ totalWorkingDays: 22, presentDays: 20, halfDays: 1, absentDays: 1, attendancePercentage: 90.9 }`).
- **Fees & Financial Safety Endpoints**:
  - `POST /api/v1/fees/orders`: Creates Razorpay order. **Enforces mandatory `Idempotency-Key` header**.
  - `GET /api/v1/fees/receipts/:id`: Returns PDF tax receipt metadata and download URL.
- **Safety & Child Dismissal Endpoints**:
  - `mock-store.service.ts`: Active pickup authorization seeded for Aarav Patel: OTP `482910`, 30-minute validity (`Date.now() + 30 * 60 * 1000`).
  - `POST /api/v1/safety/pickup/verify`: Verifies 6-digit OTP at gate.
- **Transport Fleet Endpoints**:
  - `GET /api/v1/transport/routes` & `GET /api/v1/transport/buses`: Route 1 Budharaja Shuttle stops (`Budharaja Fatak` -> `Sakhipada Chhak` -> `Ainthapali Chowk` -> `BOMIS Campus Gate`).
  - `POST /api/v1/transport/gps-ping`: Ingests real-time vehicle GPS telemetry (`{ busId, latitude, longitude, speed, heading }`) and emits geofence proximity alerts.
  - `POST /api/v1/transport/boarding/scan`: Ingests student boarding/deboarding QR scan (`{ busId, studentId, stopId, action: "BOARD" | "DEBOARD", lat, lng }`).

---

## 2. Logic Chain

1. **Monorepo Ecosystem Alignment**:
   `apps/mobile/` is an Expo SDK 51 application living inside the Turborepo monorepo. It imports types directly from `@bomis/shared` and brand tokens from `@bomis/ui`. To ensure seamless cross-platform execution (iOS, Android, and Expo Web preview), all UI primitives must be built on pure React Native components (`View`, `Text`, `TouchableOpacity`, `ScrollView`, `TextInput`, `Modal`, `StyleSheet`) styled with `@bomis/ui` tokens without conflicting DOM-only dependencies.

2. **Multi-Role Single-App Architecture**:
   Schools require parents, students, teachers, and transport crew to use a unified mobile app without downloading 4 separate store binaries. The mobile architecture must therefore implement dynamic role-swapping:
   - Root navigation renders `AuthScreen` when unauthenticated.
   - When authenticated, the active role (`PARENT`, `STUDENT`, `TEACHER`, `TRANSPORT_STAFF`) directs the user to their designated role dashboard tab.
   - For evaluation, demo, and automated QA convenience, the `AuthScreen` must provide a high-contrast **"1-Click Evaluation Quick Login"** bar with 4 presets that automatically populate credentials, fetch JWTs, and launch the target role experience.

3. **Parent Experience Isolation & State Integrity**:
   Dr. Rajesh Patel has two children (Aarav in Grade 5A, Ananya in Grade 2A). Sibling state must never bleed across tabs. The `SiblingSwitcher` component sits in the parent header or subheader:
   - Swapping from Aarav to Ananya immediately updates the active `childId` in the parent state context.
   - Child-specific data (attendance calendar, bus tracking route & stop, fee installments, dismissal OTP token) dynamically re-keys and re-renders for the selected child.

4. **Bus Tracking Geofence & Dismissal Token Architecture**:
   - Aarav is assigned to Pilot Bus 01 with pickup/drop at `Sakhipada Chhak`. The mobile live bus tracker must display a prominent 5-minute geofence alert banner when Bus 01's telemetry is within proximity, along with live speed (28 km/h), driver name (Maheswar Bhoi), and a 1-tap "Call Pilot" trigger.
   - Afternoon dismissal requires physical security verification at Campus Gate 1/2. The mobile app must feature a single-use 6-digit OTP card (`482910`), a dynamic QR pickup pass, and a live ticking 30-minute countdown timer (`mm:ss`). When T=0 is reached, the OTP automatically blurs and transitions to `EXPIRED`, requiring a 1-tap "Regenerate OTP" call.

5. **Teacher Rapid Attendance (<10s SLA) & Offline Queue**:
   Classroom teachers cannot tolerate slow, multi-tap forms. The `RapidAttendanceGrid`:
   - Defaults the entire class (40 students) to `PRESENT` with a single tap.
   - Allows marking exceptions with a single tap per student cycling `PRESENT` -> `ABSENT` -> `LATE` -> `HALF_DAY`.
   - Sends only exception deltas to achieve sub-second execution (<10s SLA).
   - If network connectivity is lost, an offline outbox interceptor queues the batch event with a client UUID idempotency key into local storage, displaying an "Offline Mode — 1 Batch Queued" badge, and automatically flushes via `POST /api/v1/sync/batch` upon reconnection.

6. **Driver Fleet Pilot Tools**:
   The transport driver mini-app provides three mission-critical workflows:
   - Route Navigation: View the 4 stops for Budharaja Shuttle with student manifest counts.
   - GPS Broadcaster Toggle: When enabled, simulates periodic GPS dispatches every 5 seconds to `POST /api/v1/transport/gps-ping`.
   - QR Scanner & Manual Fallback: Viewfinder interface simulating student ID card scanning (`BOMIS:STUDENT:...`), with an instant manual entry search bar for students who forgot physical ID cards.

---

## 3. Caveats

1. **Hardware Camera & Native Barcode Scanner**: In Expo SDK 51 development environments (and web previews), native camera hardware access may not be available on desktop or simulator. The architecture implements an interactive camera viewport simulator that permits both simulated 1-tap barcode triggers (for automated testing and manual QA) and standard text fallback entry, while using standard React Native abstractions ready for `expo-camera` or `expo-barcode-scanner` integration in native builds.
2. **Push Notifications**: Instant absence alerts and 5-minute geofence notifications are modeled with active local banners and WebSocket/telemetry state listeners. Real APNs/FCM credentials require production Apple Developer and Firebase project keys.
3. **Razorpay Native SDK vs WebView/Checkout**: Razorpay native Android/iOS bridging requires native build artifacts (`expo prebuild` / custom dev client). The mobile architecture simulates the Razorpay checkout modal with strict `Idempotency-Key` headers, test mode payment methods, and PDF receipt rendering matching the backend API contracts.

---

## 4. Conclusion & Mobile Architecture Blueprint

### 4.1 Target Directory Structure (`apps/mobile/`)

```
apps/mobile/
├── assets/
│   ├── icon.png
│   ├── splash.png
│   ├── adaptive-icon.png
│   └── favicon.png
├── src/
│   ├── components/
│   │   ├── ui/
│   │   │   ├── BOMISButton.tsx         # Primary, Accent, Outline, Ghost buttons
│   │   │   ├── BOMISCard.tsx           # Elevated card with border radius & shadow
│   │   │   ├── BOMISBadge.tsx          # Status, Role, and Category pill badges
│   │   │   ├── BOMISInput.tsx          # Styled input with icons & error states
│   │   │   ├── BOMISTabs.tsx           # Segmented role & navigation tab bar
│   │   │   └── BOMISHeader.tsx         # Top bar with branding, role badge & avatar
│   │   └── common/
│   │       ├── SiblingSwitcher.tsx     # Aarav (5A) vs Ananya (2A) toggle
│   │       ├── DynamicQrView.tsx       # Dynamic QR code card with verification string
│   │       ├── OfflineBanner.tsx       # Offline outbox sync status banner
│   │       └── GeofenceAlert.tsx       # 5-min proximity banner for Sakhipada Chhak
│   ├── screens/
│   │   ├── auth/
│   │   │   └── AuthScreen.tsx          # Mobile OTP login + 4 Evaluation Quick Presets
│   │   ├── parent/
│   │   │   ├── ParentDashboardScreen.tsx   # Parent home aggregating widgets
│   │   │   ├── AttendanceCalendarView.tsx  # Monthly calendar & statistics
│   │   │   ├── LiveBusTrackerView.tsx      # Live GPS map, 5-min geofence alert
│   │   │   ├── FeeCheckoutModalView.tsx    # Razorpay checkout with Idempotency-Key
│   │   │   └── DismissalOtpCardView.tsx    # 6-digit OTP, 30-min timer & QR pickup pass
│   │   ├── student/
│   │   │   ├── StudentDashboardScreen.tsx  # Student home aggregating widgets
│   │   │   ├── DigitalIdCardView.tsx       # Student digital ID card with dynamic QR
│   │   │   ├── HomeworkDiaryView.tsx       # Homework & Digital Diary assignments
│   │   │   └── TimetableScheduleView.tsx   # Weekly period-by-period class schedule
│   │   ├── teacher/
│   │   │   ├── TeacherDashboardScreen.tsx  # Teacher home aggregating widgets
│   │   │   ├── RapidAttendanceGridView.tsx # <10s SLA grid with offline queue sync
│   │   │   ├── HomeworkPosterView.tsx      # Assignment announcement composer
│   │   │   └── TeacherTimetableSchedule.tsx# Teacher teaching timetable
│   │   └── driver/
│   │       ├── DriverDashboardScreen.tsx   # Driver transport hub
│   │       ├── RouteStopsListView.tsx      # Route 1 Budharaja Shuttle stops list
│   │       ├── GpsBroadcasterToggle.tsx    # Live GPS telemetry periodic broadcaster
│   │       └── BoardingQrScannerView.tsx   # QR scanner + manual fallback entry
│   ├── services/
│   │   ├── api/
│   │   │   ├── apiClient.ts            # Axios/Fetch wrapper with standard envelope
│   │   │   ├── authApi.ts              # OTP dispatch, verify, staff login
│   │   │   ├── attendanceApi.ts        # Rapid batch, stats, offline batch sync
│   │   │   ├── feesApi.ts              # Orders with Idempotency-Key, receipts
│   │   │   ├── safetyApi.ts            # Child pickup verification, anonymous SOS
│   │   │   └── transportApi.ts         # Routes, telemetry GPS ping, boarding scan
│   │   ├── offline/
│   │   │   └── outboxQueue.ts          # Offline storage, idempotency deduplication
│   │   └── location/
│   │       └── gpsSimulator.ts         # Periodic telemetry simulator
│   ├── state/
│   │   └── AppContext.tsx              # Auth, Active Persona, Active Sibling, Outbox
│   ├── types/
│   │   └── mobile.ts                   # Screen types, Presets, DTOs
│   ├── utils/
│   │   └── formatters.ts               # Currency, IST Date/Time, Countdown helpers
│   └── App.tsx                         # Multi-role application root & router
├── app.json
├── package.json
└── tsconfig.json
```

---

### 4.2 Multi-Role Screen Architecture & Specifications

#### 1. Authentication & 1-Click Evaluation Presets (`AuthScreen.tsx`)
- **Phone OTP Authentication**:
  - Input field for 10-digit Indian mobile number (`+91` prefix locked).
  - Validation: rejects invalid lengths or non-Indian carrier prefixes.
  - "Send OTP" button triggering `POST /api/v1/auth/otp/send`.
  - 6-digit OTP code entry field with "Auto-fill Mock OTP (123456)" helper.
  - "Verify & Sign In" button triggering `POST /api/v1/auth/otp/verify`.
- **1-Click Evaluation Quick Login Presets**:
  - Prominent horizontal selector card at the top or bottom of the screen labeled **"⚡ Quick Evaluation Login Presets"**:
    1. **Parent Preset**: Dr. Rajesh Kumar Patel (`+919876543210`) -> Roles: `PARENT`, linked to Aarav (5A) & Ananya (2A).
    2. **Student Preset**: Aarav Patel (`+919876543211`) -> Roles: `STUDENT`, Grade 5A.
    3. **Teacher Preset**: Mrs. Arundhati Dash (`+919437100005`) -> Roles: `TEACHER`, Class Teacher 5A.
    4. **Driver Preset**: Maheswar Bhoi (`+919437200001`) -> Roles: `TRANSPORT_STAFF`, Bus 01 Pilot.
  - Tapping any preset automatically sets state, logs in, and navigates directly to that role's dashboard.
  - Quick Logout / Persona Switcher button accessible in every role's header to allow evaluators to cycle roles instantly.

#### 2. Parent View (`screens/parent/`)
- **Sibling Switcher (`SiblingSwitcher.tsx`)**:
  - Horizontal pill selector with avatars and badges:
    - `[ 👦 Aarav Patel (Grade 5A) ]` vs `[ 👧 Ananya Patel (Grade 2A) ]`.
  - Active selection highlighted in Warm Coral `#FF6B4A` with Navy `#0F2942` text.
  - Selecting a child dynamically updates all parent dashboard tabs without state bleeding.
- **Attendance Calendar & Summary (`AttendanceCalendarView.tsx`)**:
  - High-level metric card: `90.9% Attendance Rate` (October 2026: 20 Present, 1 Half Day, 1 Absent out of 22 working days).
  - Calendar grid rendering day-by-day status dots using `@bomis/ui` tokens:
    - Emerald `#10B981`: Present (Days 1–14, 17–22).
    - Blue `#3B82F6`: Half Day (Day 15 — "Early medical departure").
    - Red `#EF4444`: Absent (Day 16 — "Medical leave reported by parent").
  - "Apply for Leave" modal with date picker and reason input.
- **Live Bus Tracker (`LiveBusTrackerView.tsx`)**:
  - Header: Bus 01 (`OD-15-AB-1001`), Tata Winger, Senior Pilot Maheswar Bhoi (`+919437200001`).
  - Route: Route 1 - Budharaja Shuttle.
  - **5-Minute Geofence Proximity Alert Banner**:
    - High-contrast Amber alert: *"5-Minute Proximity Geofence Alert: Bus 01 is approaching Sakhipada Chhak (Aarav's Stop). Estimated arrival in 4 mins (Speed: 28 km/h)."*
    - Dismissible with audio chime simulation.
  - Timeline of 4 Route Stops:
    1. Budharaja Fatak (07:15 AM) — *Departed*
    2. Sakhipada Chhak (07:25 AM) — *Approaching (Current)*
    3. Ainthapali Chowk (07:35 AM) — *Next*
    4. BOMIS Campus Gate (07:45 AM) — *Destination*
  - Boarding status: *"Aarav safely boarded Bus 01 at 07:28 AM (QR Verified)"*.
  - Action buttons: "Call Pilot" (`Linking.openURL('tel:+919437200001')`), "Share Bus ETA".
- **Razorpay Fee Checkout (`FeeCheckoutModalView.tsx`)**:
  - Fee breakdown for Grade 5: Tuition Fee (₹16,500 Term 2), Science Lab Fee, Activity Fee.
  - Payment method selector: UPI (Google Pay / PhonePe / Paytm), Netbanking, Credit/Debit Card.
  - **Mandatory `Idempotency-Key` Enforcement**:
    - Generates client UUID v4 key: `crypto.randomUUID()`.
    - Passes `Idempotency-Key: <uuid>` header on `POST /api/v1/fees/orders`.
    - In-flight double-click guard disables pay button during submission.
  - Payment Success Card:
    - Green checkmark, Amount Paid: ₹16,500, Receipt No: `REC-2026-04928`, Razorpay Order ID.
    - "Download Official Tax Receipt (PDF)" button triggering PDF download.
- **Dismissal OTP & QR Pickup Pass (`DismissalOtpCardView.tsx`)**:
  - Designed for afternoon campus gate dispersal (Gate 1 / Gate 2).
  - Large monospace 6-digit gate code: `482910` (for Aarav) or dynamic per sibling.
  - **30-Minute Live Countdown Timer**:
    - Ticks every second (`29:59`, `29:58`, ...).
    - Status transitions: `ACTIVE` -> `EXPIRED` (at 00:00, OTP blurs with alert: "Code Expired, regenerate").
  - Dynamic QR Pickup Pass rendering `BOMIS:PICKUP:b1000000-0005-4000-8000-000000000001:482910`.
  - "Regenerate OTP" button (re-rolls a fresh 6-digit code and resets 30-min timer).
  - "Simulate Gatekeeper Scan" button (marks code `USED / PICKED UP`).

#### 3. Student View (`screens/student/`)
- **Digital Student ID Card (`DigitalIdCardView.tsx`)**:
  - School Crest: "Birla Open Minds International School, Sambalpur (CBSE Affiliation #1530284)".
  - Navy `#0F2942` card background with gold/coral accents and holographic border styling.
  - Student photo placeholder, Student Name: `Aarav Patel`, Admission No: `BOMIS-2021-0042`, Roll No: `1`.
  - Academic Year: `2026-2027`, Grade & Section: `Grade 5A`, House: `KALINGA`, Blood Group: `O+`.
  - **Dynamic QR Code**:
    - High-density QR rendering payload: `BOMIS:STUDENT:b1000000-0005-4000-8000-000000000001:BOMIS-2021-0042`.
    - Usable for bus boarding scan, campus gate access, and library book checkout.
  - Emergency contacts: Dr. Rajesh Kumar Patel (`+919876543210`).
  - Medical alert tag: "Allergic to peanuts and dust".
- **Homework & Digital Diary (`HomeworkDiaryView.tsx`)**:
  - Subject filter tabs: `All`, `Mathematics`, `Science`, `English`, `Odia`.
  - Cards showing assignment title, due date, teacher instructions, MinIO attachment download buttons.
  - Submission toggle: "Mark as Completed / Submit Homework" triggering status update to `SUBMITTED`.
- **Class Timetable Schedule (`TimetableScheduleView.tsx`)**:
  - Day selector: `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday`, `Saturday`.
  - 8-period schedule for Grade 5A with current active period highlighted.
  - Displays subject, teacher name (Mrs. Arundhati Dash, Mr. Subrat Pradhan, etc.), and room number (Room 201).

#### 4. Teacher View (`screens/teacher/`)
- **Rapid Attendance Grid (`RapidAttendanceGridView.tsx`)**:
  - Designed for classroom morning roll call with strict **<10s SLA**.
  - Roster of 40 Grade 5A students (Aarav Patel, Isha Mohanty, Rohan Das, Ananya Patel, etc.).
  - 1-Click "Mark All Present" button (instantly marks all 40 students `PRESENT`).
  - Fast-tap exception cycle: Tapping any student row toggles `PRESENT` -> `ABSENT` (Red `#EF4444`) -> `LATE` (Amber `#F59E0B`) -> `HALF_DAY` (Blue `#3B82F6`) -> `PRESENT`.
  - Summary metrics strip: `38 Present, 1 Absent, 1 Late`.
  - Stopwatch SLA timer: displays submission duration (e.g. `2.8s`).
  - **Offline Queue Engine**:
    - Online/Offline toggle simulator.
    - When offline: enqueues `ATTENDANCE_BATCH` into local outbox with UUID idempotency key.
    - When network is restored: automatically dispatches queue to `POST /api/v1/sync/batch` and displays "Batch Synced Successfully" toast.
- **Homework Announcement Poster (`HomeworkPosterView.tsx`)**:
  - Quick post composer: Select Subject (Mathematics, Science, etc.), Due Date, Title, Assignment details.
  - "Post Assignment & Notify Parents" button broadcasting notification.
  - History list of posted assignments with parent read-receipt counters ("38/40 Parents Acknowledged").
- **Teacher Timetable (`TeacherTimetableSchedule.tsx`)**:
  - Weekly period schedule for Mrs. Arundhati Dash showing Grade 5A Math, Grade 6B Math, Lab sessions, and free planning periods.

#### 5. Driver View (`screens/driver/`)
- **Active Route Stops List (`RouteStopsListView.tsx`)**:
  - Route 1: Budharaja Shuttle (`RT-BUDHARAJA-01`), Bus 01 (`OD-15-AB-1001`), Tata Winger.
  - Chronological stops with scheduled times and boarding counts:
    - Stop 1: Budharaja Fatak (07:15 AM) — 6 boarded.
    - Stop 2: Sakhipada Chhak (07:25 AM) — 8 boarded (includes Aarav Patel).
    - Stop 3: Ainthapali Chowk (07:35 AM) — 4 boarded.
    - Stop 4: BOMIS Campus Gate (07:45 AM) — Destination.
  - Total passengers onboard: `18 / 24 Capacity`.
- **Live GPS Broadcaster Toggle (`GpsBroadcasterToggle.tsx`)**:
  - Prominent master toggle switch: `[ BROADCASTING LIVE GPS ]`.
  - Periodic ping engine (every 5 seconds) dispatching to `POST /api/v1/transport/gps-ping`:
    - Latitude: `21.46690`, Longitude: `83.98120`, Speed: `28 km/h`, Heading: `45°`.
  - Live status indicator: "Last ping: 1s ago (200 OK — Proximity alert triggered for Sakhipada Chhak)".
  - Offline buffering: caches breadcrumbs in outbox if mobile network cuts out in transit.
- **Student Boarding/Deboarding QR Scanner (`BoardingQrScannerView.tsx`)**:
  - Viewfinder viewport with scanning animation.
  - Mode selector: `[ Morning Boarding ]` vs `[ Afternoon Deboarding ]`.
  - 1-Tap Simulated Scan: "Scan Aarav Patel's ID Card".
  - Instant scan verification: displays student photo, name, class Grade 5A, designated stop Sakhipada Chhak, and logs to `POST /api/v1/transport/boarding/scan`.
  - **Manual Fallback Entry**:
    - Search input for roll number or admission number (`BOMIS-2021-0042` or `Aarav`).
    - 1-Tap "Mark Boarded (Manual Fallback)" button with reason ("Student forgot ID card").

---

### 4.3 Atomic & Layout Component Token Specifications

All mobile components in `src/components/ui/` will apply the following design tokens directly:

| Token Category | Token Key | Value | Mobile Usage |
|---|---|---|---|
| **Primary Navy** | `colors.primary.DEFAULT` | `#0F2942` | Headers, Splash, Nav bars, Primary buttons, ID card crest |
| **Navy Light** | `colors.primary[100]` | `#EBF2F8` | Teacher badge background, card accent headers |
| **Navy Surface** | `colors.primary[50]` | `#F4F8FA` | Student badge background, input background |
| **Accent Coral** | `colors.accent.DEFAULT` | `#FF6B4A` | Countdown timer, CTA buttons, active tab indicator, urgent banners |
| **Coral Light** | `colors.accent[100]` | `#FFEAE5` | Parent badge background, promo badges |
| **Neutral Screen** | `colors.neutral[50]` | `#F8FAFC` | Mobile SafeAreaView background |
| **Neutral Card** | `#FFFFFF` | `#FFFFFF` | Elevated card surfaces |
| **Neutral Border**| `colors.neutral[200]` | `#E2E8F0` | Input borders, card borders, stop timeline lines |
| **Text Primary** | `colors.neutral[900]` | `#0F172A` | Screen titles, card titles, student names |
| **Text Secondary**| `colors.neutral[500]` | `#64748B` | Timestamps, subtitles, bus plate numbers, admission codes |
| **Status Success**| `colors.status.success` | `#10B981` | Present pill, Boarded status, Paid fee badge, verified check |
| **Status Warning**| `colors.status.warning` | `#F59E0B` | Late pill, Geofence approaching banner, countdown warning |
| **Status Danger** | `colors.status.danger` | `#EF4444` | Absent pill, Expired OTP, SOS alert button |
| **Status Info** | `colors.status.info` | `#3B82F6` | Half day pill, bus route notice, timetable period badge |
| **Border Radius** | `borderRadius.xl` | `16` | Card container corner radius |
| **Border Radius** | `borderRadius.full` | `9999` | Status pills, role badges, avatar circles |

---

### 4.4 Offline Outbox Sync Engine Architecture

The mobile app implements an offline-first sync pattern conforming to `/api/v1/sync/batch`:

```typescript
// src/services/offline/outboxQueue.ts
export interface OutboxSyncEvent {
  id: string; // client uuid
  actionType: 'ATTENDANCE_BATCH' | 'BOARDING_SCAN' | 'GPS_PING';
  idempotencyKey: string;
  timestamp: number;
  payload: Record<string, unknown>;
  retryCount: number;
  status: 'QUEUED' | 'SYNCED' | 'FAILED';
}

export class OutboxSyncManager {
  private queue: OutboxSyncEvent[] = [];

  enqueue(actionType: OutboxSyncEvent['actionType'], payload: any): OutboxSyncEvent {
    const event: OutboxSyncEvent = {
      id: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      actionType,
      idempotencyKey: `idem_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      timestamp: Date.now(),
      payload,
      retryCount: 0,
      status: 'QUEUED',
    };
    this.queue.push(event);
    return event;
  }

  async flush(apiClient: any): Promise<{ syncedCount: number }> {
    const pending = this.queue.filter(e => e.status === 'QUEUED');
    if (pending.length === 0) return { syncedCount: 0 };

    const batchPayload = {
      events: pending.map(e => ({
        id: e.id,
        actionType: e.actionType,
        idempotencyKey: e.idempotencyKey,
        timestamp: e.timestamp,
        payload: e.payload,
      })),
    };

    const res = await apiClient.post('/sync/batch', batchPayload);
    // Mark items SYNCED
    for (const item of pending) {
      item.status = 'SYNCED';
    }
    return { syncedCount: pending.length };
  }
}
```

---

### 4.5 Implementation Roadmap for Mobile Developer

1. **Step 1: Install Dependencies**:
   Ensure Expo SDK 51 dependencies are installed in `apps/mobile`:
   - React Native core components, safe area context, status bar.
2. **Step 2: Scaffold Component Primitives**:
   Implement `src/components/ui/` (`BOMISButton`, `BOMISCard`, `BOMISBadge`, `BOMISInput`, `BOMISTabs`, `BOMISHeader`).
3. **Step 3: Implement Shared Services & State**:
   Implement `src/services/api/apiClient.ts`, `src/services/offline/outboxQueue.ts`, and `src/state/AppContext.tsx` with persona preset auto-login.
4. **Step 4: Implement Auth Screen with 4 Presets**:
   Build `src/screens/auth/AuthScreen.tsx` with phone input, OTP verification, and 1-click evaluation login presets for Parent, Student, Teacher, and Driver.
5. **Step 5: Implement Parent View**:
   Build `SiblingSwitcher`, `AttendanceCalendarView`, `LiveBusTrackerView` (with 5-minute geofence alert), `FeeCheckoutModalView` (with `Idempotency-Key` and PDF receipt download), and `DismissalOtpCardView` (with 30-min countdown and QR pass).
6. **Step 6: Implement Student View**:
   Build `DigitalIdCardView` (with dynamic QR), `HomeworkDiaryView`, and `TimetableScheduleView`.
7. **Step 7: Implement Teacher View**:
   Build `RapidAttendanceGridView` (<10s SLA with offline queue), `HomeworkPosterView`, and `TeacherTimetableSchedule`.
8. **Step 8: Implement Driver View**:
   Build `RouteStopsListView`, `GpsBroadcasterToggle` (periodic GPS pings), and `BoardingQrScannerView` (with manual fallback).
9. **Step 9: Wire Multi-Role Navigation in `App.tsx`**:
   Connect all role dashboards, header role badges, persona switcher, and offline banner.
10. **Step 10: Run Verification**:
    Execute typecheck (`pnpm --filter @bomis/mobile typecheck`) and verify zero TypeScript errors.

---

## 5. Verification Method

To independently verify the implementation against this architecture blueprint:

1. **Typecheck & Build Validation**:
   ```powershell
   pnpm --filter @bomis/mobile typecheck
   ```
   *Expected outcome*: Exits with code 0, verifying 100% type congruence with `@bomis/shared` and `@bomis/ui`.

2. **Persona Preset Verification**:
   - Launch app (`pnpm --filter @bomis/mobile start` or test harness).
   - In `AuthScreen`, click each of the 4 quick evaluation presets:
     - **Parent Preset**: Confirms Dr. Rajesh Patel profile loads, Sibling Switcher toggles between Aarav (5A) and Ananya (2A), Attendance displays 90.9%, Bus Tracker shows Bus 01 approaching Sakhipada Chhak with 5-min geofence alert, Fee checkout generates UUID `Idempotency-Key` and simulates receipt download, Dismissal card displays 6-digit OTP with ticking 30-min timer and QR code.
     - **Student Preset**: Confirms Aarav Patel profile loads, Digital ID card renders photo, details, and dynamic QR code, Homework feed shows assignments, and Timetable displays Grade 5A schedule.
     - **Teacher Preset**: Confirms Mrs. Arundhati Dash profile loads, Rapid Attendance Grid allows 1-click "Mark All Present" and exception toggles in <10s SLA, Offline queue enqueues and syncs via `/api/v1/sync/batch`, and Homework announcement composer works.
     - **Driver Preset**: Confirms Maheswar Bhoi profile loads, Route 1 Budharaja Shuttle 4 stops display, Live GPS broadcaster toggle pings `/api/v1/transport/gps-ping` every 5 seconds, and QR scanner view simulates student ID scan with manual fallback entry.

3. **Invalidation Conditions**:
   - If `apps/mobile/package.json` breaks monorepo workspace resolution with `@bomis/shared` or `@bomis/ui`.
   - If payment order creation omits the `Idempotency-Key` header.
   - If sibling state leaks between Aarav and Ananya in Parent View.
   - If teacher attendance grid fails to provide offline queue dispatch.
