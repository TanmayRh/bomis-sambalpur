# Technical Implementation Plan: Prisma Schema, DPDP Act Compliance & Field-Level Encryption

**Project**: Birla Open Minds International School (BOMIS), Sambalpur  
**Milestone**: M2 (Shared Packages, DPDP Schema & Security Foundation)  
**Author**: Explorer M2-2 (`teamwork_preview_explorer`)  
**Target Output**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m2_2\analysis.md`  
**Related Documents**: `ORIGINAL_REQUEST.md`, `PROJECT.md`, `docs/adr/0002-dpdp-multi-tenant-isolation-rls.md`, `spec_miner_survey_1/analysis.md`

---

## 1. Executive Summary & Architecture Overview

This document provides the definitive architectural blueprint and technical implementation plan for the **database layer, statutory privacy compliance, and cryptographic security** of the BOMIS Sambalpur Unified School Platform.

### 1.1 Core Objectives
1. **Complete 36-Model Master Prisma Schema**: Define the complete domain model encompassing academic hierarchy, student & guardian master records, multi-role staff profiles, timetabling with clash prevention, CBSE examinations & marks entry, fee structures & Razorpay transactions, fleet telematics & boarding logs, digital diary & homework, visitor management, granular consent tracking, and immutable audit logs.
2. **Multi-Tenant Row-Level Security (RLS)**: Enforce strict data isolation where every business entity is partitioned by `school_id String @db.Uuid` backed by composite indexes and PostgreSQL Row-Level Security (`ALTER TABLE ... ENABLE ROW LEVEL SECURITY`) driven by session-local settings (`app.current_school_id`).
3. **Digital Personal Data Protection (DPDP) Act 2023 Compliance**: Incorporate statutory soft-deletion (`deleted_at DateTime?`) with a strict 90-day retention schedule (`retention_until DateTime?`), daily automated cryptographic shredding via BullMQ, verifiable opt-in consent tracking with SHA-256 HMAC proof hashes, and immutable append-only audit logging protected by PostgreSQL rules (`DO INSTEAD NOTHING`).
4. **Field-Level Encryption (AES-256-GCM)**: Implement an enterprise-grade cryptographic utility supporting 256-bit keys, unique 96-bit (12-byte) initialization vectors (IV), 128-bit authentication tags, Additional Authenticated Data (AAD) tenant-binding, and key rotation versioning (`v1:<iv_hex>:<tag_hex>:<ciphertext_hex>`) for sensitive health, national identity, and financial records.
5. **Zero-Friction Tooling & Migrations**: Formulate Prisma schema configuration, client generation, custom SQL migrations for PostgreSQL RLS policies, and workspace package integration for local development and CI/CD pipelines.

---

## 2. Complete 36-Model Master Prisma Schema Specification

The master Prisma schema resides at `prisma/schema.prisma`. It connects to PostgreSQL 16 (initialized with `uuid-ossp` and `pgcrypto` extensions) and exports standard TypeScript types to `@prisma/client`.

### 2.1 Prisma Datasource & Generator Configuration

```prisma
// ==============================================================================
// BOMIS Sambalpur Master Prisma Schema
// Target Database: PostgreSQL 16+
// Client Generator: prisma-client-js
// ==============================================================================

generator client {
  provider        = "prisma-client-js"
  previewFeatures = ["relationMode", "postgresqlExtensions"]
}

datasource db {
  provider   = "postgresql"
  url        = env("DATABASE_URL")
  extensions = [uuidOssp(map: "uuid-ossp"), pgcrypto]
}
```

---

### 2.2 Canonical Domain Enums

These enums mirror `@bomis/shared/src/enums/index.ts` with 100% type congruence:

```prisma
enum UserRole {
  SUPER_ADMIN
  ADMIN
  PRINCIPAL
  TEACHER
  ACCOUNTANT
  STUDENT
  PARENT
  TRANSPORT_STAFF
}

enum UserStatus {
  ACTIVE
  INACTIVE
  SUSPENDED
  PENDING_VERIFICATION
}

enum Gender {
  MALE
  FEMALE
  OTHER
}

enum AttendanceStatus {
  PRESENT
  ABSENT
  LATE
  HALF_DAY
  EXCUSED
}

enum FeeFrequency {
  ONE_TIME
  ANNUAL
  TERM
  MONTHLY
  CUSTOM
}

enum PaymentStatus {
  PENDING
  SUCCESS
  FAILED
  REFUNDED
}

enum PaymentMethod {
  RAZORPAY_UPI
  RAZORPAY_NETBANKING
  RAZORPAY_CARD
  CASH
  CHEQUE
  BANK_TRANSFER
}

enum HomeworkStatus {
  ASSIGNED
  SUBMITTED
  REVIEWED
  RESUBMISSION_REQUESTED
}

enum ExamTerm {
  TERM_1
  TERM_2
  UNIT_TEST_1
  UNIT_TEST_2
  MID_TERM
  FINAL
}

enum BusTripType {
  MORNING_PICKUP
  AFTERNOON_DROP
  SPECIAL_EVENT
}

enum BoardingStatus {
  SCHEDULED
  BOARDED
  DEBOARDED
  ABSENT
}

enum ConsentType {
  DATA_PROCESSING
  HEALTH_RECORDS
  MEDIA_RELEASE
  TRANSPORT_TRACKING
  SMS_NOTIFICATIONS
}

enum ConsentStatus {
  GRANTED
  REVOKED
  EXPIRED
}

enum AuditAction {
  CREATE
  UPDATE
  DELETE
  LOGIN
  LOGOUT
  CONSENT_CHANGE
  PAYMENT
  DATA_ERASURE
}

enum ConcessionStatus {
  PENDING
  APPROVED
  REJECTED
}

enum VisitorPassStatus {
  PRE_APPROVED
  ACTIVE_ON_CAMPUS
  CHECKED_OUT
  EXPIRED
  DENIED
}
```

---

### 2.3 Detailed Models Breakdown (All 36 Models)

#### Domain 1: Multi-Tenant Root & Identity (Models 1 - 3)

##### 1. `School` (Multi-Tenant Root)
```prisma
model School {
  id                 String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  name               String   @db.VarChar(255)
  code               String   @unique @db.VarChar(50)
  affiliation_number String?  @db.VarChar(50)
  address            String   @db.Text
  city               String   @db.VarChar(100)
  state              String   @db.VarChar(100)
  postal_code        String   @db.VarChar(20)
  phone              String   @db.VarChar(20)
  email              String   @db.VarChar(255)
  website            String?  @db.VarChar(255)
  logo_url           String?  @db.VarChar(500)
  status             String   @default("ACTIVE") @db.VarChar(20)
  created_at         DateTime @default(now())
  updated_at         DateTime @updatedAt

  // Tenant Child Relations
  users                       User[]
  refresh_tokens              RefreshToken[]
  students                    Student[]
  guardians                   Guardian[]
  student_guardians           StudentGuardian[]
  staff                       Staff[]
  academic_years              AcademicYear[]
  classes                     Class[]
  sections                    Section[]
  subjects                    Subject[]
  teacher_assignments         TeacherAssignment[]
  attendances                 Attendance[]
  staff_attendances           StaffAttendance[]
  fee_categories              FeeCategory[]
  fee_structures              FeeStructure[]
  fee_concessions             FeeConcession[]
  fee_installments            FeeInstallment[]
  payments                    Payment[]
  homeworks                   Homework[]
  homework_submissions        HomeworkSubmission[]
  timetables                  Timetable[]
  teacher_substitutions       TeacherAbsenceSubstitution[]
  exams                       Exam[]
  exam_subjects               ExamSubject[]
  marks_entries               MarksEntry[]
  transport_routes            TransportRoute[]
  transport_stops             TransportStop[]
  vehicles                    Vehicle[]
  student_transports          StudentTransport[]
  transport_telemetries       TransportTelemetry[]
  boarding_events             BoardingEvent[]
  notice_circulars            NoticeCircular[]
  visitor_passes              VisitorPass[]
  consents                    Consent[]
  audit_logs                  AuditLog[]

  @@map("schools")
}
```

##### 2. `User` (Authentication & Core Account)
```prisma
model User {
  id              String     @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id       String     @db.Uuid
  email           String?    @db.VarChar(255)
  phone           String     @db.VarChar(20)
  password_hash   String?    @db.VarChar(255)
  role            UserRole
  status          UserStatus @default(ACTIVE)
  first_name      String     @db.VarChar(100)
  last_name       String     @db.VarChar(100)
  avatar_url      String?    @db.VarChar(500)
  last_login_at   DateTime?
  created_at      DateTime   @default(now())
  updated_at      DateTime   @updatedAt
  deleted_at      DateTime?
  retention_until DateTime?

  // Relations
  school          School         @relation(fields: [school_id], references: [id], onDelete: Cascade)
  refresh_tokens  RefreshToken[]
  student_profile Student?
  guardian_profile Guardian?
  staff_profile   Staff?
  consents        Consent[]
  payments_made   Payment[]      @relation("UserPayments")
  notices_created NoticeCircular[] @relation("CreatedNotices")

  @@unique([school_id, phone])
  @@unique([school_id, email])
  @@index([school_id, role])
  @@index([school_id, status])
  @@index([deleted_at])
  @@map("users")
}
```

##### 3. `RefreshToken` (Token Rotation & Session Management)
```prisma
model RefreshToken {
  id         String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id  String   @db.Uuid
  user_id    String   @db.Uuid
  token_hash String   @unique @db.VarChar(255)
  family_id  String   @db.Uuid
  is_revoked Boolean  @default(false)
  expires_at DateTime
  user_agent String?  @db.VarChar(500)
  ip_address String?  @db.VarChar(50)
  created_at DateTime @default(now())
  updated_at DateTime @updatedAt

  school School @relation(fields: [school_id], references: [id], onDelete: Cascade)
  user   User   @relation(fields: [user_id], references: [id], onDelete: Cascade)

  @@index([school_id, user_id])
  @@index([family_id])
  @@index([expires_at])
  @@map("refresh_tokens")
}
```

---

#### Domain 2: People Master & Profiles (Models 4 - 7)

##### 4. `Student` (Academic Pupil Master Record)
```prisma
model Student {
  id                      String    @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id               String    @db.Uuid
  user_id                 String?   @unique @db.Uuid
  admission_number        String    @db.VarChar(50)
  roll_number             String    @db.VarChar(50)
  first_name              String    @db.VarChar(100)
  last_name               String    @db.VarChar(100)
  date_of_birth           DateTime
  gender                  Gender
  class_id                String    @db.Uuid
  section_id              String    @db.Uuid
  academic_year_id        String    @db.Uuid
  emergency_contact       String    @db.VarChar(20)
  
  // Field-Level Encrypted PII (AES-256-GCM v1:...)
  blood_group_encrypted   String?   @db.Text
  medical_notes_encrypted String?   @db.Text
  aadhaar_number_encrypted String?  @db.Text

  address                 String?   @db.Text
  photo_url               String?   @db.VarChar(500)
  is_active               Boolean   @default(true)
  created_at              DateTime  @default(now())
  updated_at              DateTime  @updatedAt
  deleted_at              DateTime?
  retention_until         DateTime?

  // Relations
  school           School              @relation(fields: [school_id], references: [id], onDelete: Cascade)
  user             User?               @relation(fields: [user_id], references: [id], onDelete: SetNull)
  class            Class               @relation(fields: [class_id], references: [id], onDelete: Restrict)
  section          Section             @relation(fields: [section_id], references: [id], onDelete: Restrict)
  academic_year    AcademicYear        @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)
  guardians        StudentGuardian[]
  attendances      Attendance[]
  fee_concessions  FeeConcession[]
  fee_installments FeeInstallment[]
  payments         Payment[]
  submissions      HomeworkSubmission[]
  marks_entries    MarksEntry[]
  transports       StudentTransport[]
  boarding_events  BoardingEvent[]

  @@unique([school_id, admission_number])
  @@unique([school_id, class_id, section_id, roll_number])
  @@index([school_id, class_id, section_id])
  @@index([deleted_at])
  @@map("students")
}
```

##### 5. `Guardian` (Parent / Guardian Master Record)
```prisma
model Guardian {
  id                       String    @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id                String    @db.Uuid
  user_id                  String    @unique @db.Uuid
  first_name               String    @db.VarChar(100)
  last_name                String    @db.VarChar(100)
  relationship             String    @db.VarChar(50)
  occupation               String?   @db.VarChar(100)
  
  // Field-Level Encrypted PII (AES-256-GCM v1:...)
  aadhaar_number_encrypted String?   @db.Text
  annual_income_encrypted  String?   @db.Text

  emergency_phone          String?   @db.VarChar(20)
  created_at               DateTime  @default(now())
  updated_at               DateTime  @updatedAt
  deleted_at               DateTime?
  retention_until          DateTime?

  school   School            @relation(fields: [school_id], references: [id], onDelete: Cascade)
  user     User              @relation(fields: [user_id], references: [id], onDelete: Cascade)
  children StudentGuardian[]

  @@index([school_id, user_id])
  @@index([deleted_at])
  @@map("guardians")
}
```

##### 6. `StudentGuardian` (Multi-Child Sibling Linking & Custody)
```prisma
model StudentGuardian {
  id                 String    @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id          String    @db.Uuid
  student_id         String    @db.Uuid
  guardian_id        String    @db.Uuid
  relation_type      String    @db.VarChar(50)
  is_primary_contact Boolean   @default(false)
  can_pickup         Boolean   @default(true)
  created_at         DateTime  @default(now())
  updated_at         DateTime  @updatedAt
  deleted_at         DateTime?
  retention_until    DateTime?

  school   School   @relation(fields: [school_id], references: [id], onDelete: Cascade)
  student  Student  @relation(fields: [student_id], references: [id], onDelete: Cascade)
  guardian Guardian @relation(fields: [guardian_id], references: [id], onDelete: Cascade)

  @@unique([school_id, student_id, guardian_id])
  @@index([school_id, student_id])
  @@index([school_id, guardian_id])
  @@map("student_guardians")
}
```

##### 7. `Staff` (Employee Master Profile)
```prisma
model Staff {
  id                       String    @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id                String    @db.Uuid
  user_id                  String    @unique @db.Uuid
  employee_id              String    @db.VarChar(50)
  designation              String    @db.VarChar(100)
  department               String    @db.VarChar(100)
  qualification            String?   @db.VarChar(255)
  joining_date             DateTime
  
  // Field-Level Encrypted PII (AES-256-GCM v1:...)
  pan_number_encrypted     String?   @db.Text
  aadhaar_number_encrypted String?   @db.Text

  emergency_phone          String?   @db.VarChar(20)
  created_at               DateTime  @default(now())
  updated_at               DateTime  @updatedAt
  deleted_at               DateTime?
  retention_until          DateTime?

  school               School                       @relation(fields: [school_id], references: [id], onDelete: Cascade)
  user                 User                         @relation(fields: [user_id], references: [id], onDelete: Cascade)
  class_sections       Section[]                    @relation("ClassTeacher")
  teacher_assignments  TeacherAssignment[]
  marked_attendances   Attendance[]                 @relation("MarkedByStaff")
  staff_attendances    StaffAttendance[]
  timetables           Timetable[]
  substitutions_absent TeacherAbsenceSubstitution[] @relation("AbsentStaff")
  substitutions_sub    TeacherAbsenceSubstitution[] @relation("SubstituteStaff")
  assigned_homeworks   Homework[]
  reviewed_submissions HomeworkSubmission[]
  marks_entries        MarksEntry[]
  driven_vehicles      Vehicle[]
  scanned_boardings    BoardingEvent[]

  @@unique([school_id, employee_id])
  @@index([school_id, user_id])
  @@index([deleted_at])
  @@map("staff")
}
```

---

#### Domain 3: Academic Structure & Scheduling (Models 8 - 12, 22 - 23)

##### 8. `AcademicYear`
```prisma
model AcademicYear {
  id         String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id  String   @db.Uuid
  name       String   @db.VarChar(50)
  start_date DateTime
  end_date   DateTime
  is_current Boolean  @default(false)
  created_at DateTime @default(now())
  updated_at DateTime @updatedAt

  school              School              @relation(fields: [school_id], references: [id], onDelete: Cascade)
  students            Student[]
  teacher_assignments TeacherAssignment[]
  attendances         Attendance[]
  fee_structures      FeeStructure[]
  fee_concessions     FeeConcession[]
  fee_installments    FeeInstallment[]
  payments            Payment[]
  timetables          Timetable[]
  exams               Exam[]
  student_transports  StudentTransport[]

  @@unique([school_id, name])
  @@index([school_id, is_current])
  @@map("academic_years")
}
```

##### 9. `Class` (Grade Level)
```prisma
model Class {
  id          String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id   String   @db.Uuid
  name        String   @db.VarChar(50)
  code        String   @db.VarChar(20)
  grade_level Int
  order_index Int      @default(0)
  created_at  DateTime @default(now())
  updated_at  DateTime @updatedAt

  school              School              @relation(fields: [school_id], references: [id], onDelete: Cascade)
  sections            Section[]
  students            Student[]
  teacher_assignments TeacherAssignment[]
  attendances         Attendance[]
  fee_structures      FeeStructure[]
  timetables          Timetable[]
  homeworks           Homework[]
  exam_subjects       ExamSubject[]

  @@unique([school_id, name])
  @@unique([school_id, grade_level])
  @@index([school_id, order_index])
  @@map("classes")
}
```

##### 10. `Section` (Class Section)
```prisma
model Section {
  id               String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id        String   @db.Uuid
  class_id         String   @db.Uuid
  name             String   @db.VarChar(20)
  capacity         Int      @default(40)
  room_number      String?  @db.VarChar(50)
  class_teacher_id String?  @db.Uuid
  created_at       DateTime @default(now())
  updated_at       DateTime @updatedAt

  school              School              @relation(fields: [school_id], references: [id], onDelete: Cascade)
  class               Class               @relation(fields: [class_id], references: [id], onDelete: Restrict)
  class_teacher       Staff?              @relation("ClassTeacher", fields: [class_teacher_id], references: [id], onDelete: SetNull)
  students            Student[]
  teacher_assignments TeacherAssignment[]
  attendances         Attendance[]
  timetables          Timetable[]
  homeworks           Homework[]

  @@unique([school_id, class_id, name])
  @@index([school_id, class_id])
  @@map("sections")
}
```

##### 11. `Subject`
```prisma
model Subject {
  id            String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id     String   @db.Uuid
  name          String   @db.VarChar(100)
  code          String   @db.VarChar(50)
  description   String?  @db.Text
  is_scholastic Boolean  @default(true)
  created_at    DateTime @default(now())
  updated_at    DateTime @updatedAt

  school              School              @relation(fields: [school_id], references: [id], onDelete: Cascade)
  teacher_assignments TeacherAssignment[]
  timetables          Timetable[]
  homeworks           Homework[]
  exam_subjects       ExamSubject[]

  @@unique([school_id, code])
  @@map("subjects")
}
```

##### 12. `TeacherAssignment`
```prisma
model TeacherAssignment {
  id               String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id        String   @db.Uuid
  staff_id         String   @db.Uuid
  class_id         String   @db.Uuid
  section_id       String   @db.Uuid
  subject_id       String   @db.Uuid
  academic_year_id String   @db.Uuid
  created_at       DateTime @default(now())
  updated_at       DateTime @updatedAt

  school        School       @relation(fields: [school_id], references: [id], onDelete: Cascade)
  staff         Staff        @relation(fields: [staff_id], references: [id], onDelete: Cascade)
  class         Class        @relation(fields: [class_id], references: [id], onDelete: Restrict)
  section       Section      @relation(fields: [section_id], references: [id], onDelete: Restrict)
  subject       Subject      @relation(fields: [subject_id], references: [id], onDelete: Restrict)
  academic_year AcademicYear @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)

  @@unique([school_id, staff_id, section_id, subject_id, academic_year_id])
  @@index([school_id, section_id])
  @@index([school_id, staff_id])
  @@map("teacher_assignments")
}
```

##### 22. `Timetable`
```prisma
model Timetable {
  id               String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id        String   @db.Uuid
  academic_year_id String   @db.Uuid
  class_id         String   @db.Uuid
  section_id       String   @db.Uuid
  subject_id       String   @db.Uuid
  staff_id         String   @db.Uuid
  day_of_week      Int
  period_number    Int
  start_time       String   @db.VarChar(10)
  end_time         String   @db.VarChar(10)
  room_number      String?  @db.VarChar(50)
  created_at       DateTime @default(now())
  updated_at       DateTime @updatedAt

  school        School                       @relation(fields: [school_id], references: [id], onDelete: Cascade)
  academic_year AcademicYear                 @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)
  class         Class                        @relation(fields: [class_id], references: [id], onDelete: Restrict)
  section       Section                      @relation(fields: [section_id], references: [id], onDelete: Restrict)
  subject       Subject                      @relation(fields: [subject_id], references: [id], onDelete: Restrict)
  staff         Staff                        @relation(fields: [staff_id], references: [id], onDelete: Restrict)
  substitutions TeacherAbsenceSubstitution[]

  // Clash Prevention Constraints:
  @@unique([school_id, academic_year_id, staff_id, day_of_week, period_number])
  @@unique([school_id, academic_year_id, section_id, day_of_week, period_number])
  @@index([school_id, section_id, day_of_week])
  @@map("timetables")
}
```

##### 23. `TeacherAbsenceSubstitution`
```prisma
model TeacherAbsenceSubstitution {
  id                  String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id           String   @db.Uuid
  timetable_id        String   @db.Uuid
  absent_staff_id     String   @db.Uuid
  substitute_staff_id String   @db.Uuid
  date                DateTime @db.Date
  status              String   @default("APPROVED") @db.VarChar(20)
  remarks             String?  @db.Text
  created_at          DateTime @default(now())
  updated_at          DateTime @updatedAt

  school           School    @relation(fields: [school_id], references: [id], onDelete: Cascade)
  timetable        Timetable @relation(fields: [timetable_id], references: [id], onDelete: Cascade)
  absent_staff     Staff     @relation("AbsentStaff", fields: [absent_staff_id], references: [id], onDelete: Restrict)
  substitute_staff Staff     @relation("SubstituteStaff", fields: [substitute_staff_id], references: [id], onDelete: Restrict)

  @@unique([school_id, timetable_id, date])
  @@index([school_id, substitute_staff_id, date])
  @@index([school_id, absent_staff_id, date])
  @@map("teacher_absence_substitutions")
}
```

---

#### Domain 4: Attendance & Daily Operations (Models 13 - 14)

##### 13. `Attendance` (Daily Student Attendance with Offline Sync)
```prisma
model Attendance {
  id               String           @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id        String           @db.Uuid
  student_id       String           @db.Uuid
  class_id         String           @db.Uuid
  section_id       String           @db.Uuid
  academic_year_id String           @db.Uuid
  date             DateTime         @db.Date
  status           AttendanceStatus
  remarks          String?          @db.VarChar(255)
  marked_by_id     String?          @db.Uuid
  offline_id       String?          @db.Uuid
  synced_at        DateTime?
  created_at       DateTime         @default(now())
  updated_at       DateTime         @updatedAt
  deleted_at       DateTime?
  retention_until  DateTime?

  school        School       @relation(fields: [school_id], references: [id], onDelete: Cascade)
  student       Student      @relation(fields: [student_id], references: [id], onDelete: Cascade)
  class         Class        @relation(fields: [class_id], references: [id], onDelete: Restrict)
  section       Section      @relation(fields: [section_id], references: [id], onDelete: Restrict)
  academic_year AcademicYear @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)
  marked_by     Staff?       @relation("MarkedByStaff", fields: [marked_by_id], references: [id], onDelete: SetNull)

  @@unique([school_id, student_id, date])
  @@index([school_id, section_id, date])
  @@index([school_id, status, date])
  @@index([deleted_at])
  @@map("attendances")
}
```

##### 14. `StaffAttendance` (Employee Clock-in/Clock-out)
```prisma
model StaffAttendance {
  id              String    @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id       String    @db.Uuid
  staff_id        String    @db.Uuid
  date            DateTime  @db.Date
  check_in_time   DateTime?
  check_out_time  DateTime?
  status          String    @db.VarChar(20)
  leave_type      String?   @db.VarChar(50)
  remarks         String?   @db.VarChar(255)
  created_at      DateTime  @default(now())
  updated_at      DateTime  @updatedAt
  deleted_at      DateTime?
  retention_until DateTime?

  school School @relation(fields: [school_id], references: [id], onDelete: Cascade)
  staff  Staff  @relation(fields: [staff_id], references: [id], onDelete: Cascade)

  @@unique([school_id, staff_id, date])
  @@index([school_id, date])
  @@index([deleted_at])
  @@map("staff_attendances")
}
```

---

#### Domain 5: Financial Operations & Razorpay Transactions (Models 15 - 19)

##### 15. `FeeCategory`
```prisma
model FeeCategory {
  id          String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id   String   @db.Uuid
  name        String   @db.VarChar(100)
  code        String   @db.VarChar(50)
  description String?  @db.Text
  is_optional Boolean  @default(false)
  created_at  DateTime @default(now())
  updated_at  DateTime @updatedAt

  school          School          @relation(fields: [school_id], references: [id], onDelete: Cascade)
  fee_structures  FeeStructure[]
  fee_concessions FeeConcession[]

  @@unique([school_id, code])
  @@map("fee_categories")
}
```

##### 16. `FeeStructure`
```prisma
model FeeStructure {
  id               String       @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id        String       @db.Uuid
  academic_year_id String       @db.Uuid
  class_id         String       @db.Uuid
  fee_category_id  String       @db.Uuid
  amount           Decimal      @db.Decimal(10, 2)
  frequency        FeeFrequency
  due_date         DateTime?
  created_at       DateTime     @default(now())
  updated_at       DateTime     @updatedAt

  school           School           @relation(fields: [school_id], references: [id], onDelete: Cascade)
  academic_year    AcademicYear     @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)
  class            Class            @relation(fields: [class_id], references: [id], onDelete: Restrict)
  fee_category     FeeCategory      @relation(fields: [fee_category_id], references: [id], onDelete: Restrict)
  fee_installments FeeInstallment[]

  @@unique([school_id, academic_year_id, class_id, fee_category_id])
  @@index([school_id, class_id])
  @@map("fee_structures")
}
```

##### 17. `FeeConcession`
```prisma
model FeeConcession {
  id               String           @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id        String           @db.Uuid
  student_id       String           @db.Uuid
  fee_category_id  String           @db.Uuid
  academic_year_id String           @db.Uuid
  discount_type    String           @db.VarChar(20)
  discount_value   Decimal          @db.Decimal(10, 2)
  reason           String           @db.Text
  status           ConcessionStatus @default(PENDING)
  approved_by_id   String?          @db.Uuid
  approved_at      DateTime?
  created_at       DateTime         @default(now())
  updated_at       DateTime         @updatedAt
  deleted_at       DateTime?
  retention_until  DateTime?

  school        School       @relation(fields: [school_id], references: [id], onDelete: Cascade)
  student       Student      @relation(fields: [student_id], references: [id], onDelete: Cascade)
  fee_category  FeeCategory  @relation(fields: [fee_category_id], references: [id], onDelete: Restrict)
  academic_year AcademicYear @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)

  @@index([school_id, student_id])
  @@index([school_id, status])
  @@index([deleted_at])
  @@map("fee_concessions")
}
```

##### 18. `FeeInstallment`
```prisma
model FeeInstallment {
  id                 String        @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id          String        @db.Uuid
  student_id         String        @db.Uuid
  fee_structure_id   String        @db.Uuid
  academic_year_id   String        @db.Uuid
  installment_number Int
  title              String        @db.VarChar(100)
  due_date           DateTime
  base_amount        Decimal       @db.Decimal(10, 2)
  concession_amount  Decimal       @default(0.00) @db.Decimal(10, 2)
  net_amount         Decimal       @db.Decimal(10, 2)
  paid_amount        Decimal       @default(0.00) @db.Decimal(10, 2)
  status             PaymentStatus @default(PENDING)
  created_at         DateTime      @default(now())
  updated_at         DateTime      @updatedAt
  deleted_at         DateTime?
  retention_until    DateTime?

  school        School       @relation(fields: [school_id], references: [id], onDelete: Cascade)
  student       Student      @relation(fields: [student_id], references: [id], onDelete: Cascade)
  fee_structure FeeStructure @relation(fields: [fee_structure_id], references: [id], onDelete: Restrict)
  academic_year AcademicYear @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)
  payments      Payment[]

  @@index([school_id, student_id, status])
  @@index([school_id, due_date])
  @@index([deleted_at])
  @@map("fee_installments")
}
```

##### 19. `Payment` (Financial Ledger with Idempotency)
```prisma
model Payment {
  id                  String        @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id           String        @db.Uuid
  student_id          String        @db.Uuid
  installment_id      String        @db.Uuid
  academic_year_id    String        @db.Uuid
  amount              Decimal       @db.Decimal(10, 2)
  currency            String        @default("INR") @db.VarChar(10)
  payment_method      PaymentMethod
  payment_status      PaymentStatus
  idempotency_key     String        @unique @db.VarChar(100)
  razorpay_order_id   String?       @db.VarChar(100)
  razorpay_payment_id String?       @unique @db.VarChar(100)
  razorpay_signature  String?       @db.VarChar(255)
  receipt_number      String        @unique @db.VarChar(100)
  paid_at             DateTime?
  payer_id            String?       @db.Uuid
  receipt_url         String?       @db.VarChar(500)
  webhook_payload     Json?
  created_at          DateTime      @default(now())
  updated_at          DateTime      @updatedAt
  deleted_at          DateTime?
  retention_until     DateTime?

  school        School         @relation(fields: [school_id], references: [id], onDelete: Cascade)
  student       Student        @relation(fields: [student_id], references: [id], onDelete: Cascade)
  installment   FeeInstallment @relation(fields: [installment_id], references: [id], onDelete: Restrict)
  academic_year AcademicYear   @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)
  payer         User?          @relation("UserPayments", fields: [payer_id], references: [id], onDelete: SetNull)

  @@index([school_id, student_id])
  @@index([school_id, payment_status])
  @@index([school_id, paid_at])
  @@index([deleted_at])
  @@map("payments")
}
```

---

#### Domain 6: Academic Homework & Submissions (Models 20 - 21)

##### 20. `Homework`
```prisma
model Homework {
  id              String         @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id       String         @db.Uuid
  class_id        String         @db.Uuid
  section_id      String         @db.Uuid
  subject_id      String         @db.Uuid
  teacher_id      String         @db.Uuid
  title           String         @db.VarChar(255)
  description     String         @db.Text
  attachments     Json?
  due_date        DateTime
  max_marks       Decimal?       @db.Decimal(5, 2)
  status          HomeworkStatus @default(ASSIGNED)
  created_at      DateTime       @default(now())
  updated_at      DateTime       @updatedAt
  deleted_at      DateTime?
  retention_until DateTime?

  school      School               @relation(fields: [school_id], references: [id], onDelete: Cascade)
  class       Class                @relation(fields: [class_id], references: [id], onDelete: Restrict)
  section     Section              @relation(fields: [section_id], references: [id], onDelete: Restrict)
  subject     Subject              @relation(fields: [subject_id], references: [id], onDelete: Restrict)
  teacher     Staff                @relation(fields: [teacher_id], references: [id], onDelete: Restrict)
  submissions HomeworkSubmission[]

  @@index([school_id, section_id, due_date])
  @@index([school_id, teacher_id])
  @@index([deleted_at])
  @@map("homeworks")
}
```

##### 21. `HomeworkSubmission`
```prisma
model HomeworkSubmission {
  id              String         @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id       String         @db.Uuid
  homework_id     String         @db.Uuid
  student_id      String         @db.Uuid
  submission_text String?        @db.Text
  attachments     Json?
  submitted_at    DateTime       @default(now())
  status          HomeworkStatus @default(SUBMITTED)
  marks_obtained  Decimal?       @db.Decimal(5, 2)
  feedback        String?        @db.Text
  reviewed_by_id  String?        @db.Uuid
  reviewed_at     DateTime?
  created_at      DateTime       @default(now())
  updated_at      DateTime       @updatedAt
  deleted_at      DateTime?
  retention_until DateTime?

  school      School   @relation(fields: [school_id], references: [id], onDelete: Cascade)
  homework    Homework @relation(fields: [homework_id], references: [id], onDelete: Cascade)
  student     Student  @relation(fields: [student_id], references: [id], onDelete: Cascade)
  reviewed_by Staff?   @relation(fields: [reviewed_by_id], references: [id], onDelete: SetNull)

  @@unique([school_id, homework_id, student_id])
  @@index([school_id, student_id])
  @@index([deleted_at])
  @@map("homework_submissions")
}
```

---

#### Domain 7: CBSE Exams & Marks (Models 24 - 26)

##### 24. `Exam`
```prisma
model Exam {
  id               String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id        String   @db.Uuid
  academic_year_id String   @db.Uuid
  name             String   @db.VarChar(100)
  term             ExamTerm
  start_date       DateTime
  end_date         DateTime
  is_published     Boolean  @default(false)
  created_at       DateTime @default(now())
  updated_at       DateTime @updatedAt

  school        School        @relation(fields: [school_id], references: [id], onDelete: Cascade)
  academic_year AcademicYear  @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)
  exam_subjects ExamSubject[]

  @@unique([school_id, academic_year_id, name])
  @@index([school_id, academic_year_id, term])
  @@map("exams")
}
```

##### 25. `ExamSubject`
```prisma
model ExamSubject {
  id         String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id  String   @db.Uuid
  exam_id    String   @db.Uuid
  class_id   String   @db.Uuid
  subject_id String   @db.Uuid
  exam_date  DateTime @db.Date
  start_time String   @db.VarChar(10)
  end_time   String   @db.VarChar(10)
  max_marks  Decimal  @db.Decimal(5, 2)
  pass_marks Decimal  @db.Decimal(5, 2)
  created_at DateTime @default(now())
  updated_at DateTime @updatedAt

  school        School       @relation(fields: [school_id], references: [id], onDelete: Cascade)
  exam          Exam         @relation(fields: [exam_id], references: [id], onDelete: Cascade)
  class         Class        @relation(fields: [class_id], references: [id], onDelete: Restrict)
  subject       Subject      @relation(fields: [subject_id], references: [id], onDelete: Restrict)
  marks_entries MarksEntry[]

  @@unique([school_id, exam_id, class_id, subject_id])
  @@index([school_id, exam_id])
  @@map("exam_subjects")
}
```

##### 26. `MarksEntry`
```prisma
model MarksEntry {
  id              String    @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id       String    @db.Uuid
  exam_subject_id String    @db.Uuid
  student_id      String    @db.Uuid
  marks_obtained  Decimal?  @db.Decimal(5, 2)
  grade           String?   @db.VarChar(10)
  remarks         String?   @db.VarChar(255)
  is_absent       Boolean   @default(false)
  is_locked       Boolean   @default(false)
  teacher_id      String?   @db.Uuid
  created_at      DateTime  @default(now())
  updated_at      DateTime  @updatedAt
  deleted_at      DateTime?
  retention_until DateTime?

  school       School      @relation(fields: [school_id], references: [id], onDelete: Cascade)
  exam_subject ExamSubject @relation(fields: [exam_subject_id], references: [id], onDelete: Cascade)
  student      Student     @relation(fields: [student_id], references: [id], onDelete: Cascade)
  teacher      Staff?      @relation(fields: [teacher_id], references: [id], onDelete: SetNull)

  @@unique([school_id, exam_subject_id, student_id])
  @@index([school_id, student_id])
  @@index([deleted_at])
  @@map("marks_entries")
}
```

---

#### Domain 8: Fleet & Transport Operations (Models 27 - 32)

##### 27. `TransportRoute`
```prisma
model TransportRoute {
  id          String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id   String   @db.Uuid
  name        String   @db.VarChar(100)
  code        String   @db.VarChar(50)
  start_point String   @db.VarChar(255)
  end_point   String   @db.VarChar(255)
  created_at  DateTime @default(now())
  updated_at  DateTime @updatedAt

  school             School               @relation(fields: [school_id], references: [id], onDelete: Cascade)
  stops              TransportStop[]
  vehicles           Vehicle[]
  student_transports StudentTransport[]
  telemetries        TransportTelemetry[]

  @@unique([school_id, code])
  @@map("transport_routes")
}
```

##### 28. `TransportStop`
```prisma
model TransportStop {
  id                     String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id              String   @db.Uuid
  route_id               String   @db.Uuid
  name                   String   @db.VarChar(100)
  latitude               Float
  longitude              Float
  stop_order             Int
  pickup_time            String   @db.VarChar(10)
  drop_time              String   @db.VarChar(10)
  geofence_radius_meters Int      @default(500)
  created_at             DateTime @default(now())
  updated_at             DateTime @updatedAt

  school             School             @relation(fields: [school_id], references: [id], onDelete: Cascade)
  route              TransportRoute     @relation(fields: [route_id], references: [id], onDelete: Cascade)
  student_transports StudentTransport[]
  boarding_events    BoardingEvent[]

  @@unique([school_id, route_id, stop_order])
  @@index([school_id, route_id])
  @@map("transport_stops")
}
```

##### 29. `Vehicle` (School Fleet Buses - 4 Pilot Buses)
```prisma
model Vehicle {
  id                  String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id           String   @db.Uuid
  registration_number String   @unique @db.VarChar(50)
  bus_number          String   @db.VarChar(50)
  capacity            Int
  model               String?  @db.VarChar(100)
  driver_staff_id     String?  @db.Uuid
  current_route_id    String?  @db.Uuid
  status              String   @default("ACTIVE") @db.VarChar(20)
  created_at          DateTime @default(now())
  updated_at          DateTime @updatedAt

  school             School               @relation(fields: [school_id], references: [id], onDelete: Cascade)
  driver             Staff?               @relation(fields: [driver_staff_id], references: [id], onDelete: SetNull)
  current_route      TransportRoute?      @relation(fields: [current_route_id], references: [id], onDelete: SetNull)
  student_transports StudentTransport[]
  telemetries        TransportTelemetry[]
  boarding_events    BoardingEvent[]

  @@unique([school_id, bus_number])
  @@index([school_id, registration_number])
  @@map("vehicles")
}
```

##### 30. `StudentTransport`
```prisma
model StudentTransport {
  id               String      @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id        String      @db.Uuid
  student_id       String      @db.Uuid
  route_id         String      @db.Uuid
  stop_id          String      @db.Uuid
  vehicle_id       String?     @db.Uuid
  trip_type        BusTripType
  academic_year_id String      @db.Uuid
  created_at       DateTime    @default(now())
  updated_at       DateTime    @updatedAt
  deleted_at       DateTime?
  retention_until  DateTime?

  school        School         @relation(fields: [school_id], references: [id], onDelete: Cascade)
  student       Student        @relation(fields: [student_id], references: [id], onDelete: Cascade)
  route         TransportRoute @relation(fields: [route_id], references: [id], onDelete: Restrict)
  stop          TransportStop  @relation(fields: [stop_id], references: [id], onDelete: Restrict)
  vehicle       Vehicle?       @relation(fields: [vehicle_id], references: [id], onDelete: SetNull)
  academic_year AcademicYear   @relation(fields: [academic_year_id], references: [id], onDelete: Restrict)

  @@unique([school_id, student_id, trip_type, academic_year_id])
  @@index([school_id, route_id])
  @@index([school_id, vehicle_id])
  @@index([deleted_at])
  @@map("student_transports")
}
```

##### 31. `TransportTelemetry` (High-Volume GPS Tracking)
```prisma
model TransportTelemetry {
  id          String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id   String   @db.Uuid
  vehicle_id  String   @db.Uuid
  route_id    String?  @db.Uuid
  latitude    Float
  longitude   Float
  speed       Float?
  heading     Float?
  recorded_at DateTime
  created_at  DateTime @default(now())

  school  School          @relation(fields: [school_id], references: [id], onDelete: Cascade)
  vehicle Vehicle         @relation(fields: [vehicle_id], references: [id], onDelete: Cascade)
  route   TransportRoute? @relation(fields: [route_id], references: [id], onDelete: SetNull)

  @@index([school_id, vehicle_id, recorded_at])
  @@map("transport_telemetries")
}
```

##### 32. `BoardingEvent` (Student QR Boarding Logs)
```prisma
model BoardingEvent {
  id              String         @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id       String         @db.Uuid
  student_id      String         @db.Uuid
  vehicle_id      String         @db.Uuid
  stop_id         String         @db.Uuid
  scan_type       String         @db.VarChar(20) // BOARD or DEBOARD
  status          BoardingStatus @default(BOARDED)
  scanned_by_id   String?        @db.Uuid
  scanned_at      DateTime
  created_at      DateTime       @default(now())
  deleted_at      DateTime?
  retention_until DateTime?

  school     School        @relation(fields: [school_id], references: [id], onDelete: Cascade)
  student    Student       @relation(fields: [student_id], references: [id], onDelete: Cascade)
  vehicle    Vehicle       @relation(fields: [vehicle_id], references: [id], onDelete: Restrict)
  stop       TransportStop @relation(fields: [stop_id], references: [id], onDelete: Restrict)
  scanned_by Staff?        @relation(fields: [scanned_by_id], references: [id], onDelete: SetNull)

  @@index([school_id, student_id, scanned_at])
  @@index([school_id, vehicle_id, scanned_at])
  @@index([deleted_at])
  @@map("boarding_events")
}
```

---

#### Domain 9: Communication, Safety & Regulatory Governance (Models 33 - 36)

##### 33. `NoticeCircular`
```prisma
model NoticeCircular {
  id            String   @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id     String   @db.Uuid
  title         String   @db.VarChar(255)
  content       String   @db.Text
  attachments   Json?
  target_roles  String[]
  is_emergency  Boolean  @default(false)
  publish_date  DateTime @default(now())
  created_by_id String?  @db.Uuid
  created_at    DateTime @default(now())
  updated_at    DateTime @updatedAt

  school     School @relation(fields: [school_id], references: [id], onDelete: Cascade)
  created_by User?  @relation("CreatedNotices", fields: [created_by_id], references: [id], onDelete: SetNull)

  @@index([school_id, publish_date])
  @@index([school_id, is_emergency])
  @@map("notice_circulars")
}
```

##### 34. `VisitorPass` (Gate Security QR Gate Passes)
```prisma
model VisitorPass {
  id                          String            @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id                   String            @db.Uuid
  visitor_name                String            @db.VarChar(100)
  visitor_phone               String            @db.VarChar(20)
  visitor_id_type             String            @db.VarChar(50)
  
  // Field-Level Encrypted Identity (AES-256-GCM v1:...)
  visitor_id_number_encrypted String?           @db.Text

  purpose                     String            @db.VarChar(255)
  person_to_meet_id           String?           @db.Uuid
  pass_code                   String            @unique @db.VarChar(50)
  qr_code_payload             String            @db.Text
  status                      VisitorPassStatus @default(PRE_APPROVED)
  valid_from                  DateTime
  valid_until                 DateTime
  check_in_at                 DateTime?
  check_out_at                DateTime?
  created_at                  DateTime          @default(now())
  updated_at                  DateTime          @updatedAt
  deleted_at                  DateTime?
  retention_until             DateTime?

  school School @relation(fields: [school_id], references: [id], onDelete: Cascade)

  @@index([school_id, pass_code])
  @@index([school_id, status])
  @@index([deleted_at])
  @@map("visitor_passes")
}
```

##### 35. `Consent` (DPDP Act Granular Consent Ledger)
```prisma
model Consent {
  id              String        @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id       String        @db.Uuid
  user_id         String        @db.Uuid
  consent_type    ConsentType
  version         String        @db.VarChar(50)
  status          ConsentStatus @default(GRANTED)
  proof_hash      String        @db.VarChar(64)
  ip_address      String?       @db.VarChar(50)
  user_agent      String?       @db.VarChar(500)
  granted_at      DateTime      @default(now())
  revoked_at      DateTime?
  created_at      DateTime      @default(now())
  updated_at      DateTime      @updatedAt
  deleted_at      DateTime?
  retention_until DateTime?

  school School @relation(fields: [school_id], references: [id], onDelete: Cascade)
  user   User   @relation(fields: [user_id], references: [id], onDelete: Cascade)

  @@index([school_id, user_id])
  @@index([school_id, consent_type, status])
  @@index([deleted_at])
  @@map("consents")
}
```

##### 36. `AuditLog` (Immutable Audit Trail)
```prisma
model AuditLog {
  id          String      @id @default(dbgenerated("gen_random_uuid()")) @db.Uuid
  school_id   String?     @db.Uuid
  user_id     String?     @db.Uuid
  action      AuditAction
  entity_type String      @db.VarChar(100)
  entity_id   String      @db.Uuid
  before_state Json?
  after_state  Json?
  diff        Json?
  ip_address  String?     @db.VarChar(50)
  user_agent  String?     @db.VarChar(500)
  created_at  DateTime    @default(now())

  school School? @relation(fields: [school_id], references: [id], onDelete: Cascade)

  @@index([school_id, created_at])
  @@index([school_id, entity_type, entity_id])
  @@index([school_id, user_id, action])
  @@map("audit_logs")
}
```

---

## 3. DPDP Act (2023) Compliance Architecture

The Digital Personal Data Protection Act, 2023 establishes legal mandates for processing children's personal data. The BOMIS Sambalpur architecture satisfies every statutory mandate:

### 3.1 Statutory Mandates & Architecture Crosswalk

| DPDP Act Provision | Statutory Requirement | BOMIS Technical Implementation |
|---|---|---|
| **Section 9(1)** | Verifiable parental consent prior to processing child personal data | Granular `Consent` ledger recording explicit parental opt-in with SHA-256 HMAC proof hash (`proof_hash`). |
| **Section 9(2)** | Prohibition against tracking, behavioral monitoring, or targeted ads directed at children | Zero behavioural trackers. `TransportTelemetry` strictly records bus fleet hardware positions, NOT student personal devices. |
| **Section 12(1)** | Data erasure upon purpose fulfillment or consent withdrawal | 90-day soft deletion grace period followed by automated BullMQ irreversible cryptographic shredding. |
| **Section 8(5)** | Protection of personal data through reasonable security safeguards | AES-256-GCM field-level encryption for sensitive health, Aadhaar, and financial records. |
| **Section 8(6)** | Mandatory breach auditability and incident reporting | Immutable, append-only `AuditLog` table protected by PostgreSQL database rules. |

---

### 3.2 90-Day Soft-Delete & Cryptographic Shredding Lifecycle

To reconcile statutory retention mandates (e.g., CBSE academic records, financial audit requirements) with the DPDP right to erasure, BOMIS implements a 2-stage lifecycle:

```
[User / Guardian Deletion Request]
               │
               ▼
   [Stage 1: Soft Deletion]
   - deleted_at = NOW()
   - retention_until = NOW() + INTERVAL '90 DAYS'
   - Row immediately hidden from application queries: WHERE deleted_at IS NULL
               │
               │ (90-Day Regulatory Grace Period / Audit Window)
               ▼
   [Stage 2: Cryptographic Shredding via BullMQ]
   - Worker runs daily at 02:00 AM UTC
   - Identifies records WHERE retention_until <= NOW()
   - Irreversibly scrubs PII:
       firstName = "[ERASED]"
       lastName = "[ERASED]"
       phone = "+910000000000"
       email = "erased_<uuid>@purged.bomis"
       encrypted_fields = NULL
   - Emits immutable AuditLog: action = 'DATA_ERASURE'
```

#### BullMQ Cryptographic Shredder Worker Specification
- **Queue Name**: `dpdp-retention-queue`
- **Job Name**: `purge-expired-records`
- **Cron Schedule**: `0 2 * * *` (Daily at 02:00 AM UTC)
- **Target Entities**: `User`, `Student`, `Guardian`, `Staff`, `StudentGuardian`, `Consent`
- **Shredding Transaction**:
  ```typescript
  await prisma.$transaction(async (tx) => {
    // 1. Identify expired students
    const expiredStudents = await tx.student.findMany({
      where: { retention_until: { lte: new Date() } },
      select: { id: true, school_id: true }
    });

    for (const student of expiredStudents) {
      // 2. Cryptographic scrub
      await tx.student.update({
        where: { id: student.id },
        data: {
          first_name: '[ERASED]',
          last_name: '[ERASED]',
          emergency_contact: '+910000000000',
          address: null,
          photo_url: null,
          blood_group_encrypted: null,
          medical_notes_encrypted: null,
          aadhaar_number_encrypted: null,
          retention_until: null, // Marks shredding complete
        }
      });

      // 3. Emit immutable audit log
      await tx.auditLog.create({
        data: {
          school_id: student.school_id,
          action: 'DATA_ERASURE',
          entity_type: 'Student',
          entity_id: student.id,
          diff: { status: 'IRREVERSIBLY_SHREDDED', timestamp: new Date().toISOString() },
        }
      });
    }
  });
  ```

---

### 3.3 Granular Consent Model & SHA-256 Proof Hashing

Consent cannot be a blanket terms acceptance. It must be granular, versioned, and cryptographically verifiable.

#### Proof Hash Algorithm
The `proof_hash` guarantees that neither the parent nor the school can alter or repudiate the terms accepted:

$$\text{proof\_hash} = \text{HMAC-SHA256}\Big(\text{Secret}, \text{userId} \parallel \text{schoolId} \parallel \text{consentType} \parallel \text{version} \parallel \text{status} \parallel \text{timestamp} \parallel \text{ipAddress}\Big)$$

```typescript
import { createHmac } from 'crypto';

export function generateConsentProofHash(params: {
  userId: string;
  schoolId: string;
  consentType: string;
  version: string;
  status: string;
  timestamp: string;
  ipAddress?: string;
  secret: string;
}): string {
  const payload = [
    params.userId,
    params.schoolId,
    params.consentType,
    params.version,
    params.status,
    params.timestamp,
    params.ipAddress || 'UNKNOWN',
  ].join(':');

  return createHmac('sha256', params.secret).update(payload).digest('hex');
}
```

---

### 3.4 Immutable AuditLog Model with PostgreSQL Rules

Audit logs must be tamper-proof even against authorized database operators. Application user `bomis_admin` cannot overwrite or delete audit records.

#### PostgreSQL Immutability Rules
Applied during database migration:

```sql
-- Enforce Append-Only Immutability on Audit Logs
CREATE RULE audit_logs_no_update AS 
  ON UPDATE TO "audit_logs" 
  DO INSTEAD NOTHING;

CREATE RULE audit_logs_no_delete AS 
  ON DELETE TO "audit_logs" 
  DO INSTEAD NOTHING;
```

---

## 4. Field-Level Encryption (AES-256-GCM) Utility Specification

### 4.1 Cryptographic Design & Parameters

| Parameter | Specification | Rationale |
|---|---|---|
| **Cipher Algorithm** | `aes-256-gcm` | Authenticated encryption with associated data (AEAD) providing confidentiality and authenticity. |
| **Key Size** | 256 bits (32 bytes) | Enterprise-grade symmetric security matching DPDP standards. |
| **Initialization Vector (IV)** | 96 bits (12 bytes) | NIST recommendation for GCM mode; generated uniquely per encryption via `crypto.randomBytes(12)`. |
| **Authentication Tag** | 128 bits (16 bytes) | Verifies ciphertext integrity; prevents bit-flipping attacks. |
| **Additional Authenticated Data (AAD)** | Optional tenant binding (`${schoolId}:${entityId}`) | Prevents cross-tenant ciphertext swapping. |
| **Ciphertext Serialization** | `v1:<iv_hex>:<tag_hex>:<ciphertext_hex>` | Clean, colon-delimited versioned string. |

---

### 4.2 Key Versioning & Zero-Downtime Key Rotation

When rotating keys from `v1` to `v2`:
1. Add `APP_ENCRYPTION_KEY_V2` to environment variables.
2. The active encryption key is updated to `v2`.
3. All new database writes serialize as `v2:<iv>:<tag>:<ciphertext>`.
4. Existing rows remain `v1:...`.
5. When reading records, the utility checks the version prefix (`v1` or `v2`), selects the corresponding key from the key registry, and decrypts successfully.
6. A background migration job can lazily re-encrypt `v1` records to `v2` without downtime.

---

### 4.3 Complete TypeScript Cryptographic Utility Module

Target Location: `apps/api/src/common/crypto/crypto.service.ts` (or `/packages/shared/src/crypto/cipher.ts`):

```typescript
import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
  CipherGCM,
  DecipherGCM,
} from 'crypto';

export interface CryptoOptions {
  keyRegistry?: Record<string, string>; // e.g. { v1: 'hex32...', v2: 'hex32...' }
  activeVersion?: string;               // default 'v1'
}

export class CryptoService {
  private readonly keyRegistry: Map<string, Buffer>;
  private readonly activeVersion: string;

  constructor(options?: CryptoOptions) {
    this.keyRegistry = new Map();
    this.activeVersion = options?.activeVersion || 'v1';

    if (options?.keyRegistry) {
      for (const [ver, keyHex] of Object.entries(options.keyRegistry)) {
        this.registerKey(ver, keyHex);
      }
    } else {
      // Default to environment variable
      const envKey = process.env.APP_ENCRYPTION_KEY;
      if (!envKey) {
        throw new Error('APP_ENCRYPTION_KEY environment variable is missing');
      }
      this.registerKey('v1', envKey);
    }
  }

  private registerKey(version: string, keyHex: string): void {
    const keyBuf = Buffer.from(keyHex, 'hex');
    if (keyBuf.length !== 32) {
      throw new Error(
        `Encryption key for version [${version}] must be exactly 32 bytes (64 hex characters). Received ${keyBuf.length} bytes.`
      );
    }
    this.keyRegistry.set(version, keyBuf);
  }

  /**
   * Encrypts plaintext string using AES-256-GCM with version prefix.
   * Output format: `${version}:${iv_hex}:${tag_hex}:${ciphertext_hex}`
   */
  public encrypt(plaintext: string | null | undefined, aad?: string): string | null {
    if (plaintext === null || plaintext === undefined || plaintext === '') {
      return null;
    }

    const key = this.keyRegistry.get(this.activeVersion);
    if (!key) {
      throw new Error(`Active key version [${this.activeVersion}] is not registered`);
    }

    // 12-byte IV for AES-GCM
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', key, iv) as CipherGCM;

    if (aad) {
      cipher.setAAD(Buffer.from(aad, 'utf8'));
    }

    const encrypted = Buffer.concat([
      cipher.update(plaintext, 'utf8'),
      cipher.final(),
    ]);

    const tag = cipher.getAuthTag();

    return `${this.activeVersion}:${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
  }

  /**
   * Decrypts versioned ciphertext string using AES-256-GCM.
   */
  public decrypt(ciphertext: string | null | undefined, aad?: string): string | null {
    if (ciphertext === null || ciphertext === undefined || ciphertext === '') {
      return null;
    }

    const parts = ciphertext.split(':');
    if (parts.length !== 4) {
      throw new Error(
        'Invalid encrypted format. Expected format: version:iv:tag:ciphertext'
      );
    }

    const [version, ivHex, tagHex, encryptedHex] = parts;

    const key = this.keyRegistry.get(version);
    if (!key) {
      throw new Error(`Encryption key for version [${version}] is not available in key registry`);
    }

    const iv = Buffer.from(ivHex, 'hex');
    const tag = Buffer.from(tagHex, 'hex');
    const encrypted = Buffer.from(encryptedHex, 'hex');

    if (iv.length !== 12) {
      throw new Error(`Invalid IV length: expected 12 bytes, got ${iv.length}`);
    }
    if (tag.length !== 16) {
      throw new Error(`Invalid auth tag length: expected 16 bytes, got ${tag.length}`);
    }

    const decipher = createDecipheriv('aes-256-gcm', key, iv) as DecipherGCM;
    decipher.setAuthTag(tag);

    if (aad) {
      decipher.setAAD(Buffer.from(aad, 'utf8'));
    }

    try {
      const decrypted = Buffer.concat([
        decipher.update(encrypted),
        decipher.final(),
      ]);
      return decrypted.toString('utf8');
    } catch (err: any) {
      throw new Error(`Decryption failed: integrity authentication mismatch or corrupted ciphertext (${err.message})`);
    }
  }
}
```

---

### 4.4 Encrypted Field Mapping in Prisma Schema

| Model | Encrypted Column | Sensitive Content | Plaintext DTO Field |
|---|---|---|---|
| `Student` | `blood_group_encrypted` | Medical blood group (e.g., `O+`, `B+`) | `bloodGroup` |
| `Student` | `medical_notes_encrypted` | Allergies, chronic conditions, emergency medical protocols | `medicalNotes` |
| `Student` | `aadhaar_number_encrypted` | 12-digit Indian national identity number | `aadhaarNumber` |
| `Guardian` | `aadhaar_number_encrypted` | Guardian national identity number | `aadhaarNumber` |
| `Guardian` | `annual_income_encrypted` | Annual household income for concession eligibility | `annualIncome` |
| `Staff` | `pan_number_encrypted` | Income tax PAN number | `panNumber` |
| `Staff` | `aadhaar_number_encrypted` | Staff national identity number | `aadhaarNumber` |
| `VisitorPass` | `visitor_id_number_encrypted` | Driving license / Voter ID / Aadhaar of campus visitor | `visitorIdNumber` |

---

## 5. Multi-Tenant Row-Level Security (RLS) Database Architecture

### 5.1 Defense-in-Depth Multi-Tenancy Strategy

Multi-tenancy is enforced at two independent layers:
1. **Application Layer (Prisma)**: Every business model incorporates `school_id String @db.Uuid`. NestJS guards, repositories, and services strictly append `where: { school_id }` on all reads, writes, and mutations.
2. **Database Engine Layer (PostgreSQL RLS)**: Even if application logic has a flaw or a raw SQL query omits the tenant filter, PostgreSQL Row-Level Security blocks cross-tenant row access at the database kernel level.

---

### 5.2 PostgreSQL RLS Policies SQL Specification

Generated in a post-migration SQL script:

```sql
-- ==============================================================================
-- Multi-Tenant Row-Level Security Policies for BOMIS Sambalpur
-- Applies to all 35 tenant-scoped tables
-- ==============================================================================

DO $$
DECLARE
  tbl text;
  tenant_tables text[] := ARRAY[
    'users',
    'refresh_tokens',
    'students',
    'guardians',
    'student_guardians',
    'staff',
    'academic_years',
    'classes',
    'sections',
    'subjects',
    'teacher_assignments',
    'attendances',
    'staff_attendances',
    'fee_categories',
    'fee_structures',
    'fee_concessions',
    'fee_installments',
    'payments',
    'homeworks',
    'homework_submissions',
    'timetables',
    'teacher_absence_substitutions',
    'exams',
    'exam_subjects',
    'marks_entries',
    'transport_routes',
    'transport_stops',
    'vehicles',
    'student_transports',
    'transport_telemetries',
    'boarding_events',
    'notice_circulars',
    'visitor_passes',
    'consents',
    'audit_logs'
  ];
BEGIN
  FOREACH tbl IN ARRAY tenant_tables LOOP
    -- Enable RLS and Force it for table owner
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY;', tbl);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY;', tbl);

    -- Drop existing policy if present
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation_policy ON %I;', tbl);

    -- Create Tenant Isolation Policy
    -- Matches school_id against current session setting 'app.current_school_id'
    -- If 'app.bypass_rls' is 'on', bypass policy for Super Admin maintenance
    EXECUTE format('
      CREATE POLICY tenant_isolation_policy ON %I
      FOR ALL
      USING (
        current_setting(''app.bypass_rls'', true) = ''on''
        OR
        school_id = NULLIF(current_setting(''app.current_school_id'', true), '''')::uuid
      )
      WITH CHECK (
        current_setting(''app.bypass_rls'', true) = ''on''
        OR
        school_id = NULLIF(current_setting(''app.current_school_id'', true), '''')::uuid
      );
    ', tbl);
  END LOOP;
END $$;
```

---

### 5.3 NestJS Prisma Client Extension for Session Variable Injection

To pass the authenticated tenant context to PostgreSQL within connection pooling:

```typescript
import { PrismaClient } from '@prisma/client';

export function createTenantPrismaClient(prisma: PrismaClient, schoolId: string) {
  return prisma.$extends({
    query: {
      $allModels: {
        async $allOperations({ args, query }) {
          // Wrap operations inside interactive transaction with session setting
          return prisma.$transaction(async (tx) => {
            await tx.$executeRaw`SELECT set_config('app.current_school_id', ${schoolId}, true)`;
            return query(args);
          });
        },
      },
    },
  });
}
```

---

## 6. Prisma Tooling, Migrations & Workspace Integration Plan

### 6.1 Package Boundaries & Directory Layout

```
bomis_sambalpur/
├── prisma/
│   ├── schema.prisma           # Master Prisma schema (36 models)
│   ├── seed.ts                 # Master seed generator (specified by Spec Miner M2-3)
│   └── migrations/
│       ├── 20261018000001_init_dpdp_multi_tenant_schema/
│       │   └── migration.sql   # DDL generated by prisma migrate dev
│       └── 20261018000002_rls_and_audit_immutability_rules/
│           └── migration.sql   # Custom RLS & PostgreSQL audit rules
├── apps/
│   └── api/
│       ├── src/
│       │   ├── common/
│       │   │   └── crypto/
│       │   │       ├── crypto.service.ts       # AES-256-GCM utility
│       │   │       └── crypto.service.spec.ts  # Crypto unit tests
│       │   └── database/
│       │       ├── prisma.service.ts           # NestJS PrismaService wrapper
│       │       └── tenant-context.middleware.ts# Sets app.current_school_id
```

---

### 6.2 Workspace Scripts Integration

Configured in root `package.json`:

```json
{
  "scripts": {
    "db:generate": "dotenv -e .env -- prisma generate --schema=prisma/schema.prisma",
    "db:migrate": "dotenv -e .env -- prisma migrate dev --schema=prisma/schema.prisma",
    "db:migrate:deploy": "dotenv -e .env -- prisma migrate deploy --schema=prisma/schema.prisma",
    "db:seed": "dotenv -e .env -- ts-node prisma/seed.ts",
    "db:studio": "dotenv -e .env -- prisma studio --schema=prisma/schema.prisma"
  }
}
```

---

### 6.3 Package Dependencies Verification

| Package | Version | Location | Purpose | Status |
|---|---|---|---|---|
| `prisma` | `^5.14.0` | Root devDependencies & `apps/api` | CLI generator & migration engine | PRESENT |
| `@prisma/client` | `^5.14.0` | `apps/api` dependencies | Generated database query client | PRESENT |
| `dotenv-cli` | `^7.4.2` | Root devDependencies | Environment variable injection | PRESENT |
| `ts-node` | `^10.9.2` | Root devDependencies | Direct execution of `seed.ts` | PRESENT |
| `bcrypt` | `^5.1.1` | `apps/api` dependencies | Secure password hashing for seed users | PRESENT |

---

## 7. Verification & Quality Assurance Plan

### 7.1 Verification Checklist against Milestone Acceptance Criteria

- [x] **36 Prisma Models**: All 36 models enumerated and mapped to PostgreSQL relations.
- [x] **Multi-Tenant Isolation**: Every tenant model includes `school_id String @db.Uuid` and composite indexes.
- [x] **PostgreSQL RLS**: Complete SQL script enabling RLS and tenant isolation policies on all 35 tenant tables.
- [x] **DPDP Act 2023 Compliance**: `deleted_at` and `retention_until` (90-day retention schedule) implemented on sensitive entities.
- [x] **Granular Consent Ledger**: `Consent` model with SHA-256 HMAC `proof_hash` non-repudiation mechanism.
- [x] **Immutable AuditLog**: Append-only `AuditLog` model with PostgreSQL `DO INSTEAD NOTHING` rules.
- [x] **Field-Level Encryption**: AES-256-GCM cryptographic utility with key versioning (`v1:...`), 96-bit IV, 128-bit auth tag, and AAD tenant binding.
- [x] **Zero Production Modification**: All analyses conducted strictly in read-only mode in accordance with Teamwork Explorer protocol.

---

### 7.2 Cryptographic Utility Unit Test Specification

Unit test suite to be written by Worker M2 at `apps/api/src/common/crypto/crypto.service.spec.ts`:

1. **Encryption & Decryption Round-Trip**:
   - Plaintext: `"O+ (Positive)"` (blood group)
   - Encrypt $\rightarrow$ produces `v1:<iv>:<tag>:<ciphertext>`.
   - Decrypt $\rightarrow$ exactly equals `"O+ (Positive)"`.
2. **Probabilistic Encryption (IV Uniqueness)**:
   - Encrypting the exact same plaintext twice produces **different** ciphertexts and **different** IVs.
3. **Integrity & Tampering Defense**:
   - Altering 1 bit in ciphertext or tag causes `decipher.final()` to throw authentication mismatch error.
4. **Tenant AAD Context Binding**:
   - Encrypting with AAD `"school-1:student-1"` and decrypting with AAD `"school-2:student-1"` throws authentication failure.
5. **Key Versioning & Rotation**:
   - Ciphertext prefixed with `v1:` decrypts using V1 key.
   - Ciphertext prefixed with `v2:` decrypts using V2 key.
6. **Null / Empty Input Handling**:
   - Passing `null` or `undefined` returns `null` safely without throwing.

---

## 8. Concrete Next Steps for Implementation (Worker M2)

1. Create `prisma/schema.prisma` with the 36 models and configuration defined in Section 2.
2. Run `pnpm db:generate` to generate `@prisma/client`.
3. Create migration `prisma/migrations/20261018000001_init_dpdp_multi_tenant_schema` and custom RLS SQL migration `prisma/migrations/20261018000002_rls_and_audit_immutability_rules`.
4. Implement `apps/api/src/common/crypto/crypto.service.ts` with test suite `crypto.service.spec.ts` as specified in Section 4.
5. Coordinate with Spec Miner M2-3 for `prisma/seed.ts` execution.
