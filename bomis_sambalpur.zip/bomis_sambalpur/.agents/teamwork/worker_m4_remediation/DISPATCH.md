## 2026-10-20T07:22:05Z
You are worker_m4_remediation (Milestone M4 Remediation Worker).
Your working directory is C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m4_remediation.
Your orchestrator conversation ID is 61cb1a70-f093-4eb1-8970-0e6aa09a7e37.

You MUST read the following authoritative documents before starting your work:
- ORIGINAL_REQUEST: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
- PROJECT: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
- GATE STATUS: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen5\GATE_STATUS.md
- CHALLENGER 1 FINDINGS: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\challenger_m4_1\handoff.md
- CHALLENGER 2 FINDINGS: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\challenger_m4_2\handoff.md
- REVIEWER 2 REPORT: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\reviewer_m4_2\handoff.md

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

SCOPE OF REMEDIATION (Target package: apps/web):
You own exclusive write permissions for files under `apps/web/`. Implement the following 6 targeted fixes:

1. Multi-Child State Isolation & Fee Checkout Idempotency:
   - In `apps/web/src/app/(dashboard)/parent/page.tsx`, mount child-scoped components with `key={activeChild.id}`:
     `<AttendanceCalendarCard key={`att-${activeChild.id}`} childName={childFullName} childId={activeChild.id} />`
     `<RazorpayCheckoutModal key={`fee-${activeChild.id}`} studentName={childFullName} studentId={activeChild.id} />`
     `<LiveBusTracker key={`bus-${activeChild.id}`} childName={activeChild.firstName} />`
     `<PickupOtpCard key={`otp-${activeChild.id}`} childName={childFullName} childId={activeChild.id} />`
   - In `apps/web/src/components/modules/parent/razorpay-checkout-modal.tsx`:
     - Add `useEffect` resetting `isTerm2Paid(false)` and `paymentSuccess(null)` when `studentId` prop changes.
     - Add in-flight double-click guard: `if (isProcessing) return;` at the very start of `handleStartPayment`.
     - Generate RFC 4122 compliant UUID for `idempotencyKey` using `crypto.randomUUID()` (or standard RFC 4122 v4 UUID generator).
     - Differentiate live API HTTP 4xx/5xx rejections from offline simulation (do NOT mark `isTerm2Paid(true)` on API error).

2. Fail-Closed Route Protection in Edge Middleware (`apps/web/src/middleware.ts`):
   - In line 111, change:
     `if (userRole && allowedRoles && !allowedRoles.includes(userRole))`
     to fail-closed logic:
     `if (!userRole || (allowedRoles && !allowedRoles.includes(userRole))) { const userDashboard = userRole ? (DEFAULT_ROLE_REDIRECT[userRole] || '/parent') : '/login'; return NextResponse.redirect(new URL(userDashboard, request.url)); }`

3. Dismissal OTP Lifecycle & Expiry (`apps/web/src/components/modules/parent/pickup-otp-card.tsx`):
   - Set initial `secondsRemaining` to `1800` (30 minutes).
   - Implement status lifecycle: `type OtpStatus = 'ACTIVE' | 'USED' | 'EXPIRED'`.
   - When `secondsRemaining === 0`, update status to `'EXPIRED'`, render `<Badge variant="destructive">Expired</Badge>`, blur or hide the code, and show "Regenerate Single-Use OTP" CTA.
   - Add a "Simulate Gate Pickup Verification" action that sets status to `'USED'`, invalidating the OTP with `<Badge variant="secondary">Dismissed / Picked Up</Badge>`.
   - Key OTP by child or accept `childId` prop so siblings have independent OTP states.

4. Bus Telemetry 30s Polling, Lat/Lng & Speed Alert (`apps/web/src/components/modules/principal/bus-telemetry-widget.tsx`):
   - Update `BusTelemetry` interface to include `lat: number; lng: number;` and render GPS coordinates (e.g. `21.4669° N, 83.9812° E`).
   - Add speed threshold check (>50 km/h) rendering an alert badge (`Speed Alert (>50 km/h)`) when `bus.speed > 50`.
   - Add TanStack `useQuery` with `refetchInterval: 30000` consuming `transportApi.getBuses()` with fallback to pilot bus defaults.
   - Ensure fleet plates match pilot fleet: `OD-15-AB-1001`, `OD-15-AB-1002`, `OD-15-AC-2001`, `OD-15-AC-2002`.

5. CBSE Marks Entry Input Bounds & API Error Handling (`apps/web/src/components/modules/teacher/cbse-marks-entry.tsx`):
   - In `calculateCbseGrade(totalMarks)`: guard against `totalMarks > 100` (cap at 100) and `totalMarks < 0` (cap at 0).
   - In `updateMarks()`: clamp input values against component upper limits:
     `periodicTest`: `Math.min(10, Math.max(0, val))`
     `notebook`: `Math.min(5, Math.max(0, val))`
     `subjectEnrichment`: `Math.min(5, Math.max(0, val))`
     `examMarks`: `Math.min(80, Math.max(0, val))`
   - In `handleSaveBatch`: display error feedback on API error rather than false success.

6. Rapid Attendance 40-Student Roster & IST Date (`apps/web/src/components/modules/teacher/rapid-attendance-grid.tsx`):
   - Provide full 40-student mock roster in `INITIAL_ROSTER_5A` (Rolls 1 to 40).
   - Compute attendance date in IST / local calendar format (`YYYY-MM-DD`, e.g. `new Date().toLocaleDateString('en-CA')`).

VERIFICATION & DELIVERABLES:
1. Verify all modified components and run existing unit/challenger tests (`apps/web/src/tests/m4-challenger.spec.ts`, `apps/web/src/lib/academic-financial.challenge.spec.ts`, `apps/web/src/lib/utils.spec.ts`).
2. Write your full handoff report to:
   C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m4_remediation\handoff.md
3. Send a message to orchestrator (61cb1a70-f093-4eb1-8970-0e6aa09a7e37) upon completion.
