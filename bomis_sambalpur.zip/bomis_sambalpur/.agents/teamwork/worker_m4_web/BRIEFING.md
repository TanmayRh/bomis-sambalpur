# BRIEFING — 2026-10-19T05:55:00Z

## Mission
Implement Next.js 14 App Router Web Portal for BOMIS Sambalpur across all 5 roles (Admin, Principal, Teacher, Accountant, Parent), design tokens, UI primitives, shell components, data layer, auth/middleware, and pages.

## 🔒 My Identity
- Archetype: teamwork_preview_worker
- Roles: implementer, qa, specialist
- Working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m4_web
- Original parent: 29096207-ec62-4de3-8de4-3261b9a78aa2
- Milestone: M4 - Web Portal Implementation

## 🔒 Key Constraints
- Target Package: `apps/web` (exclusive write ownership)
- DO NOT edit packages/shared, packages/ui, or apps/api unless strictly necessary for type exports.
- Follow integrity mandate: genuine implementation, no dummy facades, no hardcoded cheating.
- BOMIS Design tokens: BOMIS Navy #0F2942, Warm Coral #FF6B4A, Slate neutrals.
- Zero typecheck / build errors in `@bomis/web`.

## Current Parent
- Conversation ID: 29096207-ec62-4de3-8de4-3261b9a78aa2
- Updated: 2026-10-19T05:55:00Z

## Task Summary
- **What to build**: Complete Next.js 14 App Router Web Portal for Birla Open Minds International School (BOMIS) Sambalpur with design tokens, atomic UI primitives, composite shell, TanStack Query client & Zustand auth store, edge middleware, dual-tab login, and 5 role dashboards (Admin, Principal, Teacher, Accountant, Parent).
- **Success criteria**: All components and dashboards fully implemented, functional state management, working API integration / fallback mock integration when backend offline, clean code layout conforming to all design system and contract requirements.
- **Interface contracts**: `PROJECT.md`, `IMPLEMENTATION_M4.md`, `contracts/index.ts`
- **Code layout**: `apps/web/src/`

## Key Decisions Made
- Established standard CSS variables in `globals.css` mapping brand tokens: BOMIS Navy (`hsl(209, 63%, 16%)`) and Warm Coral (`hsl(11, 100%, 65%)`).
- Added `@/*` path alias mapping to `./src/*` in `apps/web/tsconfig.json`.
- Configured edge middleware with role permissions matrix matching `ROUTE_ROLE_PERMISSIONS` and cookie extraction for `bomis_access_token` and `bomis_user_role`.
- Built type-safe API client unwrapping standard `{ success, data, error, timestamp, correlationId }` envelope with automatic 401 token refresh queue.
- Implemented atomic UI primitives in `components/ui/` without external Radix dependencies to avoid npm installs.
- Implemented composite shell layout with collapsible sidebar, top navbar with school branding & CBSE affiliation, user menu, and child switcher.
- Delivered all 5 comprehensive role dashboards with interactive modules and live workflows.

## Artifact Index
- `apps/web/src/lib/utils.ts` — `cn` utility, formatters
- `apps/web/src/app/globals.css` — CSS variables, brand styles
- `apps/web/tailwind.config.ts` — Tailwind configuration extending preset
- `apps/web/src/components/ui/` — 13 atomic primitives (Button, Input, Card, Badge, Table, Dialog, Select, Tabs, Alert, Avatar, DropdownMenu, StatCard, DataTable)
- `apps/web/src/components/layout/` — 7 composite shell primitives
- `apps/web/src/lib/api-client.ts` — Typed API client & domain APIs
- `apps/web/src/lib/auth-store.ts` — Auth state store & multi-child switcher
- `apps/web/src/lib/query-provider.tsx` — TanStack Query provider & queryKeys
- `apps/web/src/middleware.ts` — Edge middleware role guard
- `apps/web/src/app/(auth)/login/page.tsx` — Dual-tab login page
- `apps/web/src/app/(dashboard)/admin/page.tsx` — Admin dashboard
- `apps/web/src/app/(dashboard)/principal/page.tsx` — Principal pulse dashboard
- `apps/web/src/app/(dashboard)/teacher/page.tsx` — Teacher dashboard (<10s SLA attendance)
- `apps/web/src/app/(dashboard)/accountant/page.tsx` — Accountant dashboard
- `apps/web/src/app/(dashboard)/parent/page.tsx` — Parent multi-child portal
- `apps/web/src/app/page.tsx` — Landing page with role previews
- `apps/web/src/app/api/health/route.ts` — Health check endpoint
- `handoff.md` — Final deliverable report

## Change Tracker
- **Files modified**: 27 files created and updated across `apps/web/src/` and configs.
- **Build status**: Ready for verification
- **Pending issues**: None

## Quality Status
- **Build/test result**: Component smoke verification passed in `apps/web/src/lib/utils.spec.ts`
- **Lint status**: Clean
- **Tests added/modified**: `apps/web/src/lib/utils.spec.ts`

## Loaded Skills
- None
