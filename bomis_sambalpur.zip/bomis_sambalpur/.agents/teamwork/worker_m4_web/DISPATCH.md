# Dispatch: Worker M4 (Web Portal Implementation)

## 🔒 Task Assignment
- **Agent Name**: worker_m4_web
- **Archetype**: teamwork_preview_worker
- **Target Package**: `apps/web` (exclusive write ownership)
- **Role**: Implement Next.js 14 App Router Web Portal for BOMIS Sambalpur
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m4_web`
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Parent Conversation ID**: `29096207-ec62-4de3-8de4-3261b9a78aa2`

---

## Authoritative Inputs & Blueprints
1. `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md` (Authoritative user requirements)
2. `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md` (Project master specification)
3. `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen4\IMPLEMENTATION_M4.md` (Consolidated M4 Blueprint)
4. `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m4_1\handoff.md` (UI primitives, design tokens & design system)
5. `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_1\handoff.md` (App Router structure, middleware, API client, auth store)
6. `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_2\handoff.md` (5 role dashboards, form validations, data tables)

---

## 🔒 Mandatory Integrity Warning
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

---

## Scope & Implementation Deliverables
You have exclusive write ownership of `apps/web`. Implement the complete web portal:
1. **Design Tokens & Tailwind Setup**:
   - `apps/web/src/lib/utils.ts` (`cn()` using `twMerge` + `clsx`)
   - `apps/web/src/app/globals.css` (CSS variables for BOMIS Navy `#0F2942`, Warm Coral `#FF6B4A`, Slate neutrals)
   - `apps/web/tailwind.config.ts` (configured with `@bomis/ui` preset and CSS variables)
2. **Atomic UI Primitives (`apps/web/src/components/ui/`)**:
   - `button.tsx`, `input.tsx`, `card.tsx`, `badge.tsx`, `table.tsx`, `dialog.tsx`, `select.tsx`, `tabs.tsx`, `alert.tsx`, `avatar.tsx`, `dropdown-menu.tsx`
3. **Composite Shell Primitives (`apps/web/src/components/layout/`)**:
   - `dashboard-shell.tsx`, `sidebar.tsx`, `top-navbar.tsx`, `user-nav.tsx`, `child-switcher.tsx`, `stat-card.tsx`, `data-table.tsx`
4. **Data Layer & Middleware**:
   - `apps/web/src/lib/api-client.ts` (Typed API client consuming NestJS `/api/v1` with standard ApiResponse envelope unwrapping and 401 token refresh queue)
   - `apps/web/src/lib/auth-store.ts` (Zustand auth store with token cookies sync and active child switcher for Aarav & Ananya Patel)
   - `apps/web/src/lib/query-provider.tsx` (TanStack Query client and centralized `queryKeys`)
   - `apps/web/src/middleware.ts` (Edge middleware protecting `/admin`, `/principal`, `/teacher`, `/accountant`, `/parent` based on user role)
5. **Role Dashboards & Module Widgets (`apps/web/src/app/(dashboard)/` and `apps/web/src/components/modules/`)**:
   - **Admin (`/admin`)**: KPI StatCards, Audit Log table (`/api/v1/admin/audit-logs`), Bulk CSV Importer, Visitor Pass tracker
   - **Principal Pulse (`/principal`)**: Pulse KPI cards (`/api/v1/pulse/metrics`), Class attendance breakdown, 4 pilot buses fleet telemetry widget, Substitute teacher allocation quick modal
   - **Teacher (`/teacher`)**: Rapid Attendance Grid (<10s SLA) with 1-click "Mark All Present", exception toggles, batch submission to `POST /api/v1/attendance`, CBSE 9-point marks entry table, Class diary modal
   - **Accountant (`/accountant`)**: Financial KPIs, Fee structure catalog, Concession approvals, Payment transactions ledger with PDF receipt download
   - **Parent (`/parent`)**: Sibling switcher (Aarav Patel Grade 5A vs Ananya Patel Grade 2A), Monthly attendance calendar with CBSE compliance status, Simulated Razorpay checkout modal with mandatory `Idempotency-Key` header, Live bus tracking with 5-minute geofence alert, Child pickup single-use 6-digit OTP card
6. **Auth Pages (`apps/web/src/app/(auth)/login/page.tsx`)**:
   - Dual-tab login: Staff Email/Password login and Parent/Student Phone OTP login
7. **Build & Typecheck Verification**:
   - Verify that `pnpm --filter @bomis/web build` or `pnpm --filter @bomis/web typecheck` passes with zero errors.
   - Run existing or added tests to ensure clean operation.

---

## Output Requirements
When complete, write `handoff.md` in your working directory (`C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m4_web\handoff.md`) with:
1. Observation (Files implemented, lines touched, dependencies used)
2. Logic Chain (Design decisions, role routing, state management, API integration)
3. Verification (Commands executed and full passing results)
4. Caveats & Notes
5. Send a message back to parent (`29096207-ec62-4de3-8de4-3261b9a78aa2`) upon completion.


## 2026-10-19T05:06:20Z
You are Worker M4 (Web Portal Implementation).
Your Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m4_web
Project Root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur
Parent Conversation ID: 29096207-ec62-4de3-8de4-3261b9a78aa2

Read DISPATCH.md in your working directory first.
Read the authoritative user request at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
Read the project master specification at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
Read the M4 implementation blueprint at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen4\IMPLEMENTATION_M4.md
Read the UI & design system spec at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m4_1\handoff.md
Read the architecture & data layer spec at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_1\handoff.md
Read the role dashboards & feature workflows spec at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_2\handoff.md
