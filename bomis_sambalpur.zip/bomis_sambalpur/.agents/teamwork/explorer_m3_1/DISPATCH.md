# Dispatch: Explorer M3-1 (Core Infrastructure & Data Layer)

- Target Agent: teamwork_preview_explorer
- Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_1
- Project Root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur
- Authoritative Sources:
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md (MANDATORY)
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\prisma\schema.prisma
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\prisma\seed.ts
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\infra\postgres\init_rls.sql
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\apps\api\src\common\crypto\crypto.service.ts
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\DEAD_ENDS.md

## 2026-10-18T06:56:54Z
You are Explorer 1 for Milestone M3 (NestJS Modular Monolith API) of the BOMIS Sambalpur Unified School Platform.

Your Working Directory:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_1

Project Root:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur

Dispatch Details:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_1\DISPATCH.md

Authoritative Sources to Read (MANDATORY):
1. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
2. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
3. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md
4. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\prisma\schema.prisma (36 models)
5. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\prisma\seed.ts
6. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\infra\postgres\init_rls.sql
7. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\apps\api\src\common\crypto\crypto.service.ts
8. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\DEAD_ENDS.md

Your Mission:
Investigate and design the Core Infrastructure, Database, and Cryptographic Integration for NestJS (/apps/api):
1. Prisma Service & Module with PostgreSQL Row-Level Security (RLS):
   - Tenant isolation via `app.current_school_id` transaction variable or Prisma extension.
   - Dynamic tenant context injection per request (from JWT or header).
   - Soft-delete extension enforcing `where: { deleted_at: null }` for active queries.
2. Field-Level Encryption Integration:
   - Injecting `CryptoService` (`apps/api/src/common/crypto/crypto.service.ts`) for automatic decryption of sensitive PII fields (`aadhaar_number_encrypted`, `blood_group_encrypted`, etc.) when requested by authorized roles.
3. Database seeding and in-memory mock fallback mode if PostgreSQL/Redis are offline in test/build environments.
4. Logging & Distributed Tracing:
   - Pino structured logger integration with AsyncLocalStorage for `x-correlation-id`.
   - Logging format compliant with enterprise audit standards.
5. BullMQ & Background Worker integration strategy for async tasks (PDF receipts, report cards, DPDP 90-day cryptographic erasure).

Output:
Write your full investigation report to `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_1\analysis.md`.
Write your handoff report to `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_1\handoff.md` with:
- Observation
- Logic Chain
- Caveats
- Conclusion
- Verification Method
Send a completion message with summary and report path back to the orchestrator.
Do NOT modify any source code files.
