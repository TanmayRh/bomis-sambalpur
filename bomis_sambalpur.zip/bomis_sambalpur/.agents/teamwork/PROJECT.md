# Project: BOMIS Sambalpur Unified School Platform

## Architecture
A production-grade, multi-role school operating system for Birla Open Minds International School, Sambalpur (Odisha), replacing fragmented paper/WhatsApp/spreadsheet systems. Built as a high-performance TypeScript monorepo using Turborepo and pnpm workspaces.

```
bomis_sambalpur/
├── apps/
│   ├── api/          # NestJS 10 modular monolith with strict domain modules & Pino logger
│   ├── web/          # Next.js 14 App Router, Tailwind CSS, shadcn/ui primitives, TanStack Query
│   └── mobile/       # React Native (Expo SDK 51+) multi-role app with offline SQLite sync
├── packages/
│   ├── shared/       # Canonical Zod schemas, TypeScript types, 8 RBAC roles, standard envelope
│   └── ui/           # BOMIS brand design tokens (#0F2942 navy, #FF6B4A coral), typography, UI
├── infra/            # Docker Compose (PostgreSQL 16, Redis 7, MinIO, Mailpit), Dockerfiles
└── docs/             # Postman Collections, Newman CI scripts, Architecture Decision Records (ADRs)
```

## Feature Inventory
| # | Feature | Description | Milestone | Source |
|---|---------|-------------|-----------|--------|
| 1 | Turborepo & pnpm workspace | Root monorepo orchestration, task pipelines, caching | M1 | R1 |
| 2 | Docker Compose Dev Infrastructure | PostgreSQL 16, Redis 7, MinIO S3, Mailpit containers | M1 | R1 |
| 3 | Shared Types & Zod Schemas | Canonical data contracts & validation schemas | M2 | R1, AC-1 |
| 4 | Brand Tokens & Shared UI Primitives | #0F2942 Navy & #FF6B4A Coral design tokens | M2 | R1 |
| 5 | Multi-Tenant Data Model | 36 Prisma models with indexed school_id & Postgres RLS | M2 | R2 |
| 6 | DPDP Act Compliance & 90-Day Retention | Soft delete with 90-day retention & cryptographic erasure | M2 | R2 |
| 7 | Field-Level Data Encryption | AES-256-GCM encryption for sensitive health/identity data | M2 | R2 |
| 8 | Immutable Audit Logs | Immutable table logging user actions, mutations, diffs, IPs | M2 | R2 |
| 9 | Realistic Seed Data Generator | Grades 1-8 Section A, 4 pilot buses, teachers, parents | M2 | AC-6 |
| 10 | Standardized Response Envelope | { success, data, error, timestamp, correlationId } | M3 | R1, AC-2 |
| 11 | Global Validation Pipes & Pino Logger | Request correlation IDs via AsyncLocalStorage | M3 | R1 |
| 12 | Swagger OpenAPI & Health Probes | OpenAPI at /api/docs, /health & /ready Terminus probes | M3 | R1 |
| 13 | Mobile OTP & Email Dual Auth | Parents/students mobile OTP, staff email+password/OTP | M3 | R3 |
| 14 | 8-Role RBAC Authorization | 8 distinct roles with granular permission guards | M3 | R3 |
| 15 | Session Lifecycle & Rate Limiting | Rotating refresh tokens, instant revocation, Redis limits | M3 | R3 |
| 16 | People Master Profiles & Siblings | Multi-child linking under single guardian account | M3 | R3 |
| 17 | Streaming Bulk CSV Ingestion | Student/staff bulk import with row validation error logs | M3 | R3 |
| 18 | Rapid Attendance Grid Backend | <10s classroom attendance recording & staff leaves | M3 | R3 |
| 19 | Offline Sync Queue API | /api/v1/sync/batch for offline mobile sync with idempotency | M3 | R3 |
| 20 | Instant FCM Absence Push Alerts | Immediate push notification dispatch on student absence | M3 | R3 |
| 21 | Digital Diary & Homework API | Rich text, MinIO attachments, submission tracking | M3 | R3 |
| 22 | Fee Structures & Concession Approvals | Configurable installments & multi-step approvals | M3 | R3 |
| 23 | Razorpay Payment Gateway Integration | Test mode UPI/Netbanking/Cards, HMAC signature verify | M3 | R3, AC-3 |
| 24 | Financial Idempotency & Reconciliation | Idempotency-Key headers, duplicate payload defense, ledger | M3 | R3, AC-3 |
| 25 | Digital Fee Tax Receipt Generator | Automated PDF receipts via BullMQ worker | M3 | R3 |
| 26 | Timetable Scheduler & Clash Detector | Teacher & room conflict detection, 1-click substitute | M3 | R4 |
| 27 | CBSE Exams & 9-Point Grading Scale | Scholastic A1-E and co-scholastic A-C marks validation | M3 | R4 |
| 28 | Automated CBSE PDF Report Card Worker | BullMQ asynchronous report card generator | M3 | R4 |
| 29 | Transport Fleet Socket.IO Gateway | 4 pilot buses GPS broadcast, geofence 5-min alert | M3 | R4 |
| 30 | Student Boarding/Deboarding QR Scan | Dynamic QR validation for bus transit logging | M3 | R4 |
| 31 | Pre-Approved Visitor Pass Management | Gate pass QR generation & gatekeeper validation | M3 | R5 |
| 32 | Child Pickup Verification | OTP & dynamic QR verification for safe student pickup | M3 | R5 |
| 33 | Anonymous Anti-Bullying Incident Reporting | Zero-log anonymous safety reports | M3 | R5 |
| 34 | DPDP-Compliant Health Records | Access-controlled encrypted student medical records | M3 | R5 |
| 35 | AI Study Buddy & Syllabus Assistant | Grade-appropriate curriculum question answering | M3 | R5 |
| 36 | AI Lesson Planner & Draft Remarks Assist | Teacher assistant with mandatory human review | M3 | R5 |
| 37 | Principal Pulse Real-Time Dashboard API | Live school metrics aggregation | M3 | R5 |
| 38 | Next.js 14 App Router Web Portal | Responsive portal with role-tailored dashboards | M4 | R1, R3, R5 |
| 39 | React Native Expo Mobile App | Offline-first mobile app for Parent, Student, Driver, Teacher | M5 | R1, R3, R4 |
| 40 | 4-Tier E2E Test Suite & Postman Newman CI | Automated Postman collection, Newman CI, >=70% test coverage | E2E | AC-4, AC-5 |

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| M1 | Monorepo Foundation & Tooling | Turborepo, pnpm workspace, root configs, infra/docker-compose.yml | none | DONE |
| M2 | Shared Packages & DPDP Schema | @bomis/shared, @bomis/ui, Prisma 36 models, RLS, seed data | M1 | DONE |
| M3 | NestJS Modular Monolith API | /apps/api core, auth, RBAC, domain modules, BullMQ, Socket.IO | M2 | DONE |
| M4 | Next.js 14 Web Portal | /apps/web, shadcn/ui, role dashboards (Admin, Principal, Teacher, Accountant, Parent) | M2, M3 | DONE |
| M5 | React Native Mobile App | /apps/mobile, Expo, offline SQLite queue, camera QR, driver GPS | M2, M3 | DONE |
| M6 | Final E2E Test Pass & Hardening | Pass 100% E2E tests (Tiers 1-4) then Adversarial Hardening (Tier 5) | M3, M4, M5, E2E | DONE |

## E2E Testing Track (Parallel)
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| E2E | E2E Testing & Postman Newman CI | Test infra, Newman collection /docs/postman, 4-tier test runner, TEST_READY.md | M1, M2 | DONE |

## Interface Contracts

### Standard Response Envelope (NestJS ↔ Frontend/Postman)
All REST API endpoints conform to:
```typescript
export interface ApiResponse<T> {
  success: boolean;
  data: T | null;
  error?: {
    code: string;
    message: string;
    details?: any;
  } | null;
  timestamp: string;
  correlationId: string;
}
```

### Shared Zod Validation & Enums
`@bomis/shared` exports:
- 8 Roles: `SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `TEACHER`, `ACCOUNTANT`, `STUDENT`, `PARENT`, `TRANSPORT_STAFF`.
- Auth schemas: `MobileOtpRequestSchema`, `VerifyOtpSchema`, `StaffLoginSchema`.
- Attendance schemas: `AttendanceMarkBatchSchema`, `AttendanceSyncQueueSchema`.
- Fee schemas: `CreateFeeStructureSchema`, `RazorpayOrderSchema`, `FeePaymentWebhookSchema`.
- Academic schemas: `MarksEntryBatchSchema`, `SubstituteTeacherSchema`.
- Transport schemas: `GpsLocationUpdateSchema`, `StudentBoardingLogSchema`.

### Code Layout
```
/apps/api
  src/
    common/         # interceptors, filters, guards, decorators, pino logger
    modules/        # auth, users, attendance, fees, academics, transport, safety, ai, health
    database/       # prisma service, extensions (RLS, encryption)
/apps/web
  src/
    app/            # (auth), (dashboard)/admin, principal, teacher, accountant, parent
    components/     # shadcn/ui primitives, role widgets, navbar, sidebar
    lib/            # api client, auth store, query provider
/apps/mobile
  src/
    screens/        # auth, parent, student, teacher, driver
    services/       # sync outbox, sqlite, location broadcaster, qr scanner
/packages/shared
  src/
    enums/          # roles, attendance status, payment status, cbse grades
    schemas/        # zod schemas for all domain entities
    types/          # inferred typescript interfaces
/packages/ui
  src/
    tokens/         # colors (#0F2942, #FF6B4A), typography, spacing
    components/     # shared atomic components
/infra
  docker-compose.yml # PostgreSQL 16, Redis 7, MinIO, Mailpit
/docs
  postman/          # bomis_collection.json, bomis_environment.json, newman runner
```
