# Comprehensive Test Infrastructure & Verification Analysis
## BOMIS Sambalpur Unified School Platform — Milestone M6 (Phase 1)

**Investigator**: `explorer_m6_2`  
**Date**: 2026-10-22  
**Target Workspaces**: `@bomis/shared`, `@bomis/ui`, `@bomis/api`  
**Authoritative Sources**: `ORIGINAL_REQUEST.md`, `PROJECT.md`, `TEST_INFRA.md`  

---

## 1. Executive Summary

A comprehensive, read-only static analysis and dependency audit of the BOMIS Sambalpur repository test infrastructure was conducted across the foundation workspaces: `@bomis/shared` (packages/shared), `@bomis/ui` (packages/ui), and `@bomis/api` (apps/api).

### Core Findings
1. **Rich Test Inventory Already Implemented**:
   - `@bomis/shared`: 1 test suite (`test/shared.spec.ts`, 479 lines) covering 8 canonical roles, RBAC matrix, and 26 canonical Zod schemas.
   - `@bomis/ui`: 1 test suite (`test/tokens.spec.ts`, 152 lines) covering brand palette (Navy `#0F2942`, Coral `#FF6B4A`), typography, spacing, role badges, attendance status styles, button variants, and Tailwind presets.
   - `@bomis/api`: 18 test suites (17 unit/service spec files in `src/` comprising ~2,000 lines + 1 E2E spec in `test/app.e2e-spec.ts`).
2. **Self-Contained In-Memory Mock Architecture (`USE_MOCK_DB=true`)**:
   - The entire backend test suite in `@bomis/api` is engineered to run decoupled from live external databases. All service tests set `process.env.USE_MOCK_DB = 'true'` and inject `MockStoreService` and `MockRedisService`. Unit tests can execute cleanly in isolated CI/local environments without requiring Docker containers or DB migrations.
3. **Topological Dependency Requirement**:
   - Monorepo package dependencies follow `@bomis/shared` -> `@bomis/ui` & `@bomis/api`.
   - Turborepo (`turbo.json`) enforces `"dependsOn": ["^build"]` for `build`, `typecheck`, and `test` tasks.
   - While Jest in `@bomis/api` maps `@bomis/shared` directly to source TypeScript (`packages/shared/src`), executing workspace-wide commands requires `@bomis/shared` to be compiled (`pnpm --filter @bomis/shared build`) first to satisfy Turbo pipelines and module resolution.

---

## 2. Workspace Configuration & Monorepo Tooling Analysis

### 2.1 Monorepo Orchestration (`turbo.json`)
The monorepo utilizes Turborepo v2.0.4 with strict topological task relationships:
```json
{
  "tasks": {
    "build": { "dependsOn": ["^build"], "outputs": ["dist/**", ".next/**", "!.next/cache/**"] },
    "test": { "dependsOn": ["^build"], "outputs": ["coverage/**"] },
    "typecheck": { "dependsOn": ["^build"] },
    "lint": { "dependsOn": ["^build"] }
  }
}
```
*Key Takeaway*: Because `test` and `typecheck` depend on `^build`, attempting to execute `pnpm test` or `pnpm typecheck` at the root will first build upstream workspace dependencies.

### 2.2 TypeScript Configuration Hierarchy
- **Root `tsconfig.base.json`**:
  - Target: `ES2022`, Module: `NodeNext`, ModuleResolution: `NodeNext`.
  - Strict mode enabled (`strict: true`, `noImplicitAny: true`, `strictNullChecks: true`, `noUncheckedIndexedAccess: true`).
  - Path mappings configured for `@bomis/shared` (`packages/shared/src/index.ts`) and `@bomis/ui` (`packages/ui/src/index.ts`).
- **`packages/shared/tsconfig.json`**:
  - Extends base, outputs to `./dist`, rootDir `./src`, `composite: true`.
- **`packages/ui/tsconfig.json`**:
  - Extends base, outputs to `./dist`, rootDir `./src`, `composite: true`.
- **`apps/api/tsconfig.json`**:
  - Extends base, overrides `module: "commonjs"` and `moduleResolution: "node"` for NestJS compatibility, enables `emitDecoratorMetadata` and `experimentalDecorators`.

### 2.3 Jest Configurations
| Workspace | Configuration File | Test Match Pattern | Module Mapper |
|---|---|---|---|
| `@bomis/shared` | `packages/shared/jest.config.js` | `<rootDir>/test/**/*.spec.ts` | None |
| `@bomis/ui` | `packages/ui/jest.config.js` | `<rootDir>/test/**/*.spec.ts` | None |
| `@bomis/api` (Unit) | `apps/api/jest.config.js` | `src/**/*.spec.ts` | `@bomis/shared` -> `packages/shared/src` |
| `@bomis/api` (E2E) | `apps/api/test/jest-e2e.json` | `test/**/*.e2e-spec.ts` | `@bomis/shared` -> `packages/shared/src` |

---

## 3. Deep-Dive Specification of Existing Test Suites

### 3.1 `@bomis/shared` (`packages/shared/test/shared.spec.ts` — 479 lines)
Tests the canonical single-source-of-truth schemas, enums, and access control contracts:
1. **Canonical Enums & Aliases**:
   - 8 roles verified: `SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `TEACHER`, `ACCOUNTANT`, `STUDENT`, `PARENT`, `TRANSPORT_STAFF`.
   - Backward compatibility: `DRIVER_TRANSPORT` alias maps to `TRANSPORT_STAFF`.
   - Domain enums: `CBSEGrade`, `DayOfWeek`, `SafetyIncidentType`, `BoardingAction`, `Gender`, `AttendanceStatus`, `PaymentMethod`, `FeeFrequency`, `ConsentType`, `ConsentStatus`.
2. **RBAC Permission Matrix (`hasPermission`)**:
   - `SUPER_ADMIN`: Exhaustive rights (users, fees, transport, attendance override, DPDP, safety, notices, AI).
   - `ADMIN` & `PRINCIPAL`: Administrative oversight, student updates, concession approvals, safety gate management, marks approval, substitution.
   - `TEACHER`: Attendance marking, homework creation, marks entry, lesson planning; zero fee management or user creation rights.
   - `ACCOUNTANT`: Fee reading/management/reconciliation; zero academic or GPS broadcast rights.
   - `STUDENT` & `PARENT`: Self-service boundaries (homework submission, fee payment, DPDP erasure requests, child pickup verification).
   - `TRANSPORT_STAFF`: Telematics, GPS broadcast, boarding QR scans; zero fee or user profile access.
3. **26 Canonical Zod Validation Schemas**:
   - Auth: `MobileOtpRequestSchema` (E.164 +91 check), `VerifyOtpSchema` (6-digit check), `StaffLoginSchema` (email + >=8 char password), `RefreshTokenSchema`, `LogoutSchema`.
   - People: `CreateStudentSchema` (admission/roll numbers, DOB, emergency contacts, UUIDs).
   - Attendance & Offline: `AttendanceMarkBatchSchema`, `RapidAttendanceBatchSchema` (defaultStatus + exceptions), `OfflineSyncBatchSchema` (idempotency keys).
   - Fees & Razorpay: `InitiatePaymentSchema`, `CreateRazorpayOrderSchema`, `RazorpayWebhookSchema`, `CreateFeeStructureSchema`, `ConcessionApplicationSchema`.
   - Academics & Timetable: `MarksBatchEntrySchema`, `TimetableClashCheckSchema`, `TeacherSubstitutionSchema`, `CreateHomeworkSchema`.
   - Transport: `GpsLocationUpdateSchema`, `BoardingScanPayloadSchema`.
   - Safety & DPDP: `CreateVisitorPassSchema`, `VerifyChildPickupSchema`, `AnonymousIncidentReportSchema`, `ConsentRecordSchema` (cryptographic proofHash), `DataErasureRequestSchema` (permanent erasure flag).
   - General: `PaginationQuerySchema` (coercion and defaults).

### 3.2 `@bomis/ui` (`packages/ui/test/tokens.spec.ts` — 152 lines)
Tests design system tokens and component primitive contracts:
1. **BOMIS Navy Palette**: Primary `#0F2942` at DEFAULT and 800 scale; shades 50 to 900.
2. **Warm Coral Palette**: Accent `#FF6B4A` at DEFAULT and 500 scale; shades 50 to 900.
3. **Semantic Status Colors**: Success (`#10B981`), Warning (`#F59E0B`), Danger (`#EF4444`), Info (`#3B82F6`), Slate neutrals.
4. **Typography & Layout**: Font families (Outfit, Inter, JetBrains Mono), sizes xs to 4xl, radius sm to full, spacing 0 to 16.
5. **Component Primitives**: Role badge color maps for all 8 roles, attendance status badge styles, button variants (primary, accent, outline, ghost), and `bomisTailwindPreset`.

### 3.3 `@bomis/api` Test Inventory (18 Spec Files)
| # | Test File | LOC | Category | Primary Capabilities Tested |
|---|---|---|---|---|
| 1 | `adversarial-m3-round2.spec.ts` | 471 | Tier 5 / Adversarial | Pickup OTP replay defense across gates, zero-data division guard in KPIs, ghost user token rejection, cross-tenant sibling leak defense, Razorpay HMAC webhook verification & mandatory idempotency. |
| 2 | `app.module.spec.ts` | 36 | Infra Smoke | NestJS root module compilation, dependency tree validation, PinoLoggerService injection. |
| 3 | `common/crypto/crypto.service.spec.ts` | 177 | Tier 1 / Security | AES-256-GCM field-level encryption/decryption, IV uniqueness, tampering detection (flipped bits, altered auth tags), AAD tenant binding, key rotation (v1/v2). |
| 4 | `common/guards/roles.guard.spec.ts` | 103 | Tier 2 / RBAC | Negative RBAC gates (Student marks edit 403, Driver fee view 403, Parent audit logs 403), SUPER_ADMIN pass-through, `@Public()` bypass. |
| 5 | `common/logger/pino-logger.service.spec.ts` | 62 | Infra | AsyncLocalStorage trace correlation ID propagation, structured error/warn logging. |
| 6 | `common/pipes/zod-validation.pipe.spec.ts` | 46 | Tier 1 / Validation | Zod schema transformation, 400 Bad Request on schema violation, metatype reflection. |
| 7 | `modules/academics/academics.service.spec.ts` | 155 | Tier 1 / Academics | CBSE 9-point grading scale (A1 to E, GP 10.0 to 0.0), input bounds enforcement, `submitMarksBatch`, timetable clash detection (teacher double-booking), substitute teacher confirmation. |
| 8 | `modules/admin/admin.controller.spec.ts` | 58 | Tier 2 / Audit | DPDP audit log retrieval sorted descending, dynamic audit log trail creation. |
| 9 | `modules/ai/ai.service.spec.ts` | 60 | Tier 1 / AI | Concept study buddy NCERT citations, draft report remarks with mandatory human-in-the-loop review flags. |
| 10 | `modules/attendance/attendance.service.spec.ts` | 178 | Tier 1 & 2 / Attendance | Rapid attendance grid (<10s), CBSE attendance percentage formula `((Present + 0.5*HalfDay)/WorkingDays)*100`, <75% low attendance alert, offline sync batch idempotency (`IDEMPOTENT_SKIPPED`). |
| 11 | `modules/auth/auth.service.spec.ts` | 109 | Tier 1 & 2 / Auth | 6-digit OTP dispatch & verification, JWT access/refresh token generation, staff password authentication, token rotation, session revocation. |
| 12 | `modules/fees/fees.service.spec.ts` | 225 | Tier 1 & 2 / Fees | Grade 5 fee structure calculation, Razorpay order creation, Idempotency-Key duplicate caching, 409 Conflict on payload mismatch, HMAC-SHA256 signature verification, concession percentage validation. |
| 13 | `modules/health/health.controller.spec.ts` | 47 | Infra / Health | `/health` liveness probe and `/ready` readiness probe (checks DB, Redis, MinIO). |
| 14 | `modules/people/people.service.spec.ts` | 181 | Tier 1 & 2 / People | Student directory filtering/pagination, symbolic ID resolution, DPDP encrypted storage/decryption, linked sibling retrieval, zero cross-family leakage. |
| 15 | `modules/pulse/pulse.service.spec.ts` | 50 | Tier 1 / Pulse | Principal Pulse real-time KPIs (attendanceRate, feeCollectionRate, activeBuses, systemHealth). |
| 16 | `modules/safety/safety.service.spec.ts` | 180 | Tier 1 & 2 / Safety | Time-limited visitor QR pass generation, child pickup OTP verification, single-use OTP replay rejection, anonymous zero-log anti-bullying incident reporting. |
| 17 | `modules/transport/transport.service.spec.ts` | 103 | Tier 1 & 2 / Transport | 4 arterial routes (Budharaja, Khetrajpur, Dhanupali, Burla), 4 pilot buses with OD-15 Sambalpur registration, QR boarding scan, GPS telemetry ingestion. |
| 18 | `test/app.e2e-spec.ts` | 29 | Tier 4 / E2E Smoke | Full NestJS application bootstrap with global prefix `api/v1` and health probe routing. |

---

## 4. 5-Tier Testing Pyramid Traceability (TEST_INFRA.md Alignment)

### Tier 1: Pure Logic Engines & Mathematical Calculators
- **CBSE 9-Point Grading Scale**: Fully tested in `academics.service.spec.ts` (A1: >=91%, A2: 81-90.9%, B1: 71-80.9%, B2: 61-70.9%, C1: 51-60.9%, C2: 41-50.9%, D: 33-40.9%, E: <33%) and `apps/web/src/lib/academic-financial.challenge.spec.ts` (clamping at 0 and 100).
- **Attendance Percentage Formula**: Verified in `attendance.service.spec.ts` and `adversarial-m3-round2.spec.ts` against `((Present + 0.5 * HalfDay) / WorkingDays) * 100`, plus chronic absence trigger at <75%.
- **Timetable Clash Matrix**: Verified in `academics.service.spec.ts` (teacher double-booking detection).
- **Fee Structures & Concessions**: Verified in `fees.service.spec.ts` (Grade 5 term fee math, installment generation, concession boundaries 1-100%).
- **Zod Validation**: Exhaustively verified across 26 schemas in `packages/shared/test/shared.spec.ts`.

### Tier 2: Boundary, Edge Case & Negative RBAC Matrix
- **Financial Idempotency**: Verified in `fees.service.spec.ts` and `adversarial-m3-round2.spec.ts` (duplicate key reuse yields cached order, conflicting payload returns 409, missing header returns 400).
- **Negative RBAC Gates**: Verified in `roles.guard.spec.ts` (STUDENT blocked from marks edit, DRIVER blocked from fees, PARENT blocked from audit logs) and `packages/shared/test/shared.spec.ts`.
- **Tenant / Sibling Privacy Isolation**: Verified in `adversarial-m3-round2.spec.ts` and `people.service.spec.ts` (unlinked guardians receive `[]`, zero cross-family PII exposure).
- **Input Boundaries**: Verified across schemas in `shared.spec.ts` (E.164 phone formats, 6-digit OTPs, positive amounts).

### Tier 3: Cross-Feature Integration Workflows
- **Auth Lifecycle**: Login -> Token issuance -> Refresh rotation -> Session revocation verified in `auth.service.spec.ts`.
- **Offline Sync Outbox Queue**: Offline batch queueing with idempotency keys and idempotent replay verified in `attendance.service.spec.ts` and `apps/mobile/src/__tests__/mobile.spec.ts`.
- **Razorpay HMAC Webhook**: Cryptographic signature generation and verification verified in `fees.service.spec.ts` and `adversarial-m3-round2.spec.ts`.
- **Transport Telematics**: GPS telemetry, boarding QR scans, and Haversine distance geofence proximity verified in `transport.service.spec.ts` and `apps/mobile/src/__tests__/mobile.spec.ts`.

---

## 5. Execution Matrix for Worker Verification

To ensure clean, reproducible execution without permission errors or broken dependencies, the Worker should execute the test verification according to the following phased pipeline:

```
┌────────────────────────────────────────────────────────┐
│ Phase 1: Environment & Dependency Prep                 │
│ pnpm install && pnpm db:generate                       │
└──────────────────────────┬─────────────────────────────┘
                           │
┌──────────────────────────▼─────────────────────────────┐
│ Phase 2: Upstream Shared Packages Build & Typecheck    │
│ pnpm --filter @bomis/shared build                      │
│ pnpm --filter @bomis/shared typecheck                  │
│ pnpm --filter @bomis/ui build                          │
│ pnpm --filter @bomis/ui typecheck                      │
└──────────────────────────┬─────────────────────────────┘
                           │
┌──────────────────────────▼─────────────────────────────┐
│ Phase 3: Tier 1 Unit & Schema Tests                    │
│ pnpm --filter @bomis/shared test                       │
│ pnpm --filter @bomis/ui test                           │
└──────────────────────────┬─────────────────────────────┘
                           │
┌──────────────────────────▼─────────────────────────────┐
│ Phase 4: Backend API Typecheck & Full Test Suite       │
│ pnpm --filter @bomis/api typecheck                     │
│ pnpm --filter @bomis/api test                          │
│ pnpm --filter @bomis/api test:e2e                      │
└──────────────────────────┬─────────────────────────────┘
                           │
┌──────────────────────────▼─────────────────────────────┐
│ Phase 5: Monorepo-Wide Pipeline (Optional / Complete)  │
│ pnpm test                                              │
└────────────────────────────────────────────────────────┘
```

### Detailed Command Table
| Step | Target Workspace | Command | Expected Result |
|---|---|---|---|
| 1 | Root | `pnpm db:generate` | Prisma client generated for schema |
| 2 | `@bomis/shared` | `pnpm --filter @bomis/shared build` | Emits `dist/` declarations and JS modules |
| 3 | `@bomis/shared` | `pnpm --filter @bomis/shared typecheck` | 0 TypeScript errors |
| 4 | `@bomis/shared` | `pnpm --filter @bomis/shared test` | All 26 schema & RBAC suites pass |
| 5 | `@bomis/ui` | `pnpm --filter @bomis/ui build` | Emits `dist/` tokens and Tailwind preset |
| 6 | `@bomis/ui` | `pnpm --filter @bomis/ui typecheck` | 0 TypeScript errors |
| 7 | `@bomis/ui` | `pnpm --filter @bomis/ui test` | All brand token suites pass |
| 8 | `@bomis/api` | `pnpm --filter @bomis/api typecheck` | 0 TypeScript errors in NestJS monolith |
| 9 | `@bomis/api` | `pnpm --filter @bomis/api test` | All 17 unit and adversarial suites pass |
| 10 | `@bomis/api` | `pnpm --filter @bomis/api test:e2e` | E2E smoke test passes |

---

## 6. Summary of Recommendations for Orchestrator & Worker
1. **Zero Database Dependency for Unit Tests**: The Worker does NOT need to run PostgreSQL or Redis to execute `@bomis/api test` because of the `USE_MOCK_DB=true` mock store architecture.
2. **Execute In Dependency Order**: Worker MUST build `@bomis/shared` before running test suites in `@bomis/api` or monorepo `pnpm test`.
3. **Targeted Coverage Sufficiency**: With 18 test suites in `@bomis/api` and comprehensive coverage in `@bomis/shared`, Tiers 1, 2, and 3 are thoroughly covered and ready for green validation.
