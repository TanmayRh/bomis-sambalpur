# Dispatch: Spec Miner M3-1

- Target Agent: teamwork_preview_spec_miner
- Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m3_1
- Project Root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur
- Authoritative Sources:
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md (MANDATORY)
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\docs\postman\bomis_postman_collection.json
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\packages\shared
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\DEAD_ENDS.md

## 2026-10-18T06:56:54Z
Sender: 13f64a87-d8b4-4bd5-b7bb-78d55fbd0e64
Content: You are Spec Miner 1 for Milestone M3 (NestJS Modular Monolith API) of the BOMIS Sambalpur Unified School Platform.

Your Working Directory:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m3_1

Project Root:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur

Dispatch Details:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m3_1\DISPATCH.md

Authoritative Sources to Read (MANDATORY):
1. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
2. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
3. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md
4. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\docs\postman\bomis_postman_collection.json
5. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\packages\shared (enums, contracts, rbac, schemas, types)
6. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\DEAD_ENDS.md

Your Mission:
Mine and document the exhaustive technical specifications for the NestJS API (/apps/api) required to pass 100% of Newman E2E tests and fulfill BOMIS Sambalpur business logic.
Specifically:
1. Detailed endpoint inventory matching docs/postman/bomis_postman_collection.json across all 8 folders:
   - 00_Health_Probes: GET /health, GET /ready
   - 01_Authentication: POST /api/v1/auth/otp/send, POST /api/v1/auth/otp/verify, POST /api/v1/auth/staff/login, POST /api/v1/auth/refresh, POST /api/v1/auth/logout
   - 02_People_Management: GET /api/v1/people/students, GET /api/v1/people/students/:id, GET /api/v1/people/guardians/siblings, GET /api/v1/people/staff, POST /api/v1/people/students/bulk-import
   - 03_Attendance_Sync: GET /api/v1/attendance, POST /api/v1/attendance, POST /api/v1/attendance/batch, POST /api/v1/sync/batch, POST /api/v1/attendance/leaves
   - 04_Fees_Finance: GET/POST /api/v1/fees/structures, POST /api/v1/fees/orders, POST /api/v1/fees/webhook, GET /api/v1/fees/receipts/:id, GET/POST /api/v1/fees/concessions
   - 05_Academics_CBSE: GET/POST /api/v1/academics/terms, POST /api/v1/academics/marks/batch, POST /api/v1/academics/timetable/clash-check, POST /api/v1/academics/substitutions
   - 06_Transport_Fleet: GET /api/v1/transport/routes, GET /api/v1/transport/buses, POST /api/v1/transport/boarding/scan, POST /api/v1/transport/gps-ping
   - 07_Safety_AI: GET/POST /api/v1/safety/visitors, POST /api/v1/safety/pickup/verify, POST /api/v1/safety/incidents/anonymous, POST /api/v1/ai/study-buddy/chat
   - 08_RBAC_Negative_Gates: 403 Forbidden checks for unauthorized roles
2. Exact header contracts: `x-correlation-id`, `Idempotency-Key`, `Authorization: Bearer <jwt>`.
3. Unified response envelope format `{ success, data, error, timestamp, correlationId }` and status codes (200, 201, 400, 401, 403, 404, 409).
4. Validation schemas and error structures.

Output:
Write your full specification report to `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m3_1\analysis.md`.
Write your handoff report to `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m3_1\handoff.md` with:
- Observation
- Logic Chain
- Caveats
- Conclusion
- Verification Method
Send a completion message with summary and report path back to the orchestrator.
Do NOT modify any source code files.
