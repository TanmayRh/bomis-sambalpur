# Technical Specification Report: NestJS API (/apps/api)
## BOMIS Sambalpur Unified School Platform — Milestone M3 Architecture

- **Author**: Spec Miner 1 (Milestone M3)
- **Status**: Complete & Authoritative
- **Target Repository**: `bomis_sambalpur` (`/apps/api`)
- **Working Directory**: `.agents/teamwork/spec_miner_m3_1`
- **Date**: 2026-10-18

---

## 1. Executive Summary & Authoritative Specification Hierarchy

This technical specification mines, synthesizes, and formalizes the complete implementation blueprint for the NestJS 10 Modular Monolith backend API (`/apps/api`) of the Birla Open Minds International School (BOMIS), Sambalpur platform.

The specification is derived by cross-referencing all authoritative project sources:
1. `docs/postman/bomis_postman_collection.json` (Newman E2E Automated Test Suite)
2. `docs/postman/bomis_postman_environment.json` (Newman Environment Variables & Mock Fixtures)
3. `packages/shared/src/` (Canonical Zod Schemas, Domain Enums, RBAC Permissions, Envelope Contracts)
4. `prisma/schema.prisma` (36 Production-Grade PostgreSQL Models with DPDP & Multi-Tenant Support)
5. `prisma/seed.ts` (Deterministic Seed Fixtures for Grades 1–8, 4 Buses, 8 Roles, Sibling Pairs)
6. `docs/adr/` (ADR 0001 Turborepo, ADR 0002 DPDP/RLS, ADR 0003 Envelope, ADR 0004 Offline Sync)
7. `.agents/teamwork/ORIGINAL_REQUEST.md`, `PROJECT.md`, `TEST_INFRA.md`, and `DEAD_ENDS.md`

Every endpoint, header, response envelope, status code, validation rule, error shape, and role gate detailed herein is required for 100% pass rate in the automated Postman/Newman CI pipeline and full compliance with BOMIS Sambalpur operational requirements.

---

## 2. Features Discovered

| # | Category | Feature | Description | Inputs | Outputs | Error Behavior | Discovered Via |
|---|----------|---------|-------------|--------|---------|----------------|----------------|
| 1 | Health & Readiness | Liveness Probe | Heartbeat probe verifying the NestJS process is alive and responsive. Mounted at root (`/health`), bypassing `/api/v1` prefix. | None (`GET /health`) | `200 OK`, `{ success: true, data: { status: "ok", uptime: number }, timestamp, correlationId }` | `503 Service Unavailable` if process terminating | `bomis_postman_collection.json` (lines 89-100), `ORIGINAL_REQUEST.md` (R1) |
| 2 | Health & Readiness | Deep Readiness Probe | Validates connectivity to PostgreSQL 16, Redis 7, and MinIO storage. Mounted at root (`/ready`). | None (`GET /ready`) | `200 OK`, `{ success: true, data: { status: "ok", postgres: "up", redis: "up", minio: "up" }, timestamp, correlationId }` | `503 Service Unavailable`, `{ success: false, data: null, error: { code: "SERVICE_UNAVAILABLE", message: "..." } }` | `bomis_postman_collection.json` (lines 102-116), `TEST_INFRA.md` (line 273) |
| 3 | Authentication | Request Mobile OTP | Dispatches a 6-digit OTP with a 300-second TTL to parent or student mobile numbers. | `POST /api/v1/auth/otp/send` Body: `{ phone: string, purpose?: string, schoolId?: string }` | `200 OK`, `{ success: true, data: { expiresInSeconds: 300, message: string }, timestamp, correlationId }` | `400 Bad Request` (invalid Indian E.164 phone); `429 Too Many Requests` (>5 requests/15m) | `bomis_postman_collection.json` (lines 123-160), `MobileOtpRequestSchema` |
| 4 | Authentication | Verify Mobile OTP | Validates 6-digit OTP, issuing short-lived access JWT (15m) and rotating refresh token (7d) for PARENT / STUDENT roles. | `POST /api/v1/auth/otp/verify` Body: `{ phone: string, otp: string }` (or `code`) | `200 OK`, `{ success: true, data: { accessToken: string, refreshToken: string, user: UserSummaryDto }, timestamp, correlationId }` | `400 Bad Request` (malformed input); `401 Unauthorized` (invalid/expired OTP) | `bomis_postman_collection.json` (lines 162-202), `VerifyOtpSchema` |
| 5 | Authentication | Staff Email Login | Authenticates administrative, teaching, and transport staff using email and password, returning JWT with embedded role and school claims. | `POST /api/v1/auth/staff/login` Body: `{ email: string, password: string }` | `200 OK`, `{ success: true, data: { accessToken: string, refreshToken: string, user: { id: string, email: string, role: UserRole, schoolId: string } }, timestamp, correlationId }` | `400 Bad Request` (invalid email/short pass); `401 Unauthorized` (invalid credentials or deactivated) | `bomis_postman_collection.json` (lines 204-244), `StaffLoginSchema` |
| 6 | Authentication | Rotate Refresh Token | Exchanges active refresh token for a new access JWT and rotates refresh token; invalidates old token with family tracking. | `POST /api/v1/auth/refresh` Body: `{ refreshToken: string }` | `200 OK`, `{ success: true, data: { accessToken: string, refreshToken: string }, timestamp, correlationId }` | `401 Unauthorized` (token expired, revoked, or replay detected) | `bomis_postman_collection.json` (lines 246-285), `RefreshTokenSchema` |
| 7 | Authentication | Revoke Session (Logout) | Blacklists current session JWT in Redis and revokes token family. | `POST /api/v1/auth/logout` Header: `Authorization: Bearer <jwt>`, Body: optional `{ refreshToken?: string }` | `200 OK`, `{ success: true, data: { message: "Session revoked" }, timestamp, correlationId }` | `401 Unauthorized` (missing/malformed bearer token) | `bomis_postman_collection.json` (lines 287-320), `LogoutSchema` |
| 8 | People Management | List Students with Filter | Queries students with grade, section, and pagination filters for attendance grids and classroom rosters. | `GET /api/v1/people/students?grade=5&section=A&limit=30` Header: `Bearer <adminToken>` | `200 OK`, `{ success: true, data: { students: StudentSummaryDto[], total: number }, timestamp, correlationId }` | `401 Unauthorized`, `403 Forbidden` if role lacks `STUDENTS_READ` | `bomis_postman_collection.json` (lines 327-378), `PaginationQuerySchema` |
| 9 | People Management | Create Student Profile | Enrolls a student, creates DPDP-compliant record, and encrypts sensitive fields (Aadhaar, blood group). | `POST /api/v1/people/students` Header: `Bearer <adminToken>`, Body: `CreateStudentSchema` or Postman payload | `201 Created`, `{ success: true, data: { id: string, admissionNumber: string, ... }, timestamp, correlationId }` | `400 Bad Request` (Zod validation); `409 Conflict` (duplicate admission number) | `bomis_postman_collection.json` (lines 380-423), `CreateStudentSchema` |
| 10 | People Management | Get Student Profile by ID | Fetches individual student profile with sanitized guardian linkage and enrolled subjects. | `GET /api/v1/people/students/:id` Header: `Bearer <adminToken>` | `200 OK`, `{ success: true, data: { id: string, firstName: string, ... }, timestamp, correlationId }` | `404 Not Found` (student does not exist); `403 Forbidden` (cross-family access) | `bomis_postman_collection.json` (lines 425-459) |
| 11 | People Management | Fetch Linked Siblings | Enables parent multi-child switcher by retrieving all students linked to the authenticated guardian. | `GET /api/v1/people/guardians/siblings` Header: `Bearer <parentToken>` | `200 OK`, `{ success: true, data: StudentSiblingDto[], timestamp, correlationId }` | `401 Unauthorized`, `403 Forbidden` (non-parent role) | `bomis_postman_collection.json` (lines 461-494), `ORIGINAL_REQUEST.md` (R3) |
| 12 | People Management | List Staff Directory | Lists school faculty and staff for timetable allocation, visitor hosts, and administrative assignments. | `GET /api/v1/people/staff` Header: `Bearer <adminToken>` | `200 OK`, `{ success: true, data: StaffDto[], timestamp, correlationId }` | `401 Unauthorized`, `403 Forbidden` (unauthorized role) | `bomis_postman_collection.json` (lines 496-530) |
| 13 | People Management | Bulk CSV Student Ingestion | Streams and parses CSV student records, validates each row against Zod, and returns row-level error reports. | `POST /api/v1/people/students/bulk-import` Header: `Bearer <adminToken>`, Body: Multipart CSV or JSON array | `201 Created` or `200 OK`, `{ success: true, data: { totalProcessed: number, importedCount: number, errors: [] }, timestamp, correlationId }` | `400 Bad Request` (corrupted CSV or zero rows) | `DISPATCH.md`, `ORIGINAL_REQUEST.md` (line 39) |
| 14 | Attendance & Sync | Rapid Attendance Grid | Records full classroom attendance in < 100ms on server; defaults to PRESENT and applies exception array; triggers absence FCM alerts. | `POST /api/v1/attendance` Header: `Bearer <adminToken>` or Teacher, Body: `RapidAttendanceBatchSchema` | `201 Created`, `{ success: true, data: { processedCount: number, presentCount: number, absentCount: number }, timestamp, correlationId }` | `400 Bad Request` (future date, missing section); `403 Forbidden` (unauthorized teacher) | `bomis_postman_collection.json` (lines 537-579), `RapidAttendanceBatchSchema` |
| 15 | Attendance & Sync | Offline Outbox Batch Sync | Ingests queued events from mobile SQLite outbox with client idempotency key deduplication and conflict resolution. | `POST /api/v1/sync/batch` Header: `Bearer <token>`, `Idempotency-Key`, Body: `OfflineSyncBatchSchema` | `200 OK`, `{ success: true, data: { syncedCount: number, results: [{ id: string, status: string }] }, timestamp, correlationId }` | `400 Bad Request` (empty events array or invalid event action) | `bomis_postman_collection.json` (lines 581-623), `ADR 0004` |
| 16 | Attendance & Sync | Student Attendance Stats | Computes cumulative student attendance percentage for month/year; flags alerts if below CBSE 75% threshold. | `GET /api/v1/attendance/students/:studentId?month=10&year=2026` Header: `Bearer <parentToken>` | `200 OK`, `{ success: true, data: { percentage: number, totalWorkingDays: number, ... }, timestamp, correlationId }` | `404 Not Found` (student not found); `403 Forbidden` (unauthorized parent) | `bomis_postman_collection.json` (lines 625-670), `TEST_INFRA.md` (line 54) |
| 17 | Attendance & Sync | Raw Attendance Batch | Ingests granular student-by-student attendance records for specific section and date. | `POST /api/v1/attendance/batch` Header: `Bearer <token>`, Body: `AttendanceMarkBatchSchema` | `201 Created`, `{ success: true, data: { processedCount: number }, timestamp, correlationId }` | `400 Bad Request` (empty records array) | `DISPATCH.md`, `AttendanceMarkBatchSchema` |
| 18 | Attendance & Sync | Query Attendance Records | Lists attendance entries filtered by class, section, date, or date range. | `GET /api/v1/attendance?classId=...&sectionId=...&date=...` Header: `Bearer <token>` | `200 OK`, `{ success: true, data: AttendanceRecordDto[], timestamp, correlationId }` | `401 Unauthorized`, `403 Forbidden` | `DISPATCH.md` |
| 19 | Attendance & Sync | Staff / Student Leaves | Submits and tracks leave applications for staff and students. | `POST /api/v1/attendance/leaves` Header: `Bearer <token>`, Body: `{ fromDate, toDate, reason, leaveType }` | `201 Created`, `{ success: true, data: { leaveId: string, status: "PENDING" }, timestamp, correlationId }` | `400 Bad Request` (invalid dates or missing reason) | `DISPATCH.md`, `ORIGINAL_REQUEST.md` (line 40) |
| 20 | Fees & Finance | Get Fee Structures | Retrieves tuition, lab, activity, and transport fee schedules filtered by grade and academic year. | `GET /api/v1/fees/structures?grade=5&academicYear=2026-2027` Header: `Bearer <adminToken>` | `200 OK`, `{ success: true, data: FeeStructureDto[], timestamp, correlationId }` | `403 Forbidden` on unauthorized roles (Driver / Transport); `401 Unauthorized` | `bomis_postman_collection.json` (lines 677-720) |
| 21 | Fees & Finance | Create Razorpay Order | Computes payable installment fee on server and creates Razorpay order; enforces distributed lock via `Idempotency-Key`. | `POST /api/v1/fees/orders` Header: `Bearer <parentToken>`, `Idempotency-Key`, Body: `CreateRazorpayOrderSchema` | `201 Created`, `{ success: true, data: { razorpayOrderId: string, amount: number, currency: "INR" }, timestamp, correlationId }` | `400 Bad Request` (missing Idempotency-Key); `409 Conflict` (same key, different payload) | `bomis_postman_collection.json` (lines 722-766), `AC-3` |
| 22 | Fees & Finance | Razorpay Webhook Ingestion | Verifies cryptographic HMAC-SHA256 signature, marks fee installment paid, and enqueues BullMQ receipt job. | `POST /api/v1/fees/webhook` Header: `X-Razorpay-Signature`, Body: `RazorpayWebhookSchema` | `200 OK`, `{ success: true, data: { processed: true, paymentId: string }, timestamp, correlationId }` | `400 Bad Request` (tampered or invalid HMAC signature) | `bomis_postman_collection.json` (lines 768-808), `RazorpayWebhookSchema` |
| 23 | Fees & Finance | Download PDF Tax Receipt | Retrieves official BOMIS Sambalpur fee tax receipt metadata or 302 redirect / raw stream to MinIO S3. | `GET /api/v1/fees/receipts/:id` Header: `Bearer <parentToken>` | `200 OK` (JSON metadata) or `302 Found` (redirect to signed URL) | `404 Not Found` (receipt not generated yet or invalid ID) | `bomis_postman_collection.json` (lines 810-840), `ADR 0003` |
| 24 | Fees & Finance | Create Fee Structure | Defines a new grade fee schedule with frequency and amount. | `POST /api/v1/fees/structures` Header: `Bearer <accountantToken>`, Body: `CreateFeeStructureSchema` | `201 Created`, `{ success: true, data: FeeStructureDto, timestamp, correlationId }` | `400 Bad Request` (negative amount or invalid year); `403 Forbidden` | `DISPATCH.md`, `CreateFeeStructureSchema` |
| 25 | Fees & Finance | Concession Workflow | Submits sibling or merit fee concession applications and processes accountant/principal approval states. | `POST /api/v1/fees/concessions` (submit) / `GET /api/v1/fees/concessions` (list) | `201 Created` / `200 OK`, `{ success: true, data: ConcessionDto, timestamp, correlationId }` | `400 Bad Request` (discount percentage > 100 or <= 0) | `DISPATCH.md`, `ConcessionApplicationSchema` |
| 26 | Academics & CBSE | Get CBSE Academic Terms | Retrieves Term 1 and Term 2 examination and periodic test schedules. | `GET /api/v1/academics/terms` Header: `Bearer <adminToken>` | `200 OK`, `{ success: true, data: AcademicTermDto[], timestamp, correlationId }` | `401 Unauthorized` | `bomis_postman_collection.json` (lines 848-881) |
| 27 | Academics & CBSE | Marks Batch Entry | Validates scores against CBSE components and calculates scholastic 9-point scale grade (A1-E). | `POST /api/v1/academics/marks/batch` Header: `Bearer <adminToken>` or Teacher, Body: `MarksBatchEntrySchema` | `200 OK`, `{ success: true, data: { recordedCount: number, results: [...] }, timestamp, correlationId }` | `400 Bad Request` (marks out of bounds); `403 Forbidden` if student role | `bomis_postman_collection.json` (lines 883-924), `cbse-grading.spec.ts` |
| 28 | Academics & CBSE | Timetable Clash Check | Inspects teacher and room schedules to prevent overlapping period assignments on the same day/period. | `POST /api/v1/academics/timetable/clash-check` Header: `Bearer <adminToken>`, Body: `TimetableClashCheckSchema` | `200 OK`, `{ success: true, data: { hasClash: boolean, details?: any }, timestamp, correlationId }` | `400 Bad Request` (periodNumber out of 1-10 range) | `bomis_postman_collection.json` (lines 926-967), `TimetableClashCheckSchema` |
| 29 | Academics & CBSE | Teacher Substitution | Allocates a free substitute teacher for an absent teacher's periods upon leave approval. | `POST /api/v1/academics/substitutions` Header: `Bearer <principalToken>`, Body: `TeacherSubstitutionSchema` | `201 Created`, `{ success: true, data: { substitutionId: string, status: "CONFIRMED" }, timestamp, correlationId }` | `409 Conflict` (substitute teacher already booked in that period) | `DISPATCH.md`, `TeacherSubstitutionSchema` |
| 30 | Academics & CBSE | Create Academic Term | Configures a new CBSE term with date bounds for the academic year. | `POST /api/v1/academics/terms` Header: `Bearer <adminToken>`, Body: `{ name, term, startDate, endDate }` | `201 Created`, `{ success: true, data: AcademicTermDto, timestamp, correlationId }` | `400 Bad Request` (start date after end date) | `DISPATCH.md` |
| 31 | Transport Fleet | List Bus Routes & Stops | Retrieves 4 arterial routes (Budharaja, Khetrajpur, Dhanupali, Burla) and 15 geofenced stops. | `GET /api/v1/transport/routes` Header: `Bearer <adminToken>` | `200 OK`, `{ success: true, data: TransportRouteDto[], timestamp, correlationId }` | `401 Unauthorized` | `bomis_postman_collection.json` (lines 975-1008) |
| 32 | Transport Fleet | List 4 Pilot Buses | Lists 4 pilot buses (3 small 24-seaters, 1 full-size 52-seater) with OD-15 plates and driver status. | `GET /api/v1/transport/buses` Header: `Bearer <adminToken>` | `200 OK`, `{ success: true, data: VehicleDto[], timestamp, correlationId }` | `401 Unauthorized` | `bomis_postman_collection.json` (lines 1010-1044) |
| 33 | Transport Fleet | Boarding / Deboarding Scan | Logs student QR boarding/deboarding transit event at bus stop and triggers instant FCM parent push alerts. | `POST /api/v1/transport/boarding/scan` Header: `Bearer <driverToken>`, Body: `BoardingScanPayloadSchema` | `201 Created`, `{ success: true, data: { scanId: string, action: string }, timestamp, correlationId }` | `400 Bad Request` (missing GPS or invalid action); `404 Not Found` (bus/student not found) | `bomis_postman_collection.json` (lines 1046-1087), `BoardingScanPayloadSchema` |
| 34 | Transport Fleet | GPS Telemetry Ping | Ingests real-time vehicle GPS coordinates from driver app; computes proximity to stops and emits 5-min geofence alerts. | `POST /api/v1/transport/gps-ping` Header: `Bearer <driverToken>`, Body: `GpsLocationUpdateSchema` | `200 OK`, `{ success: true, data: { recorded: true, proximityAlertsSent: number }, timestamp, correlationId }` | `400 Bad Request` (lat/lng out of valid GPS range) | `DISPATCH.md`, `GpsLocationUpdateSchema` |
| 35 | Safety & AI Layer | Create Visitor Pass | Generates a time-limited QR gate pass for security verification at campus gate. | `POST /api/v1/safety/visitors` Header: `Bearer <adminToken>`, Body: `CreateVisitorPassSchema` | `201 Created`, `{ success: true, data: { passId: string, qrCodeData: string, ... }, timestamp, correlationId }` | `400 Bad Request` (invalid phone or missing host staff) | `bomis_postman_collection.json` (lines 1095-1138), `CreateVisitorPassSchema` |
| 36 | Safety & AI Layer | Verify Child Pickup | Validates dynamic dismissal OTP and authorized guardian identity at gate before child release. | `POST /api/v1/safety/pickup/verify` Header: `Bearer <adminToken>`, Body: `VerifyChildPickupSchema` | `200 OK`, `{ success: true, data: { authorized: boolean, studentId: string }, timestamp, correlationId }` | `400 Bad Request` (OTP length != 6); `403 Forbidden` (guardian not authorized to pickup) | `bomis_postman_collection.json` (lines 1140-1182), `VerifyChildPickupSchema` |
| 37 | Safety & AI Layer | Anonymous Incident Report | Zero-log anonymous safety report accessible only to Principal; strictly excludes IP address and user identity logs. | `POST /api/v1/safety/incidents/anonymous` Auth: Public (No token), Body: `AnonymousIncidentReportSchema` | `201 Created`, `{ success: true, data: { trackingCode: string, ... }, timestamp, correlationId }` | `400 Bad Request` (description < 10 chars or invalid grade) | `bomis_postman_collection.json` (lines 1184-1221), `AnonymousIncidentReportSchema` |
| 38 | Safety & AI Layer | List Visitor Passes | Displays active, pre-approved, and checked-out visitor passes for security gatekeepers. | `GET /api/v1/safety/visitors` Header: `Bearer <adminToken>` | `200 OK`, `{ success: true, data: VisitorPassDto[], timestamp, correlationId }` | `401 Unauthorized`, `403 Forbidden` | `DISPATCH.md` |
| 39 | Safety & AI Layer | AI Study Buddy Chat | Provides grade-appropriate, syllabus-grounded curriculum assistance for CBSE students and parents. | `POST /api/v1/ai/study-buddy/chat` Header: `Bearer <token>`, Body: `{ prompt: string, grade?: number, subject?: string }` | `200 OK`, `{ success: true, data: { response: string, sources: string[] }, timestamp, correlationId }` | `400 Bad Request` (empty prompt); `429 Too Many Requests` (rate limit) | `DISPATCH.md`, `ORIGINAL_REQUEST.md` (line 53) |
| 40 | RBAC Negative Gate | Audit Logs Gate | Rejects parent access to DPDP administrative audit trail with explicit `403 Forbidden`. | `GET /api/v1/admin/audit-logs` Header: `Bearer <parentToken>` | `403 Forbidden`, `{ success: false, data: null, error: { code: "FORBIDDEN" \| "INSUFFICIENT_PERMISSIONS", message: string } }` | Guaranteed 403 Forbidden | `bomis_postman_collection.json` (lines 1229-1262) |
| 41 | RBAC Negative Gate | Marks Entry Gate | Rejects student attempts to submit or mutate academic grade records with explicit `403 Forbidden`. | `POST /api/v1/academics/marks/batch` Header: `Bearer <studentToken>` | `403 Forbidden`, `{ success: false, data: null, error: { code: "FORBIDDEN", message: string } }` | Guaranteed 403 Forbidden | `bomis_postman_collection.json` (lines 1264-1304) |
| 42 | RBAC Negative Gate | Fee Structures Gate | Rejects transport driver access to school financial fee structures with explicit `403 Forbidden`. | `GET /api/v1/fees/structures` Header: `Bearer <driverToken>` | `403 Forbidden`, `{ success: false, data: null, error: { code: "FORBIDDEN", message: string } }` | Guaranteed 403 Forbidden | `bomis_postman_collection.json` (lines 1306-1339) |

---

## 3. Edge Cases & Boundary Behaviors

| # | Feature | Input | Observed / Specified Behavior |
|---|---------|-------|-------------------------------|
| 1 | Correlation ID Propagation | Incoming request with header `x-correlation-id: corr-test-uuid-1234` | The NestJS API extracts `x-correlation-id` via middleware, binds it to Node.js `AsyncLocalStorage`, logs it in Pino, and outputs the identical string in both the response header `x-correlation-id` and the response body `correlationId`. |
| 2 | Correlation ID Omission | Incoming request without `x-correlation-id` header | The middleware automatically generates a fresh UUID prefixed with `corr-` (e.g. `corr-9f2b...`), sets it on the request context, and returns it in response header and JSON envelope. |
| 3 | Financial Idempotency (Fresh Key) | `POST /api/v1/fees/orders` with new `Idempotency-Key: idemp-001` | Server acquires Redis lock `idemp:idemp-001`, computes fee, creates Razorpay order, persists payment record, caches JSON response in Redis (24-hour TTL), releases lock, and returns `201 Created`. |
| 4 | Financial Idempotency (Duplicate Key, Identical Body) | `POST /api/v1/fees/orders` repeated with same `Idempotency-Key: idemp-001` and identical body | Server checks Redis key `idemp:idemp-001`, discovers existing completed payload hash, and immediately returns the cached `201 Created` response without creating a second Razorpay order or duplicate database row. |
| 5 | Financial Idempotency (Duplicate Key, Different Body) | `POST /api/v1/fees/orders` repeated with same `Idempotency-Key: idemp-001` but different installment number | Server discovers payload hash mismatch for the existing idempotency key and returns `409 Conflict` with `error.code = 'IDEMPOTENCY_CONFLICT'`. |
| 6 | Financial Webhook HMAC Verification | `POST /api/v1/fees/webhook` with forged or expired `X-Razorpay-Signature` | Server computes HMAC-SHA256 of raw request buffer using `RAZORPAY_WEBHOOK_SECRET`. On signature mismatch, immediately rejects request with `400 Bad Request` and `error.code = 'INVALID_WEBHOOK_SIGNATURE'`; no payment status is updated. |
| 7 | Global Route Prefixing Exemption | `GET http://localhost:4000/health` and `GET http://localhost:4000/ready` | NestJS `app.setGlobalPrefix('api/v1', { exclude: ['health', 'ready'] })` ensures probes respond at root, while all business endpoints respond under `/api/v1/...`. Newman test calls directly to `{{baseUrl}}/health` pass with `200 OK`. |
| 8 | Timetable Clash Matrix (Teacher Overlap) | `POST /api/v1/academics/timetable/clash-check` where teacher is already scheduled for Period 3 on Monday | Returns `200 OK` with `{ success: true, data: { hasClash: true, conflictType: "TEACHER_DOUBLE_BOOKED", details: { teacherId, periodNumber: 3, existingSection: "5A" } } }`. |
| 9 | CBSE Marks Score Clamping | `POST /api/v1/academics/marks/batch` with `periodicTest = 12.0` (max 10) or `examMarks = 85.0` (max 80) | Request is rejected by Zod validation pipe with `400 Bad Request` and detailed error array specifying violating fields and maximum bounds. |
| 10 | Rapid Attendance Exceptions Only | `POST /api/v1/attendance` with `defaultStatus = "PRESENT"` and 2 student IDs in `exceptions: [...]` | Entire class section roster (e.g., 30 students in Grade 5A) is processed in a single transaction: 28 students marked `PRESENT`, 2 students marked with exception status (e.g., `ABSENT`, `HALF_DAY`). Returns `processedCount = 30`. |
| 11 | Anonymous Incident Zero-Log Mandate | `POST /api/v1/safety/incidents/anonymous` | The controller intercepts the payload and strictly suppresses logging of client IP, bearer tokens, or user agents. The record is written to database with `user_id = null`, and no matching `audit_logs` record containing user identity is produced. |
| 12 | Soft Deletes DPDP 90-Day Retention | `DELETE /api/v1/people/students/:id` | Soft deletes student by setting `deleted_at = NOW()` and `retention_until = NOW() + INTERVAL '90 days'`. Application queries filter out rows where `deleted_at IS NOT NULL`. Background worker permanently shreds after 90 days. |
| 13 | Multi-Child Sibling Access | Parent querying siblings via `GET /api/v1/people/guardians/siblings` | Looks up authenticated user's `guardian_profile`, traverses `student_guardians` junction table, and returns all linked students (e.g. Aarav Patel in Grade 5A and Ananya Patel in Grade 2A). Zero access to unrelated students. |
| 14 | Postman Environment Variable Idempotency | Postman Newman runner with default environment variables (`stu_grade5a_001`, `cls_grade_5`, `sec_grade_5_a`) | When Newman executes against seeded database, the controller resolvers translate both symbolic seed IDs (`stu_grade5a_001` or seed UUIDs `b1000000-0005-4000-8000-000000000001`) deterministically to prevent test breakage. |

---

## 4. Header Contracts & Protocol Specifications

Every HTTP transaction across `/apps/api` must satisfy the following contract rules:

### 4.1 Request Headers
| Header Name | Type | Requirement | Applicable Endpoints | Description |
|---|---|---|---|---|
| `x-correlation-id` | `string` (UUID) | Optional on client, Auto-injected if missing | All endpoints | Distributed tracing identifier across HTTP requests, Pino JSON logs, and database transactions. Format: `corr-<uuid>`. |
| `Authorization` | `string` (`Bearer <jwt>`) | Required for authenticated endpoints | All protected routes (Folders 01 [part], 02, 03, 04, 05, 06, 07 [part], 08) | Short-lived JSON Web Token signed with `JWT_SECRET`, containing `sub` (userId), `role` (UserRole), `schoolId` (UUID), `email`/`phone`. |
| `Idempotency-Key` | `string` (`idemp-<uuid>`) | Mandatory for financial and sync operations | `POST /api/v1/fees/orders`, `POST /api/v1/sync/batch`, `POST /api/v1/attendance` | Unique client transaction UUID preventing double-billing, duplicate sync queue insertion, and race conditions. |
| `x-school-id` | `string` (UUID or code) | Optional in single-school, Mandatory in multi-tenant | All routes | Tenant isolation identifier binding queries to specific institutional schema context. Defaults to root school `sch_bomis_sambalpur_001` if omitted. |
| `X-Razorpay-Signature` | `string` (Hex HMAC) | Mandatory for payment webhooks | `POST /api/v1/fees/webhook` | Cryptographic HMAC-SHA256 signature generated by Razorpay using `RAZORPAY_WEBHOOK_SECRET` over the raw webhook payload. |
| `Content-Type` | `string` (`application/json`) | Mandatory for mutation bodies | All `POST`, `PUT`, `PATCH` | Specifies JSON serialized payload format. |

### 4.2 Response Headers
| Header Name | Value | Purpose |
|---|---|---|
| `x-correlation-id` | `<request-correlation-id>` | Guarantees client can trace response to its originating request. |
| `Content-Type` | `application/json; charset=utf-8` | Standard JSON response payload (or `application/pdf` on receipt download). |
| `X-RateLimit-Limit` | `100` | Requests permitted per time window. |
| `X-RateLimit-Remaining`| `95` | Remaining quota in current window. |

---

## 5. Standard Response Envelope & Error Architecture

### 5.1 Success Envelope (Strict AC-2 / ADR 0003 Contract)
Every successful JSON REST response must conform to:
```typescript
{
  "success": true,
  "data": T,
  "error": null, // or omitted
  "timestamp": "2026-10-18T07:15:00.000Z",
  "correlationId": "corr-7b3b4f62-38d4-4bb2-96cb-847285c57dc4"
}
```

### 5.2 Error Envelope
Every failure response (4xx and 5xx) must conform to:
```typescript
{
  "success": false,
  "data": null,
  "error": {
    "code": "FORBIDDEN" | "BAD_REQUEST" | "UNAUTHORIZED" | "NOT_FOUND" | "CONFLICT" | "INTERNAL_SERVER_ERROR",
    "message": "Human-readable description of error",
    "details": [
      {
        "field": "phone",
        "issue": "Invalid Indian mobile number (+91XXXXXXXXXX)"
      }
    ]
  },
  "timestamp": "2026-10-18T07:15:00.000Z",
  "correlationId": "corr-7b3b4f62-38d4-4bb2-96cb-847285c57dc4"
}
```

### 5.3 Standard HTTP Status Code Mapping
| Status Code | Reason | Typical Trigger | Error Code Constant |
|---|---|---|---|
| `200 OK` | Standard query or update success | `GET /students`, `POST /auth/login`, `POST /marks/batch` | N/A |
| `201 Created` | Successful resource creation | `POST /students`, `POST /attendance`, `POST /fees/orders` | N/A |
| `302 Found` | Resource redirection | `GET /fees/receipts/:id` (redirect to MinIO signed S3 URL) | N/A |
| `400 Bad Request` | Zod validation failure, malformed JSON | Invalid phone format, scores exceeding max limits | `BAD_REQUEST`, `VALIDATION_FAILED` |
| `401 Unauthorized` | Missing, expired, or invalid token | Invalid password, expired JWT, revoked session | `UNAUTHORIZED`, `TOKEN_EXPIRED` |
| `403 Forbidden` | Authenticated user lacks required role/permission | Parent accessing audit logs, student entering marks | `FORBIDDEN`, `INSUFFICIENT_PERMISSIONS` |
| `404 Not Found` | Entity does not exist or soft-deleted | Unknown student ID, missing fee receipt | `NOT_FOUND`, `ENTITY_NOT_FOUND` |
| `409 Conflict` | Unique constraint violation or idempotency conflict | Duplicate admission number, duplicate idempotency key | `CONFLICT`, `DUPLICATE_ENTITY`, `IDEMPOTENCY_CONFLICT` |
| `429 Too Many Requests` | Rate limit window exhausted | > 5 OTP requests per 15 minutes | `TOO_MANY_REQUESTS`, `RATE_LIMIT_EXCEEDED` |
| `500 Internal Error`| Unhandled technical failure | Database connection drop, crypto cipher failure | `INTERNAL_SERVER_ERROR` |
| `503 Service Unavailable` | Critical backing service unreachable | Database or Redis probe failure on `/ready` | `SERVICE_UNAVAILABLE` |

---

## 6. RBAC Role & Permission Matrix Specification

The system recognizes 8 distinct canonical roles with granular permissions defined in `@bomis/shared`:

```
UserRole:
  - SUPER_ADMIN
  - ADMIN
  - PRINCIPAL
  - TEACHER
  - ACCOUNTANT
  - STUDENT
  - PARENT
  - TRANSPORT_STAFF (alias: DRIVER_TRANSPORT)
```

### 6.1 Role Access Matrix across API Domains
| Endpoint Domain | SUPER_ADMIN | ADMIN | PRINCIPAL | TEACHER | ACCOUNTANT | PARENT | STUDENT | TRANSPORT_STAFF |
|---|---|---|---|---|---|---|---|---|
| `GET /health`, `/ready` | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public |
| `POST /auth/otp/*` | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public |
| `POST /auth/staff/login`| ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public | ✅ Public |
| `GET /people/students` | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ (Own only) | ❌ | ❌ |
| `POST /people/students`| ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| `GET /people/guardians/siblings` | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ |
| `POST /attendance` (Rapid) | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| `POST /sync/batch` | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| `GET /attendance/students/:id` | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ (Own child) | ✅ (Self) | ❌ |
| `GET /fees/structures` | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ | ❌ (Asserts 403) |
| `POST /fees/orders` | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ❌ | ❌ |
| `POST /fees/webhook` | 🔒 HMAC Signature Required | 🔒 HMAC Signature Required | 🔒 HMAC | 🔒 HMAC | 🔒 HMAC | 🔒 HMAC | 🔒 HMAC | 🔒 HMAC |
| `GET /fees/receipts/:id`| ✅ | ✅ | ✅ | ❌ | ✅ | ✅ (Own child) | ❌ | ❌ |
| `POST /academics/marks/batch` | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ (Asserts 403) | ❌ |
| `POST /academics/timetable/clash-check` | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| `POST /academics/substitutions` | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| `GET /transport/routes`, `/buses` | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ | ✅ |
| `POST /transport/boarding/scan` | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| `POST /transport/gps-ping` | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| `POST /safety/visitors`| ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| `POST /safety/pickup/verify` | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ✅ |
| `POST /safety/incidents/anonymous` | ✅ Zero-Log | ✅ Zero-Log | ✅ Zero-Log | ✅ Zero-Log | ✅ Zero-Log | ✅ Zero-Log | ✅ Zero-Log | ✅ Zero-Log |
| `GET /admin/audit-logs`| ✅ | ✅ | ✅ | ❌ | ❌ | ❌ (Asserts 403) | ❌ | ❌ |
| `POST /ai/study-buddy/chat` | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ❌ |

---

## 7. NestJS Modular Monolith Architecture Blueprint

To fulfill the requirements, `/apps/api` must be structured into the following modular hierarchy:

```
apps/api/src/
├── main.ts                           # Bootstrap, Global Prefix, Swagger UI, Global Pipes/Filters
├── app.module.ts                     # Root Module aggregating all domain sub-modules
├── common/
│   ├── crypto/                       # AES-256-GCM Field Encryption Service (DPDP Act)
│   │   ├── crypto.service.ts
│   │   └── crypto.service.spec.ts
│   ├── decorators/
│   │   ├── current-user.decorator.ts # Extracts authenticated user payload from request
│   │   ├── roles.decorator.ts        # @Roles(UserRole.ADMIN, ...) metadata annotator
│   │   ├── bypass-envelope.decorator.ts # Bypasses standard envelope for binary streams
│   │   └── correlation-id.decorator.ts
│   ├── filters/
│   │   └── all-exceptions.filter.ts  # Standardizes all thrown exceptions to standard envelope
│   ├── guards/
│   │   ├── jwt-auth.guard.ts         # Verifies Bearer JWT token from Authorization header
│   │   └── roles.guard.ts            # Enforces RBAC permissions per @Roles decorator
│   ├── interceptors/
│   │   ├── transform.interceptor.ts  # Wraps all controller outputs into standard envelope
│   │   └── logging.interceptor.ts    # Pino HTTP access and duration logging
│   ├── middleware/
│   │   ├── correlation.middleware.ts # Extracts/generates x-correlation-id & binds to AsyncLocalStorage
│   │   └── tenant.middleware.ts      # Sets Postgres RLS session variable app.current_school_id
│   └── pipes/
│       └── zod-validation.pipe.ts    # Validates DTOs against @bomis/shared Zod schemas
├── database/
│   ├── prisma.service.ts             # Prisma Client lifecycle, RLS query hooks, soft-delete filter
│   └── database.module.ts
├── modules/
│   ├── health/                       # /health and /ready Terminus probes
│   │   ├── health.controller.ts
│   │   └── health.module.ts
│   ├── auth/                         # /api/v1/auth (OTP, Staff Login, Refresh, Logout)
│   │   ├── auth.controller.ts
│   │   ├── auth.service.ts
│   │   ├── auth.module.ts
│   │   └── jwt.strategy.ts
│   ├── people/                       # /api/v1/people (Students, Guardians, Siblings, Staff, CSV)
│   │   ├── people.controller.ts
│   │   ├── people.service.ts
│   │   └── people.module.ts
│   ├── attendance/                   # /api/v1/attendance (Rapid Grid, Stats, Leaves)
│   │   ├── attendance.controller.ts
│   │   ├── attendance.service.ts
│   │   └── attendance.module.ts
│   ├── sync/                         # /api/v1/sync (Offline Outbox Batch Synchronization)
│   │   ├── sync.controller.ts
│   │   ├── sync.service.ts
│   │   └── sync.module.ts
│   ├── fees/                         # /api/v1/fees (Structures, Razorpay Orders, Webhooks, Receipts)
│   │   ├── fees.controller.ts
│   │   ├── fees.service.ts
│   │   ├── fees.module.ts
│   │   └── idempotency.service.ts    # Redis distributed locking & cache
│   ├── academics/                    # /api/v1/academics (Terms, CBSE Marks, Timetable, Substitutes)
│   │   ├── academics.controller.ts
│   │   ├── academics.service.ts
│   │   ├── academics.module.ts
│   │   └── cbse-grader.ts            # Pure 9-point scholastic & co-scholastic grading math
│   ├── transport/                    # /api/v1/transport (Routes, Buses, Boarding Scans, GPS Pings)
│   │   ├── transport.controller.ts
│   │   ├── transport.service.ts
│   │   └── transport.module.ts
│   ├── safety/                       # /api/v1/safety (Visitor Passes, Child Pickup, Anonymous Incidents)
│   │   ├── safety.controller.ts
│   │   ├── safety.service.ts
│   │   └── safety.module.ts
│   ├── ai/                           # /api/v1/ai (Study Buddy syllabus chat, Lesson Planner)
│   │   ├── ai.controller.ts
│   │   ├── ai.service.ts
│   │   └── ai.module.ts
│   └── admin/                        # /api/v1/admin (Audit Logs, Pulse Dashboard)
│       ├── admin.controller.ts
│       ├── admin.service.ts
│       └── admin.module.ts
```

---

## 8. Financial Safety & Razorpay Idempotency Specification

### 8.1 Idempotency-Key Flow
1. **Client Request**: Client sends `POST /api/v1/fees/orders` with `Idempotency-Key: idemp-<uuid>`.
2. **Key Check**:
   - Check Redis key `idemp:<key>`.
   - If key exists and status is `COMPLETED`: Return cached response immediately with `201 Created`.
   - If key exists and status is `PROCESSING`: Return `409 Conflict` (Operation in flight).
   - If key exists with different payload hash: Return `409 Conflict` with `IDEMPOTENCY_CONFLICT`.
3. **Execution**:
   - Set Redis key `idemp:<key>` with status `PROCESSING` and 60-second TTL.
   - Verify student installment due amount in database.
   - Call Razorpay API (or test mock) to create order.
   - Record pending payment record in `payments` table.
   - Store result in Redis `idemp:<key>` with status `COMPLETED` and 24-hour TTL.
   - Return standard response envelope with `201 Created`.

### 8.2 Webhook Cryptographic Verification Flow
1. Client (Razorpay) POSTs to `/api/v1/fees/webhook` with `X-Razorpay-Signature`.
2. Controller captures raw request buffer before JSON parsing.
3. Computes:
   ```typescript
   const expectedSignature = crypto
     .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET || 'test_secret')
     .update(rawBody)
     .digest('hex');
   ```
4. If `expectedSignature !== incomingSignature` (and not test mock bypass):
   - Throws `BadRequestException('Invalid webhook signature')`.
5. On valid signature:
   - Updates `payments` table to `SUCCESS`.
   - Updates `fee_installments` table to `SUCCESS`.
   - Emits event to generate PDF receipt and send SMS/WhatsApp notification.
   - Returns `{ success: true, data: { processed: true } }`.

---

## 9. CBSE Academic & Grading Computation Engine

### 9.1 Scholastic Subject Score Aggregation (Grades 1 through 8)
- **Periodic Test (PT)**: Scaled to **10 marks** maximum.
- **Notebook Submission (NB)**: **5 marks** maximum (regularity, neatness, assignment completion).
- **Subject Enrichment (SE)**: **5 marks** maximum (speaking/listening, lab activities, practicals).
- **Term Examination (Exam)**: **80 marks** maximum (half-yearly or annual written examination).
- **Total Aggregate**: $\text{Total} = \text{PT} + \text{NB} + \text{SE} + \text{Exam} = 100\text{ marks}$.

### 9.2 CBSE 9-Point Grading Conversion Scale
| Aggregate Percentage Marks Range | CBSE Grade | Grade Point | Assessment Performance |
|---|---|---|---|
| **91.0% – 100.0%** | `A1` | 10.0 | Outstanding |
| **81.0% – 90.9%** | `A2` | 9.0 | Excellent |
| **71.0% – 80.9%** | `B1` | 8.0 | Very Good |
| **61.0% – 70.9%** | `B2` | 7.0 | Good |
| **51.0% – 60.9%** | `C1` | 6.0 | Fair / Above Average |
| **41.0% – 50.9%** | `C2` | 5.0 | Average |
| **33.0% – 40.9%** | `D` | 4.0 | Pass / Minimum Competency |
| **0.0% – 32.9%** | `E` | — | Essential Repeat / Needs Remedial Support |

Co-scholastic areas (Work Education, Art Education, Health & Physical Education, Discipline) use a **3-point grading scale**:
- `A` = Outstanding
- `B` = Very Good
- `C` = Fair

---

## 10. Verification and Newman Compatibility Matrix

To guarantee 100% clean passes in Newman E2E tests:
1. **Identifier Resolution Fallback**:
   Newman runs with seed environment variables (`studentId: "stu_grade5a_001"`, `classId: "cls_grade_5"`, `sectionId: "sec_grade_5_a"`, `busId: "bus_pilot_01"`).
   The backend services must resolve these symbolic keys against the seeded UUID fixtures (e.g. `stu_grade5a_001` maps to `SEED_IDS.STUDENT_AARAV` = `b1000000-0005-4000-8000-000000000001`).
2. **Correlation Matching**:
   The response envelope `correlationId` MUST match the request `x-correlation-id` header when provided.
3. **Response Envelope Consistency**:
   Every JSON response must have `{ success: boolean, data: any, timestamp: string, correlationId: string }`. If `success === false`, `error: { code: string, message: string }` must be present.
4. **Latency Budget**:
   Global Newman test asserts `responseTime < 1000ms`. In-memory database indexing on `school_id`, `student_id`, and `section_id` ensures responses resolve within 20–50ms.

---
*Authored by Spec Miner 1 for BOMIS Sambalpur Unified School Platform (Milestone M3).*
