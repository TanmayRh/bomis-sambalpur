## 2026-10-18T06:30:30Z
You are Worker M2 Remediation (teamwork_preview_worker).
Your working directory is: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m2_remediation
Project root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

MANDATORY FIRST STEP:
Read C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md completely.
Also read:
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m2_remediation\analysis.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\challenger_m2_1\handoff.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\prisma\schema.prisma

WRITE OWNERSHIP:
You have exclusive write ownership of `prisma/schema.prisma`.

TASK REQUIREMENTS:
Apply the 6 remediation changes to `prisma/schema.prisma` as detailed in `explorer_m2_remediation/analysis.md`:
1. `Payment.receipt_number`: Change from table-global `@unique` to `@@unique([school_id, receipt_number])`.
2. `Payment.student`: Change `onDelete: Cascade` to `onDelete: Restrict` to safeguard the 8-year statutory financial ledger retention.
3. `VisitorPass.pass_code`: Change from table-global `@unique` to `@@unique([school_id, pass_code])` and remove the redundant non-unique index.
4. `FeeInstallment`: Add compound unique constraint `@@unique([school_id, student_id, fee_structure_id, installment_number])` to enforce database-level billing idempotency.
5. Add missing indexes:
   - In `Student`: `@@index([school_id, academic_year_id])`
   - In `Payment`: `@@index([school_id, installment_id])`
   - In `FeeInstallment`: `@@index([school_id, fee_structure_id])`
   - In `StudentGuardian`: `@@index([deleted_at])`
6. Add referential integrity relations to `Staff`:
   - In `FeeConcession`: `approved_by Staff? @relation("ConcessionApprover", fields: [approved_by_id], references: [id], onDelete: SetNull)` and add corresponding inverse relation array `concessions_approved FeeConcession[] @relation("ConcessionApprover")` on `Staff`.
   - In `VisitorPass`: `person_to_meet Staff? @relation("VisitorHost", fields: [person_to_meet_id], references: [id], onDelete: SetNull)` and add corresponding inverse relation array `visitor_passes VisitorPass[] @relation("VisitorHost")` on `Staff`.

VERIFICATION:
Verify line-by-line that all relations, composite indexes, and unique constraints in `prisma/schema.prisma` are valid and match `explorer_m2_remediation/analysis.md`.
Verify that `prisma/seed.ts` is 100% compatible.

OUTPUT:
Write your complete 5-component handoff report (Observation, Logic Chain, Caveats, Conclusion, Verification Method) to:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m2_remediation\handoff.md
Send a message back to the orchestrator (caller) when complete.
