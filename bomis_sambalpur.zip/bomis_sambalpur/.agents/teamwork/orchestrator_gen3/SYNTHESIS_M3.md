# Architectural Synthesis: Milestone M3 (NestJS Modular Monolith API)

**Synthesized from**:
1. `spec_miner_m3_1/analysis.md` & `handoff.md` (API Spec Miner)
2. `explorer_m3_1/analysis.md` & `handoff.md` (Core Infra & Data Explorer)
3. `explorer_m3_2/analysis.md` & `handoff.md` (Domain Modules & App Explorer)

---

## 1. Consensus Decisions

1. **Routing & Global Prefix**:
   - Set global prefix `api/v1` with explicit exclusion: `app.setGlobalPrefix('api/v1', { exclude: ['health', 'ready'] })`. This allows Postman to query `GET /health` and `GET /ready` at root while all domain endpoints live under `/api/v1/...`.

2. **Standard API Response Envelope**:
   - All REST endpoints strictly return:
     ```typescript
     {
       success: boolean;
       data: T | null;
       error?: { code: string; message: string; details?: any } | null;
       timestamp: string;
       correlationId: string;
     }
     ```
   - Global `TransformInterceptor` wraps successful JSON responses.
   - Global `HttpExceptionFilter` (AllExceptionsFilter) catches all exceptions (Zod, HttpException, internal errors) and produces the unified error envelope.
   - Binary streams (PDF receipts, CSV streams) bypass envelope wrapping via `@BypassEnvelope()` or content-type check.

3. **Request Tracing & Header Echoing**:
   - `CorrelationIdMiddleware` extracts `x-correlation-id` from incoming request headers (or generates `corr-<uuid>`), binds it to `AsyncLocalStorage`, sets response header `x-correlation-id`, and injects it into both `TransformInterceptor` and `HttpExceptionFilter`.

4. **Multi-Tenant PostgreSQL Row-Level Security & Tenant Resolution**:
   - Dual-layer tenant isolation: Layer 1 Prisma Client query extension injecting `where: { school_id }` across all 35 tenant models, paired with Layer 2 PostgreSQL kernel RLS transaction policy (`SET LOCAL app.current_school_id = $schoolId`).
   - Transparent slug resolution: Maps Postman environment string `"sch_bomis_sambalpur_001"` to seeded database UUID `SEED_IDS.SCHOOL` (`e4b3c2a1-0001-4000-8000-000000000001`).

5. **DPDP Act (2023) Soft Delete & 90-Day Retention Schedule**:
   - 18 models implement `deleted_at` and `retention_until`.
   - Reads automatically inject `where: { deleted_at: null }`.
   - Deletions are converted to updates setting `deleted_at = now()` and `retention_until = now() + 90 days`.
   - Automated cryptographic erasure background job cleanses expired records.

6. **Field-Level AES-256-GCM Encryption**:
   - Integrated with `CryptoService` (`apps/api/src/common/crypto/crypto.service.ts`) using `tenant:${schoolId}` as Additional Authenticated Data (AAD).
   - Protects 8 sensitive PII columns across `Student`, `Guardian`, `Staff`, and `VisitorPass` with role-based masking.

7. **Dual Authentication & Session Lifecycle**:
   - Mobile OTP for Parents & Students with mock code `"123456"` (300s TTL). Accepts both `"code"` and `"otp"` fields in payload.
   - Email + Password (`Admin@Sambalpur2026`) for Staff.
   - 15m JWT Access Token + 7d rotating Refresh Token with token family revocation defense.

8. **RBAC Security & Negative Gates**:
   - Enforces the 8 canonical roles: `SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `TEACHER`, `ACCOUNTANT`, `STUDENT`, `PARENT`, `TRANSPORT_STAFF`.
   - Global `RolesGuard` throws HTTP 403 `INSUFFICIENT_PERMISSIONS` on unauthorized access, satisfying Postman negative gate tests.

9. **Financial Safety & Idempotency**:
   - Distributed `Idempotency-Key` header locking and caching for order creation and payment endpoints. Replays with identical payload return cached 201; differing payload returns 409 Conflict.
   - Razorpay webhook verifies HMAC-SHA256 signature using `RAZORPAY_WEBHOOK_SECRET`.

10. **In-Memory Mock Fallback for Resilient Execution**:
    - Services feature connection probing (1500ms timeout) with automatic in-memory fallback pre-seeded with `SEED_IDS` fixtures to guarantee zero crashes during offline unit testing, CI pipelines, or container bootstrapping.

---

## 2. Domain Modules Implementation Matrix

| Domain Module | Primary Controller Routes | Key Services & Dependencies | Postman / E2E Mapping |
|---------------|---------------------------|-----------------------------|-----------------------|
| `health` | `GET /health`, `GET /ready` | Terminus, Prisma probe, Redis probe | `00_System_Health_and_Probes` |
| `auth` | `/api/v1/auth/otp/send`, `/otp/verify`, `/staff/login`, `/refresh`, `/logout` | `AuthService`, `JwtService`, `UsersService`, OTP store | `01_Authentication_and_RBAC` |
| `people` | `/api/v1/people/students`, `/students/:id`, `/guardians/siblings`, `/staff`, `/students/bulk-import` | `PeopleService`, `PrismaService`, CSV stream parser | `02_People_Management` |
| `attendance`| `/api/v1/attendance`, `/attendance/batch`, `/sync/batch`, `/attendance/leaves`, `/attendance/students/:id` | `AttendanceService`, offline sync queue, percentage calculator | `03_Attendance_and_Offline_Sync` |
| `fees` | `/api/v1/fees/structures`, `/fees/orders`, `/fees/webhook`, `/fees/receipts/:id`, `/fees/concessions` | `FeesService`, Razorpay gateway, idempotency lock, receipt PDF generator | `04_Fees_and_Financial_Safety` |
| `academics` | `/api/v1/academics/terms`, `/marks/batch`, `/timetable/clash-check`, `/substitutions` | `AcademicsService`, CBSE 9-point calculator, clash matrix | `05_Academics_and_CBSE_Grading` |
| `transport` | `/api/v1/transport/routes`, `/transport/buses`, `/transport/boarding/scan`, `/transport/gps-ping` | `TransportService`, Socket.IO gateway, Haversine proximity | `06_Transport_Fleet_Operations` |
| `safety` | `/api/v1/safety/visitors`, `/safety/pickup/verify`, `/safety/incidents/anonymous` | `SafetyService`, QR generator, zero-log incident recorder | `07_Safety_and_Visitor_Management` |
| `ai` | `/api/v1/ai/study-buddy/chat`, `/api/v1/ai/lesson-planner/remarks` | `AiService`, grade-curriculum mock LLM, human review flag | Original Request R5 |
| `pulse` | `/api/v1/pulse/metrics`, `/pulse/live` | `PulseService`, school KPI aggregator | Original Request R5 |

---

## 3. Worker Implementation Strategy

A single comprehensive Worker (`worker_m3_implementation`) will construct the NestJS Modular Monolith API following these strictly partitioned file boundaries:
- `apps/api/src/common/` (filters, interceptors, pipes, guards, decorators, middleware, logger)
- `apps/api/src/database/` (Prisma service, extensions, RLS, in-memory mock fallback)
- `apps/api/src/modules/` (health, auth, people, attendance, fees, academics, transport, safety, ai, pulse)
- `apps/api/src/app.module.ts` and `apps/api/src/main.ts`
- Unit tests in `apps/api/src/**/*.spec.ts`

Verification Gate will follow:
- 2 Independent Reviewers
- 2 Empirical Challengers
- 1 Forensic Auditor (Binary veto for integrity)
