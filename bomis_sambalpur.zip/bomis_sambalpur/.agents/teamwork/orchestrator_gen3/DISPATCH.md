# Dispatch: Orchestrator Generation 3

## 2026-10-18T06:55:00Z
- **Target Agent**: teamwork_preview_orchestrator (Generation 3 Successor)
- **Parent**: Sentinel (`f0c35bf8-64ac-47bc-b1c3-1f42570e30fe`)
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen3`
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Previous Generation Handoff**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen2\handoff.md`
- **Authoritative Request**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`
- **Project Master Specification**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`
- **Gate Status**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen2\GATE_STATUS.md`
- **Test Infrastructure**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md`
- **Architectural Blueprint**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_survey_1\analysis.md`

## Mandate
1. Milestone M1 (Monorepo Foundation & Tooling) and E2E Postman Newman Track are COMPLETE.
2. Milestone M2 (Shared Packages, 36 Prisma DPDP Models, Field-Level Encryption, Seed Generator) is COMPLETE and APPROVED by Gate 2 with CLEAN forensic audit.
3. Advance immediately to **Milestone M3: NestJS Modular Monolith API**:
   - `/apps/api` NestJS 10 modular monolith with strict domain modules.
   - Prisma Service with PostgreSQL RLS middleware.
   - Pino structured logger with X-Correlation-ID AsyncLocalStorage.
   - Global validation pipes, HttpExceptionFilter standard envelope (`ApiResponse<T>`).
   - Swagger OpenAPI at `/api/docs` and Terminus `/health` & `/ready` probes.
   - Auth Module: Dual authentication (Parents/Students mobile OTP, Staff email+password/OTP), rotating JWT refresh tokens with family revocation, 8 RBAC roles guard.
   - People Module: Multi-child sibling linking under single guardian account, streaming bulk CSV ingestion with row validation error logs.
   - Attendance Module: Rapid attendance grid (<10s class mark), `/api/v1/sync/batch` offline sync queue with idempotency, instant FCM push absence alert dispatch.
   - Homework Module: Rich text assignments, MinIO attachment storage, student submission tracking.
   - Fees Module: Fee structures & installment generation, multi-step concession approvals, Razorpay payment gateway integration (test mode) with HMAC webhook signature verification, `Idempotency-Key` financial safety, BullMQ fee tax receipt PDF generator.
   - Academics Module: CBSE 9-point grading validation, timetable scheduler with teacher & room conflict detection, 1-click substitute teacher reassignment, BullMQ report card PDF generator.
   - Transport Fleet: Socket.IO GPS gateway, geofence 5-minute proximity alerts, dynamic QR student boarding/deboarding logging.
   - Safety & Governance: Visitor QR gate pass, child pickup OTP verification, anonymous anti-bullying incident reporting, DPDP health record access controls.
   - AI Assistance: Grade-appropriate curriculum study buddy mock assistant, teacher lesson planner draft remarks assist with mandatory human review.
4. Execute Milestone M3 iteration loop: Explorers -> Worker -> Reviewers (2) -> Challengers (2) -> Forensic Auditor -> Gate.
5. Proceed through subsequent milestones (M4 Next.js Web, M5 React Native Mobile, M6 Final Verification & Hardening).
6. Maintain `progress.md` and report to Sentinel (`f0c35bf8-64ac-47bc-b1c3-1f42570e30fe`) upon project completion.

## 2026-10-18T15:15:00Z
- **Sender**: Sentinel (`f0c35bf8-64ac-47bc-b1c3-1f42570e30fe`)
- **Directive**: Server restart / quota reset completed. Resume Milestone M3 Verification Gate:
  1. Reviewer 1: Architecture & Correctness
  2. Reviewer 2: Contracts, DPDP & Seed Compatibility
  3. Challenger 1: Math, Grading & RBAC Negative Gates
  4. Challenger 2: E2E Postman Contracts & Timetable Clashes
  5. Forensic Auditor: Anti-cheating, facade script detection, authentic test execution
- Evaluate Milestone M3 Verification Gate, record in GATE_STATUS.md, and upon clean pass advance through milestones M4 (Next.js 14 Web Portal), M5 (React Native Mobile App), M6 (Final Verification & Hardening).
