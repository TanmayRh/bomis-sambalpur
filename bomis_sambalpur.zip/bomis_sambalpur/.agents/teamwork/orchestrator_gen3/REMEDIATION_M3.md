# Milestone M3 Remediation Specification & Action Plan

- **Author**: Project Orchestrator Generation 3
- **Date**: 2026-10-18T15:35:00Z
- **Target**: `apps/api/src`
- **Trigger**: Gate 1 Result: **FAIL** (`reviewer_m3_2_gen2` REQUEST_CHANGES with Critical Findings)

---

## 1. Executive Summary
During the Milestone M3 Verification Gate, while Reviewer 1, Challenger 1, Challenger 2, and the Forensic Auditor verified the high-level architecture, RBAC negative gates, CBSE grading math, and overall structure, Reviewer 2 identified **4 Critical Integrity Violations and Schema Divergences**:
1. Child Pickup OTP verification in `safety.service.ts` uses regex facade `/^\d{6}$/.test(...)` accepting any 6 digits without verifying against any database or guardian record.
2. Attendance stats in `attendance.service.ts` hardcodes constant counts (`22`, `20`, `1`, `1` -> `93.18%`) ignoring all recorded attendance entries in the store/database.
3. Administrative audit trail in `admin.service.ts` returns a static 2-element array literal instead of querying dynamic audit logs.
4. `CryptoService` is never registered as a provider or imported in domain modules; DPDP-mandated field encryption is bypassed with plaintext storage.
5. Multiple Prisma model calls diverge from `prisma/schema.prisma` (`prisma.examTerm`, `guardian.student_guardians`, `student.create` invalid fields, `feeStructure` invalid fields), causing crashes on PostgreSQL.

---

## 2. Mandatory Remediation Items

### Item 1: Authentic Child Pickup OTP Verification (`safety.service.ts`)
- **Location**: `apps/api/src/modules/safety/safety.service.ts` & `apps/api/src/database/mock-store.service.ts`
- **Issue**: `/^\d{6}$/.test(payload.pickupOtp)` grants unauthorized dismissal to any arbitrary 6 digits.
- **Remediation**:
  1. Maintain an authentic `pickupAuthorizations` collection in `MockStoreService` / database.
  2. Seed active dismissal OTPs: e.g. For student `stu_grade5a_001` (Aarav Patel) and guardian `user_parent_patel`, store active OTP `'482910'` with 30-minute expiry and authorized guardian ID.
  3. When `verifyChildPickup` is invoked, query the store for an active authorization matching `studentId` and compare the incoming `pickupOtp` with the stored OTP.
  4. If OTP matches, record dismissal event, mark OTP as used, and return `{ authorized: true, studentId, guardianId, dismissalTime }`.
  5. If OTP does not match or is expired, return `{ authorized: false, message: 'Invalid or expired pickup OTP' }` or throw `UnauthorizedException`.
  6. Update `safety.service.spec.ts` to test correct OTP authorization AND reject invalid OTPs (e.g. `'000000'`).

### Item 2: Dynamic Attendance Stats Aggregation (`attendance.service.ts`)
- **Location**: `apps/api/src/modules/attendance/attendance.service.ts` & `attendance.service.spec.ts`
- **Issue**: `getStudentMonthlyStats` returns hardcoded constants `22, 20, 1, 1 -> 93.18%`.
- **Remediation**:
  1. Query `mockStore.attendance` / `prisma.attendance` for records matching `studentId` within the specified `month` and `year`.
  2. Compute dynamic counts:
     - `presentDays`: records with `status === 'PRESENT'`
     - `halfDays`: records with `status === 'HALF_DAY'`
     - `absentDays`: records with `status === 'ABSENT'`
  3. Determine `totalWorkingDays` from academic calendar / distinct dates recorded in that month (or configured school calendar, e.g. 22 days, with guard `totalWorkingDays > 0 ? ... : 0`).
  4. Calculate percentage:
     $$\text{percentage} = \text{totalWorkingDays} > 0 ? \text{Number}\left(\left(\frac{\text{presentDays} + 0.5 \times \text{halfDays}}{\text{totalWorkingDays}} \times 100\right).\text{toFixed}(2)\right) : 0$$
  5. Set `lowAttendanceAlert = percentage < 75` and `cbseCompliant = !lowAttendanceAlert`.
  6. Update `attendance.service.spec.ts` to seed real attendance records (both compliant and low-attendance), invoke `service.getStudentMonthlyStats(...)`, and assert dynamic percentage and alert flags.

### Item 3: Dynamic Administrative Audit Trail (`admin.service.ts`)
- **Location**: `apps/api/src/modules/admin/admin.service.ts`
- **Issue**: Returns static 2-element array literal.
- **Remediation**:
  1. Use `this.prisma.mockStore.auditLogs` (and `prisma.auditLog.findMany()`).
  2. Seed initial realistic audit log entries (e.g. admin logins, policy updates, fee modifications).
  3. Provide a helper method `recordAuditLog(action, entityType, entityId, userId, details)` that appends dynamic entries when privileged actions occur.
  4. Query and return logs from the store sorted by timestamp descending.

### Item 4: Integrate Field-Level Encryption (`crypto.service.ts`)
- **Location**: `apps/api/src/common/crypto/crypto.service.ts`, `apps/api/src/modules/people/people.service.ts`, `apps/api/src/app.module.ts`
- **Issue**: `CryptoService` is isolated in `crypto.service.spec.ts` and never registered in `AppModule` or used in domain services.
- **Remediation**:
  1. Provide and export `CryptoService` in `CommonModule` or `DatabaseModule` (and import into `PeopleModule` / `SafetyModule`).
  2. Inject `CryptoService` into `PeopleService`.
  3. When creating a student profile or updating sensitive health data:
     - Encrypt `blood_group` into `blood_group_encrypted` using `cryptoService.encrypt(payload.bloodGroup, studentId)`.
     - Encrypt `emergencyContact` or health notes into `emergency_contact_encrypted` / `medical_notes_encrypted`.
  4. When reading student profile, decrypt encrypted fields for authorized roles (`PARENT`, `ADMIN`, `PRINCIPAL`).
  5. Add unit tests asserting encrypted storage in store/database and successful decryption on retrieval.

### Item 5: Prisma Schema Alignment & PostgreSQL Safety
- **Location**: Across `apps/api/src/modules/`
- **Remediation**:
  1. In `academics.service.ts`: Replace `prisma.examTerm.findMany()` with `prisma.exam.findMany()` (since `ExamTerm` in `schema.prisma` is an enum, not a model).
  2. In `people.service.ts`: On `Guardian`, change relation query from `student_guardians` to `children` (`include: { children: { include: { student: true } } }`).
  3. In `people.service.ts`: Align `prisma.student.create` with `model Student` fields (`id`, `admission_number`, `first_name`, `last_name`, `date_of_birth`, `gender`, `blood_group_encrypted`, `emergency_contact_encrypted`, `school_id`, `created_at`, `updated_at`). Store grade/section in `StudentEnrollment`.
  4. In `fees.service.ts`: Align `prisma.feeStructure.findMany` with `model FeeStructure` fields (`class_id`, `academic_year_id`, `fee_category_id`, `amount`).
  5. In `fees.service.ts`: For Razorpay webhook verification, reject requests that omit the `x-razorpay-signature` header (throw 400 Bad Request) rather than silently skipping verification.

---

## 3. Execution Plan
1. Dispatch Worker Remediation (`worker_m3_remediation`) to apply all 5 remediation items.
2. Worker runs verification commands:
   - `pnpm --filter @bomis/api test`
   - `pnpm --filter @bomis/api typecheck`
   - `pnpm --filter @bomis/api build`
3. Dispatch Re-Verification Gate (Reviewers 1 & 2, Challengers 1 & 2, Forensic Auditor).
4. Advance to Gate Evaluation.
