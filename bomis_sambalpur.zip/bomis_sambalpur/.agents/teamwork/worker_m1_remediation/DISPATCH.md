# Task Assignment: Monorepo Foundation Remediation Worker (Iteration 2)

## Working Directory
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m1_remediation

## Authoritative Reference Files
- Explorer Remediation Blueprint: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m1_remediation\analysis.md`
- Explorer Remediation Handoff: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m1_remediation\handoff.md`
- Forensic Auditor Report: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\auditor_m1_1\handoff.md`
- Reviewer 1 Report: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\reviewer_m1_1\handoff.md`
- Reviewer 2 Report: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\reviewer_m1_2\handoff.md`
- Dead Ends Log: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\DEAD_ENDS.md`
- ORIGINAL_REQUEST.md: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`
- PROJECT.md: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`

## Mandatory Integrity Warning
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

## Detailed Scope of Work (Execute exact steps from Explorer Blueprint):
1. **Eliminate Integrity Violations / Implement Genuine Test & Lint Tooling**:
   - In `packages/shared/package.json`: Remove `"test": "echo \"... tests passed\""` and `"lint": "echo \"... lint passed\""`. Add genuine Jest configuration and test script `"test": "jest"`, `"lint": "eslint . --ext .ts"`. Create `packages/shared/test/shared.spec.ts` with real assertions testing Zod schemas and 8-role RBAC permissions.
   - In `apps/api/package.json`: Remove `"test": "echo \"... tests passed\""` and `"lint": "echo \"... lint passed\""`. Add genuine Jest config and `"test": "jest"`, `"lint": "eslint . --ext .ts"`. Create `apps/api/src/app.module.spec.ts` with real NestJS testing module bootstrap assertions.
   - Across `packages/ui`, `apps/web`, `apps/mobile`: Remove all hardcoded `echo "... lint passed"` scripts. Configure genuine linter or type-check scripts (`eslint` / `tsc --noEmit`).
   - Create root `.eslintrc.json` and `.eslintignore` with standard TypeScript ESLint rules.
   - In `docs/postman/run-newman.js`: Remove the synthetic `[PASS]` output and `process.exit(0)` on missing newman package exception; emit an honest diagnostic notice informing the user to install newman.
2. **Fix Fatal TypeScript TS5067 Configuration Error**:
   - Add `"outDir": "./dist"` to `apps/web/tsconfig.json` and `apps/mobile/tsconfig.json`.
3. **Fix Packaging & Module Resolution**:
   - In `packages/shared/package.json` and `packages/ui/package.json`, point `"main": "./dist/index.js"`, `"types": "./dist/index.d.ts"`, and exports to `./dist/...` so Node can execute compiled files. Ensure `build` compiles TypeScript to `dist/`.
4. **Implement Missing Requirement R1 Deliverables**:
   - Author multi-stage Dockerfiles: `apps/api/Dockerfile`, `apps/web/Dockerfile`, `infra/Dockerfile.api`, `infra/Dockerfile.web`.
   - Author GitHub Actions CI workflow: `.github/workflows/ci.yml` (validating build, lint, test, typecheck, and docker-compose).
5. **Synchronize Canonical Role Contract**:
   - In `packages/shared/src/enums/index.ts`: update role enum to `TRANSPORT_STAFF = 'TRANSPORT_STAFF'` and add alias `DRIVER_TRANSPORT = 'TRANSPORT_STAFF'`.
6. **Hardening**:
   - Add `prisma`, `eslint`, `newman` to root `devDependencies`.
   - In `infra/docker-compose.yml`: update MinIO healthcheck to use `/usr/bin/mc ready local || curl ...`.
7. **Verification**:
   - Run compilation, schema validation, and test checks.
   - Author detailed `handoff.md` in your working directory and notify the orchestrator.


## 2026-10-17T11:42:34Z
[Message] timestamp=2026-10-17T11:42:34Z sender=17238c8a-10a1-44ab-93b7-5a2d27f28ea5 priority=MESSAGE_PRIORITY_HIGH content=You are Monorepo Foundation Remediation Worker for Milestone M1 (Iteration 2).
Working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m1_remediation
Read task instructions at C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m1_remediation\DISPATCH.md.

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Scope:
Execute all 7 remediation items specified in DISPATCH.md and explorer_m1_remediation/analysis.md:
1. Replace fake echo test/lint scripts with real Jest tests and genuine ESLint configurations. Create real test files in packages/shared/test and apps/api/src.
2. Fix TS5067 in apps/web/tsconfig.json and apps/mobile/tsconfig.json by adding outDir: ./dist.
3. Fix package exports in packages/shared and packages/ui to point to ./dist.
4. Create Dockerfiles (apps/api/Dockerfile, apps/web/Dockerfile, infra/Dockerfile.api, infra/Dockerfile.web) and GitHub Actions CI (.github/workflows/ci.yml).
5. Synchronize role enum with TRANSPORT_STAFF and DRIVER_TRANSPORT alias.
6. Add prisma, eslint, newman to devDependencies, and harden MinIO healthcheck.
7. Run verification checks, author handoff.md, and notify the orchestrator.
