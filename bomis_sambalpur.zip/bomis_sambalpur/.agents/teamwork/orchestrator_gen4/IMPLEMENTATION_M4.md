# Milestone M4 Implementation Blueprint: Next.js 14 App Router Web Portal

**Project**: BOMIS Sambalpur Unified School Platform  
**Target Package**: `apps/web` (Next.js 14 App Router, TypeScript, Tailwind CSS, TanStack Query, React Hook Form, Zod)  
**Author**: Project Orchestrator Gen 4  
**Date**: 2026-10-19  

---

## 1. Executive Summary & Architecture

Milestone M4 establishes the full-featured, accessible, responsive Web Portal for Birla Open Minds International School (BOMIS), Sambalpur. It runs on Next.js 14.2.3 App Router, fully styled with Tailwind CSS and the official BOMIS design system tokens (BOMIS Navy `#0F2942`, Warm Coral `#FF6B4A`, Slate neutrals), and integrates with the NestJS backend API (`/api/v1`) via a type-safe API client consuming the standardized response envelope `{ success, data, error, timestamp, correlationId }`.

---

## 2. Directory Layout & Write Boundaries

Exclusive write ownership for `worker_m4_web` is strictly confined to `apps/web`:
```
apps/web/
├── src/
│   ├── app/
│   │   ├── (auth)/
│   │   │   ├── login/
│   │   │   │   └── page.tsx              # Staff email/password & Parent/Student OTP tabs
│   │   │   └── layout.tsx                # Centered auth branding layout
│   │   ├── (dashboard)/
│   │   │   ├── layout.tsx                # Protected dashboard layout with Sidebar & TopNavbar
│   │   │   ├── admin/
│   │   │   │   └── page.tsx              # Admin: KPIs, Audit Logs, People Master, Bulk CSV, Visitors
│   │   │   ├── principal/
│   │   │   │   └── page.tsx              # Principal Pulse: Live Metrics, CBSE Attendance, Fleet Telemetry
│   │   │   ├── teacher/
│   │   │   │   └── page.tsx              # Teacher: Rapid Attendance Grid (<10s), CBSE Marks Entry, Diary
│   │   │   ├── accountant/
│   │   │   │   └── page.tsx              # Accountant: Reconciliation, Fee Structures, Concessions, Receipts
│   │   │   └── parent/
│   │   │       └── page.tsx              # Parent: Sibling Switcher, Attendance, Fee Checkout, Bus GPS, Pickup OTP
│   │   ├── api/
│   │   │   └── health/
│   │   │       └── route.ts              # Next.js route handler for health checks
│   │   ├── globals.css                   # Tailwind base, CSS variables, BOMIS theme
│   │   ├── layout.tsx                    # Root layout with QueryProvider, Fonts, Toast/Toaster
│   │   └── page.tsx                      # Root landing / smart redirect based on session
│   ├── components/
│   │   ├── ui/                           # Atomic UI Primitives (shadcn/ui style)
│   │   │   ├── button.tsx                # 7 variants, 4 sizes, isLoading spinner
│   │   │   ├── input.tsx                 # Accessible input with error state, icons
│   │   │   ├── card.tsx                  # Card, CardHeader, CardTitle, CardContent, CardFooter
│   │   │   ├── badge.tsx                 # General, roleBadgeColors, attendanceStatusStyles
│   │   │   ├── table.tsx                 # Semantic responsive table wrapper suite
│   │   │   ├── dialog.tsx                # Accessible modal dialog with backdrop blur & focus trap
│   │   │   ├── select.tsx                # Dropdown select suite
│   │   │   ├── tabs.tsx                  # Accessible tab list, trigger, content
│   │   │   ├── alert.tsx                 # Semantic alert banner with Lucide icons
│   │   │   ├── avatar.tsx                # Avatar image with initials fallback
│   │   │   └── dropdown-menu.tsx         # Contextual dropdown menu
│   │   ├── layout/                       # Composite Shell Primitives
│   │   │   ├── dashboard-shell.tsx       # Main responsive container (desktop + mobile drawer)
│   │   │   ├── sidebar.tsx               # Role-tailored collapsible navigation
│   │   │   ├── top-navbar.tsx            # Campus header, CBSE badge, notifications, child switcher
│   │   │   ├── user-nav.tsx              # Profile dropdown, role badge, logout
│   │   │   ├── child-switcher.tsx        # Aarav Patel vs Ananya Patel toggle
│   │   │   ├── stat-card.tsx             # Standardized KPI card with trend indicator
│   │   │   └── data-table.tsx            # Generic search, filter, pagination table
│   │   └── modules/                      # Domain-specific interactive widgets
│   │       ├── admin/
│   │       │   ├── audit-log-table.tsx
│   │       │   ├── bulk-csv-importer.tsx
│   │       │   └── visitor-log-table.tsx
│   │       ├── principal/
│   │       │   ├── pulse-kpi-grid.tsx
│   │       │   ├── class-attendance-chart.tsx
│   │       │   └── bus-telemetry-widget.tsx
│   │       ├── teacher/
│   │       │   ├── rapid-attendance-grid.tsx # <10s SLA rapid attendance toggle
│   │       │   ├── cbse-marks-entry.tsx      # 9-point scale live auto-grader
│   │       │   └── homework-dialog.tsx
│   │       ├── accountant/
│   │       │   ├── fee-reconciliation-card.tsx
│   │       │   ├── fee-structure-table.tsx
│   │       │   └── concession-approval-dialog.tsx
│   │       └── parent/
│   │           ├── parent-sibling-bar.tsx
│   │           ├── attendance-calendar-card.tsx
│   │           ├── razorpay-checkout-modal.tsx # Idempotent fee checkout simulation
│   │           ├── live-bus-tracker.tsx        # 4 pilot buses GPS & 5-min alert
│   │           └── pickup-otp-card.tsx         # Single-use 6-digit OTP with status
│   ├── lib/
│   │   ├── utils.ts                      # cn() classnames merge utility (twMerge + clsx)
│   │   ├── api-client.ts                 # Typed fetch client unwrapping ApiResponse envelope & 401 refresh
│   │   ├── auth-store.ts                 # Zustand auth store with cookie sync & activeChildId
│   │   └── query-provider.tsx            # TanStack QueryClientProvider & queryKeys
│   └── middleware.ts                     # Edge middleware for role-based route protection
├── tailwind.config.ts                    # Extends @bomis/ui preset with CSS variables
└── tsconfig.json                         # Strict TypeScript configuration
```

---

## 3. Core Technical Specifications

### 3.1 Design System & Contrast Compliance
- **Brand Navy**: `#0F2942` (Primary solid buttons, active tabs, navigation headers, text headings).
- **Warm Coral**: `#FF6B4A` (Accent highlights, large bold CTAs). Text badges MUST use `#94311B` on `#FFF5F2` (7.15:1 AAA compliant) to satisfy WCAG AA contrast rules.
- **Role Badges**: Strictly adopt `roleBadgeColors` from `@bomis/ui` for all 8 roles.
- **Attendance Status Badges**: Strictly adopt `attendanceStatusStyles` from `@bomis/ui` (`PRESENT`, `ABSENT`, `LATE`, `HALF_DAY`, `EXCUSED`).

### 3.2 State Management & API Client
- **Zustand Auth Store (`src/lib/auth-store.ts`)**:
  - State: `user: UserProfile | null`, `accessToken: string | null`, `refreshToken: string | null`, `activeChildId: string | null`, `isAuthenticated: boolean`.
  - Actions: `setAuth()`, `logout()`, `setActiveChild(childId: string)`.
  - Cookie Sync: Writes `bomis_access_token` and `bomis_user_role` to cookies on login for Next.js `middleware.ts`.
- **API Client (`src/lib/api-client.ts`)**:
  - Consumes NestJS API (default: `http://localhost:4000/api/v1` or `/api/v1` via Next rewrite).
  - Unwraps standard envelope: `{ success: true, data: T }`. Throws structured `ApiError` if `success === false`.
  - Injects `Authorization: Bearer <accessToken>`.
  - Automatic 401 token rotation: calls `/api/v1/auth/refresh` on token expiration.
- **Query Provider (`src/lib/query-provider.tsx`)**:
  - `QueryClient` with standard retry/staleTime configuration.
  - Centralized `queryKeys` factory for all modules.

### 3.3 Route Protection (`src/middleware.ts`)
- Public routes: `/login`, `/api/health`, `/_next`, `/favicon.ico`.
- Reads `bomis_access_token` and `bomis_user_role` from request cookies.
- Redirects unauthenticated users to `/login`.
- Role-based route matrix:
  - `/admin/*` -> `SUPER_ADMIN`, `ADMIN`
  - `/principal/*` -> `PRINCIPAL`, `SUPER_ADMIN`, `ADMIN`
  - `/teacher/*` -> `TEACHER`
  - `/accountant/*` -> `ACCOUNTANT`, `ADMIN`
  - `/parent/*` -> `PARENT`, `STUDENT`
- Unauthorized role access redirects to the user's appropriate default dashboard.

### 3.4 Five Role Dashboards Implementation Requirements
1. **Admin Dashboard (`/admin`)**:
   - StatCards: Total Students (1,250), Staff (85), Buses (4/4 Active), Safety (0 incidents).
   - Audit Log Viewer: Consumes `/api/v1/admin/audit-logs`, tabular view with filter by entity and action.
   - Bulk CSV Importer: File upload UI with preview and progress indication.
   - Visitor Pass Log: Tabular view of visitor passes with approval status.
2. **Principal Pulse (`/principal`)**:
   - Pulse Metrics: Dynamic Attendance Rate (CBSE formula), Fee Collection Rate, Fleet Telemetry.
   - Class-wise attendance breakdown table with color-coded warning for <75% attendance.
   - Live Bus Fleet Status card (OD-15-AB-1001 to OD-15-AC-2001).
   - Quick Action: 1-click substitute teacher allocation modal.
3. **Teacher Dashboard (`/teacher`)**:
   - Rapid Attendance Grid (<10s SLA): Class 5A student roster (Aarav Patel Roll 1, etc.). Defaults all students to 'PRESENT' in 1 click; allows toggling exceptions (Absent, Late, Half Day); submits batch payload to `POST /api/v1/attendance`.
   - CBSE Marks Entry: Interactive table for Periodic Test (10), Notebook (5), Subject Enrichment (5), Exam (80) = 100 Marks. Computes Grade (A1 to E) dynamically in real-time.
   - Class Diary / Homework Creator: Form with title, subject, due date, description.
4. **Accountant Dashboard (`/accountant`)**:
   - Financial KPIs: Total Billed, Collected, Pending, Concessions Approved.
   - Fee Structures Table: Tuition (₹45,000), Science/Lab (₹8,000), Activity (₹4,500), Transport (₹12,000).
   - Concession Approvals: Table with approve/reject actions for pending discount requests.
   - Payment Ledger: List of payment transactions with "Download PDF Receipt" action.
5. **Parent Portal (`/parent`)**:
   - Sibling Switcher: Prominent dropdown or toggle between Aarav Patel (Grade 5A, Kalinga House) and Ananya Patel (Grade 2A). Switching children reactively updates child-scoped data.
   - Monthly Attendance Calendar: Visual calendar showing present/absent/holiday days and CBSE compliance status.
   - Fee Payment Checkout Modal: Displays pending installment, simulates Razorpay order creation (`POST /api/v1/fees/orders`) with mandatory `Idempotency-Key` header, simulates success, and shows receipt.
   - Live School Bus Tracker: Bus route status, next stop ETA, geofence 5-minute proximity alerts.
   - Child Pickup Authorization Card: Generates single-use 6-digit OTP with expiration timer for gate dismissal.

---

## 4. Verification & Quality Acceptance Criteria

1. **Clean TypeScript Build**: `pnpm --filter @bomis/web build` or `pnpm --filter @bomis/web typecheck` passes with 0 errors.
2. **No Mock Bypass or Fake Data Hacks**: All API interactions must use genuine endpoints and data contracts.
3. **Responsive & Accessible**: All pages must render cleanly on desktop and mobile viewports with no horizontal scroll issues.
4. **Co-located Component Tests**: Basic component tests or smoke tests verifying core rendering of UI primitives and dashboards.
