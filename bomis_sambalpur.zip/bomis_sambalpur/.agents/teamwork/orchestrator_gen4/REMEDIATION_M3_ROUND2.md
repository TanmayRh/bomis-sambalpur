# Milestone M3 Remediation Round 2 Specification

- **Target Agent**: `teamwork_preview_worker` (`worker_m3_remediation_r2`)
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m3_remediation_r2`
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Source Documents**:
  - `reviewer_m3_1_gen4/handoff.md`
  - `challenger_m3_1_gen4/handoff.md`
  - `reviewer_m3_2_gen4/handoff.md`
  - `auditor_m3_1_gen4/handoff.md`
  - `PROJECT.md`, `TEST_INFRA.md`, `ORIGINAL_REQUEST.md`, `prisma/schema.prisma`

---

## Mandate & Remediation Tasks

### 1. Child Pickup OTP Replay Attack Fix (`safety.service.ts` & `safety.service.spec.ts`)
- **File**: `apps/api/src/modules/safety/safety.service.ts`
- **Defect**: `verifyChildPickup` marks `auth.status = 'USED'`, but does not check whether `auth.status === 'ACTIVE'` before authorizing dismissal. An already used OTP presented a second time within 30 minutes authorizes release again (`authorized: true`).
- **Remediation**:
  - Immediately following `if (!auth)` in `verifyChildPickup`, check `auth.status !== 'ACTIVE'`.
  - If `auth.status === 'USED'`, return `{ authorized: false, studentId, message: 'Pickup authorization has already been used' }`.
  - If `auth.status === 'EXPIRED'`, return `{ authorized: false, studentId, message: 'Pickup OTP has expired' }`.
  - If `auth.status !== 'ACTIVE'`, return `{ authorized: false, studentId, message: 'No active pickup authorization found for student' }`.
- **Unit Test**: In `apps/api/src/modules/safety/safety.service.spec.ts`, add a test verifying single-use OTP replay rejection:
  - Generate dynamic authorization for student.
  - First `verifyChildPickup` call succeeds (`authorized: true`).
  - Second `verifyChildPickup` call with identical OTP is rejected (`authorized: false`, message matching `/already been used/i`).

### 2. Remove Hardcoded HMAC Webhook Bypass (`fees.service.ts`)
- **File**: `apps/api/src/modules/fees/fees.service.ts:260–268`
- **Defect**: Hardcoded `const isMockBypass = isTestEnv && signature === 'test_hmac_sha256_mock_signature';` allowing fake signatures to bypass cryptographic verification in mock/test mode.
- **Remediation**:
  - Remove `isMockBypass` and `test_hmac_sha256_mock_signature`.
  - Strictly enforce `if (expectedSignature !== signature)` throwing HTTP 400 `INVALID_WEBHOOK_SIGNATURE`.
  - Enforce mandatory `idempotency-key` header on `createRazorpayOrder` / payment initiation (throw 400 `BadRequestException` if missing).
  - Update `docs/postman/bomis_postman_collection.json` (or pre-request script) to calculate or provide a valid HMAC-SHA256 signature using `RAZORPAY_WEBHOOK_SECRET` for webhook test requests.

### 3. Compute Real-Time Pulse Metrics Dynamically (`pulse.service.ts`)
- **File**: `apps/api/src/modules/pulse/pulse.service.ts:26–27`
- **Defect**: Constant literal metrics `attendanceRate = 95.4; feeCollectionRate = 89.2;`.
- **Remediation**:
  - Compute `attendanceRate` dynamically: query `mockStore.attendance` / `prisma.attendance`, calculate ratio `((presentDays + 0.5 * halfDays) / totalDays) * 100`, default to 0 if no records.
  - Compute `feeCollectionRate` dynamically: query `mockStore.payments` and `feeInstallments` / `prisma.payment` and `prisma.feeInstallment`, compute ratio `(totalPaidAmount / totalInstallmentAmount) * 100`, default to 0 if no records.

### 4. Eliminate Admin Privilege Escalation on Invalid Refresh Token (`auth.service.ts`)
- **File**: `apps/api/src/modules/auth/auth.service.ts:161–164`
- **Defect**: Falls back to `SEED_IDS.USER_ADMIN` when refresh token user ID is not found.
- **Remediation**:
  - Remove `user = this.prisma.mockStore.users.get(SEED_IDS.USER_ADMIN)`.
  - If `!user`, throw `UnauthorizedException({ code: 'USER_NOT_FOUND', message: 'User associated with refresh token does not exist' })`.

### 5. Fix Sibling Cross-Tenant Data Leakage (`people.service.ts`)
- **File**: `apps/api/src/modules/people/people.service.ts:388–399` and `442–448`
- **Defect**: Falls back to returning Aarav & Ananya Patel's profiles to any unlinked guardian.
- **Remediation**:
  - Remove fallback to `[SEED_IDS.STUDENT_AARAV, SEED_IDS.STUDENT_ANANYA]`.
  - If a guardian has no linked children, return an empty array `[]` cleanly. Never leak another family's children or health records.

### 6. Implement Dual Database Mode PostgreSQL Writes
- **Files**:
  - `apps/api/src/modules/attendance/attendance.service.ts`
  - `apps/api/src/modules/academics/academics.service.ts`
  - `apps/api/src/modules/fees/fees.service.ts`
  - `apps/api/src/modules/transport/transport.service.ts`
  - `apps/api/src/modules/safety/safety.service.ts`
- **Defect**: Mutations write only to in-memory `mockStore` and omit Prisma calls.
- **Remediation**:
  - In each mutation method, ensure that when `!this.prisma.isMock`, the corresponding Prisma create/createMany/update operations are executed against PostgreSQL tables.

### 7. Prisma Schema Alignment for `emergency_contact_encrypted`
- **File**: `prisma/schema.prisma` and `apps/api/src/modules/people/people.service.ts`
- **Remediation**: Add `emergency_contact_encrypted String? @db.Text` to `model Student` in `prisma/schema.prisma` (under sensitive health/identity fields) to maintain 100% schema alignment with `PeopleService.createStudent`.

### 8. Wire Pino Logger & Global Validation
- **Files**: `apps/api/src/main.ts`, `apps/api/src/app.module.ts`
- **Remediation**:
  - Configure global logger with Pino and `AsyncLocalStorage` correlation ID.
  - Wire `ZodValidationPipe` globally or configure global validation.
