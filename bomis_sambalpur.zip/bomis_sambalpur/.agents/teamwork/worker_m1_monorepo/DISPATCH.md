# Task Assignment: Monorepo Foundation & DevOps Worker (Milestone M1)

## Working Directory
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m1_monorepo

## Authoritative Reference Files
- ORIGINAL_REQUEST.md: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`
- PROJECT.md: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`
- Spec Miner Analysis: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_survey_1\analysis.md`

## Scope of Work (Milestone M1)
1. Initialize the Turborepo + pnpm monorepo workspace at `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`:
   - `package.json` with scripts: `build`, `dev`, `lint`, `test`, `typecheck`, `db:migrate`, `db:seed`, `docker:up`, `docker:down`.
   - `pnpm-workspace.yaml` declaring packages: `apps/*`, `packages/*`.
   - `turbo.json` with caching, pipeline dependencies (`^build`), outputs (`dist/**`, `.next/**`).
   - Root `tsconfig.json` and base configuration.
   - `.gitignore` (ignoring node_modules, dist, .next, .turbo, .env, coverage).
   - `.env.example` with standard ports and credentials (PostgreSQL 5432, Redis 6379, MinIO 9000/9001, Mailpit 1025/8025, JWT secrets, encryption keys).
2. Create `/infra/docker-compose.yml`:
   - PostgreSQL 16 (database `bomis_db`, user `bomis_admin`, password `bomis_dev_pass`, port 5432)
   - Redis 7 (port 6379)
   - MinIO S3-compatible storage (ports 9000 & 9001, root user `minioadmin`, pass `minioadmin`, bucket `bomis-assets`)
   - Mailpit SMTP & Webmail (port 1025 SMTP, 8025 Web UI)
3. Scaffold initial package folders with valid `package.json` and `tsconfig.json`:
   - `/packages/shared` (`@bomis/shared`)
   - `/packages/ui` (`@bomis/ui`)
   - `/apps/api` (`@bomis/api`)
   - `/apps/web` (`@bomis/web`)
   - `/apps/mobile` (`@bomis/mobile`)
4. Verify workspace configuration and syntax. Run package/workspace validation commands.
5. Provide detailed handoff report in your working directory (`handoff.md`).

## Mandatory Integrity Warning
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.


## 2026-10-17T11:09:36Z
[Message] timestamp=2026-10-17T11:09:36Z sender=17238c8a-10a1-44ab-93b7-5a2d27f28ea5 priority=MESSAGE_PRIORITY_HIGH content=You are Monorepo Foundation & DevOps Worker (Milestone M1) for BOMIS Sambalpur.
Your working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m1_monorepo
Read your task instructions at C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m1_monorepo\DISPATCH.md and C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md.

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Scope:
Scaffold root package.json, pnpm-workspace.yaml, turbo.json, tsconfig.json, .gitignore, .env.example, README.md, infra/docker-compose.yml (Postgres 16, Redis 7, MinIO, Mailpit), and scaffold workspace folders (/packages/shared, /packages/ui, /apps/api, /apps/web, /apps/mobile) with valid package.json and tsconfig.json manifests.
Run verification commands and document them. Write handoff.md in your working directory and notify the orchestrator when complete.
