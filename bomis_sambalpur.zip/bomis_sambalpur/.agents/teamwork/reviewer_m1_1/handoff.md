# Review & Adversarial Handoff Report: Milestone M1 (Monorepo Foundation & Tooling)

**Milestone**: M1 - Monorepo Foundation & Tooling  
**Reviewer**: Reviewer 1 (Archetype: Reviewer & Adversarial Critic)  
**Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\reviewer_m1_1`  
**Target Repository**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`  
**Verdict**: **REQUEST_CHANGES**  

---

## Executive Review Summary

Following a thorough independent quality review and adversarial challenge of Milestone M1 (Monorepo Foundation & Tooling), the verdict is **REQUEST_CHANGES**.

While the monorepo root structure (`pnpm-workspace.yaml`, `turbo.json`, `tsconfig.base.json`, `tsconfig.json`, `.gitignore`, `.env.example`, `README.md`), Postgres/Redis/MinIO/Mailpit service topologies, and workspace skeletons are well-organized, multiple critical defects and contract desynchronizations were identified. Most notably, a **Critical Integrity Violation** exists in the form of facade `echo "... passed"` test and lint scripts that self-certify without executing real verification engines. Additionally, required deliverables from specification R1 (Dockerfiles and CI workflow templates) are completely missing, role contracts diverge between `@bomis/shared` and the authoritative specifications, and packaging module resolution flaws in `@bomis/shared` will cause Node runtime crashes.

---

## 1. Observation

Direct file observations, line numbers, and verbatim evidence:

### 1.1 Facade Test and Lint Scripts (Integrity Violation)
- `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\packages\shared\package.json`:
  - Line 19: `"lint": "echo \"@bomis/shared lint passed\""`
  - Line 21: `"test": "echo \"@bomis/shared tests passed\""`
- `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\packages\ui\package.json`:
  - Line 16: `"lint": "echo \"@bomis/ui lint passed\""`
  - (No `"test"` script defined)
- `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\apps\api\package.json`:
  - Line 11: `"lint": "echo \"@bomis/api lint passed\""`
  - Line 13: `"test": "echo \"@bomis/api tests passed\""`
- `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\apps\web\package.json`:
  - Line 10: `"lint": "echo \"@bomis/web lint passed\""`
  - (No `"test"` script defined)
- `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\apps\mobile\package.json`:
  - Line 13: `"lint": "echo \"@bomis/mobile lint passed\""`
  - (No `"test"` script defined)
- `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\package.json` (Root):
  - Line 10: `"lint": "turbo run lint"`
  - Line 11: `"test": "turbo run test"`
  - DevDependencies (Lines 24–32): `turbo`, `typescript`, `ts-node`, `prettier`, `rimraf`, `dotenv-cli`, `@types/node`. Notice `eslint` is absent from root and from all workspace package manifests. There are no `.eslintrc` or `eslint.config` files anywhere in the repository.

### 1.2 Missing Required Deliverables from Specification R1
- `ORIGINAL_REQUEST.md` (Line 25):
  > `- /infra: Docker Compose for local development (PostgreSQL 16, Redis 7, MinIO S3-compatible, Mailpit), Dockerfiles, and CI workflow templates.`
- `PROJECT.md` (Line 15):
  > `├── infra/ # Docker Compose (PostgreSQL 16, Redis 7, MinIO, Mailpit), Dockerfiles`
- `ORIGINAL_REQUEST.md` (Line 64):
  > `- [ ] Postman & Newman CI: ... passing cleanly in GitHub Actions CI.`
- File Search Result:
  - Exact search for `*Dockerfile*`: 0 results across repository.
  - Exact search for `*.yml` / `*.yaml`: Only `infra/docker-compose.yml` and `pnpm-workspace.yaml`. Zero CI workflow files (e.g., `.github/workflows/ci.yml` or CI templates in `infra/`).

### 1.3 Role Contract Desynchronization: `TRANSPORT_STAFF` vs `DRIVER_TRANSPORT`
- `PROJECT.md` (Line 98):
  > `- 8 Roles: SUPER_ADMIN, ADMIN, PRINCIPAL, TEACHER, ACCOUNTANT, STUDENT, PARENT, TRANSPORT_STAFF.`
- `TEST_INFRA.md` (Line 18):
  > `2. Deterministic Role-Based Security: Complete RBAC isolation across 8 distinct roles (SUPER_ADMIN, ADMIN, PRINCIPAL, TEACHER, ACCOUNTANT, STUDENT, PARENT, TRANSPORT_STAFF)...`
- `docs/postman/README.md` (Line 80):
  > `8. TRANSPORT_STAFF`
- `docs/postman/bomis_postman_collection.json` (Line 1335):
  > `"description": "Guarantees TRANSPORT_STAFF cannot inspect school financial structures."`
- BUT in `packages/shared/src/enums/index.ts` (Line 13):
  > `DRIVER_TRANSPORT = 'DRIVER_TRANSPORT',`
- And in `packages/shared/src/rbac/index.ts` (Line 144):
  > `[UserRole.DRIVER_TRANSPORT]: [`

### 1.4 Packaging & TypeScript Module Resolution Defect
- `packages/shared/package.json`:
  ```json
  "main": "./src/index.ts",
  "types": "./src/index.ts",
  "exports": {
    ".": "./src/index.ts",
    "./enums": "./src/enums/index.ts",
    "./contracts": "./src/contracts/index.ts",
    "./schemas": "./src/schemas/index.ts",
    "./types": "./src/types/index.ts",
    "./rbac": "./src/rbac/index.ts"
  },
  "scripts": {
    "build": "tsc -p tsconfig.json"
  }
  ```
- `apps/api/package.json`:
  - Line 17: `"@bomis/shared": "workspace:*"`
  - Line 9: `"start": "node dist/main.js"`
- `apps/api/tsconfig.json`:
  - Targets `"module": "commonjs"`, `"moduleResolution": "node"`. No project references to `packages/shared`. When built, `apps/api` requires `@bomis/shared`, which points directly to raw `./src/index.ts`. At runtime, Node (`node dist/main.js`) will fail because Node cannot execute unbundled TypeScript files.

### 1.5 MinIO Container Healthcheck Fragility
- `infra/docker-compose.yml` (Lines 65–69):
  ```yaml
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
    interval: 10s
    timeout: 5s
    retries: 5
  ```
  And `minio-create-buckets` (Lines 77–79):
  ```yaml
  depends_on:
    minio:
      condition: service_healthy
  ```
  Official `minio/minio:latest` Docker images (built on minimal UBI/distroless base images) do not ship with `curl`. Without `curl`, the healthcheck fails with `executable file not found in $PATH` (exit code 127), preventing the container from becoming healthy and deadlocking `minio-create-buckets`.

---

## 2. Logic Chain

1. **Integrity Violation Analysis**:
   - The workspace manifests define `"test": "echo \"... tests passed\""` and `"lint": "echo \"... lint passed\""`.
   - When a developer or CI executes `pnpm test` or `pnpm lint`, Turborepo runs these scripts and prints the echo string with exit code 0.
   - The project claims automated linting and test passes, but in reality, no code is inspected by a linter (neither ESLint nor any other tool is installed or configured), and no test runner is invoked.
   - Per reviewer instructions, hardcoded test results, facade implementations that implement no real logic, and self-certifying work without genuine independent verification require a mandatory verdict of `REQUEST_CHANGES` tagged as `INTEGRITY VIOLATION`.

2. **Specification Conformance Analysis**:
   - Requirement R1 explicitly dictates: `infra: Docker Compose for local development (PostgreSQL 16, Redis 7, MinIO S3-compatible, Mailpit), Dockerfiles, and CI workflow templates.`
   - Acceptance Criteria state Postman & Newman must run in `GitHub Actions CI`.
   - Neither application Dockerfiles (e.g., `apps/api/Dockerfile`, `apps/web/Dockerfile`) nor any CI workflow files (e.g., `.github/workflows/ci.yml`) were authored.
   - Omitting these core components leaves downstream milestone developers without containerized build targets or CI pipelines.

3. **Domain & Contract Synchronization Analysis**:
   - `PROJECT.md`, `TEST_INFRA.md`, and the Postman Newman test suite in `docs/postman/` define the 8th role strictly as `TRANSPORT_STAFF`.
   - `packages/shared/src/enums/index.ts` defined it as `DRIVER_TRANSPORT`.
   - In Milestone M2 (Prisma schema) and Milestone M3 (NestJS RBAC), using `DRIVER_TRANSPORT` will cause schema clashes or RBAC test failures when Postman sends or asserts `TRANSPORT_STAFF`.
   - To preserve 100% contract congruence, `@bomis/shared` must align with `TRANSPORT_STAFF` (or provide aliasing if dual naming is desired).

4. **Runtime Resolution Analysis**:
   - Monorepo packages compiled via `tsc` must export their compiled artifacts (`./dist/index.js`, `./dist/index.d.ts`) in `package.json` for consuming Node.js applications, while path aliases in `tsconfig.base.json` provide local TS resolution during development.
   - Exposing uncompiled `.ts` files as `"main"` in `@bomis/shared` causes runtime failure under standard Node execution in `@bomis/api`.

---

## 3. Findings

### [Critical - INTEGRITY VIOLATION] Finding 1: Facade Test and Lint Scripts Self-Certifying Success
- **Where**:
  - `packages/shared/package.json` (lines 19, 21)
  - `apps/api/package.json` (lines 11, 13)
  - `packages/ui/package.json` (line 16)
  - `apps/web/package.json` (line 10)
  - `apps/mobile/package.json` (line 13)
- **Why**: The scripts execute `echo "... passed"` to trick Turbo and CI runners into reporting passing lint and test stages without running any linter or test suite. ESLint is not even installed.
- **Suggestion**:
  1. Replace facade lint scripts with real ESLint setup (install `eslint`, `@typescript-eslint/parser`, `@typescript-eslint/eslint-plugin`, configure `.eslintrc.js` or `eslint.config.mjs`).
  2. For tests in packages without active test files yet, either configure genuine test runners (e.g. `jest --passWithNoTests` or `vitest run --passWithNoTests`) or remove the fake echo scripts so tests aren't deceptively reported as executed.

### [Major] Finding 2: Missing Application Dockerfiles and CI Workflow Templates (R1 Violation)
- **Where**: `infra/` and `.github/workflows/`
- **Why**: Requirement R1 requires Dockerfiles and CI workflow templates. Currently, only `docker-compose.yml` exists. There are no Dockerfiles for `apps/api` or `apps/web`, and no GitHub Actions workflow (`.github/workflows/ci.yml`) to execute builds, linting, tests, and Newman.
- **Suggestion**:
  1. Add production-grade Dockerfiles for `apps/api` and `apps/web` (or under `infra/docker/`).
  2. Add `.github/workflows/ci.yml` orchestrating `pnpm install`, `pnpm lint`, `pnpm typecheck`, `pnpm test`, and `infra/docker-compose.yml` spin-up.

### [Major] Finding 3: Role Contract Mismatch Between `@bomis/shared` and Specifications/Postman
- **Where**:
  - `packages/shared/src/enums/index.ts` (line 13)
  - `packages/shared/src/rbac/index.ts` (line 144)
  - vs. `PROJECT.md` (line 98), `TEST_INFRA.md` (line 18), `docs/postman/README.md` (line 80), `docs/postman/bomis_postman_collection.json` (line 1335).
- **Why**: Specifications and automated Newman tests expect `TRANSPORT_STAFF`, whereas `@bomis/shared` declared `DRIVER_TRANSPORT`.
- **Suggestion**: Update `UserRole` in `packages/shared/src/enums/index.ts` to `TRANSPORT_STAFF = 'TRANSPORT_STAFF'` (or alias `DRIVER_TRANSPORT = 'TRANSPORT_STAFF'`).

### [Major] Finding 4: `@bomis/shared` and `@bomis/ui` Package Manifests Export Raw TypeScript Files
- **Where**: `packages/shared/package.json` (lines 6–15), `packages/ui/package.json` (lines 6–12)
- **Why**: `"main": "./src/index.ts"` and exports pointing directly to `.ts` files will break standard Node.js execution for `@bomis/api` (`node dist/main.js`).
- **Suggestion**:
  Update `package.json` in `@bomis/shared` and `@bomis/ui` to:
  ```json
  "main": "./dist/index.js",
  "types": "./dist/index.d.ts",
  "exports": {
    ".": {
      "types": "./dist/index.d.ts",
      "import": "./dist/index.js",
      "default": "./dist/index.js"
    }
  }
  ```

### [Medium] Finding 5: MinIO Healthcheck Relies on `curl`
- **Where**: `infra/docker-compose.yml` (lines 65–69)
- **Why**: Modern official MinIO images do not include `curl`. Healthcheck failure blocks `minio-create-buckets`.
- **Suggestion**: Use `test: ["CMD-SHELL", "mc ready local || exit 1"]` or `["CMD", "/usr/bin/mc", "ready", "local"]` or a Python/socket check.

---

## 4. Adversarial Challenges & Stress Testing

| Challenge | Target Assumption | Attack Scenario | Blast Radius | Recommended Mitigation |
|---|---|---|---|---|
| **ADV-1: Deceptive CI Green** | Assumption that `turbo run lint && turbo run test` guarantees code health. | Code with syntax errors, unused variables, or broken invariants passes CI because scripts only run `echo "... passed"`. | Broken PRs merge silently without verification. | Implement real ESLint and Jest/Vitest configs. |
| **ADV-2: MinIO Bootstrap Deadlock** | Assumption that `minio/minio:latest` container has `curl` installed. | `docker compose up -d` starts MinIO; Docker runs `curl http://localhost:9000/...`; fails with code 127; `service_healthy` condition never met; `minio-create-buckets` hangs or fails. | Automated local bootstrap (`pnpm docker:up`) fails on fresh machines. | Change healthcheck to use MinIO's built-in `mc` client. |
| **ADV-3: Production Node Crash** | Assumption that `@bomis/shared` can be required by Node.js from `./src/index.ts`. | `apps/api` builds to `dist/main.js` via `tsc`. When started with `node dist/main.js`, Node attempts to require `./packages/shared/src/index.ts`, throwing `SyntaxError: Unexpected token 'export'` or `Unknown file extension .ts`. | Backend crashes immediately on startup. | Point `"main"` and `"types"` to compiled `./dist/` in shared packages. |
| **ADV-4: RBAC Test Failure in Postman** | Assumption that role names match between shared package and Newman test collection. | Newman runs `/docs/postman/run-newman.js` asserting `TRANSPORT_STAFF` token permissions; API returns 403 or invalid role because enum is `DRIVER_TRANSPORT`. | CI Newman test suite fails. | Standardize enum to `TRANSPORT_STAFF`. |

---

## 5. Verified Claims vs Unverified Items

### Verified Claims
- Root monorepo orchestration: `package.json`, `pnpm-workspace.yaml`, `turbo.json` are properly configured with workspace layout matching `apps/*` and `packages/*`.
- Environment variables: `.env.example` comprehensively covers all R1–R5 services (Postgres, Redis, MinIO, Mailpit, JWT, DPDP encryption key, Razorpay, FCM, OpenAI).
- PostgreSQL initialization: `infra/postgres/init.sql` enables `uuid-ossp` and `pgcrypto` and sets timezone to `Asia/Kolkata`.
- Brand design tokens: `packages/ui/src/tokens/index.ts` accurately defines `#0F2942` Primary Navy and `#FF6B4A` Accent Coral.
- ADRs: 4 comprehensive ADRs exist in `docs/adr/`.
- Postman Collection: Full v2.1 collection exists in `docs/postman/` with 8 roles.

### Unverified Items / Caveats
- Runtime execution of terminal commands (`pnpm install`, `pnpm build`, `docker compose up`) was not performed because permission for terminal command execution was denied in the environment.
- Verification was conducted through comprehensive static code analysis, AST inspection, cross-referencing manifests, and adversarial trace modeling.

---

## 6. Conclusion & Recommended Action

**Verdict**: **REQUEST_CHANGES**

Milestone M1 cannot be approved in its current state due to the **Critical Integrity Violation** (facade test/lint scripts) and missing R1 deliverables.

### Action Items for Worker M1:
1. **Fix Integrity Violation**: Remove dummy `echo "... passed"` scripts; configure real ESLint and genuine test commands (e.g. `jest --passWithNoTests`).
2. **Implement Missing R1 Deliverables**: Add Dockerfiles for `apps/api` and `apps/web`, and create `.github/workflows/ci.yml`.
3. **Synchronize Role Enum**: Change `DRIVER_TRANSPORT` to `TRANSPORT_STAFF` in `packages/shared/src/enums/index.ts` and `packages/shared/src/rbac/index.ts`.
4. **Fix Shared Package Manifest**: Point `main`, `types`, and `exports` in `packages/shared/package.json` and `packages/ui/package.json` to `./dist/` instead of `./src/`.
5. **Harden MinIO Healthcheck**: Update `infra/docker-compose.yml` MinIO healthcheck to avoid dependency on `curl`.

---

## 7. Verification Method

1. Inspect `packages/shared/package.json`, `apps/api/package.json`, `packages/ui/package.json`, `apps/web/package.json`, `apps/mobile/package.json` for removal of `echo "... passed"` facade scripts.
2. Verify existence of `Dockerfile` (or `infra/docker/Dockerfile.*`) and `.github/workflows/ci.yml`.
3. Inspect `packages/shared/src/enums/index.ts` line 13 to verify `TRANSPORT_STAFF` matching `PROJECT.md` line 98.
4. Inspect `packages/shared/package.json` to verify `"main": "./dist/index.js"` and `"types": "./dist/index.d.ts"`.
5. Inspect `infra/docker-compose.yml` minio healthcheck command.
