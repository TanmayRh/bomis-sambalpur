# Dispatch: Worker M3 Completion (Replacement)

- Target Agent: teamwork_preview_worker
- Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m3_completion
- Project Root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur
- Exclusive Write Ownership:
  - `apps/api/src/**/*`
  - `apps/api/package.json`
  - `apps/api/tsconfig.json`
  - `apps/api/test/**/*`
- Mandatory Reference Documents:
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md` (MANDATORY)
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen3\SYNTHESIS_M3.md`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m3_1\analysis.md`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_1\analysis.md`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_2\analysis.md`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\DEAD_ENDS.md`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\docs\postman\bomis_postman_collection.json`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\packages\shared`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\prisma\schema.prisma`
  - `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\prisma\seed.ts`

## Integrity Warning
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

## 2026-10-18T07:50:36Z
You are Worker M3 Completion (Replacement) for the BOMIS Sambalpur Unified School Platform.

Your Tasks to Complete Milestone M3:
1. Complete `modules/people/`: create `people.controller.ts` and `people.module.ts` (GET /students, POST /students, GET /students/:id, GET /guardians/siblings, GET /staff, POST /students/bulk-import).
2. Implement `modules/attendance/`: `attendance.controller.ts`, `attendance.service.ts`, `attendance.module.ts` (GET/POST /attendance, POST /attendance/batch, POST /sync/batch, POST /attendance/leaves, GET /attendance/students/:id, attendance percentage formula).
3. Implement `modules/fees/`: `fees.controller.ts`, `fees.service.ts`, `fees.module.ts` (GET /fees/structures, POST /fees/orders with Idempotency-Key support, POST /fees/webhook with HMAC verification, GET /fees/receipts/:id, GET/POST /fees/concessions).
4. Implement `modules/academics/`: `academics.controller.ts`, `academics.service.ts`, `academics.module.ts` (GET /academics/terms, POST /academics/marks/batch with CBSE 9-point scale A1-E, POST /academics/timetable/clash-check, POST /academics/substitutions).
5. Implement `modules/transport/`: `transport.controller.ts`, `transport.service.ts`, `transport.module.ts` (GET /transport/routes, GET /transport/buses [returns at least 4 pilot buses with OD-15 plates], POST /transport/boarding/scan, POST /transport/gps-ping).
6. Implement `modules/safety/`: `safety.controller.ts`, `safety.service.ts`, `safety.module.ts` (POST /safety/visitors, POST /safety/pickup/verify, POST /safety/incidents/anonymous [zero-log]).
7. Implement `modules/ai/`: `ai.controller.ts`, `ai.service.ts`, `ai.module.ts` (POST /ai/study-buddy/chat, POST /ai/lesson-planner/remarks).
8. Implement `modules/pulse/`: `pulse.controller.ts`, `pulse.service.ts`, `pulse.module.ts` (GET /pulse/metrics).
9. Update `apps/api/src/app.module.ts` to import and export all domain modules and `DatabaseModule`.
10. Ensure all controllers strictly use the RBAC `@Roles(...)` and `@Public()` decorators, and validation pipes matching the Postman collection.
11. Write comprehensive unit test suites in `apps/api/src/**/*.spec.ts`.
