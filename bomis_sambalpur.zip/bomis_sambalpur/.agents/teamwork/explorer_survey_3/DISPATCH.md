# Task Assignment: Frontend, Mobile & QA Explorer

## Working Directory
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_3

## Authoritative Reference
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md

## Mission
Analyze ORIGINAL_REQUEST.md with focus on:
1. Next.js 14 Web Portal (/apps/web): App Router, Tailwind CSS, shadcn/ui primitives, TanStack Query, React Hook Form, Zod, BOMIS branding, responsive layouts for Admin, Principal, Teacher, Accountant, Parent.
2. React Native (Expo) Mobile App (/apps/mobile): multi-role (Parent, Student, Driver, Teacher), offline-first sync architecture, secure storage, push notification handling, QR scanning for transport/pickup.
3. QA & E2E Testing Strategy:
   - Acceptance Criteria verification
   - 4-Tier test methodology (Tier 1 Feature coverage, Tier 2 Boundaries, Tier 3 Cross-feature pairwise, Tier 4 Real-world application scenarios)
   - Minimum test counts (>=70% coverage on business logic)
   - Postman Collection & Newman CI automation (/docs/postman with pre-request auth scripts and test assertions)
   - One-command bootstrapping verification: `docker compose up -d` + `pnpm install && pnpm db:migrate && pnpm db:seed && pnpm dev`.

Deliver comprehensive analysis to your working directory:
`analysis.md` and `handoff.md`.


## 2026-10-17T11:03:10Z
You are Frontend, Mobile & QA Explorer for BOMIS Sambalpur.
Your working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_3
Your task assignment: Read C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_3\DISPATCH.md and C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md.
Analyze all requirements for Next.js 14 web app (/apps/web), Expo mobile app (/apps/mobile), brand design tokens, offline-first sync, QA & Acceptance Criteria, 4-tier E2E testing strategy, and Postman/Newman collection automation.
Write your detailed analysis to analysis.md and a self-contained handoff.md in your working directory.
Update progress.md with your liveness heartbeat. When done, send a message to orchestrator with your findings and file path.
