# Handoff Report: Frontend, Mobile & QA Survey

**Agent**: Frontend, Mobile & QA Explorer (`explorer_survey_3`)  
**Task Assignment**: Frontend, Mobile, Design Tokens, Offline Sync, QA & Postman/Newman Analysis  
**Date**: 2026-10-17  
**Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_3`  
**Target Reference**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`  

---

## 1. Observation

Direct observations extracted from project baseline files:

1. **Web App Framework & Libraries**:
   - `ORIGINAL_REQUEST.md:21`: `"- /apps/web: Next.js 14 App Router, Tailwind CSS, shadcn/ui design primitives, TanStack Query, React Hook Form, and Zod."`
2. **Mobile App Framework & Capabilities**:
   - `ORIGINAL_REQUEST.md:22`: `"- /apps/mobile: React Native (Expo) multi-role app supporting iOS and Android, offline-first sync architecture, secure storage, and push notifications."`
3. **Brand Palette & Shared Tokens**:
   - `ORIGINAL_REQUEST.md:24`: `"- /packages/ui: Shared design tokens (BOMIS Sambalpur brand palette: navy/teal primary #0F2942, warm coral accent #FF6B4A), typography, and reusable UI tokens."`
4. **Attendance Performance Target & Offline Sync**:
   - `ORIGINAL_REQUEST.md:40`: `"Attendance: Teacher rapid attendance grid (<10 seconds per class), offline queue sync, instant FCM parent push alerts, and staff attendance/leave module."`
5. **Transport Fleet & Driver Mini-App**:
   - `ORIGINAL_REQUEST.md:48`: `"Transport: Routes, stops, driver mini-app broadcasting GPS coordinates via WebSockets/Socket.IO, student boarding/deboarding QR scanning, geofence-based \"5-minute away\" parent alerts, and fleet monitoring for 4 pilot buses (3 small, 1 full-size)."`
6. **Financial Safety & Razorpay Requirements**:
   - `ORIGINAL_REQUEST.md:42`: `"Fees: Fee categories, structures, concession approval workflows, Razorpay payment gateway integration (UPI/Netbanking/Cards test mode), receipt generation, day-wise reconciliation, and accountant collection dashboard."`
   - `ORIGINAL_REQUEST.md:62`: `"Idempotency & Financial Safety: All payment endpoints enforce Idempotency-Key headers; Razorpay webhooks verify cryptographic signatures with duplicate payload protection."`
7. **Verification & Quality Assurance Criteria**:
   - `ORIGINAL_REQUEST.md:60`: `"Type & Schema Synchronization: All frontend and backend validation originates from /packages/shared Zod schemas with 100% type congruence."`
   - `ORIGINAL_REQUEST.md:61`: `"Standardized Envelope: All REST endpoints return { success: boolean, data: T, error?: { code: string, message: string, details?: any }, timestamp: string, correlationId: string }."`
   - `ORIGINAL_REQUEST.md:63`: `"Test Coverage: Minimum 70% test coverage on business logic (fee calculation, attendance percentages, grading algorithms, timetable clash detection), with role-scoping tests verifying zero unauthorized data exposure."`
   - `ORIGINAL_REQUEST.md:64`: `"Postman & Newman CI: Exported Postman collection and environment in /docs/postman featuring pre-request role authentication, test assertions on all endpoints, and passing cleanly in GitHub Actions CI."`
   - `ORIGINAL_REQUEST.md:65`: `"One-Command Bootstrapping: docker compose up -d followed by pnpm install && pnpm db:migrate && pnpm db:seed && pnpm dev starts the entire platform with realistic seed data for Grades 1–8 Section A and 4 buses."`

---

## 2. Logic Chain

1. **From Observation 1 (Web stack)**:
   - Next.js 14 App Router requires server-component boundaries for data fetching combined with TanStack Query (React Query v5) on the client side for optimistic mutations and automatic cache revalidation.
   - Form state management with React Hook Form + Zod requires importing schemas directly from `@bomis/shared` to enforce the 100% type congruence stipulated in Observation 7 (AC-1).
   - The UI requires `shadcn/ui` primitives (Radix UI) styled with Tailwind CSS using the brand tokens defined in Observation 3.

2. **From Observation 2 & 4 (Mobile app & offline sync)**:
   - Given intermittent cellular connectivity in rural and semi-urban Sambalpur, mobile attendance marking and transport QR scanning cannot rely solely on an active network connection.
   - An offline-first sync architecture is necessary: actions are committed immediately to local SQLite (`local_sync_outbox`) and transmitted asynchronously via a dedicated `/api/v1/sync/batch` endpoint when connectivity is detected via NetInfo.
   - Idempotency keys generated on the client prevent duplicate submissions when network retries occur.

3. **From Observation 5 (Transport & pilot fleet)**:
   - The pilot fleet comprises exactly 4 buses: 3 mini-buses (24-seater) and 1 full-size bus (52-seater).
   - Driver mobile workflow requires high-frequency background GPS location broadcast via WebSockets/Socket.IO every 3–5 seconds and continuous hardware QR code scanning (`expo-camera`) for student boarding/deboarding.
   - Geofencing logic triggers FCM push notifications to parents when the bus is within 1.5 km or <= 5 minutes away.

4. **From Observation 6 (Fees, payments & idempotency)**:
   - Double-charging risks are eliminated by enforcing an `Idempotency-Key` header on order creation and payment capture.
   - The backend validates the Razorpay HMAC SHA-256 signature and uses Redis with a 24-hour TTL to reject replayed payloads.

5. **From Observation 7 (QA, Test Coverage & Newman CI)**:
   - Achieving >= 70% business logic coverage requires a structured 4-tier testing hierarchy:
     - **Tier 1**: Unit tests for pure calculation engines (fee math, CBSE grading, timetable clash detection, attendance rates).
     - **Tier 2**: Boundary and negative tests (idempotency enforcement, missing headers, RBAC permission violations, cross-role tampering).
     - **Tier 3**: Cross-feature pairwise workflows (leave approval -> substitution -> push notification; concession -> Razorpay payment -> receipt -> ledger).
     - **Tier 4**: Real-world E2E scenarios using Playwright (web portal) and mobile test harnesses.
   - Newman CI automation requires an exported Postman collection and environment in `/docs/postman`, equipped with dynamic pre-request authentication, correlation ID injection, and standard envelope schema assertions.

---

## 3. Caveats

1. **Hardware-Specific Mobile Testing**:
   - Hardware camera scanning (`expo-camera`) and background geolocation (`expo-location`) require physical mobile devices or simulated sensor inputs in simulators. In headless CI environments, these sensors must be exercised through mocked driver harnesses or simulated GPS telemetry streams.
2. **Razorpay Live Gateway**:
   - Testing is strictly scoped to Razorpay Test Mode with test keys and mock webhook deliveries. No real financial transactions are executed in development.
3. **Multilingual Text Rendering**:
   - While typography supports English, Hindi (Devanagari), and Odia scripts, UI layout testing should account for varying string lengths in Odia and Hindi to prevent text clipping in mobile buttons and table headers.

---

## 4. Conclusion

The architectural, technical, and testing specifications for the BOMIS Sambalpur frontend web portal, mobile app, shared UI design system, offline sync engine, and QA automation are fully mapped and detailed in `analysis.md`. 

Key architectural requirements established:
- `/apps/web`: Next.js 14 App Router, Tailwind CSS, shadcn/ui, TanStack Query, React Hook Form, and Zod with role-scoped dashboards for Admin, Principal, Teacher, Accountant, and Parent.
- `/apps/mobile`: Expo SDK 51+ multi-role application (Parent, Student, Driver, Teacher) with local SQLite outbox queue, camera QR scanner, background GPS broadcaster, and push notification handlers.
- `/packages/ui`: Brand palette with Navy/Deep Slate Teal `#0F2942` primary, Warm Coral `#FF6B4A` accent, slate neutrals, semantic status tokens, and Indian locale formatting utilities.
- `/docs/postman`: Multi-domain collection with pre-request scripts, correlation ID generation, standard response envelope validation, and automated Newman CI runner.
- Bootstrapping: Deterministic one-command startup (`docker compose up -d && pnpm install && pnpm db:migrate && pnpm db:seed && pnpm dev`) supporting Grades 1–8 Section A and 4 pilot buses.

---

## 5. Verification Method

To independently verify the analysis and specifications:

1. **Inspect Analysis Report**:
   - Read `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_3\analysis.md` for complete technical details, code schemas, and testing matrices.
2. **Cross-Check with Project Requirements**:
   - Compare `analysis.md` against `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md` sections R1, R3, R4, R5, and Acceptance Criteria.
3. **Verify Route Maps & Directory Structures**:
   - Verify that `/apps/web` App Router pages map directly to the 5 web roles (Admin, Principal, Teacher, Accountant, Parent).
   - Verify that `/apps/mobile` routes cover all 4 mobile roles (Parent, Student, Driver, Teacher).
4. **Invalidation Conditions**:
   - This analysis is invalidated if the project deviates from Next.js 14 App Router, Expo React Native, Turborepo + pnpm workspaces, or the BOMIS Sambalpur brand palette (`#0F2942` / `#FF6B4A`).
