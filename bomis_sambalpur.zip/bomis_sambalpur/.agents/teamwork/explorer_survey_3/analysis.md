# Frontend, Mobile & QA Architectural Analysis: BOMIS Sambalpur

**Document Version**: 1.0.0  
**Author**: Frontend, Mobile & QA Explorer (`explorer_survey_3`)  
**Target Repository**: `bomis_sambalpur`  
**Working Directory**: `.agents/teamwork/explorer_survey_3`  
**Date**: 2026-10-17  

---

## Executive Summary

The Birla Open Minds International School (BOMIS), Sambalpur platform is a mission-critical, multi-role school operating system serving school administrators, teachers, accountants, parents, students, and transport drivers. This analysis provides the architectural blueprints, technical requirements, component specifications, and testing strategies for:
1. **Next.js 14 Web Portal (`/apps/web`)**: Modern App Router web application with role-tailored dashboards, server-side data fetching, TanStack Query client caching, shadcn/ui components, and Zod validation.
2. **React Native (Expo) Mobile App (`/apps/mobile`)**: Cross-platform (iOS/Android) mobile application with dynamic role navigation (Parent, Student, Driver, Teacher), offline-first outbox synchronization, hardware camera QR scanning, background GPS broadcasting, and push notifications.
3. **Brand Design Tokens & Shared UI (`/packages/ui`)**: BOMIS Sambalpur brand identity system (Primary Navy/Teal `#0F2942`, Accent Warm Coral `#FF6B4A`, slate neutrals, semantic status colors) unified across web and mobile.
4. **Offline-First Synchronization Architecture**: Resilient local SQLite outbox queue, FIFO processing, batch synchronization endpoint `/api/v1/sync/batch`, and multi-layer conflict resolution for low-connectivity environments.
5. **QA & Acceptance Criteria Matrix**: Complete verification mapping for schema synchronization, standardized response envelopes, financial idempotency, 70%+ business logic coverage, and one-command bootstrapping.
6. **4-Tier E2E Testing Strategy**: Comprehensive testing pyramid covering Tier 1 Feature Unit Tests, Tier 2 Boundaries & Negative Scenarios, Tier 3 Cross-Feature Pairwise Integration, and Tier 4 Real-World E2E Scenarios (Playwright and Mobile harness).
7. **Postman & Newman CI Automation (`/docs/postman`)**: 8-domain automated collection with pre-request correlation ID and JWT token injection, response envelope assertions, and Newman headless execution in CI.

---

## 1. Next.js 14 Web Portal Architecture (`/apps/web`)

### 1.1 Technical Stack & Core Dependencies
- **Framework**: Next.js 14.2+ (React 18+, Node.js 20+ LTS) utilizing App Router (`src/app` architecture).
- **Styling**: Tailwind CSS v3.4+, PostCSS, Autoprefixer, `tailwind-merge`, `clsx`, `tailwindcss-animate`.
- **Component Primitives**: `shadcn/ui` (accessible Radix UI primitives):
  - Navigation & Layout: `Sidebar`, `Navbar`, `Tabs`, `Breadcrumb`, `Sheet`, `ScrollArea`, `Separator`.
  - Data Entry & Forms: `Form`, `Input`, `Select`, `Checkbox`, `RadioGroup`, `Textarea`, `Switch`, `Calendar`, `DatePicker`, `Command` (combobox).
  - Feedback & Overlays: `Dialog`, `AlertDialog`, `Toast` (Sonner), `Tooltip`, `Popover`, `Skeleton`, `Progress`.
  - Data Display: `Table`, `DataTable` (TanStack Table v8), `Badge`, `Avatar`, `Card`, `Accordion`.
- **State Management & Server Synchronization**:
  - `TanStack Query` (React Query v5): Query client with caching policies, optimistic updates for rapid attendance and checklist actions, query invalidation helpers.
  - Client session context: React Context + Zustand for multi-role switching, active academic session, and UI preferences (collapsed sidebar, dark/light theme).
- **Form Handling & Contract Synchronization**:
  - `React Hook Form` (v7) with `@hookform/resolvers/zod`.
  - 100% type congruence: All validation schemas imported directly from `@bomis/shared`.
- **Data Visualization**:
  - `Recharts` for Principal's Pulse KPI dashboard (attendance trends, fee collection run-rate, grade distributions).
- **Typography & Internationalization**:
  - Next Font: `Inter` or `Plus Jakarta Sans` for Latin numerals and English UI.
  - Multilingual support for English, Hindi, and Odia: Google Fonts `Noto Sans Devanagari` and `Noto Sans Oriya` bundled.

### 1.2 Layout Hierarchy & Route Groups

```
apps/web/src/app/
├── (auth)/
│   ├── layout.tsx                     # Centered branded card layout with school crest
│   ├── login/page.tsx                 # Staff email+password & OTP toggle
│   ├── verify-otp/page.tsx            # 6-digit OTP verification input
│   └── forgot-password/page.tsx       # Password recovery workflow
├── (dashboard)/
│   ├── layout.tsx                     # Responsive dashboard shell (Sidebar, Header, Breadcrumbs)
│   ├── admin/
│   │   ├── page.tsx                   # Admin overview & system status
│   │   ├── school/page.tsx            # School profile, terms, CBSE affiliation config
│   │   ├── users/page.tsx             # Staff and student directory, bulk CSV import
│   │   ├── roles/page.tsx             # RBAC role-permission matrix view
│   │   └── audit-logs/page.tsx        # DPDP immutable audit logs viewer
│   ├── principal/
│   │   ├── pulse/page.tsx             # Real-time Pulse KPI dashboard
│   │   ├── substitutions/page.tsx     # One-click teacher absence substitution manager
│   │   └── approvals/page.tsx         # Concession & leave final approval workflow
│   ├── teacher/
│   │   ├── attendance/page.tsx        # Rapid attendance grid (<10s per class)
│   │   ├── diary/page.tsx             # Digital diary & homework creator with MinIO upload
│   │   ├── marks/page.tsx             # CBSE marks entry sheet & grade calculation
│   │   ├── timetable/page.tsx         # Weekly schedule and substitution alerts
│   │   └── ai-assistant/page.tsx      # Lesson planner & report card remarks generator
│   ├── accountant/
│   │   ├── structures/page.tsx        # Fee categories, installments, and late fee rules
│   │   ├── concessions/page.tsx       # Concession applications & approval queue
│   │   ├── collect/page.tsx           # Cash/Cheque/POS receipt entry & Razorpay link
│   │   ├── reconciliation/page.tsx    # Day-wise reconciliation ledger
│   │   └── receipts/[id]/page.tsx     # Printable tax receipt & fee voucher
│   └── parent/                        # Desktop parent view
│       ├── students/page.tsx          # Multi-child sibling selector
│       ├── attendance/page.tsx        # Monthly color-coded attendance calendar
│       ├── fees/page.tsx              # Razorpay checkout & payment history
│       ├── homework/page.tsx          # Homework feed & submission status
│       └── report-cards/page.tsx      # Term report cards & PDF download
├── api/
│   └── [...proxy]/route.ts            # Optional Next.js API route proxy / rewrite to NestJS
├── globals.css                        # Tailwind directives + BOMIS CSS variables
└── layout.tsx                         # Root HTML layout with providers (QueryClient, Theme, Toast)
```

### 1.3 Key Role-Based Web User Experiences

| Role | Key Views & Features | Performance & UX Target |
|---|---|---|
| **Admin** | Bulk CSV user import, Staff master profiles, RBAC permission toggles, DPDP audit trail inspection with filter by actor/date/IP. | Sub-second table filtering on 1,000+ records, client-side CSV validation before server dispatch. |
| **Principal** | Pulse Dashboard: real-time student/staff attendance rates, bus route statuses, pending approvals; one-click teacher absence substitution engine. | Live refresh (30s polling or WebSocket), zero-latency substitution suggestion list. |
| **Teacher** | Rapid Attendance Grid: all students in class rendered in grid/list; keyboard shortcuts (P/A/L) or one-click "Mark All Present"; homework authoring with rich text and PDF attachments. | Whole class (35 students) attendance marked and submitted in < 10 seconds. |
| **Accountant** | Fee collection portal: installment status indicators, concession approval workflow, Razorpay payment status sync, day-wise reconciliation ledger, printable GST-compliant receipts. | Instant calculation of late fines and concessions; PDF receipt preview under 500ms. |
| **Parent** | Multi-child switcher, fee payment via Razorpay modal (Cards, UPI, Netbanking), downloadable CBSE report card PDFs, school circular acknowledgements. | Clean mobile-responsive desktop layout, immediate receipt confirmation upon webhook resolution. |

---

## 2. React Native (Expo) Mobile App Architecture (`/apps/mobile`)

### 2.1 Technical Stack & Core Dependencies
- **Framework**: React Native 0.74+ with Expo SDK 51+ (Hermes JavaScript engine, New Architecture enabled).
- **Navigation**: `expo-router` (v3) file-based routing or `@react-navigation/native` with native stacks and bottom tabs.
- **Styling**: `NativeWind` (Tailwind CSS for React Native) referencing shared design tokens from `@bomis/ui`.
- **Local Persistence & SQLite**:
  - `expo-sqlite` (v14+) or `@nozbe/watermelondb` for offline data storage and sync outbox.
  - `expo-secure-store` for hardware-backed encryption of JWT access tokens, refresh tokens, and biometric credentials.
- **Hardware Integration & Sensors**:
  - `expo-camera` / `expo-barcode-scanner`: Fast hardware QR code scanning for bus boarding and gate pickup.
  - `expo-location`: Foreground and background geolocation tracking for driver bus broadcasts.
  - `expo-notifications`: Push notification handling (FCM / APNs) with actionable deep linking.
  - `react-native-maps`: Native map display for live bus tracking with animated vehicle markers and polyline routes.
- **Payment Gateway**:
  - `react-native-razorpay` native bridge or secure WebView checkout for UPI intent (Google Pay, PhonePe, Paytm).

### 2.2 Dynamic Role-Based Mobile Navigation

The mobile application dynamically mounts role-specific navigation trees based on the authenticated user's profile:

```
apps/mobile/src/app/
├── (auth)/
│   ├── login.tsx                      # Mobile number + OTP request
│   └── verify-otp.tsx                 # 6-digit OTP entry with auto-read
├── (parent)/
│   ├── _layout.tsx                    # Parent tab bar + Top child switcher
│   ├── dashboard.tsx                  # Daily summary, alerts, timetable
│   ├── bus-tracking.tsx               # Real-time map with live bus marker & geofence alert
│   ├── diary.tsx                      # Homework feed & circulars with read receipts
│   ├── fees.tsx                       # Pending installments & instant Razorpay pay
│   └── pickup-pass.tsx                # Dynamic student QR pass for gate dismissal
├── (student)/
│   ├── _layout.tsx                    # Student tab bar
│   ├── timetable.tsx                  # Current period and weekly timetable
│   ├── assignments.tsx                # Homework submission & teacher remarks
│   ├── id-card.tsx                    # Digital student ID card with QR code
│   └── study-buddy.tsx                # AI Study Buddy conversational interface
├── (driver)/
│   ├── _layout.tsx                    # Driver transport mini-app layout
│   ├── trip-control.tsx               # Start/End Morning/Afternoon trip toggle
│   ├── live-gps.tsx                   # GPS broadcasting status & telemetry log
│   ├── qr-scanner.tsx                 # Continuous camera QR reader for boarding/deboarding
│   └── manifest.tsx                   # Stop-by-stop passenger boarding checklist (4 pilot buses)
└── (teacher)/
    ├── _layout.tsx                    # Teacher mobile tabs
    ├── rapid-attendance.tsx           # Touch-optimized rapid attendance grid (<10s)
    ├── quick-homework.tsx             # Camera photo capture + homework assignment broadcast
    └── substitutions.tsx              # Today's substitution assignments notification
```

### 2.3 4 Pilot Buses Specification (Sambalpur Routes)

The mobile transport module is engineered to support the 4 pilot buses specified in R4:
1. **Pilot Bus 1 (Mini-bus 1, 24-seater)**: Route: Khetrajpur -> Golebazar -> Budharaja -> BOMIS Campus.
2. **Pilot Bus 2 (Mini-bus 2, 24-seater)**: Route: Dhanupali -> Ainthapali -> Bareipali -> BOMIS Campus.
3. **Pilot Bus 3 (Mini-bus 3, 24-seater)**: Route: Burla Town -> VSSUT Campus -> Hirakud -> BOMIS Campus.
4. **Pilot Bus 4 (Full-size Bus 4, 52-seater)**: Route: Sambalpur Central -> Modipara -> Farm Road -> Remed -> BOMIS Campus.

- **Driver Telemetry**: Broadcasts payload every 3–5 seconds:
  `{ tripId: string, busId: string, routeId: string, lat: number, lng: number, speed: number, heading: number, timestamp: string }`
- **Parent Alert**: Server triggers push alert when bus distance is <= 1.5 km or estimated travel time is <= 5 minutes based on geofence polyline calculation.

---

## 3. Brand Design Tokens & Shared UI (`/packages/ui`)

### 3.1 BOMIS Sambalpur Color Palette
The brand system embodies the institutional authority, academic warmth, and modern international spirit of Birla Open Minds International School:

```typescript
export const bomisPalette = {
  // Brand Identity Primary: Navy / Deep Slate Teal
  primary: {
    50: '#F0F5FA',
    100: '#D9E6F2',
    200: '#B3CDE5',
    300: '#80ACD4',
    400: '#4D8BC3',
    500: '#0F2942', // Base Brand Navy
    600: '#0D2338',
    700: '#0A1C2D',
    800: '#081623',
    900: '#050E17',
    DEFAULT: '#0F2942',
    foreground: '#FFFFFF',
  },
  // Brand Identity Accent: Warm Coral / Terracotta
  accent: {
    50: '#FFF3F0',
    100: '#FFE4DD',
    200: '#FFC5B8',
    300: '#FF9F88',
    400: '#FF7E5F',
    500: '#FF6B4A', // Base Brand Warm Coral
    600: '#E65331',
    700: '#C03E20',
    800: '#992E15',
    900: '#7A220E',
    DEFAULT: '#FF6B4A',
    foreground: '#FFFFFF',
  },
  // Semantic Status Colors
  success: {
    DEFAULT: '#10B981', // Emerald 500 (Present attendance, Paid fee)
    light: '#ECFDF5',
    foreground: '#FFFFFF',
  },
  warning: {
    DEFAULT: '#F59E0B', // Amber 500 (Late attendance, Concession pending)
    light: '#FFFBEB',
    foreground: '#FFFFFF',
  },
  danger: {
    DEFAULT: '#EF4444', // Red 500 (Absent attendance, Overdue fee, SOS Alert)
    light: '#FEF2F2',
    foreground: '#FFFFFF',
  },
  info: {
    DEFAULT: '#0EA5E9', // Sky 500 (Transport live, Circular notice)
    light: '#F0F9FF',
    foreground: '#FFFFFF',
  },
  // Neutrals (Slate scale)
  neutral: {
    50: '#F8FAFC',  // Main app background (light)
    100: '#F1F5F9', // Card headers, disabled states
    200: '#E2E8F0', // Border color
    300: '#CBD5E1', // Divider lines
    400: '#94A3B8', // Placeholder text, subtle icons
    500: '#64748B', // Secondary text
    600: '#475569', // Body text
    700: '#334155', // Subheadings
    800: '#1E293B', // Main text / Card background (dark)
    900: '#0F172A', // App background (dark)
  }
};
```

### 3.2 Typography & Spacing System
- **Scale**:
  - `xs`: 12px / Line height 16px (Badges, timestamps, helper text)
  - `sm`: 14px / Line height 20px (Table cells, form labels, secondary body)
  - `base`: 16px / Line height 24px (Standard body copy, inputs)
  - `lg`: 18px / Line height 28px (Card headers, modal titles)
  - `xl`: 20px / Line height 28px (Section titles, KPI metrics)
  - `2xl`: 24px / Line height 32px (Page headers)
  - `3xl`: 30px / Line height 36px (Dashboard hero banners)
- **Radii**: `sm: 4px`, `md: 6px`, `lg: 8px`, `xl: 12px`, `full: 9999px`.
- **Elevation / Shadows**: Standard tailwind shadows customized for clean elevation on school documents and cards.
- **Indian Locale Formatting Helpers**:
  - `formatINR(amount: number): string` -> Formats `125000` to `₹1,25,000`.
  - `formatISTDate(date: string | Date): string` -> Formats to `DD/MM/YYYY`.
  - `formatISTTime(date: string | Date): string` -> Formats to `hh:mm A`.

---

## 4. Offline-First Sync Architecture & Queue Protocol

In semi-urban and rural areas of Sambalpur, 4G cellular coverage can be intermittent (e.g. on bus routes, in concrete basement classrooms, or sports fields). The mobile application implements an offline-first architecture to guarantee zero data loss.

### 4.1 Local SQLite Outbox Queue Schema

```sql
CREATE TABLE IF NOT EXISTS local_sync_outbox (
  id TEXT PRIMARY KEY,                 -- Client-generated UUIDv4
  action_type TEXT NOT NULL,           -- Enum: 'ATTENDANCE_BATCH', 'TRANSPORT_SCAN', 'HOMEWORK_SUBMIT'
  endpoint TEXT NOT NULL,              -- Target API route, e.g. '/api/v1/attendance/batch'
  method TEXT NOT NULL,                -- 'POST' | 'PATCH' | 'PUT'
  payload TEXT NOT NULL,               -- JSON serialized payload
  idempotency_key TEXT NOT NULL UNIQUE,-- Client idempotency key
  created_at INTEGER NOT NULL,         -- Unix millisecond timestamp
  retry_count INTEGER DEFAULT 0,       -- Attempt count
  status TEXT DEFAULT 'PENDING',       -- 'PENDING' | 'SYNCING' | 'FAILED' | 'RESOLVED'
  error_message TEXT
);

CREATE INDEX IF NOT EXISTS idx_outbox_status ON local_sync_outbox(status);
```

### 4.2 Sync Engine Lifecycle & Queue Processing

```
[User Action: e.g. Mark Attendance or Scan QR]
           │
           ▼
[Write to Local SQLite DB (Immediate UI Update)]
           │
           ▼
[Append record to local_sync_outbox (Status: PENDING)]
           │
           ▼
[Check NetInfo: Is Internet Available?]
      ├─── NO ───► [Wait for NetInfo 'change' event / Background Sync Job]
      │
     YES
      ▼
[Acquire Sync Mutex Lock]
      │
      ▼
[Select Top 20 PENDING Records FIFO]
      │
      ▼
[POST to /api/v1/sync/batch with Headers: Authorization, x-correlation-id]
      │
      ▼
[Process Backend Batch Response]
      ├── SUCCESS: [DELETE record from local_sync_outbox]
      ├── 409 CONFLICT: [Trigger Conflict Resolver Strategy]
      └── NETWORK ERROR: [Increment retry_count, apply exponential backoff (2^n seconds)]
      │
      ▼
[Release Sync Mutex Lock]
```

### 4.3 Conflict Resolution Strategies

1. **Attendance Marking**:
   - Class teacher's submission is authoritative.
   - If two offline devices submit conflicting attendance for the same student on the same date:
     - The latest timestamp takes precedence.
     - An audit entry `ATTENDANCE_CONFLICT_OVERWRITE` is logged in `audit_logs` table.
     - Admin or Principal manual edits override all automated/teacher submissions.
2. **Transport Boarding/Deboarding**:
   - Scan events are **append-only immutable events** (`transport_scans`).
   - Conflict cannot occur because scans are recorded as distinct events with timestamp and coordinates. If duplicate scan occurs within 30 seconds, client deduplicates locally.
3. **Homework Submissions**:
   - If student submits offline and re-submits later, higher version / latest timestamp is retained; previous submission is archived as historical revision.

---

## 5. QA & Acceptance Criteria Verification

Mapping of all Acceptance Criteria from `ORIGINAL_REQUEST.md` to concrete implementation and test verifications:

| Criteria ID | Acceptance Criteria | Implementation Strategy | Verification & Automated Test Check |
|---|---|---|---|
| **AC-1** | **Type & Schema Synchronization**: All frontend and backend validation originates from `/packages/shared` Zod schemas with 100% type congruence. | Export shared Zod schemas from `@bomis/shared`. Backend NestJS uses `nestjs-zod` or ZodValidationPipe; Next.js uses `zodResolver`; Expo uses shared Zod schemas. | Type-check script `pnpm typecheck` across all workspaces. Unit tests validating schema rejection on malformed payloads. |
| **AC-2** | **Standardized Envelope**: All REST endpoints return `{ success: boolean, data: T, error?: { code: string, message: string, details?: any }, timestamp: string, correlationId: string }`. | NestJS global `TransformInterceptor` wraps successful responses; global `HttpExceptionFilter` formats all exceptions; correlationId generated via AsyncLocalStorage/Pino. | Postman Collection tests assert `pm.expect(response.json()).to.have.property('correlationId')` and `success` boolean on 100% of endpoints. |
| **AC-3** | **Idempotency & Financial Safety**: All payment endpoints enforce `Idempotency-Key` headers; Razorpay webhooks verify cryptographic signatures with duplicate payload protection. | NestJS `IdempotencyInterceptor` storing cached results in Redis (24h TTL); Webhook controller validates HMAC-SHA256 signature using `crypto.timingSafeEqual`. | Tier 2 test suites: replay identical request with same key returns cached result; tampered webhook signature returns 400. |
| **AC-4** | **Test Coverage**: Minimum 70% test coverage on business logic (fee calculation, attendance percentages, grading algorithms, timetable clash detection), role-scoping tests. | Vitest / Jest test suites targeting `@bomis/shared` calculation functions and NestJS domain service classes with coverage reporter. | CI command `pnpm test:coverage` asserting `>= 70%` branch and line coverage threshold. |
| **AC-5** | **Postman & Newman CI**: Exported Postman collection and environment in `/docs/postman` featuring pre-request role authentication, test assertions on all endpoints, and passing cleanly in CI. | Collection JSON and Environment JSON in `/docs/postman`, automated token generation script, comprehensive assertions, headless run via Newman. | GitHub Actions CI job running `newman run ...` returning exit code 0. |
| **AC-6** | **One-Command Bootstrapping**: `docker compose up -d` followed by `pnpm install && pnpm db:migrate && pnpm db:seed && pnpm dev` starts the entire platform with realistic seed data for Grades 1–8 Section A and 4 buses. | Complete `docker-compose.yml` (Postgres, Redis, MinIO, Mailpit); deterministic `prisma/seed.ts` seeding 240+ students, 8 roles, 4 pilot buses with routes and stops. | Automated bootstrapping verification script in CI testing complete start sequence on clean environment. |

---

## 6. 4-Tier E2E Testing Strategy Matrix

```
             ▲
            / \
           /   \         Tier 4: Real-World E2E Scenarios (Playwright / Mobile Harness)
          / T4  \        Multi-role user journeys, full-stack browser automation
         /-------\
        /         \      Tier 3: Cross-Feature Pairwise & Integration Tests
       /    T3     \     API + DB + Redis + BullMQ workflows across roles
      /-------------\
     /               \   Tier 2: Boundary, Edge Case & Negative Tests
    /       T2        \  Validation limits, concurrency, idempotency, 403 checks
   /-------------------\
  /         T1          \ Tier 1: Feature Coverage & Unit Tests
 /                       \ Pure logic: Fee math, CBSE grading, clash detection
/─────────────────────────\
```

### Tier 1: Feature Coverage & Unit Tests
- **Target**: Pure functions, mathematical engines, validation schemas, utility formatters.
- **Tools**: Vitest / Jest (`pnpm --filter @bomis/shared test`, `pnpm --filter @bomis/api test:unit`).
- **Test Inventory**:
  1. `fee-calculator.spec.ts`:
     - Base fee computation across Grade 1 to 8.
     - Transport fee addition based on distance slab (0-5km, 5-10km, 10-15km).
     - Sibling concession logic: 10% on second child, 15% on third child.
     - Merit/Need-based concession percentage and fixed-amount discounts.
     - Late fine calculation: ₹50/day after 10th of the installment month.
  2. `cbse-grading.spec.ts`:
     - Conversion of raw marks to CBSE 9-point scale (A1, A2, B1, B2, C1, C2, D, E).
     - Weighted average calculation across FA1, FA2, SA1, SA2 terms.
     - Pass/Fail/Compartment determination logic.
  3. `timetable-clash.spec.ts`:
     - Teacher schedule overlap matrix: detecting when Teacher X is assigned to two classes simultaneously.
     - Room resource clash: detecting room double-booking.
     - Maximum consecutive periods constraint (<= 3 periods without break).
  4. `attendance-stats.spec.ts`:
     - Attendance percentage formula: `(Present + 0.5 * HalfDay) / TotalWorkingDays * 100`.
     - 75% CBSE mandatory minimum threshold warning trigger.
  5. `zod-schemas.spec.ts`:
     - Verification of valid vs invalid inputs for all 20+ shared Zod schemas.

### Tier 2: Boundary, Edge Case & Negative Tests
- **Target**: Security boundaries, exception handling, extreme parameters, concurrency safety.
- **Tools**: Vitest / Supertest (`pnpm --filter @bomis/api test:e2e`).
- **Test Inventory**:
  1. `financial-idempotency.spec.ts`:
     - Calling `POST /api/v1/payments/razorpay/order` without `Idempotency-Key` -> 400 Bad Request.
     - Calling `POST /api/v1/payments/razorpay/order` with same key and identical body -> 200 OK (cached response returned, zero duplicate database rows).
     - Calling with same key but different amount -> 422 Unprocessable Entity / 409 Conflict.
     - Razorpay webhook replay attack: sending identical payment captured event twice -> 200 OK (second event ignored idempotently).
  2. `rbac-negative-matrix.spec.ts`:
     - Cross-role authorization tests (Matrix of 8 roles x 15 sensitive endpoints):
       - Parent accessing `/api/v1/admin/audit-logs` -> 403 Forbidden.
       - Student accessing `/api/v1/academics/marks/entry` -> 403 Forbidden.
       - Teacher accessing `/api/v1/fees/structures` -> 403 Forbidden.
       - Accountant accessing `/api/v1/safety/visitor-pass` -> 403 Forbidden.
       - Driver accessing `/api/v1/admin/users` -> 403 Forbidden.
  3. `tenant-isolation-rls.spec.ts`:
     - Parent A attempting to view Student B's profile via direct ID tampering -> 403/404.
     - Teacher A attempting to mark attendance for Section B without substitution grant -> 403 Forbidden.
  4. `input-boundary.spec.ts`:
     - Mobile OTP input with letters, 5 digits, or 7 digits -> rejected by Zod.
     - Marking attendance for future dates or official school holidays -> 400 Bad Request.
     - Uploading files > 10MB or disallowed MIME types -> 413 Payload Too Large / 400.

### Tier 3: Cross-Feature Pairwise & Integration Tests
- **Target**: Multi-service integration with PostgreSQL, Redis, BullMQ workers, and WebSocket gateway.
- **Test Inventory**:
  1. `auth-session-revocation.spec.ts`:
     - Staff login -> token issue -> API access succeeds -> logout called -> Redis blacklists refresh token -> immediate re-use returns 401 Unauthorized.
  2. `absence-to-substitution-workflow.spec.ts`:
     - Teacher A requests sick leave -> Principal approves leave -> Substitution Engine identifies absent periods -> matches available free teachers -> assigns Teacher B -> enqueues FCM push notification.
  3. `fee-concession-to-payment-workflow.spec.ts`:
     - Sibling concession submitted -> Accountant reviews -> Principal approves -> Installment amount updates -> Parent initiates payment -> Razorpay webhook captures payment -> Receipt generated -> Day-book reconciled.
  4. `transport-gps-to-geofence-alert.spec.ts`:
     - Driver starts trip on Route 1 -> publishes coordinates -> Geofence worker detects bus is 1.2km from Stop 2 -> triggers push notification job to parents of Stop 2 students.

### Tier 4: Real-World E2E Application Scenarios
- **Target**: Complete end-to-end browser journeys using Playwright.
- **Tools**: `@playwright/test` running in headless Chrome/Firefox.
- **Scenario Scripts**:

#### Scenario 1: Teacher Rapid Attendance Flow
```typescript
test('Teacher completes rapid attendance for Grade 5-A in < 10 seconds', async ({ page }) => {
  // 1. Login as Grade 5-A Class Teacher
  await page.goto('/login');
  await page.fill('input[name="email"]', 'teacher.grade5a@bomis-sambalpur.edu.in');
  await page.fill('input[name="password"]', 'Teacher@Pass123');
  await page.click('button[type="submit"]');
  await page.waitForURL('/teacher/attendance');

  // 2. Verify Section Grid is loaded
  await expect(page.locator('h1')).toContainText('Class 5 - Section A Attendance');
  const studentRows = page.locator('[data-testid="attendance-row"]');
  await expect(studentRows).toHaveCount(30);

  // 3. Perform Rapid Marking: Mark All Present, then toggle 2 students to Absent
  const startTime = Date.now();
  await page.click('[data-testid="mark-all-present-btn"]');
  await page.click('[data-testid="student-row-5"] [data-testid="status-absent"]');
  await page.click('[data-testid="student-row-12"] [data-testid="status-absent"]');
  
  // 4. Submit
  await page.click('[data-testid="submit-attendance-btn"]');
  await expect(page.locator('[data-testid="toast-success"]')).toContainText('Attendance recorded successfully');
  const duration = (Date.now() - startTime) / 1000;
  expect(duration).toBeLessThan(10); // Verified under 10 seconds!
});
```

#### Scenario 2: Principal Real-Time Pulse & Substitution
- Principal logs in, reviews live KPI cards (School Attendance: 94.2%, Fees Collected Today: ₹1,45,000, Active Buses: 4/4).
- Navigates to `/principal/substitutions`.
- Inspects automatically detected conflict for absent Class 4 Science teacher.
- Selects recommended free teacher (Period 3) and clicks "Confirm Substitution".
- Verifies real-time update in schedule.

#### Scenario 3: Parent Multi-Child Sibling Switch & Fee Payment
- Parent logs in via OTP.
- Uses top avatar switcher to toggle between Child 1 (Grade 4) and Child 2 (Grade 7).
- Navigates to `/parent/fees`.
- Clicks "Pay Installment (₹16,000)" -> Razorpay checkout mock handles transaction.
- Verifies status updates to "PAID" and downloads PDF receipt.

#### Scenario 4: Driver Pilot Bus Journey & Boarding Scanner
- Driver logs in on mobile device for Bus #1 (Mini-bus 1).
- Clicks "Start Morning Trip" on Route 1.
- QR scanner continuously scans 3 test student QR codes.
- Asserts passenger count increments from 0 to 3.
- Clicks "End Trip at Campus".

---

## 7. Postman Collection & Newman CI Automation (`/docs/postman`)

### 7.1 Directory Layout
```
docs/postman/
├── bomis_sambalpur.postman_collection.json    # Complete multi-domain collection
├── bomis_sambalpur.postman_environment.json   # Environment variables (dev, ci, prod)
├── newman-runner.js                           # Custom Node.js runner script with HTML/JSON reports
└── README.md                                  # Instructions for manual and automated runs
```

### 7.2 Collection Structure & Pre-Request Automation

#### Global Collection Pre-Request Script
```javascript
// Auto-generate Correlation ID for every request
var correlationId = 'corr-' + pm.variables.replaceIn('{{$guid}}');
pm.variables.set('correlationId', correlationId);
pm.request.headers.add({ key: 'x-correlation-id', value: correlationId });

// Auto-generate Idempotency-Key for POST/PUT payments
if (pm.request.method === 'POST' && pm.request.url.getPath().includes('payments')) {
    var idempotencyKey = 'idemp-' + pm.variables.replaceIn('{{$guid}}');
    pm.variables.set('idempotencyKey', idempotencyKey);
    pm.request.headers.add({ key: 'Idempotency-Key', value: idempotencyKey });
}
```

#### Global Response Test Script
```javascript
// Validate BOMIS Standard Envelope
pm.test("Standard Response Envelope Schema is valid", function () {
    var json = pm.response.json();
    pm.expect(json).to.be.an('object');
    pm.expect(json).to.have.property('success');
    pm.expect(json).to.have.property('timestamp');
    pm.expect(json).to.have.property('correlationId');
    pm.expect(json.correlationId).to.eql(pm.variables.get('correlationId'));
    
    if (json.success === true) {
        pm.expect(json).to.have.property('data');
    } else {
        pm.expect(json).to.have.property('error');
        pm.expect(json.error).to.have.property('code');
        pm.expect(json.error).to.have.property('message');
    }
});

pm.test("Response time < 500ms", function () {
    pm.expect(pm.response.responseTime).to.be.below(500);
});
```

### 7.3 Domain Test Folders in Postman Collection

1. **`00_Health_and_Readiness`**:
   - `GET /health`: Liveness probe, memory usage.
   - `GET /ready`: Readiness probe checking PostgreSQL, Redis, and MinIO connectivity.
2. **`01_Authentication_and_RBAC`**:
   - `POST /api/v1/auth/otp/request` (Parent mobile OTP)
   - `POST /api/v1/auth/otp/verify` (Token extraction -> saved to `parentToken`)
   - `POST /api/v1/auth/staff/login` (Admin/Teacher/Accountant login -> tokens saved)
   - `POST /api/v1/auth/token/refresh` (Refresh rotation)
   - `GET /api/v1/admin/audit-logs` with `parentToken` -> Assert `403 Forbidden`
3. **`02_People_and_Students`**:
   - `GET /api/v1/students?grade=5&section=A` -> Returns list of 30 students.
   - `GET /api/v1/students/:id/profile` -> Validates DPDP-compliant field sanitization.
4. **`03_Attendance_and_Offline_Sync`**:
   - `POST /api/v1/attendance/batch`: Submits class attendance payload.
   - `POST /api/v1/sync/batch`: Submits array of offline outbox events.
   - `GET /api/v1/attendance/class/:id/summary`: Checks calculated percentage.
5. **`04_Fees_and_Payments`**:
   - `GET /api/v1/fees/installments?studentId={{studentId}}`
   - `POST /api/v1/fees/concessions/apply`
   - `PATCH /api/v1/fees/concessions/:id/approve`
   - `POST /api/v1/payments/razorpay/order` (Asserts `Idempotency-Key`)
   - `POST /api/v1/payments/razorpay/webhook` (Simulated HMAC signature)
   - `GET /api/v1/fees/reconciliation/day-book`
6. **`05_Academics_and_Report_Cards`**:
   - `GET /api/v1/timetable/class/:id`
   - `POST /api/v1/academics/marks/entry`
   - `POST /api/v1/academics/report-cards/generate-pdf` -> Asserts 202 Accepted (BullMQ job ID returned).
7. **`06_Transport_and_Safety`**:
   - `GET /api/v1/transport/buses` -> Asserts 4 pilot buses present.
   - `POST /api/v1/transport/trip/start`
   - `POST /api/v1/transport/student-scan`
   - `POST /api/v1/transport/gps-ping`
   - `POST /api/v1/safety/visitor-pass`

### 7.4 Newman Execution in CI
- **Root NPM Script**:
  ```json
  "test:postman": "newman run docs/postman/bomis_sambalpur.postman_collection.json -e docs/postman/bomis_sambalpur.postman_environment.json --reporters cli,json --reporter-json-export docs/postman/newman-report.json --bail false"
  ```
- Executed automatically in CI after Docker bootstrap and migration.

---

## 8. One-Command Bootstrapping & Developer Experience Verification

### 8.1 Bootstrapping Command Chain
```bash
docker compose up -d && pnpm install && pnpm db:migrate && pnpm db:seed && pnpm dev
```

### 8.2 Execution Step Analysis

| Sequence | Command | What It Does | Success Criteria |
|---|---|---|---|
| 1 | `docker compose up -d` | Starts local infrastructure: PostgreSQL 16 (port 5432), Redis 7 (port 6379), MinIO (ports 9000/9001), Mailpit (ports 1025/8025). | All containers in `healthy` status; ports reachable. |
| 2 | `pnpm install` | Installs dependencies across all workspaces (`/apps/api`, `/apps/web`, `/apps/mobile`, `/packages/shared`, `/packages/ui`) with symlinks. | Exit code 0, lockfile intact, no unmet peer dependencies. |
| 3 | `pnpm db:migrate` | Runs `prisma migrate deploy` to create all tables, indexes, enums, and foreign keys in Postgres. | All migrations applied cleanly without errors. |
| 4 | `pnpm db:seed` | Executes `prisma/seed.ts` to populate: BOMIS Sambalpur school profile, 8 roles, 25 staff members, Grades 1–8 Section A (240+ students with sibling links), CBSE subjects, fee structures, and 4 pilot buses with routes/stops. | Seed script prints summary confirmation of records created. |
| 5 | `pnpm dev` | Turborepo launches development processes: `/apps/api` (port 4000), `/apps/web` (port 3000), and `/apps/mobile` (Expo bundler port 8081). | Web portal accessible at `http://localhost:3000`, API Swagger at `http://localhost:4000/api/docs`. |

---

## 9. Edge Cases, Risks & Mitigations

| Risk / Edge Case | Impact | Technical Mitigation |
|---|---|---|
| **Intermittent 4G cellular drops on rural Sambalpur bus routes** | Telemetry and student boarding scans lost or delayed. | Mobile app saves all scan events and GPS pings to local SQLite outbox queue; automatically flushes in chronological batches upon reconnection with idempotency keys. |
| **Simultaneous double-click on fee payment submission** | Duplicate charge to parent or double credit recorded. | Frontend disables payment button upon first click with loading spinner; backend enforces unique `Idempotency-Key` header with 24-hour Redis TTL cache. |
| **Concurrent attendance edits by primary teacher and substitute teacher** | Overwritten attendance records and conflicting parent alerts. | Database optimistic locking with version column; latest teacher submission audited; system logs `ATTENDANCE_CONFLICT_OVERWRITE` if discrepancies occur. |
| **High latency during PDF report card generation for 240+ students** | Server thread blocking or request timeout. | Generation offloaded to BullMQ background worker queue with Redis; API returns 202 Accepted with job ID; user notified via notification center when PDF is ready in MinIO. |
| **Unauthorized sibling data exposure in multi-child families** | Privacy breach under DPDP Act 2023. | Row-Level Security (RLS) and Prisma middleware verify parent-guardian relationship to `student_id` before returning records. |
| **Camera failure or scratched QR codes during bus boarding** | Driver delayed at stop. | Manual student checklist fallback in driver app allowing 1-tap manual check-in with student photo confirmation. |

---

## 10. Conclusion & Recommended Action Plan

The specifications and architectural models analyzed in this report provide complete coverage for Phase 0 Foundation and subsequent implementation milestones. 

1. **For Monorepo Architect & Spec Miner**: Ensure `@bomis/ui` package exports the complete palette and design tokens, and `@bomis/shared` contains all Zod validation contracts.
2. **For Backend Engineers**: Implement the `/api/v1/sync/batch` offline sync endpoint, Redis idempotency interceptor, and standard response envelope filter.
3. **For Frontend & Mobile Engineers**: Scaffold Next.js 14 App Router and Expo mobile structures matching the route maps detailed above.
4. **For QA & DevOps Engineers**: Initialize the Postman collection and Newman CI automated runner in `/docs/postman` and verify the one-command bootstrap workflow.
