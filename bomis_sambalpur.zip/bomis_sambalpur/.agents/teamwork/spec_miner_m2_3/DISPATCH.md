## 2026-10-18T05:54:28Z
You are Spec Miner M2-3 (teamwork_preview_spec_miner).
Your working directory is: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m2_3
Project root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur

MANDATORY FIRST STEP:
Read C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md completely.
Also read:
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_survey_1\analysis.md

TASK:
Mine and specify the exact requirements and data fixtures for the Realistic Seed Data Generator (`prisma/seed.ts`):
1. BOMIS Sambalpur Root School Entity:
   - Name: Birla Open Minds International School, Sambalpur
   - Code, Address (Sambalpur, Odisha, PIN 768006), Contact, Affiliation (CBSE), Academic Year 2026-2027.
2. Academic Classes & Sections:
   - Grades 1 through 8, Section A for each grade.
   - Standard CBSE curriculum subjects per grade (English, Hindi/Odia, Mathematics, Environmental Studies/Science, Social Studies, Computer Science).
3. Realistic Indian User Entities across 8 RBAC Roles:
   - Super Admin, Admin, Principal, Faculty / Teachers (assigned to grades and subjects), Accountant, Students (at least 20-30 students across grades with realistic Sambalpur/Odisha names), Parents/Guardians (with multi-child sibling relationships linking parents to students in different grades), Driver/Transport Staff.
   - Valid bcrypt password hashes and phone numbers for OTP auth.
4. Transport Fleet:
   - 4 pilot buses (3 small, 1 full-size) with registration numbers (OD-15-...), drivers, routes, geofenced stops in Sambalpur, and student assignments.
5. Seed execution strategy:
   - Clean idempotent upsert or clear-and-populate logic.
   - Seed script configuration in `package.json` and `prisma/seed.ts`.

OUTPUT:
Write your comprehensive specification report to:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m2_3\analysis.md
and write handoff.md in that directory.
Send a message back to the orchestrator (caller) with a summary when complete. DO NOT modify any production source code.
