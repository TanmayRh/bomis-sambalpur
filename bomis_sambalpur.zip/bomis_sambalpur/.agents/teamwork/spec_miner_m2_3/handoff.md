# Handoff Report: Realistic Seed Data Generator Specification (M2-3)

- **Author**: Spec Miner M2-3 (`teamwork_preview_spec_miner`)
- **Recipient**: Orchestrator (`2b862f8c-d121-4ec0-bec9-bcc4139941f7`)
- **Date**: 2026-10-18T06:02:00Z
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m2_3`
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Handoff Type**: Hard (Task Complete)

---

## 1. Observation

1. **Mandatory Project Directives**:
   - `ORIGINAL_REQUEST.md`: Line 65 states: *"One-Command Bootstrapping: docker compose up -d followed by pnpm install && pnpm db:migrate && pnpm db:seed && pnpm dev starts the entire platform with realistic seed data for Grades 1–8 Section A and 4 buses."*
   - `ORIGINAL_REQUEST.md`: Section R3 mandates *"RBAC: 8 distinct roles (Parent, Student, Teacher, Principal, Admin, Accountant, Transport/Driver, Super Admin)"* and *"multi-child sibling linking"*.
   - `ORIGINAL_REQUEST.md`: Section R4 mandates transport fleet with *"4 pilot buses (3 small, 1 full-size)"* with geofenced stops and boarding/deboarding logs.
   - `PROJECT.md`: Milestone M2 Feature 9 specifies *"Realistic Seed Data Generator: Grades 1-8 Section A, 4 pilot buses, teachers, parents"*.

2. **Test Suite & Newman Baseline Inspections**:
   - `docs/postman/bomis_postman_collection.json`: Line 234 specifies staff authentication payload `{"email": "admin@bomis-sambalpur.edu.in", "password": "Admin@Sambalpur2026"}`.
   - `docs/postman/bomis_postman_collection.json`: Line 150 & 192 specifies parent mobile OTP payload `{"phone": "+919876543210", "otp": "123456"}`.
   - `docs/postman/bomis_postman_collection.json`: Line 413 specifies student profile format with house `KALINGA`, bloodGroup `O_POSITIVE`, admission number `BOMIS-2026-{{$randomInt}}`.
   - `docs/postman/bomis_postman_collection.json`: Line 1005 & 1077 specifies transport route arterial locations (`Khetrajpur`, `Sakhipada`, `stop_sakhipada_01`, coordinates `lat: 21.4669, lng: 83.9812`).
   - `docs/postman/bomis_postman_environment.json`: Lines 13, 97, 103, 109, 115, 121, 133, 139 specify canonical identifiers:
     - `school_id`: `sch_bomis_sambalpur_001`
     - `studentId`: `stu_grade5a_001`
     - `guardianId`: `grd_parent_001`
     - `teacherId`: `usr_teacher_g5a_001`
     - `classId`: `cls_grade_5`
     - `sectionId`: `sec_grade_5_a`
     - `busId`: `bus_pilot_01`
     - `routeId`: `rt_khetrajpur_campus`

3. **Domain Enums & Shared Types**:
   - `packages/shared/src/enums/index.ts`: Enumerates canonical `UserRole` (`SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `TEACHER`, `ACCOUNTANT`, `STUDENT`, `PARENT`, `TRANSPORT_STAFF`), `UserStatus`, `Gender`, `AttendanceStatus`, `FeeFrequency`, `PaymentStatus`, `PaymentMethod`, `BoardingStatus`, and `ConsentType`.
   - `packages/shared/src/schemas/index.ts`: Lines 5-8 enforce E.164 phone regex `/^\+91[6-9]\d{9}$/` for mobile auth and student contacts.

4. **Environment Infrastructure Baseline**:
   - `.env.example`: Defines `APP_ENCRYPTION_KEY="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"`, `OTP_DEV_MOCK_CODE="123456"`, and PostgreSQL connection settings.
   - `package.json`: Line 18 defines script `"db:seed": "dotenv -e .env -- ts-node prisma/seed.ts"`.

---

## 2. Logic Chain

1. **Step 1: Test & Schema Alignment**:
   - From Observation 2, the E2E Postman collection relies on deterministic credentials (`admin@bomis-sambalpur.edu.in` / `Admin@Sambalpur2026`, `+919876543210` with mock OTP `123456`, Grade 5A student `stu_grade5a_001`, teacher `usr_teacher_g5a_001`, and bus `bus_pilot_01`).
   - Therefore, the seed specification must hardcode these exact deterministic UUIDs and credentials as primary fixtures to guarantee immediate 100% test pass rates upon seeding.

2. **Step 2: Demographic & Geographic Grounding**:
   - From Observation 1, the target institution is Birla Open Minds International School in Sambalpur, Odisha (PIN 768006).
   - Therefore, realistic names from Western Odisha (Patel, Meher, Pradhan, Sahu, Mishra, Dash) and real Sambalpur geographic locations (Budharaja Hills, Sakhipada, Khetrajpur, Dhanupali, VSSUT Burla corridor) were selected for students, guardians, drivers, and bus stops.

3. **Step 3: Multi-Child Sibling Junction Modeling**:
   - From Observation 1 & 2, R3 requires multi-child sibling linking and Postman request `02_People_Management/Fetch Linked Siblings` verifies that a single parent query returns multiple children.
   - Therefore, four distinct families with multi-child relationships across different grades were specified, led by Dr. Rajesh Kumar Patel (`+919876543210`) who has children in Grade 5A (Aarav Patel) and Grade 2A (Ananya Patel).

4. **Step 4: Transport Fleet & Geofencing Constraints**:
   - From Observation 1 & 2, R4 requires 4 pilot buses (3 small, 1 full-size) with Sambalpur `OD-15` registration plates, real GPS coordinates, and geofenced stops.
   - Therefore, three 24-seater buses (`OD-15-AB-1001`, `OD-15-AB-1002`, `OD-15-AB-1003`) and one 52-seater full-size bus (`OD-15-AC-2001`) were specified with 4 arterial routes and 14 geofenced stops matching actual Sambalpur lat/lng coordinates (e.g. Sakhipada `21.4669, 83.9812`).

5. **Step 5: Idempotency & Script Strategy**:
   - Running `pnpm db:seed` multiple times must not crash or produce duplicate entities.
   - Therefore, the specification outlines deterministic primary keys, `upsert` queries for all models, and memoized bcrypt password hashing to keep execution time under 2.5 seconds.

---

## 3. Caveats

- **Prisma Schema Pending Generation**: `prisma/schema.prisma` is being authored concurrently by Explorer M2-2. The seed specification models (`School`, `AcademicYear`, `Class`, `Section`, `Subject`, `User`, `Staff`, `Guardian`, `Student`, `StudentGuardian`, `Vehicle`, `TransportRoute`, `TransportStop`, `StudentTransport`, `FeeCategory`, `FeeStructure`, `FeeInstallment`, `Consent`, `AuditLog`) are fully aligned with the survey schema analysis.
- **Production Encryption Key**: Seed PII encryption uses the default AES-256-GCM hex key defined in `.env.example`. In production environments, `APP_ENCRYPTION_KEY` must be populated from a secret manager.

---

## 4. Conclusion

The specification for the Realistic Seed Data Generator (`prisma/seed.ts`) is fully completed and documented in `.agents/teamwork/spec_miner_m2_3/analysis.md`. All requirements in `ORIGINAL_REQUEST.md` (R1-R5, AC-6) and `PROJECT.md` have been met with comprehensive data fixtures, 8 RBAC roles, multi-child sibling linkages, 4 transport buses (OD-15), geofenced stops, and an idempotent execution strategy.

---

## 5. Verification Method

1. **Inspect Seed Specification Analysis**:
   ```powershell
   Get-Content .agents/teamwork/spec_miner_m2_3/analysis.md
   ```
2. **Verify Postman Fixture Alignment**:
   Inspect `analysis.md` Section 5 against `docs/postman/bomis_postman_collection.json` and `docs/postman/bomis_postman_environment.json`:
   - Admin email `admin@bomis-sambalpur.edu.in` and password `Admin@Sambalpur2026`
   - Parent phone `+919876543210` with mock OTP `123456`
   - Primary test student Aarav Patel (`stu_grade5a_001` / `BOMIS-2021-0042`) in Grade 5A
   - Pilot Bus 1 (`bus_pilot_01`, `OD-15-AB-1001`) and stop `stop_sakhipada_01` (`21.4669, 83.9812`)
3. **Verify Features Discovered & Edge Cases Tables**:
   Inspect Tables in Section 2 and Section 3 of `analysis.md` confirming all 13 discovered features and 10 edge cases are documented.
