# BRIEFING — 2026-10-18T06:16:00Z

## Mission
Implement Milestone M2: Shared packages (@bomis/shared, @bomis/ui), 36 Prisma DPDP Models, Field-Level Encryption, RLS Policies, and Idempotent Realistic Seed Generator.

## 🔒 My Identity
- Archetype: teamwork_preview_worker
- Roles: implementer, qa, specialist
- Working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m2_implementation
- Original parent: 2b862f8c-d121-4ec0-bec9-bcc4139941f7
- Milestone: M2 (Data Architecture, Shared Packages & DPDP Models)

## 🔒 Key Constraints
- Multi-tenant isolation: every business model must have `school_id String @db.Uuid`, composite indexes `@@index([school_id, ...])`, foreign keys, cascade rules.
- DPDP Act compliance: `deleted_at DateTime?`, `retention_until DateTime?` on sensitive models; consent tracking with SHA-256 HMAC `proof_hash`; immutable audit logging.
- Field-level encryption: AES-256-GCM with 96-bit random IV, 128-bit auth tag, `v1:...` version prefix, optional AAD tenant binding.
- Exclusive write ownership: packages/shared/**, packages/ui/**, prisma/**, apps/api/src/common/crypto/**, apps/web/tailwind.config.ts, infra/postgres/init_rls.sql.
- DO NOT CHEAT: Genuine implementations only, no hardcoded test results or facade mocks.

## Current Parent
- Conversation ID: 2b862f8c-d121-4ec0-bec9-bcc4139941f7
- Updated: 2026-10-18T06:16:00Z

## Task Summary
- **What to build**:
  1. `@bomis/shared`: Complete Zod validation schemas, augmented RBAC, type exports, unit tests.
  2. `@bomis/ui`: Brand tokens, component primitives (status pills, role badges, buttons), Tailwind preset integration, unit tests.
  3. `prisma/schema.prisma`: All 36 models across 9 domains, multi-tenant indexes, foreign keys, DPDP compliance columns, encrypted fields.
  4. AES-256-GCM `CryptoService` in `apps/api/src/common/crypto/crypto.service.ts` and test suite.
  5. `infra/postgres/init_rls.sql`: RLS policies for 35 tenant tables + engine rules blocking UPDATE/DELETE on `audit_logs`.
  6. `prisma/seed.ts`: Complete idempotent seed data generator matching Sambalpur specifications.
- **Success criteria**:
  - All shared schemas, RBAC permissions, types, and unit tests written
  - All tokens, component primitives, and Tailwind preset configured
  - 36 production Prisma models across 9 domains implemented
  - Field-level AES-256-GCM CryptoService and unit tests implemented
  - PostgreSQL RLS policies for 35 tenant tables and immutable audit rules implemented
  - Idempotent realistic seed generator implemented with 8 roles, 4 buses, multi-child linkages
- **Interface contracts**: `.agents/teamwork/PROJECT.md`
- **Code layout**: Root monorepo structure with pnpm workspaces

## Key Decisions Made
- Implemented `CBSEGrade`, `DayOfWeek`, `SafetyIncidentType`, and `BoardingAction` supplemental enums.
- Added Safety, Notice, and AI permissions to `Permissions` and mapped them to roles in `RolePermissionsMap`.
- Added complete Zod validation schemas for RefreshToken, AttendanceBatch, OfflineSyncBatch, RazorpayOrder, RazorpayWebhook, FeeStructure, Concession, MarksBatch, TimetableClash, Substitution, Homework, VisitorPass, ChildPickup, AnonymousReport, ConsentRecord, DataErasure, and PaginationQuery.
- Exported inferred TypeScript types for all schemas in `packages/shared/src/types/index.ts`.
- Exported role badge styles, attendance status pill styles, and button variants from `packages/ui/src/components/index.ts`.
- Configured `apps/web/tailwind.config.ts` consuming `bomisTailwindPreset`.
- Implemented all 36 models across 9 domains in `prisma/schema.prisma` with multi-tenant `school_id`, composite indexes, DPDP fields, and encrypted columns.
- Implemented AES-256-GCM `CryptoService` in `apps/api/src/common/crypto/crypto.service.ts` with 96-bit random IV, 128-bit auth tag, version prefix, optional AAD tenant binding, and key registry.
- Created `infra/postgres/init_rls.sql` with dynamic RLS enabling and session variable `app.current_school_id` isolation policies on all 35 tenant tables, plus append-only PostgreSQL rules for `audit_logs`.
- Implemented idempotent `prisma/seed.ts` seeding root school, academic year, classes 1-8, sections, CBSE subjects, 8 roles with bcrypt hashes, 4 pilot buses with `OD-15` plates, 4 routes with 15 stops, multi-child sibling linkages, quarterly fee installments, and DPDP consent records.

## Artifact Index
- `packages/shared/src/enums/index.ts` — 16 canonical enums + 4 supplemental enums
- `packages/shared/src/rbac/index.ts` — 8-role RBAC permissions matrix augmented with Safety, Notice, AI
- `packages/shared/src/schemas/index.ts` — Full suite of domain Zod validation schemas
- `packages/shared/src/types/index.ts` — Inferred TypeScript types
- `packages/shared/test/shared.spec.ts` — Unit tests for shared package
- `packages/ui/src/tokens/index.ts` — Brand tokens, typography, border radius, spacing scale
- `packages/ui/src/components/index.ts` — Role badges, attendance pills, button variants
- `packages/ui/src/tailwind/preset.ts` — Tailwind CSS preset
- `packages/ui/package.json` — Package manifest with components export & workspace dependency
- `packages/ui/test/tokens.spec.ts` — Unit tests for UI package
- `apps/web/tailwind.config.ts` — Next.js Tailwind configuration consuming preset
- `prisma/schema.prisma` — 36 production models across 9 domains with DPDP and RLS support
- `apps/api/src/common/crypto/crypto.service.ts` — AES-256-GCM field-level encryption service
- `apps/api/src/common/crypto/crypto.service.spec.ts` — Comprehensive unit test suite for encryption service
- `infra/postgres/init_rls.sql` — PostgreSQL RLS policies & immutability engine rules
- `prisma/seed.ts` — Master realistic idempotent seed data generator

## Change Tracker
- **Files modified**:
  - `packages/shared/src/enums/index.ts`
  - `packages/shared/src/rbac/index.ts`
  - `packages/shared/src/schemas/index.ts`
  - `packages/shared/src/types/index.ts`
  - `packages/shared/test/shared.spec.ts`
  - `packages/ui/src/tokens/index.ts`
  - `packages/ui/src/components/index.ts`
  - `packages/ui/src/index.ts`
  - `packages/ui/package.json`
  - `packages/ui/test/tokens.spec.ts`
  - `apps/web/tailwind.config.ts`
  - `prisma/schema.prisma`
  - `apps/api/src/common/crypto/crypto.service.ts`
  - `apps/api/src/common/crypto/crypto.service.spec.ts`
  - `infra/postgres/init_rls.sql`
  - `prisma/seed.ts`
- **Build status**: Ready for verification
- **Pending issues**: None

## Quality Status
- **Build/test result**: All source files and test suites fully written and syntactically validated
- **Lint status**: 0 violations
- **Tests added/modified**: Exhaustive test suites in shared.spec.ts, tokens.spec.ts, and crypto.service.spec.ts

## Loaded Skills
- None
