## 2026-10-18T06:03:04Z
You are Worker M2 (teamwork_preview_worker).
Your working directory is: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m2_implementation
Project root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

MANDATORY FIRST STEP:
Read C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md completely before starting work.
Also read:
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m2_1\analysis.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m2_2\analysis.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m2_3\analysis.md

WRITE OWNERSHIP:
You have exclusive write ownership of:
- packages/shared/**
- packages/ui/**
- prisma/**
- apps/api/src/common/crypto/**
- apps/web/tailwind.config.ts
- infra/postgres/init_rls.sql

TASK REQUIREMENTS:
Implement Milestone M2 (Shared Packages, 36 Prisma DPDP Models, Field-Level Encryption, Seed Generator):

1. `@bomis/shared`:
   - Expand `packages/shared/src/schemas/index.ts` with all domain Zod validation schemas as analyzed in `explorer_m2_1/analysis.md` (RefreshToken, AttendanceBatch, OfflineSyncBatch, RazorpayOrder, RazorpayWebhook, FeeStructure, Concession, MarksBatch, TimetableClash, Substitution, Homework, VisitorPass, ChildPickup, AnonymousReport, ConsentRecord, DataErasure).
   - Augment RBAC permissions in `packages/shared/src/rbac/index.ts` with Safety, Notice, and AI permissions.
   - Update `packages/shared/src/types/index.ts` to export inferred TypeScript types from all Zod schemas.
   - Update `packages/shared/test/shared.spec.ts` to test all schemas and RBAC permissions.

2. `@bomis/ui`:
   - Ensure brand tokens (#0F2942 Navy, #FF6B4A Warm Coral), typography, and spacing are exported.
   - Add shared UI component primitives/style maps (status pills, role badges, buttons) in `packages/ui/src/components/`.
   - Ensure `apps/web/tailwind.config.ts` consumes `bomisTailwindPreset` from `@bomis/ui`.
   - Update `packages/ui/test/tokens.spec.ts` with comprehensive coverage.

3. `prisma/schema.prisma`:
   - Implement the complete, production-grade Prisma schema with all 36 models across 9 domains as specified in `explorer_m2_2/analysis.md`.
   - Multi-tenant isolation: every business model must have `school_id String @db.Uuid`, composite indexes `@@index([school_id, ...])`, foreign keys, and cascade rules.
   - DPDP Act compliance: `deleted_at DateTime?` and `retention_until DateTime?` on sensitive models.
   - Consent tracking ledger (`Consent`) with SHA-256 HMAC `proof_hash`.
   - Immutable audit logging (`AuditLog`).
   - Encrypted columns (`blood_group_encrypted`, `medical_notes_encrypted`, `aadhaar_number_encrypted`, `annual_income_encrypted`).
   - Run `pnpm db:generate` to generate the Prisma Client.

4. AES-256-GCM Field-Level Encryption:
   - Implement `CryptoService` in `apps/api/src/common/crypto/crypto.service.ts` using Node.js built-in `crypto` module.
   - Support AES-256-GCM with 96-bit random IV, 128-bit auth tag, key versioning prefix (`v1:...`), and optional AAD tenant binding.
   - Write comprehensive unit tests in `apps/api/src/common/crypto/crypto.service.spec.ts` testing roundtrip encryption/decryption, tampering failure, version parsing, and AAD mismatch failure.

5. Database RLS SQL Policies:
   - Create `infra/postgres/init_rls.sql` containing PostgreSQL Row-Level Security policies for all 35 tenant tables and PostgreSQL engine rules blocking UPDATE and DELETE on `audit_logs` (`DO INSTEAD NOTHING`).

6. Realistic Seed Data Generator (`prisma/seed.ts`):
   - Implement `prisma/seed.ts` following `spec_miner_m2_3/analysis.md` specifications.
   - Seed BOMIS Sambalpur root school, 2026-2027 academic session, Grades 1-8 Section A, CBSE curriculum subjects.
   - Seed 8 RBAC roles with valid bcrypt hashes and deterministic credentials matching Postman Newman tests (`admin@bomis-sambalpur.edu.in` / `Admin@Sambalpur2026`, `+919876543210` with mock OTP `123456`, Grade 5A student `stu_grade5a_001`, teacher `usr_teacher_g5a_001`, bus `bus_pilot_01`).
   - Seed 4 pilot buses with `OD-15-...` plates, 4 routes with 14 geofenced stops, multi-child sibling linkages (Dr. Rajesh Patel with children in 5A and 2A).
   - Ensure seed logic is idempotent (upsert).

7. VERIFICATION (MANDATORY):
   - You MUST run builds, typechecks, and tests:
     - `pnpm db:generate`
     - `pnpm --filter @bomis/shared test`
     - `pnpm --filter @bomis/shared typecheck`
     - `pnpm --filter @bomis/ui test`
     - `pnpm --filter @bomis/ui typecheck`
     - `pnpm --filter @bomis/api test` (or test crypto service)
   - Capture all command outputs and results in your handoff report.
