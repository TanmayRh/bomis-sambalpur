## 2026-10-18T07:13:38Z
You are Worker M3 for the BOMIS Sambalpur Unified School Platform.

Your Working Directory:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m3_impl

Project Root:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur

Dispatch Details:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m3_impl\DISPATCH.md

Mandatory Authoritative Sources to Read FIRST:
1. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md (MANDATORY)
2. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
3. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen3\SYNTHESIS_M3.md
4. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m3_1\analysis.md
5. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_1\analysis.md
6. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_2\analysis.md
7. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\DEAD_ENDS.md
8. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md
9. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\docs\postman\bomis_postman_collection.json
10. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\packages\shared
11. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\prisma\schema.prisma
12. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\prisma\seed.ts

Exclusive Write Ownership:
You have exclusive write ownership of:
- `apps/api/src/**/*`
- `apps/api/package.json`
- `apps/api/tsconfig.json`
- `apps/api/test/**/*`
Do NOT modify any files in `packages/shared`, `packages/ui`, `infra/`, `prisma/`, or `docs/`.

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Your Mission:
Implement the complete, production-grade NestJS 10 Modular Monolith API in `/apps/api`:
1. Application Plumbing:
   - Global Prefix: `app.setGlobalPrefix('api/v1', { exclude: ['health', 'ready'] })` in `apps/api/src/main.ts`.
   - Global `TransformInterceptor`: Wraps successful responses into `{ success: true, data, error: null, timestamp, correlationId }`. Echos `x-correlation-id` response header. Bypasses raw streams (PDFs, CSVs).
   - Global `HttpExceptionFilter`: Formats all exceptions (ZodError, HttpException, Prisma errors) into `{ success: false, data: null, error: { code, message, details }, timestamp, correlationId }`.
   - `CorrelationIdMiddleware` with AsyncLocalStorage to propagate `x-correlation-id`.
   - Global `ZodValidationPipe` integrating schemas from `@bomis/shared`.
   - Swagger OpenAPI at `/api/docs` with Bearer auth configuration.
   - Terminus `/health` (liveness) and `/ready` (readiness) probes.
2. Core Infrastructure & Data Layer:
   - `PrismaService` & Database Module: Dual-layer tenant isolation (Prisma extension `where: { school_id }` + PostgreSQL RLS transaction `SET LOCAL app.current_school_id = $schoolId`).
   - Tenant Slug Normalization: Automatic mapping of `"sch_bomis_sambalpur_001"` to `SEED_IDS.SCHOOL` (`e4b3c2a1-0001-4000-8000-000000000001`).
   - DPDP Soft-Delete Extension for 18 models (`deleted_at: now`, `retention_until: now + 90 days`, queries enforce `deleted_at: null`).
   - `CryptoService` Integration: AES-256-GCM encryption with `tenant:${schoolId}` AAD for 8 encrypted PII columns.
   - In-Memory Mock Fallback: Connection probe (1500ms) with automatic fallback to memory store seeded from `SEED_IDS` deterministic fixtures for reliable offline test/build execution.
3. Auth & RBAC Module:
   - Dual Authentication: Mobile OTP (mock `123456`, 300s TTL, accepting both `code` and `otp`) for Parents & Students; Email + Password (`Admin@Sambalpur2026`) for Staff.
   - JWT Access Token (15m) + rotating Refresh Token (7d) with token family tracking.
   - `@Roles(...)` decorator and `RolesGuard` strictly enforcing the 8 canonical roles in `@bomis/shared` and throwing HTTP 403 `INSUFFICIENT_PERMISSIONS` on unauthorized access.
   - Supporting `@Public()` and `@CurrentUser()` decorators.
4. Domain Modules (8 modules matching Postman collection):
   - `people`: Student/Staff profiles, multi-child sibling linkage under guardian (`/api/v1/people/guardians/siblings`), bulk CSV streaming.
   - `attendance`: Rapid classroom mark (<10s), offline `/api/v1/sync/batch` queue, absence FCM push notification trigger, attendance percentage formula `((present + 0.5 * halfDay) / workingDays) * 100`.
   - `fees`: Fee structures catalog, Razorpay orders with distributed `Idempotency-Key` lock/cache, HMAC-SHA256 webhook signature verification (`RAZORPAY_WEBHOOK_SECRET`), BullMQ/mock PDF receipt generator.
   - `academics`: CBSE 9-point scale grading logic (A1 [91-100] to E [0-32]), timetable clash matrix detector, 1-click teacher substitution.
   - `transport`: 4 pilot buses (`OD-15`), GPS ping telematics, Socket.IO gateway, QR boarding/deboarding logging.
   - `safety`: Gate visitor pass QR, child pickup OTP verification, anonymous anti-bullying reporting with zero user logging.
   - `ai`: Grade-appropriate curriculum study buddy mock assistant, teacher report card remarks generator with mandatory human review.
   - `pulse`: Principal Pulse live metrics dashboard aggregation API.
5. Unit & Integration Tests:
   - Create comprehensive unit test suites in `apps/api/src/**/*.spec.ts` covering plumbing, auth, RBAC guards, fee idempotency, CBSE grading, timetable clash checks, and attendance percentages.
   - Verify build: Run `tsc -p tsconfig.json` and unit tests `pnpm --filter @bomis/api test`.
