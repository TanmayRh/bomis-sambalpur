# Test Infrastructure & Quality Assurance Architecture (TEST_INFRA)
# Birla Open Minds International School (BOMIS), Sambalpur

**Document Version**: 1.0.0  
**Status**: APPROVED & ACTIVE  
**Last Updated**: 2026-10-17  
**Target Repository**: `bomis_sambalpur`  
**Test Working Directory**: `.agents/teamwork/test_writer_e2e_1` & `docs/postman/`

---

## 1. Executive Overview & Testing Philosophy

The Birla Open Minds International School (BOMIS), Sambalpur platform is a mission-critical, enterprise school operating system managing sensitive personal student data, regulatory academic workflows under the CBSE framework, real-time bus telemetry, and financial fee collections under Indian banking and DPDP Act (2023) regulations.

### Core Testing Mandates:
1. **Zero-Tolerance Financial Safety**: Every payment transaction must enforce distributed idempotency (`Idempotency-Key`), tamper-evident cryptographic webhook verification (HMAC-SHA256), and immutable audit logging.
2. **Deterministic Role-Based Security**: Complete RBAC isolation across 8 distinct roles (`SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `TEACHER`, `ACCOUNTANT`, `STUDENT`, `PARENT`, `TRANSPORT_STAFF`), ensuring zero cross-tenant or unauthorized data exposure.
3. **Rigorous Contract Synchronization**: 100% type and schema congruence between backend DTOs, database models, frontend web forms, mobile screens, and Postman API contracts via `@bomis/shared`.
4. **Standardized API Envelope Enforcement**: Every REST response without exception conforms to `{ success: boolean, data: T | null, error?: ApiError | null, timestamp: string, correlationId: string }`.
5. **High Coverage on Core Business Logic**: Minimum 70% branch and statement coverage for fee calculations, CBSE 9-point grading conversions, timetable clash matrices, and rapid attendance percentage calculations.

---

## 2. 5-Tier Testing Pyramid Strategy

```
                   ▲
                  / \
                 / T5\         Tier 5: Adversarial Hardening & Regulatory Stress
                /-----\        Replay attacks, data exfiltration, DPDP shredding
               /       \
              /   T4    \      Tier 4: Real-World E2E Scenarios (Playwright / Newman)
             /-----------\     Multi-role end-to-end user journeys
            /             \
           /      T3       \   Tier 3: Cross-Feature Pairwise & Integration Tests
          /-----------------\  DB + Redis + BullMQ workers + WebSocket workflows
         /                   \
        /         T2          \ Tier 2: Boundary, Edge Case & Negative RBAC Matrix
       /-----------------------\ 403 checks, concurrency, idempotency replay
      /                         \
     /            T1             \ Tier 1: Feature Unit Tests & Mathematical Engines
    /                             \ Fee math, CBSE grading, clash detection, Zod validation
   /───────────────────────────────\
```

### 2.1 Tier 1: Feature Unit Tests & Pure Logic Engines
- **Target**: Pure deterministic functions, mathematical calculators, CBSE grading scales, timetable scheduling constraints, and shared validation schemas in `/packages/shared`.
- **Framework**: Vitest / Jest.
- **Coverage Areas**:
  - `fee-calculator.spec.ts`: Base tuition calculation (Grades 1–8), distance-slab transport fee (0–5km, 5–10km, 10–15km), sibling concessions (10% on second child, 15% on third child), late fine accruals (₹50/day post-10th).
  - `cbse-grading.spec.ts`: Scholastic 9-point scale (`A1` [91-100], `A2` [81-90], `B1` [71-80], `B2` [61-70], `C1` [51-60], `C2` [41-50], `D` [33-40], `E` [0-32]), co-scholastic 3-point scale (`A`, `B`, `C`), Term 1/2 weighted aggregations.
  - `timetable-clash.spec.ts`: Matrix conflict verification (teacher double-booking, room overlap, max consecutive period constraints).
  - `attendance-stats.spec.ts`: Attendance percentage formula `((Present + 0.5 * HalfDay) / WorkingDays) * 100`, low-attendance alert triggers (< 75%).
  - `zod-schemas.spec.ts`: Validation assertion on all 20+ request/response schemas.

### 2.2 Tier 2: Boundary, Edge Case & Negative Tests
- **Target**: Input boundaries, security gates, exception handling filters, and RBAC matrix.
- **Coverage Areas**:
  - `financial-idempotency.spec.ts`: Duplicate `Idempotency-Key` reuse with identical payload returns cached response; different payload with same key returns `409 Conflict`; missing header returns `400 Bad Request`.
  - `rbac-negative-matrix.spec.ts`: 8 roles tested against 15+ restricted endpoints ensuring explicit `403 Forbidden` responses for unauthorized roles.
  - `tenant-isolation-rls.spec.ts`: Parent A querying Student B ID returns `404 Not Found` or `403 Forbidden`; tenant ID spoofing in headers is discarded.
  - `input-boundary.spec.ts`: Phone numbers exceeding 10 digits or non-numeric characters, future attendance marking, oversized file attachments (> 10MB).

### 2.3 Tier 3: Cross-Feature Pairwise & Integration Tests
- **Target**: Inter-module service interactions, PostgreSQL RLS transactions, Redis cache invalidation, and BullMQ background queues.
- **Coverage Areas**:
  - `auth-session-revocation.spec.ts`: Login -> Token issuance -> API call succeeds -> Logout -> Token invalidated in Redis -> Immediate reuse rejected with `401 Unauthorized`.
  - `absence-to-substitution-workflow.spec.ts`: Teacher marks leave -> Principal approves -> Timetable engine detects orphaned periods -> Suggests free substitute -> Substitution confirmed -> Teacher push alert queued in BullMQ.
  - `fee-concession-to-payment-workflow.spec.ts`: Concession submitted -> Accountant verified -> Principal approved -> Due installment amount re-evaluated -> Parent initiates payment -> Razorpay webhook captures event -> Digital receipt generated.
  - `transport-gps-to-geofence-alert.spec.ts`: Driver emits bus coordinates -> Haversine distance drops below 1.5km -> 5-minute proximity push notification emitted to parents.

### 2.4 Tier 4: Real-World E2E Scenarios
- **Target**: Multi-step holistic workflows spanning client and server interfaces.
- **Coverage Areas**:
  - **Scenario 1**: Teacher Rapid Attendance Grid (<10s classroom recording).
  - **Scenario 2**: Principal Real-Time Pulse Dashboard & One-Click Substitute Assignment.
  - **Scenario 3**: Parent Multi-Child Sibling Switch & Online Razorpay Fee Payment.
  - **Scenario 4**: Driver Morning Route Run, Continuous Student QR Boarding Scan, and Fleet GPS Broadcast for 4 Pilot Buses.

### 2.5 Tier 5: Adversarial Hardening & Compliance Verification
- **Target**: Resiliency under deliberate misuse, rate exhaustion, and regulatory auditing.
- **Coverage Areas**:
  - `otp-flood-defense.spec.ts`: Exceeding 5 OTP requests per 15 minutes triggers `429 Too Many Requests`.
  - `webhook-replay-defense.spec.ts`: Tampered or replayed Razorpay webhooks with expired timestamps or forged HMAC signatures are dropped.
  - `dpdp-shredding-audit.spec.ts`: Verifies soft-deleted records older than 90 days undergo cryptographic erasure and cannot be retrieved.

---

## 3. Postman Newman Test Automation Architecture

The platform provides a production-grade, headless Postman test suite located at `/docs/postman/` executed through Node.js via Newman.

### 3.1 Directory Structure
```
docs/postman/
├── bomis_postman_collection.json    # Complete v2.1 collection covering all 8 roles & domains
├── bomis_postman_environment.json   # Configurable environment variables (dev, ci, staging)
├── run-newman.js                   # Node.js runner script with CLI flags and custom reporting
└── README.md                       # Comprehensive runner guide and troubleshooting docs
```

### 3.2 Pre-Request Script Automation Architecture
All collection requests run automated pre-request scripts:
1. **Correlation ID Generation**:
   ```javascript
   var correlationId = 'corr-' + pm.variables.replaceIn('{{$guid}}');
   pm.variables.set('correlationId', correlationId);
   pm.request.headers.upsert({ key: 'x-correlation-id', value: correlationId });
   ```
2. **Financial Idempotency Injection**:
   ```javascript
   if (['POST', 'PUT', 'PATCH'].includes(pm.request.method) && 
       (pm.request.url.getPath().includes('orders') || pm.request.url.getPath().includes('payments') || pm.request.url.getPath().includes('sync'))) {
       var idempotencyKey = 'idemp-' + pm.variables.replaceIn('{{$guid}}');
       pm.variables.set('idempotencyKey', idempotencyKey);
       pm.request.headers.upsert({ key: 'Idempotency-Key', value: idempotencyKey });
   }
   ```
3. **Dynamic Bearer Token Resolution**:
   Pre-request scripts dynamically inject the appropriate role token based on folder context (`adminToken`, `teacherToken`, `parentToken`, `accountantToken`, `principalToken`, `driverToken`, `studentToken`).

### 3.3 Global Response Test Scripts & Envelope Assertions
Every endpoint in the collection executes strict assertions against the BOMIS Standard Response Envelope:
```javascript
pm.test("Status code is valid", function () {
    pm.expect(pm.response.code).to.be.oneOf([200, 201, 202, 204, 400, 401, 403, 404, 409]);
});

pm.test("Standard Response Envelope Format is strictly valid", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData).to.be.an('object');
    pm.expect(jsonData).to.have.property('success');
    pm.expect(jsonData.success).to.be.a('boolean');
    pm.expect(jsonData).to.have.property('timestamp');
    pm.expect(jsonData).to.have.property('correlationId');
    
    // Validate correlationId matches request header
    var reqCorrId = pm.variables.get('correlationId');
    if (reqCorrId) {
        pm.expect(jsonData.correlationId).to.eql(reqCorrId);
    }

    if (jsonData.success === true) {
        pm.expect(jsonData).to.have.property('data');
    } else {
        pm.expect(jsonData).to.have.property('error');
        pm.expect(jsonData.error).to.be.an('object');
        pm.expect(jsonData.error).to.have.property('code');
        pm.expect(jsonData.error).to.have.property('message');
    }
});

pm.test("Response time is within acceptable SLA (< 1000ms)", function () {
    pm.expect(pm.response.responseTime).to.be.below(1000);
});
```

### 3.4 Domain Endpoints & Role Coverage Breakdown

| Folder / Domain | Target Endpoints | Roles Exercised | Assertions Verified |
|---|---|---|---|
| **00_Health_Probes** | `GET /health`, `GET /ready` | Public | Liveness, PostgreSQL & Redis connectivity, envelope schema. |
| **01_Authentication** | `/api/v1/auth/otp/send`, `/api/v1/auth/otp/verify`, `/api/v1/auth/staff/login`, `/api/v1/auth/refresh`, `/api/v1/auth/logout` | Parent, Staff, Admin | OTP dispatch, token issuance, refresh rotation, session revocation. |
| **02_People_Management** | `/api/v1/people/students`, `/api/v1/people/students/:id`, `/api/v1/people/guardians/siblings`, `/api/v1/people/staff` | Admin, Parent, Principal | Pagination, multi-child sibling linkage, DPDP sanitization. |
| **03_Attendance_Sync** | `/api/v1/attendance`, `/api/v1/attendance/batch`, `/api/v1/sync/batch`, `/api/v1/attendance/leaves` | Teacher, Admin, Mobile Outbox | <10s rapid batch, offline outbox idempotency, conflict resolution. |
| **04_Fees_Finance** | `/api/v1/fees/structures`, `/api/v1/fees/orders`, `/api/v1/fees/webhook`, `/api/v1/fees/receipts/:id`, `/api/v1/fees/concessions` | Accountant, Parent, Admin | Installment math, Razorpay order creation, signature verification, PDF receipt. |
| **05_Academics_CBSE** | `/api/v1/academics/terms`, `/api/v1/academics/marks/batch`, `/api/v1/academics/timetable/clash-check`, `/api/v1/academics/substitutions` | Teacher, Principal, Admin | CBSE 9-point scale grading, timetable conflict matrix, teacher substitution. |
| **06_Transport_Fleet** | `/api/v1/transport/routes`, `/api/v1/transport/buses`, `/api/v1/transport/boarding/scan`, `/api/v1/transport/gps-ping` | Transport Staff, Parent | 4 pilot buses, continuous boarding QR scans, GPS telemetry ping. |
| **07_Safety_AI** | `/api/v1/safety/visitors`, `/api/v1/safety/pickup/verify`, `/api/v1/safety/incidents/anonymous`, `/api/v1/ai/study-buddy/chat` | Gatekeeper, Parent, Student, Teacher | Visitor QR pass, OTP pickup verification, zero-log anti-bullying report. |
| **08_RBAC_Negative_Gates** | Cross-role restricted calls | Parent, Student, Driver, Teacher | Verifies explicit 403 Forbidden on unauthorized domain endpoints. |

---

## 4. Test Environment & Fixture Management

### 4.1 Backing Infrastructure Containers
The local and CI test environments rely on the unified `infra/docker-compose.yml`:
- **PostgreSQL 16**: Port `5432`, Multi-tenant schema with Row-Level Security enabled.
- **Redis 7**: Port `6379`, Session tokens, rate limiter cache, BullMQ job queues, distributed locks.
- **MinIO**: Ports `9000` / `9001`, S3-compatible bucket storage (`school-receipts`, `school-homework`, `report-cards`).
- **Mailpit**: Ports `1025` / `8025`, Local SMTP catch-all server for OTP and notification inspection.

### 4.2 Seed Data Determinism
The Prisma seed script (`prisma/seed.ts`) establishes realistic test fixtures:
- **Academic Setup**: Academic Year 2026–27, Terms 1 & 2.
- **Classes & Sections**: Grades 1 through 8, Section A (30 students per section, total 240 students).
- **Users & Credentials**:
  - 1 Super Admin (`superadmin@bomis-sambalpur.edu.in`)
  - 2 Admins (`admin@bomis-sambalpur.edu.in`)
  - 1 Principal (`principal@bomis-sambalpur.edu.in`)
  - 2 Accountants (`accounts@bomis-sambalpur.edu.in`)
  - 12 Teachers (`teacher.g1a@bomis-sambalpur.edu.in` ... `teacher.g8a@...`)
  - 4 Transport Staff / Drivers (`driver.bus1@...` ... `driver.bus4@...`)
  - Seeded Parents with multi-child sibling relationships (e.g., Parent with child in Grade 2 and child in Grade 5).
- **Fleet Setup**: 4 Pilot Buses:
  - Bus 1 (Mini-bus 24-seater, Khetrajpur Route)
  - Bus 2 (Mini-bus 24-seater, Dhanupali Route)
  - Bus 3 (Mini-bus 24-seater, Burla Route)
  - Bus 4 (Full-size 52-seater, Remed / Arterial Route)

---

## 5. Execution Commands & CI/CD Pipeline Integration

### 5.1 Test Execution Matrix

| Action | Command | Purpose |
|---|---|---|
| **Unit & Calculation Tests** | `pnpm --filter @bomis/shared test` | Run Tier 1 mathematical, CBSE grading, and Zod tests |
| **API Integration Tests** | `pnpm --filter @bomis/api test:e2e` | Run Tier 2 & 3 NestJS integration and RBAC gate tests |
| **Postman Headless Run** | `node docs/postman/run-newman.js` | Run full automated collection with standard CLI reporter |
| **Postman JSON Report Run** | `node docs/postman/run-newman.js --reporter=json` | Output test execution summary to `docs/postman/newman-report.json` |
| **Targeted Domain Run** | `node docs/postman/run-newman.js --folder="04_Fees_Finance"` | Execute only the Fees & Payment verification suite |
| **Coverage Threshold Check** | `pnpm test:coverage` | Enforce `>= 70%` branch and line coverage threshold |

### 5.2 GitHub Actions CI Quality Gate
```yaml
name: Continuous Integration & Test Verification

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

jobs:
  verify:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_DB: bomis_test
          POSTGRES_USER: bomis_app
          POSTGRES_PASSWORD: bomis_secure_password
        ports: [5432:5432]
      redis:
        image: redis:7-alpine
        ports: [6379:6379]

    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v3
        with:
          version: 9
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'pnpm'

      - name: Install Dependencies
        run: pnpm install --frozen-lockfile

      - name: Typecheck Workspaces
        run: pnpm typecheck

      - name: Run Database Migrations & Seed
        run: |
          pnpm db:migrate
          pnpm db:seed

      - name: Execute Tier 1 Unit & Schema Tests
        run: pnpm test:unit

      - name: Start API Monolith in Background
        run: pnpm --filter @bomis/api start:dev &
        env:
          PORT: 4000
          NODE_ENV: test

      - name: Wait for API Readiness Probe
        run: npx wait-on http://localhost:4000/ready -t 30000

      - name: Execute Postman Newman Automated Suite
        run: node docs/postman/run-newman.js --baseUrl=http://localhost:4000
```

---

## 6. Audit & Acceptance Criteria Traceability

| Acceptance Criteria | Verified By | Test Harness File | Passing Condition |
|---|---|---|---|
| **AC-1: Type & Schema Synchronization** | Vitest + TypeScript Compiler | `packages/shared/test/schemas.spec.ts` | 100% type congruence; zero schema divergence. |
| **AC-2: Standardized Response Envelope** | Newman Global Test Assertions | `docs/postman/bomis_postman_collection.json` | 100% of responses contain `{ success, data, timestamp, correlationId }`. |
| **AC-3: Idempotency & Financial Safety** | Postman & Supertest Integration | `04_Fees_Finance` / `payments.spec.ts` | Zero duplicate orders; Redis lock verifies `Idempotency-Key`. |
| **AC-4: Test Coverage (>= 70%)** | Vitest Coverage Reporter | `pnpm test:coverage` | Branches >= 70%, Lines >= 70% in domain modules. |
| **AC-5: Postman & Newman CI Automation** | Newman CLI & CI Workflow | `docs/postman/run-newman.js` | All tests pass cleanly with exit code 0. |
| **AC-6: One-Command Bootstrapping** | Automated Bootstrap Harness | `infra/docker-compose.yml` & seed | Clean system start with 8 grades and 4 pilot buses. |

---

*Authored by E2E Test Suite & Postman Newman Architect for BOMIS Sambalpur Unified School Platform.*
