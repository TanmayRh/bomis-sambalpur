# Empirical Analysis: Frontend Test Suites, Tier 4 Real-World Verification, and Tier 5 Adversarial Attack Surfaces

**Author**: `explorer_m6_3`  
**Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m6_3`  
**Timestamp**: 2026-10-22T10:15:00Z  
**Target Repository**: `bomis_sambalpur` (Turborepo + pnpm monorepo)  
**Authoritative References**: `ORIGINAL_REQUEST.md`, `PROJECT.md`, `TEST_INFRA.md`

---

## 1. Executive Summary

This investigation performed an exhaustive, read-only architectural and empirical audit of the frontend test suites in `apps/web` and `apps/mobile`, evaluated test coverage for all **8 Tier 4 Real-World Application Scenarios**, and conducted a monorepo-wide defensive vulnerability assessment to map out **Tier 5 Adversarial Attack Surfaces** for Phase 2 hardening.

### Core Audit Takeaways:
1. **Frontend Spec Integrity**:
   - `apps/web`: Features a high-quality empirical challenge suite (`m4-challenger.spec.ts`, `m4-remediation.spec.ts`, `academic-financial.challenge.spec.ts`, `utils.spec.ts`) validating 17 telemetry, dismissal OTP, sibling isolation, and edge middleware assertions, alongside 20 CBSE 9-point boundary test cases and rapid attendance benchmarks (<10s SLA).
   - `apps/mobile`: Features a comprehensive 8-suite test harness (`mobile.spec.ts`) validating the 3-tier adaptive storage engine, durable offline outbox queue with `idem_<action>_<uuid>` keys, reconnect batch replay to `/api/v1/sync/batch`, sibling isolation (Aarav vs Ananya Patel), 30-minute dismissal OTP countdown & dynamic QR payloads, and 1.5km Haversine geofence proximity alerts along Sambalpur Route 1.
2. **Tier 4 Workload Coverage**:
   - High coverage exists across core business logic (Teacher Rapid Attendance, Parent Multi-Child Switching, Razorpay Checkout Idempotency, Bus GPS Telemetry & 1.5km Geofence Alert).
   - Gaps identified: Frontend UI integration testing is thinner on the **Admin Dashboard** (CSV malformed row error boundaries, audit log diff viewers) and **Accountant Dashboard** (fee structure editing and concession approval state machines), although both are covered at the API controller and Postman Newman layers.
3. **Tier 5 Adversarial Attack Surfaces**:
   - Identified **9 distinct adversarial attack surfaces** across authentication, session rotation, RBAC edge boundaries, IDOR data exfiltration, payment webhook replays, GPS telemetry spoofing, pickup OTP brute forcing, and DPDP 90-day retention shredding.

---

## 2. Frontend Test Suite Architecture & Detailed Inspection

### 2.1 Web Portal Test Suites (`apps/web`)

| File Path | Primary Function / Scope | Key Assertions / Harnesses |
|---|---|---|
| `apps/web/src/tests/m4-challenger.spec.ts` | Empirical challenge suite for M4 Web Portal | 17 empirical tests across 4 categories: `TELEMETRY` (4 tests), `DISMISSAL_OTP` (4 tests), `MULTI_CHILD_STATE` (4 tests), `EDGE_MIDDLEWARE` (5 tests). |
| `apps/web/src/tests/m4-remediation.spec.ts` | Master remediation runner & aggregator | `runMasterRemediationVerification()` aggregating smoke tests, academic/financial challenges, and security/state assertions into a structured `MasterRemediationReport`. |
| `apps/web/src/lib/academic-financial.challenge.spec.ts` | Mathematical and SLA empirical benchmark | - `runCbseGradingChallenge()`: 20 boundary mark test cases across A1 (91-100) down to E (0-32), plus clamped upper bound (>100 -> A1/10.0) and clamped lower bound (<0 -> E/0.0).<br>- `runRapidAttendanceSlaChallenge()`: 40-student roster benchmark (`INITIAL_ROSTER_5A`), Mark All Present + 3 exception cycles + delta payload creation enforcing `< 10,000ms` SLA.<br>- `runFeeCheckoutIdempotencyChallenge()`: Verifies RFC-4122 v4 UUID format for `Idempotency-Key` and double-click in-flight guard. |
| `apps/web/src/lib/utils.spec.ts` | Utility & helper smoke tests | Tailwind `cn()` merge logic, `formatCurrency(45000)` formatting, and sanity checks on CBSE grade calculations for 95 (A1/10.0) and 45 (C2/5.0). |

#### Detailed Verification of `m4-challenger.spec.ts`:
- **`TEL-01`**: Asserts all 4 pilot fleet registration plates match `['OD-15-AB-1001', 'OD-15-AB-1002', 'OD-15-AC-2001', 'OD-15-AC-2002']`.
- **`TEL-02`**: Asserts all `PILOT_BUSES` have valid numeric `lat` and `lng` coordinates.
- **`TEL-03`**: Tests speed threshold alert logic for speeds `> 50 km/h` (e.g., speed 62 km/h triggers warning badge).
- **`TEL-04`**: Verifies 30-second TanStack `refetchInterval` polling cadence and offline fallback to `PILOT_BUSES`.
- **`OTP-01`**: Verifies 6-digit numeric OTP regex (`^\d{6}$`).
- **`OTP-02`**: Verifies 30-minute initial countdown timer duration (`1800` seconds).
- **`OTP-03`**: Verifies timer cutoff at `00:00`, transitioning status to `EXPIRED` and masking the OTP code.
- **`OTP-04`**: Verifies single-use invalidation mechanics upon gatekeeper verification (`USED` state).
- **`STATE-01`**: Tests `authStore.setActiveChildId()` reactive state toggling between Aarav (Grade 5) and Ananya (Grade 2).
- **`STATE-02`**: Verifies component remounting via `key={`fee-${activeChild.id}`}` prevents fee payment state bleeding between siblings.
- **`STATE-03`**: Verifies dismissal OTP tokens remain isolated between siblings.
- **`STATE-04`**: Verifies child-specific attendance stats and bus routes.
- **`EDGE-01` to `EDGE-05`**: Tests Next.js edge route permissions (`PARENT` blocked from `/admin` & `/accountant`, `TEACHER` blocked from `/accountant`, `PRINCIPAL` allowed to `/principal`, and fail-closed check for undefined role cookies).

### 2.2 Mobile Application Test Suites (`apps/mobile`)

The mobile test suite is consolidated in `apps/mobile/src/__tests__/mobile.spec.ts`, exercising core offline-first engines and user journeys:

| Suite Section | Target Service / Component | Empirical Coverage |
|---|---|---|
| **1. 3-Tier Adaptive Storage Engine** | `MemoryStorageAdapter`, `WebLocalStorageAdapter`, `createStorageAdapter()` | Verifies `setItem`, `getItem`, `removeItem`, `multiGet`, `multiSet`, `clear`, and `getAllKeys` across web and headless environments. |
| **2. Offline Outbox Queue & Idempotency** | `OutboxRepository` (`outbox-queue.ts`) | Verifies mutation enqueuing with client UUID (`evt_<timestamp>_<rand>`), idempotency key format `idem_<actionType>_<id>`, status lifecycle `PENDING -> SYNCING -> SYNCED / FAILED`, retry count incrementing, and 24h completed record purging. |
| **3. Offline Sync Manager & Reconnect Replay** | `SyncManager` & `NetworkMonitor` (`sync-manager.ts`) | Verifies that network disconnect buffers mutations locally in outbox, and reconnect immediately triggers `syncPending()` batch POST to `/api/v1/sync/batch`. |
| **4. Multi-Child Sibling State Isolation** | `SEED_PERSONAS.PARENT.children` | Asserts distinct identities for Aarav (Grade 5, Roll 1, BOMIS-2021-0042, O+) vs Ananya (Grade 2, Roll 4, BOMIS-2024-0118, B+), with independent fee statuses (Aarav ₹16,500 DUE vs Ananya ₹14,000 PAID) and attendance percentages (90.9% vs 95.5%). |
| **5. 30-Minute Dismissal OTP & Dynamic QR** | `ParentScreen.tsx` dismissal logic | Asserts 6-digit numeric OTP, 1800s expiry window, expiration at T=0, and dynamic QR payload format `BOMIS:PICKUP:<studentId>:<otp>`. |
| **6. Rapid Attendance Delta Calculation (<10s SLA)** | `TeacherScreen.tsx` roster calculation | Asserts 40-student roster produces 0 exceptions on full present, and accurately extracts delta array when exceptions are flagged (Roll 2 Absent, Roll 6 Late, Roll 13 Half Day). |
| **7. GPS Haversine Distance & 1.5km Geofence Alert** | `calculateHaversineDistanceKm`, `ROUTE_1_BUDHARAJA_WAYPOINTS` | Calculates distance between Budharaja Fatak (21.4825, 83.9782) and Sakhipada Chhak (21.4669, 83.9812) (~1.76km), and triggers proximity geofence alert when vehicle coordinate is `<= 1.5km`. |
| **8. Seed Persona Fixtures Integrity** | `SEED_PERSONAS` | Verifies roles and phone numbers for `PARENT` (`+919876543210`), `STUDENT` (`+919876543211`), `TEACHER` (`+919437100005`), and `DRIVER` (`+919437200001`). |

---

## 3. Tier 4 Real-World Application Scenarios Test Verification Matrix

Below is the verification trace across all 8 Tier 4 Real-World Application Scenarios specified in the project architecture:

| # | Real-World Scenario | Frontend Web Coverage (`apps/web`) | Mobile Coverage (`apps/mobile`) | API Monolith Coverage (`apps/api`) | Postman Newman CI (`docs/postman`) | Gap / Hardening Need |
|---|---|---|---|---|---|---|
| **1** | **Admin Operations Center**<br>(Bulk CSV import, DPDP audit trail, visitor passes) | Protected by `EDGE-01` & `EDGE-05`. UI components in `components/modules/admin/` (`bulk-csv-importer.tsx`, `audit-log-table.tsx`, `visitor-log-table.tsx`). | N/A (Admin is desktop web only). | `admin.controller.spec.ts`, `people.service.spec.ts`, `safety.service.spec.ts`. | Folder `02_People_Management`, `07_Safety_AI`. | **Gap**: Web frontend lacks automated unit tests for CSV malformed row validation (e.g., verifying row 5 rejected for non-E.164 phone format). |
| **2** | **Principal Pulse Command Center**<br>(Live radar KPIs, attendance chart, fleet telemetry, 1-click substitute) | `TEL-01` to `TEL-04` (plates, GPS, speed >50km/h alert, 30s cadence). `EDGE-04` verifies `/principal` authorization. | N/A (Principal is desktop web only). | `pulse.service.spec.ts`, `adversarial-m3-round2.spec.ts` (division by zero defense 2B-2C, weighted formula 2D-2E). | Folder `00_Health_Probes`, `05_Academics_CBSE`. | **Gap**: Substitute modal UI state transitions (teacher clash detection and period re-assignment) lack a frontend integration spec. |
| **3** | **Teacher Operations Hub**<br>(Rapid attendance <10s SLA, CBSE 9-point marks entry, homework dialog) | Fully covered in `academic-financial.challenge.spec.ts` (CBSE 20 boundary cases, 40-student benchmark <10s SLA). | `mobile.spec.ts` Suite 6 (40 students, 0 exceptions on full present, 3 exceptions delta dispatch). | `attendance.service.spec.ts` (rapid batch, monthly percentage formula). | Folder `03_Attendance_Sync`, `05_Academics_CBSE`. | **Verified 100%**: Dual web + mobile test harness passes cleanly with <10s execution SLA. |
| **4** | **Accountant Operations Hub**<br>(Tuition & bus reconciliation, fee structures, payment ledger, concessions) | Protected by `EDGE-02` (PARENT blocked) and `EDGE-03` (TEACHER blocked). UI in `components/modules/accountant/`. | N/A (Accountant is desktop web only). | `fees.service.spec.ts` (structures, concessions, orders, webhook, receipts). | Folder `04_Fees_Finance` (covers structures, orders, concessions, receipts). | **Gap**: Frontend fee reconciliation card and concession approval dialog lack component-level unit assertions for multi-slab calculations. |
| **5** | **Parent Unified Portal**<br>(Sibling switcher, attendance calendar, Razorpay checkout, live bus GPS, dismissal OTP) | `m4-challenger.spec.ts` `OTP-01` to `OTP-04`, `STATE-01` to `STATE-04`, `academic-financial.challenge.spec.ts` UUID idempotency. | `mobile.spec.ts` Suite 4 (sibling isolation), Suite 5 (dismissal OTP & QR), Suite 7 (bus GPS geofence). | `auth.service.spec.ts`, `people.service.spec.ts`, `fees.service.spec.ts`, `safety.service.spec.ts`. | Folder `01_Authentication`, `02_People_Management`, `04_Fees_Finance`. | **Verified 100%**: High parity across web components and React Native mobile screens. |
| **6** | **Multi-Child Sibling State Isolation**<br>(Aarav Grade 5 vs Ananya Grade 2 Patel) | `m4-challenger.spec.ts` `STATE-01` (authStore), `STATE-02` (Razorpay modal keyed by child ID), `STATE-03` (OTP tokens), `STATE-04` (attendance/bus). | `mobile.spec.ts` Suite 4 (distinct identities, roll numbers, admission numbers, fee amounts, and attendance rates). | `adversarial-m3-round2.spec.ts` Suite 4 (4A-4E: zero leakage to unlinked guardians, null handling, orphan guardians). | Folder `02_People_Management` (`GET /people/guardians/siblings`). | **Verified 100%**: Strict isolation in store, UI remounting keys, mobile state, and backend RLS queries. |
| **7** | **Offline SQLite Outbox Sync**<br>(Durable queue, client UUID, idempotent replay, `/api/v1/sync/batch`) | Web uses live TanStack query with offline cached state. | `mobile.spec.ts` Suites 1, 2, 3 (adaptive storage, outbox enqueue, status flow, reconnect sync, TTL purge). | `attendance.service.spec.ts` lines 150–175 (`syncBatch` idempotency key deduplication). | Folder `03_Attendance_Sync` (`POST /api/v1/sync/batch`). | **Verified 100%**: Mobile client correctly implements `idem_<actionType>_<id>` and backend deduplicates via Redis. |
| **8** | **Bus GPS Broadcast & 1.5km Geofence Alert**<br>(4 pilot buses, 5s telemetry pings, Route 1 Budharaja, 1.5km threshold) | `m4-challenger.spec.ts` `TEL-01` to `TEL-04`. `live-bus-tracker.tsx` renders 5-min geofence banner. | `mobile.spec.ts` Suite 7 (Haversine formula, Budharaja waypoints, 1.5km geofence proximity trigger). | `transport.service.ts` lines 151–210 (`recordGpsPing`, vehicle telemetry update). | Folder `06_Transport_Fleet` (`/transport/gps-ping`, `/transport/buses`). | **Verified 100%**: Spherical Haversine formula and 1.5km alert boundary mathematically verified. |

---

## 4. Comprehensive Monorepo-Wide Adversarial Attack Surfaces (Phase 2 Tier 5 Hardening)

Through rigorous source code auditing of controllers, services, guards, middleware, and schemas, we have uncovered **9 specific adversarial attack surfaces** requiring defensive hardening in Tier 5:

### ⚠️ Attack Surface 1: Edge Middleware Role Spoofing & Missing Cryptographic Signature Check
- **Location**: `apps/web/src/middleware.ts` (lines 34–44, 62–66, 110–114)
- **Vulnerability Mechanism**:
  1. `decodeJwtPayload` manually splits `token` by `.` and decodes base64 JSON (`atob`) without verifying the cryptographic HMAC/RSA signature (`jwt.verify`).
  2. If the token is invalid or non-standard, line 65 falls back: `let userRole = decoded?.role || roleCookie;`.
  3. Line 66 sets `let isAuthenticated = !!token && !isTokenExpired;`.
  4. An attacker can set cookie `bomis_access_token=arbitrary_string` and cookie `bomis_user_role=ADMIN`. The edge middleware treats `isAuthenticated = true` and `userRole = ADMIN`, allowing access into `/admin` or `/accountant`.
- **Impact**: Unauthorized client-side page rendering and potential exposure of static admin assets or cached data.
- **Hardening Requirement**: In Next.js edge runtime, use `jose` (`jwtVerify`) with `process.env.JWT_SECRET` to cryptographically verify token signatures at the edge, and deprecate trusting raw `bomis_user_role` cookies for route access.

---

### ⚠️ Attack Surface 2: Session Revocation Bypass & Token Blacklist Non-Enforcement
- **Location**: `apps/api/src/modules/auth/auth.service.ts` (lines 144–175, 180–187) and `apps/api/src/common/guards/jwt-auth.guard.ts`
- **Vulnerability Mechanism**:
  1. In `logout()` (lines 180–187), the server records the revoked token in Redis: `await this.redis.set(`blacklist:${refreshToken}`, 'revoked', 604800);`.
  2. However, in `rotateRefreshToken()` (lines 144–175), the code verifies the JWT structure, extracts `userId`, and issues a new token pair **without ever checking Redis for `blacklist:${refreshTokenString}`**.
  3. Furthermore, `JwtAuthGuard` only checks JWT signature and expiry; it does not check if the access token's `jti` is revoked in Redis.
- **Impact**: An attacker who obtains a stolen refresh token can continue rotating it to maintain persistent unauthorized access even after the legitimate user logs out.
- **Hardening Requirement**:
  - Add explicit blacklist check in `rotateRefreshToken`:
    ```typescript
    const isBlacklisted = await this.redis.get(`blacklist:${refreshTokenString}`);
    if (isBlacklisted) throw new UnauthorizedException('Token has been revoked');
    ```
  - Implement token family revocation (reuse detection) where attempting to use an already-rotated token invalidates the entire refresh token family.

---

### ⚠️ Attack Surface 3: Unrestricted OTP Dispatch (SMS Flooding / Denial of Wallet) & Static Dev Credential
- **Location**: `apps/api/src/modules/auth/auth.service.ts` (lines 28–48)
- **Vulnerability Mechanism**:
  1. `sendOtp` does not enforce the 5 OTP requests per 15 minutes rate limit specified in `TEST_INFRA.md` section 2.5 (`otp-flood-defense.spec.ts`). An automated script can repeatedly invoke `POST /api/v1/auth/otp/send` to exhaust SMS gateway budgets.
  2. The OTP is hardcoded to `'123456'` with no check for `process.env.NODE_ENV === 'production'`. In a production deployment without code changes, all accounts would have the static OTP `123456`.
- **Impact**: Financial loss via SMS credit exhaustion and trivial credential bypass if static OTP persists.
- **Hardening Requirement**:
  - Implement Redis sliding-window rate limiter (`INCR` with 900s TTL, rejecting on `count > 5` with `429 Too Many Requests`).
  - Generate cryptographically secure 6-digit random OTP via `crypto.randomInt(100000, 999999)` when outside mock test mode.

---

### ⚠️ Attack Surface 4: Insecure Direct Object Reference (IDOR) on Student PII & Health Data
- **Location**: `apps/api/src/modules/people/people.controller.ts` (lines 60–71) & `apps/api/src/modules/attendance/attendance.controller.ts` (lines 38–54)
- **Vulnerability Mechanism**:
  1. `GET /api/v1/people/students/:id` permits `UserRole.PARENT` in `@Roles(...)`.
  2. However, the controller does not inject `@CurrentUser() user`, and `peopleService.getStudentById(id)` does not verify whether the authenticated parent has an active guardian relationship to student `:id`.
  3. Similarly, `GET /api/v1/attendance/students/:id` permits `UserRole.PARENT` and `UserRole.STUDENT` without scoping to the caller's linked children.
- **Impact**: Any authenticated parent can query arbitrary student IDs to exfiltrate other children's names, dates of birth, decrypted blood groups, house affiliations, emergency contact numbers, and daily attendance records.
- **Hardening Requirement**:
  - Inject `@CurrentUser() user` into `getStudentById` and `getStudentStats`.
  - If `user.role === UserRole.PARENT`, verify `studentId` is present in `await this.getLinkedSiblingIds(user.id)`. If not, throw `403 Forbidden` or `404 Not Found`.

---

### ⚠️ Attack Surface 5: Child Dismissal Gatekeeper OTP Brute-Force Vulnerability
- **Location**: `apps/api/src/modules/safety/safety.service.ts` (lines 107–176)
- **Vulnerability Mechanism**:
  1. `verifyChildPickup` validates a 6-digit OTP (`100000` to `999999`).
  2. If the OTP is incorrect (line 169), it logs a warning and returns `{ authorized: false, message: 'Invalid pickup OTP' }`.
  3. Crucially, **it does not increment an attempt counter or lock the authorization**.
- **Impact**: An attacker who knows a student ID can script 1,000 requests per minute against `POST /api/v1/safety/pickup/verify` to brute-force the 6-digit code before the 30-minute timer expires, enabling unauthorized child pickup.
- **Hardening Requirement**:
  - Track `failed_attempts` on the authorization record in Redis/store.
  - After 3 consecutive failed attempts, immediately transition authorization status to `LOCKED` / `EXPIRED`, emit a high-priority security alert to the guardian, and require manual parent re-authorization.

---

### ⚠️ Attack Surface 6: Razorpay Webhook Replay & Race Conditions in Order Creation
- **Location**: `apps/api/src/modules/fees/fees.service.ts` (lines 200–225, 289–336)
- **Vulnerability Mechanism**:
  1. In `processWebhook`, the HMAC-SHA256 signature is verified against the payload body. However, there is no timestamp freshness check (e.g. rejecting webhooks older than 5 minutes) nor webhook event ID deduplication (`x-razorpay-event-id`). A captured webhook payload and signature can be replayed.
  2. In `createRazorpayOrder`, idempotency is checked by looking up `cached = await this.redis.getIdempotentResult(idempotencyKey)`. However, if two concurrent HTTP requests arrive simultaneously with the same `Idempotency-Key`, both read `cached === null` before the first writes `setIdempotentResult`, leading to duplicate Razorpay order creation.
- **Impact**: Duplicate payment order creation, potential double billing, and fraudulent ledger reconciliation via replayed webhooks.
- **Hardening Requirement**:
  - Implement Redis distributed lock (`SET lock:idemp:<key> <val> NX EX 10`) at the start of order creation.
  - Store processed webhook IDs in Redis with 7-day TTL (`SET webhook:<event_id> 1 NX EX 604800`) and reject duplicate deliveries.

---

### ⚠️ Attack Surface 7: Unvalidated Vehicle GPS Telemetry Ingestion & Spoofing
- **Location**: `apps/api/src/modules/transport/transport.controller.ts` (lines 55–61) & `transport.service.ts` (lines 151–210)
- **Vulnerability Mechanism**:
  1. `POST /api/v1/transport/gps-ping` binds `@Body() body: any` without schema pipe validation.
  2. `recordGpsPing` accepts latitude and longitude without validating geographic bounding boxes (Sambalpur District latitude [21.0 - 22.0], longitude [83.5 - 84.5]) or physical speed feasibility (e.g. vehicle speed > 120 km/h or teleportation between pings).
- **Impact**: A compromised driver credential or malicious client could transmit coordinates in the Arabian Sea or simulate teleportation, triggering erroneous 5-minute parent geofence notifications across the city.
- **Hardening Requirement**:
  - Apply `GpsLocationUpdateSchema` via `ZodValidationPipe`.
  - Validate geographic bounding box for Sambalpur and reject pings where implied velocity between successive breadcrumbs exceeds 100 km/h.

---

### ⚠️ Attack Surface 8: Absence of DPDP Act 90-Day Retention Shredding Worker
- **Location**: Monorepo-wide background workers (`apps/api/src/modules/`)
- **Vulnerability Mechanism**:
  - Multiple services set `deleted_at: new Date()`, and queries filter `where: { deleted_at: null }`.
  - However, there is no active BullMQ worker or scheduled task (`@Cron()`) that scans for soft-deleted records older than 90 days and executes cryptographic erasure (overwriting PII fields with cryptographically random bytes before deletion), as required by DPDP Act (2023) and `TEST_INFRA.md` section 2.5 (`dpdp-shredding-audit.spec.ts`).
- **Impact**: Non-compliance with statutory DPDP 90-day retention rules and lingering unencrypted PII in database backups.
- **Hardening Requirement**:
  - Implement `@bomis/api` scheduled cron worker (`@Cron('0 2 * * *')`) that finds records where `deleted_at < NOW() - 90 days`, performs cryptographic zeroing of `first_name`, `last_name`, `emergency_contact`, and `blood_group`, and permanently removes the records.

---

### ⚠️ Attack Surface 9: AI Study Buddy Prompt Reflection & Template Injection
- **Location**: `apps/api/src/modules/ai/ai.service.ts` (lines 14–47)
- **Vulnerability Mechanism**:
  - The `studyBuddyChat` endpoint accepts raw `prompt: string` and reflects it directly into the output string: `In response to your question "${query}"...`.
  - No prompt sanitization, XSS escaping, or guardrails against curriculum jailbreaks (e.g. attempting to extract teacher remarks or exam keys) are enforced.
- **Impact**: Reflected XSS if rendered in raw HTML, or adversarial jailbreak of the AI assistant.
- **Hardening Requirement**:
  - Sanitize input strings, strip HTML/scripts, and wrap AI responses in strict system prompt constraints grounding the model solely in CBSE Grades 1–8 curriculum.

---

## 5. Synthesis & Actionable Hardening Roadmap for Phase 2 Tier 5

| Priority | Hardening Target | Recommended Implementation File | Verification Spec to Author |
|---|---|---|---|
| **P0** | **Fix IDOR on Student PII & Attendance** | `apps/api/src/modules/people/people.service.ts` & `attendance.service.ts` | `apps/api/src/tier5-idor-isolation.spec.ts` |
| **P0** | **Enforce Session Token Blacklist in Refresh Rotation** | `apps/api/src/modules/auth/auth.service.ts` | `apps/api/src/tier5-token-revocation.spec.ts` |
| **P0** | **Add Brute-Force Lockout on Child Pickup OTP (max 3 tries)** | `apps/api/src/modules/safety/safety.service.ts` | `apps/api/src/tier5-pickup-lockout.spec.ts` |
| **P1** | **Cryptographic Edge Middleware JWT Verification** | `apps/web/src/middleware.ts` | `apps/web/src/tests/tier5-edge-jwt.spec.ts` |
| **P1** | **OTP Dispatch Rate Limiter (5 requests / 15 mins)** | `apps/api/src/modules/auth/auth.service.ts` | `apps/api/src/tier5-otp-flood.spec.ts` |
| **P1** | **Razorpay Webhook Freshness & Event ID Deduplication** | `apps/api/src/modules/fees/fees.service.ts` | `apps/api/src/tier5-webhook-replay.spec.ts` |
| **P2** | **Vehicle GPS Telemetry Sambalpur Bounding Box Validation** | `apps/api/src/modules/transport/transport.service.ts` | `apps/api/src/tier5-gps-boundary.spec.ts` |
| **P2** | **Automated DPDP 90-Day Retention Shredding Worker** | `apps/api/src/modules/people/dpdp-shredder.worker.ts` | `apps/api/src/tier5-dpdp-shredding.spec.ts` |
