# Milestone M4 Exploration & Architecture Specification: Web Portal Architecture & Data Layer

- **Target Agent**: `teamwork_preview_explorer` (Explorer 1)
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_1`
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Milestone**: `M4` (`apps/web` - Next.js 14 App Router Web Portal)

---

## 1. Observation

### 1.1 Existing Workspace & Dependencies
Inspection of `apps/web/package.json` reveals the following current configuration:
```json
{
  "name": "@bomis/web",
  "version": "0.1.0",
  "private": true,
  "description": "Next.js 14 App Router Web Portal for BOMIS Sambalpur",
  "scripts": {
    "build": "next build",
    "dev": "next dev",
    "start": "next start",
    "lint": "next lint || tsc --noEmit",
    "test": "tsc --noEmit",
    "typecheck": "tsc --noEmit",
    "clean": "rimraf .next dist"
  },
  "dependencies": {
    "@bomis/shared": "workspace:*",
    "@bomis/ui": "workspace:*",
    "@tanstack/react-query": "^5.35.1",
    "clsx": "^2.1.1",
    "lucide-react": "^0.378.0",
    "next": "14.2.3",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-hook-form": "^7.51.4",
    "tailwind-merge": "^2.3.0",
    "zod": "^3.23.8"
  }
}
```
- Next.js is version `14.2.3` with App Router enabled (`apps/web/src/app/layout.tsx` and `page.tsx`).
- `@bomis/shared` and `@bomis/ui` are linked workspace dependencies.
- `@tanstack/react-query` is version `^5.35.1`.
- `react-hook-form` (`^7.51.4`) and `zod` (`^3.23.8`) are already installed.

### 1.2 Backend API Contracts & Response Envelope
Inspection of `packages/shared/src/contracts/index.ts` (lines 6–18):
```typescript
export interface ApiErrorDetail {
  code: string;
  message: string;
  details?: unknown;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data: T | null;
  error?: ApiErrorDetail | null;
  timestamp: string; // ISO 8601 UTC string
  correlationId: string; // Distributed tracing UUID
}
```
Inspection of `apps/api/src/common/interceptors/transform.interceptor.ts` (lines 80–88) confirms that all successful REST responses are enveloped as:
```typescript
const envelope: ApiResponse<T> = {
  success: true,
  data: data !== undefined ? data : null,
  error: null,
  timestamp: new Date().toISOString(),
  correlationId,
};
```
And `apps/api/src/common/filters/http-exception.filter.ts` confirms that all errors (HTTP exceptions, Zod validation errors, unhandled errors) are enveloped as:
```typescript
const envelope: ApiResponse<null> = {
  success: false,
  data: null,
  error: { code: errorCode, message: errorMessage, details: errorDetails },
  timestamp: new Date().toISOString(),
  correlationId,
};
```

### 1.3 Backend Auth Controller & Service Contracts
Inspection of `apps/api/src/modules/auth/auth.controller.ts` (lines 10–42) and `auth.service.ts` (lines 28–220):
1. **Parent/Student Mobile OTP**:
   - `POST /api/v1/auth/otp/send`: payload `{ phone: string, schoolId?: string, purpose?: string }`
     - Validates against regex `/^\+91[6-9]\d{9}$/`. Dev/test mock OTP is `123456`, TTL 300s.
   - `POST /api/v1/auth/otp/verify`: payload `{ phone: string, code: string }`
     - Returns `{ accessToken, refreshToken, user }`.
2. **Staff Login**:
   - `POST /api/v1/auth/staff/login`: payload `{ email: string, password: string }`
     - Validates bcrypt hash and returns `{ accessToken, refreshToken, user }`.
3. **Session Refresh & Token Rotation**:
   - `POST /api/v1/auth/refresh`: payload `{ refreshToken: string }`
     - Returns new `{ accessToken, refreshToken, user }`.
4. **Logout**:
   - `POST /api/v1/auth/logout`: payload `{ refreshToken?: string }` with Bearer token header.
5. **Token Claims & Expiry**:
   - `accessToken`: JWT signed with `JWT_SECRET`, expires in `15m`, payload includes `{ sub, id, email, phone, role, schoolId, jti }`.
   - `refreshToken`: JWT signed with `JWT_SECRET`, expires in `7d`, payload includes `{ sub, familyId, jti }`.
   - `user`: `{ id, email, phone, role, schoolId, firstName, lastName }`.

### 1.4 Parent Multi-Child Linking & Sibling Data
Inspection of `apps/api/src/modules/people/people.controller.ts` (lines 38–43) and `people.service.ts` (lines 374–427):
- Endpoint: `GET /api/v1/people/guardians/siblings`
- Secured by `@Roles(UserRole.PARENT, UserRole.ADMIN, UserRole.SUPER_ADMIN)`
- Returns linked children for the authenticated guardian user.
- Inspection of `apps/api/src/database/seed-fixtures.ts` (lines 106, 120, 124–125) reveals:
  - Parent: `Dr. Rajesh Kumar Patel` (email: `rajesh.patel@example.com`, phone: `+919876543210`, role: `PARENT`)
  - Child 1: `Aarav Patel` (admission: `BOMIS-2021-0042`, roll: `1`, Grade: `5`, Section: `A`, house: `KALINGA`)
  - Child 2: `Ananya Patel` (admission: `BOMIS-2024-0118`, roll: `4`, Grade: `2`, Section: `A`, house: `KALINGA`)

### 1.5 RBAC Roles & Permissions
Inspection of `packages/shared/src/enums/index.ts` (lines 5–15) and `packages/shared/src/rbac/index.ts`:
- Canonical roles: `SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `TEACHER`, `ACCOUNTANT`, `STUDENT`, `PARENT`, `TRANSPORT_STAFF`.
- `hasPermission(role, permission)` utility exists in `@bomis/shared`.

### 1.6 Brand Tokens & Tailwind Setup
Inspection of `packages/ui/src/tokens/index.ts` and `apps/web/tailwind.config.ts`:
- Primary Navy: `#0F2942` (`bomis-navy`), Accent Warm Coral: `#FF6B4A` (`bomis-coral`).
- `apps/web/tailwind.config.ts` extends `presets: [bomisTailwindPreset]` from `@bomis/ui`.

---

## 2. Logic Chain

1. **Next.js 14 App Router Separation of Concerns**:
   - Because authentication flows (login, OTP verification, password resets) require a distraction-free, branded single-column or split-screen presentation without administrative navigation chrome, they must be grouped under Route Group `(auth)`.
   - Because all authenticated application pages share the common administrative frame (collapsible sidebar, role-aware top navigation bar, active child selector for parents, notifications bell, user menu), they must be grouped under Route Group `(dashboard)`.
   - Both route groups sit alongside the public landing page `page.tsx` and root layout `layout.tsx`.

2. **Role Route Protection at Edge Runtime vs. Client React**:
   - Security in depth requires a 2-tier guard architecture:
     1. **Tier 1 (Edge Middleware - `middleware.ts`)**: Evaluates incoming requests before rendering or page transfer. Next.js Edge Middleware cannot access `localStorage`, so tokens and role indicators must be stored in secure cookies (`bomis_access_token`, `bomis_user_role`). Middleware verifies token existence, decodes unexpired JWT claims, maps path prefixes (`/admin`, `/principal`, `/teacher`, `/accountant`, `/parent`) against `ROUTE_ROLE_PERMISSIONS`, and redirects unauthenticated users to `/login` and unauthorized users to `/unauthorized`.
     2. **Tier 2 (Client Route Guard & Auth Context)**: Listens to client-side auth events (e.g., token expiration, 401 refresh failure, logout action) and handles seamless programmatic redirects without requiring hard page refreshes.

3. **Type-Safe API Client & Automatic Token Refresh**:
   - Because all NestJS endpoints return the standard `ApiResponse<T>` envelope, a raw `fetch` or Axios call creates boilerplate and risks type errors.
   - The type-safe API client must automatically unwrap `response.data` on `success: true`, throw a structured `ApiClientError` on `success: false` or HTTP errors, and inject `Authorization: Bearer <token>` and `X-Correlation-Id: <uuid>` on every request.
   - Access tokens expire after 15 minutes. To prevent user disruption during active dashboard sessions, the client must intercept `401 Unauthorized` responses, queue concurrent requests, call `POST /api/v1/auth/refresh` with `refreshToken`, store the rotated token pair, update cookies, and replay the queued requests. If the refresh call itself fails, the client must purge stored credentials and redirect to `/login?session_expired=1`.

4. **TanStack Query Setup & Query Key Granularity**:
   - TanStack Query v5 is ideal for server state caching, background refetching, and optimistic updates.
   - A centralized `queryKeys` factory ensures consistent cache keys across components, preventing stale cache leaks and enabling surgical invalidation (e.g. invalidating only `['fees', 'student', studentId]` when switching children, or `['attendance', 'section', sectionId]` when a teacher records attendance).
   - Live dashboard pulse metrics (`/principal`) can utilize TanStack Query's `refetchInterval` (15s) for auto-polling without manual setInterval spaghetti.

5. **Multi-Child State Management for Parents**:
   - In a multi-child school platform, a parent like Dr. Rajesh Kumar Patel manages multiple students (Aarav in Grade 5A, Ananya in Grade 2A).
   - All child-scoped features (attendance percentage, fee ledger, homework diary, bus tracking, pickup OTP) depend on knowing the currently selected child.
   - The auth store must track `linkedChildren: LinkedSibling[]` and `activeChildId: string`. When `activeChildId` changes, the `useChildSwitcher` hook updates the active child, synchronizes the `bomis_active_child_id` cookie, and invalidates child-dependent query keys, ensuring instant reactive updates across all dashboard widgets.

---

## 3. Caveats

1. **JWT Verification in Edge Middleware**: Next.js Edge runtime does not include the Node.js native `crypto` module required by full `jsonwebtoken`. Edge middleware performs JWT payload parsing and expiration check via lightweight base64url decoding; authoritative cryptographic signature verification is performed by NestJS backend on every API request.
2. **Reverse Proxy & CORS in Development**: By adding a Next.js rewrite rule in `next.config.mjs` forwarding `/api/v1/:path*` to `process.env.NEXT_PUBLIC_API_URL || http://localhost:3000/api/v1/:path*`, frontend browser requests can use same-origin calls without CORS preflight overhead.
3. **Zustand Dependency**: While Zustand is the ideal lightweight state management library for React, to avoid build breaks if `zustand` is not yet installed in `apps/web/package.json`, our blueprint provides both a zero-dependency React 18 `useSyncExternalStore` implementation and the equivalent Zustand store definition.

---

## 4. Conclusion & Architecture Blueprint

Below is the complete, comprehensive architecture blueprint for Milestone M4 (`apps/web`).

### 4.1 Target Directory Tree Layout

```
apps/web/
├── next.config.mjs
├── package.json
├── tailwind.config.ts
├── tsconfig.json
├── src/
│   ├── middleware.ts                         # Edge route guard & role authorization
│   ├── app/
│   │   ├── layout.tsx                        # Root layout with HTML shell & Providers
│   │   ├── page.tsx                          # Public landing page with role portals
│   │   ├── globals.css                       # Tailwind directives & BOMIS brand styles
│   │   ├── loading.tsx                       # Global page loading fallback skeleton
│   │   ├── error.tsx                         # Global uncaught error boundary
│   │   ├── not-found.tsx                     # 404 Not Found page
│   │   ├── (auth)/
│   │   │   ├── layout.tsx                    # Split-screen branded auth layout
│   │   │   ├── login/
│   │   │   │   └── page.tsx                  # Dual login (Staff Email+Pass / Parent Mobile OTP)
│   │   │   ├── verify-otp/
│   │   │   │   └── page.tsx                  # 6-digit OTP verification screen
│   │   │   └── forgot-password/
│   │   │       └── page.tsx                  # Password reset / help desk assistance
│   │   └── (dashboard)/
│   │       ├── layout.tsx                    # DashboardShell (Sidebar + TopNavbar + Content)
│   │       ├── unauthorized/
│   │       │   └── page.tsx                  # 403 Forbidden page
│   │       ├── profile/
│   │       │   └── page.tsx                  # User profile, sessions & DPDP consent
│   │       ├── admin/
│   │       │   └── page.tsx                  # Admin Dashboard (Overview, Users, Audit, Ingestion)
│   │       ├── principal/
│   │       │   └── page.tsx                  # Principal Pulse Dashboard (Live KPIs & Telemetry)
│   │       ├── teacher/
│   │       │   └── page.tsx                  # Teacher Dashboard (Attendance Grid, Diary, Marks)
│   │       ├── accountant/
│   │       │   └── page.tsx                  # Accountant Dashboard (Fees, Reconciliation, Concessions)
│   │       └── parent/
│   │           └── page.tsx                  # Parent Portal (Child Switcher, Fees, Diary, Bus, OTP)
│   ├── components/
│   │   ├── layout/
│   │   │   ├── dashboard-shell.tsx           # Layout wrapper with sidebar toggle state
│   │   │   ├── sidebar.tsx                   # Role-filtered navigation sidebar
│   │   │   ├── top-navbar.tsx                # Brand header, child switcher, user nav
│   │   │   ├── user-nav.tsx                  # Avatar dropdown with role badge & logout
│   │   │   └── child-switcher.tsx            # Multi-child dropdown selector for parents
│   │   ├── shared/
│   │   │   ├── stat-card.tsx                 # Metric KPI card
│   │   │   ├── data-table.tsx                # Reusable table with pagination & sorting
│   │   │   ├── role-guard.tsx                # Client-side component role wrapper
│   │   │   └── loading-skeleton.tsx          # Shimmer placeholder skeletons
│   │   └── ui/                               # Primitives (Button, Input, Card, Badge, etc.)
│   └── lib/
│       ├── api/
│       │   ├── client.ts                     # Core fetch client with envelope & 401 refresh
│       │   ├── errors.ts                     # ApiClientError definition
│       │   ├── auth.ts                       # Auth API service (login, OTP, refresh, logout)
│       │   ├── people.ts                     # Students, staff & sibling linking API
│       │   ├── attendance.ts                 # Rapid batch & student stats API
│       │   ├── fees.ts                       # Structures, Razorpay orders & concessions API
│       │   ├── pulse.ts                      # Principal pulse live metrics API
│       │   ├── academics.ts                  # Terms, marks batch & timetable API
│       │   ├── transport.ts                  # Bus routes & telemetry API
│       │   ├── safety.ts                     # Gate passes & pickup verification API
│       │   └── admin.ts                      # Audit logs & user administration API
│       ├── auth/
│       │   ├── store.ts                      # Auth store (tokens, user, children, active child)
│       │   ├── cookies.ts                    # Edge cookie helpers (get/set/clear)
│       │   └── use-child-switcher.ts         # Multi-child selection hook with query invalidation
│       ├── query/
│       │   ├── provider.tsx                  # TanStack Query Client Provider
│       │   ├── keys.ts                       # Canonical queryKeys factory
│       │   └── hooks/                        # Typed domain query & mutation hooks
│       └── utils.ts                          # cn() utility and formatting helpers
```

---

### 4.2 Next.js 14 Middleware Implementation (`src/middleware.ts`)

```typescript
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/serve';
import { UserRole } from '@bomis/shared';

// Route to Allowed Roles Mapping Matrix
export const ROUTE_ROLE_PERMISSIONS: Record<string, UserRole[]> = {
  '/admin': [UserRole.SUPER_ADMIN, UserRole.ADMIN],
  '/principal': [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL],
  '/teacher': [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.PRINCIPAL, UserRole.TEACHER],
  '/accountant': [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.ACCOUNTANT],
  '/parent': [UserRole.SUPER_ADMIN, UserRole.PARENT],
  '/profile': [
    UserRole.SUPER_ADMIN,
    UserRole.ADMIN,
    UserRole.PRINCIPAL,
    UserRole.TEACHER,
    UserRole.ACCOUNTANT,
    UserRole.PARENT,
    UserRole.STUDENT,
    UserRole.TRANSPORT_STAFF,
  ],
};

// Default redirect target per role upon login
export const DEFAULT_ROLE_REDIRECT: Record<UserRole, string> = {
  [UserRole.SUPER_ADMIN]: '/admin',
  [UserRole.ADMIN]: '/admin',
  [UserRole.PRINCIPAL]: '/principal',
  [UserRole.TEACHER]: '/teacher',
  [UserRole.ACCOUNTANT]: '/accountant',
  [UserRole.PARENT]: '/parent',
  [UserRole.STUDENT]: '/parent',
  [UserRole.TRANSPORT_STAFF]: '/admin',
};

// Helper to decode JWT payload without external dependencies in Edge runtime
function decodeJwtPayload(token: string): { role?: UserRole; exp?: number; sub?: string } | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const json = atob(base64);
    return JSON.parse(json);
  } catch {
    return null;
  }
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Ignore static assets, next internal routes, and favicon
  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    pathname.startsWith('/static') ||
    pathname.includes('.')
  ) {
    return NextResponse.next();
  }

  const token = request.cookies.get('bomis_access_token')?.value;
  const decoded = token ? decodeJwtPayload(token) : null;
  const isTokenExpired = decoded?.exp ? decoded.exp * 1000 < Date.now() : true;
  const isAuthenticated = !!token && !!decoded && !isTokenExpired;
  const userRole = decoded?.role;

  const isAuthRoute =
    pathname.startsWith('/login') ||
    pathname.startsWith('/verify-otp') ||
    pathname.startsWith('/forgot-password');

  // Case 1: Authenticated user accessing auth routes -> Redirect to dashboard
  if (isAuthRoute && isAuthenticated && userRole) {
    const redirectUrl = DEFAULT_ROLE_REDIRECT[userRole] || '/parent';
    return NextResponse.redirect(new URL(redirectUrl, request.url));
  }

  // Case 2: Public landing page '/'
  if (pathname === '/') {
    if (isAuthenticated && userRole) {
      const redirectUrl = DEFAULT_ROLE_REDIRECT[userRole] || '/parent';
      return NextResponse.redirect(new URL(redirectUrl, request.url));
    }
    return NextResponse.next();
  }

  // Case 3: Public Auth Routes
  if (isAuthRoute) {
    return NextResponse.next();
  }

  // Case 4: Protected Routes
  const matchedRoute = Object.keys(ROUTE_ROLE_PERMISSIONS).find(
    (prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`)
  );

  if (matchedRoute) {
    // Unauthenticated user attempting to access protected route
    if (!isAuthenticated) {
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      const response = NextResponse.redirect(loginUrl);
      // Clean stale expired cookies
      response.cookies.delete('bomis_access_token');
      response.cookies.delete('bomis_user_role');
      return response;
    }

    // Role-based authorization check
    const allowedRoles = ROUTE_ROLE_PERMISSIONS[matchedRoute];
    if (userRole && !allowedRoles.includes(userRole)) {
      // User is authenticated but lacks required role for this section
      return NextResponse.redirect(new URL('/unauthorized', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/',
    '/login/:path*',
    '/verify-otp/:path*',
    '/forgot-password/:path*',
    '/admin/:path*',
    '/principal/:path*',
    '/teacher/:path*',
    '/accountant/:path*',
    '/parent/:path*',
    '/profile/:path*',
    '/unauthorized',
  ],
};
```

---

### 4.3 Type-Safe API Client (`src/lib/api/`)

#### 4.3.1 Error Definition (`src/lib/api/errors.ts`)
```typescript
import { ApiErrorDetail } from '@bomis/shared';

export class ApiClientError extends Error {
  public readonly status: number;
  public readonly code: string;
  public readonly details?: unknown;
  public readonly correlationId?: string;

  constructor(
    status: number,
    errorObj?: ApiErrorDetail | null,
    correlationId?: string
  ) {
    super(errorObj?.message || `HTTP ${status} API Error`);
    this.name = 'ApiClientError';
    this.status = status;
    this.code = errorObj?.code || 'UNKNOWN_ERROR';
    this.details = errorObj?.details;
    this.correlationId = correlationId;
  }
}
```

#### 4.3.2 Core HTTP Client (`src/lib/api/client.ts`)
```typescript
import { ApiResponse } from '@bomis/shared';
import { ApiClientError } from './errors';
import { getAuthTokens, setAuthTokens, clearAuthTokens } from '../auth/cookies';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || '/api/v1';

export interface RequestOptions extends RequestInit {
  params?: Record<string, string | number | boolean | undefined>;
  idempotencyKey?: string;
  skipAuth?: boolean;
}

// Queue mechanism for handling in-flight 401 refresh token requests
let isRefreshing = false;
let failedQueue: Array<{
  resolve: (token: string) => void;
  reject: (error: any) => void;
}> = [];

function processQueue(error: any, token: string | null = null) {
  failedQueue.forEach((promise) => {
    if (error) {
      promise.reject(error);
    } else if (token) {
      promise.resolve(token);
    }
  });
  failedQueue = [];
}

async function refreshAccessToken(): Promise<string> {
  const { refreshToken } = getAuthTokens();
  if (!refreshToken) {
    clearAuthTokens();
    if (typeof window !== 'undefined') {
      window.location.href = '/login?session_expired=1';
    }
    throw new Error('No refresh token available');
  }

  try {
    const res = await fetch(`${API_BASE_URL}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    });

    const envelope: ApiResponse<{
      accessToken: string;
      refreshToken: string;
      user: any;
    }> = await res.json();

    if (!res.ok || !envelope.success || !envelope.data) {
      throw new Error(envelope.error?.message || 'Refresh failed');
    }

    setAuthTokens(envelope.data.accessToken, envelope.data.refreshToken, envelope.data.user.role);
    return envelope.data.accessToken;
  } catch (err) {
    clearAuthTokens();
    if (typeof window !== 'undefined') {
      window.location.href = '/login?session_expired=1';
    }
    throw err;
  }
}

export async function request<T>(
  endpoint: string,
  options: RequestOptions = {}
): Promise<T> {
  const {
    params,
    idempotencyKey,
    skipAuth = false,
    headers: customHeaders,
    ...restOptions
  } = options;

  let url = endpoint.startsWith('http') ? endpoint : `${API_BASE_URL}${endpoint}`;

  if (params) {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        searchParams.append(key, String(value));
      }
    });
    const queryString = searchParams.toString();
    if (queryString) {
      url += (url.includes('?') ? '&' : '?') + queryString;
    }
  }

  const { accessToken } = getAuthTokens();
  const correlationId = `web-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

  const headers = new Headers(customHeaders);
  headers.set('Accept', 'application/json');
  headers.set('X-Correlation-Id', correlationId);

  if (!headers.has('Content-Type') && !(restOptions.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  if (idempotencyKey) {
    headers.set('Idempotency-Key', idempotencyKey);
  }

  if (!skipAuth && accessToken) {
    headers.set('Authorization', `Bearer ${accessToken}`);
  }

  let response = await fetch(url, { ...restOptions, headers });

  // Handle 401 Unauthorized token rotation
  if (response.status === 401 && !skipAuth) {
    if (isRefreshing) {
      return new Promise<string>((resolve, reject) => {
        failedQueue.push({ resolve, reject });
      }).then((newToken) => {
        headers.set('Authorization', `Bearer ${newToken}`);
        return fetch(url, { ...restOptions, headers }).then((r) => handleResponse<T>(r));
      });
    }

    isRefreshing = true;
    try {
      const newAccessToken = await refreshAccessToken();
      processQueue(null, newAccessToken);
      headers.set('Authorization', `Bearer ${newAccessToken}`);
      response = await fetch(url, { ...restOptions, headers });
    } catch (refreshErr) {
      processQueue(refreshErr, null);
      throw refreshErr;
    } finally {
      isRefreshing = false;
    }
  }

  return handleResponse<T>(response);
}

async function handleResponse<T>(response: Response): Promise<T> {
  const correlationId = response.headers.get('x-correlation-id') || undefined;

  // Handle file downloads
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/pdf') || contentType.includes('text/csv')) {
    const blob = await response.blob();
    return blob as unknown as T;
  }

  let envelope: ApiResponse<T>;
  try {
    envelope = await response.json();
  } catch (err) {
    throw new ApiClientError(
      response.status,
      { code: 'INVALID_JSON', message: 'Unable to parse server response' },
      correlationId
    );
  }

  if (!response.ok || !envelope.success) {
    throw new ApiClientError(response.status, envelope.error, correlationId || envelope.correlationId);
  }

  return envelope.data as T;
}

export const apiClient = {
  get: <T>(url: string, options?: RequestOptions) =>
    request<T>(url, { method: 'GET', ...options }),
  post: <T>(url: string, body?: any, options?: RequestOptions) =>
    request<T>(url, {
      method: 'POST',
      body: body instanceof FormData ? body : JSON.stringify(body),
      ...options,
    }),
  put: <T>(url: string, body?: any, options?: RequestOptions) =>
    request<T>(url, {
      method: 'PUT',
      body: body instanceof FormData ? body : JSON.stringify(body),
      ...options,
    }),
  patch: <T>(url: string, body?: any, options?: RequestOptions) =>
    request<T>(url, {
      method: 'PATCH',
      body: body instanceof FormData ? body : JSON.stringify(body),
      ...options,
    }),
  delete: <T>(url: string, options?: RequestOptions) =>
    request<T>(url, { method: 'DELETE', ...options }),
};
```

#### 4.3.3 Domain Typed Services (`src/lib/api/`)

- **Auth Service (`src/lib/api/auth.ts`)**:
```typescript
import { apiClient } from './client';
import { UserRole } from '@bomis/shared';

export interface AuthTokensResponse {
  accessToken: string;
  refreshToken: string;
  user: {
    id: string;
    email: string | null;
    phone: string | null;
    role: UserRole;
    schoolId: string;
    firstName: string;
    lastName: string;
  };
}

export const authApi = {
  sendOtp: (phone: string, schoolId?: string, purpose = 'LOGIN') =>
    apiClient.post<{ expiresInSeconds: number; message: string }>('/auth/otp/send', {
      phone,
      schoolId,
      purpose,
    }, { skipAuth: true }),

  verifyOtp: (phone: string, code: string) =>
    apiClient.post<AuthTokensResponse>('/auth/otp/verify', { phone, code }, { skipAuth: true }),

  loginStaff: (email: string, password: string) =>
    apiClient.post<AuthTokensResponse>('/auth/staff/login', { email, password }, { skipAuth: true }),

  logout: (refreshToken?: string) =>
    apiClient.post<{ message: string }>('/auth/logout', { refreshToken }),
};
```

- **People & Multi-Child Sibling Service (`src/lib/api/people.ts`)**:
```typescript
import { apiClient } from './client';

export interface LinkedSibling {
  id: string;
  admissionNumber: string;
  rollNumber: string;
  firstName: string;
  lastName: string;
  grade: number;
  section: string;
  classId: string;
  sectionId: string;
  bloodGroup: string;
  emergencyContact: string;
  relationship: string;
}

export interface StudentProfile extends LinkedSibling {
  dateOfBirth?: string;
  gender?: string;
  house?: string;
  schoolId?: string;
}

export const peopleApi = {
  getLinkedSiblings: () =>
    apiClient.get<LinkedSibling[]>('/people/guardians/siblings'),

  getStudentById: (id: string) =>
    apiClient.get<StudentProfile>(`/people/students/${id}`),

  listStudents: (params?: { grade?: number; section?: string; page?: number; limit?: number }) =>
    apiClient.get<{ students: StudentProfile[]; total: number; page: number; limit: number }>(
      '/people/students',
      { params }
    ),

  listStaff: () =>
    apiClient.get<any[]>('/people/staff'),

  bulkImportStudents: (data: any) =>
    apiClient.post('/people/students/bulk-import', data),
};
```

- **Attendance Service (`src/lib/api/attendance.ts`)**:
```typescript
import { apiClient } from './client';
import { AttendanceStatus } from '@bomis/shared';

export interface StudentMonthlyAttendanceStats {
  studentId: string;
  studentName: string;
  presentDays: number;
  totalWorkingDays: number;
  attendancePercentage: number;
  lateDays: number;
  halfDays: number;
  absentDays: number;
  month: number;
  year: number;
}

export const attendanceApi = {
  recordRapidBatch: (payload: {
    date: string;
    classId: string;
    sectionId: string;
    defaultStatus?: AttendanceStatus;
    exceptions?: Array<{ studentId: string; status: AttendanceStatus; remarks?: string }>;
  }) => apiClient.post('/attendance', payload),

  getStudentStats: (studentId: string, month?: number, year?: number) =>
    apiClient.get<StudentMonthlyAttendanceStats>(`/attendance/students/${studentId}`, {
      params: { month, year },
    }),

  applyLeave: (payload: any) =>
    apiClient.post('/attendance/leaves', payload),
};
```

- **Fees Service (`src/lib/api/fees.ts`)**:
```typescript
import { apiClient } from './client';

export interface RazorpayOrderResult {
  orderId: string;
  amount: number;
  currency: string;
  keyId: string;
  installmentId: string;
}

export const feesApi = {
  getStructures: (grade?: string, academicYear?: string) =>
    apiClient.get<any[]>('/fees/structures', { params: { grade, academicYear } }),

  createRazorpayOrder: (
    payload: { installmentId: string; amount: number; studentId: string },
    idempotencyKey?: string
  ) =>
    apiClient.post<RazorpayOrderResult>('/fees/orders', payload, { idempotencyKey }),

  getConcessions: () =>
    apiClient.get<any[]>('/fees/concessions'),

  applyConcession: (payload: any) =>
    apiClient.post('/fees/concessions', payload),
};
```

- **Pulse & Admin Service (`src/lib/api/pulse.ts` & `admin.ts`)**:
```typescript
import { apiClient } from './client';

export interface PulseMetrics {
  attendanceRate: number;
  feeCollectionRate: number;
  totalStudents: number;
  activeBuses: number;
  safetyIncidentsPending: number;
  academicYear: string;
  systemHealth: string;
  lastUpdated: string;
}

export const pulseApi = {
  getMetrics: () => apiClient.get<PulseMetrics>('/pulse/metrics'),
};

export const adminApi = {
  getAuditLogs: () => apiClient.get<any[]>('/admin/audit-logs'),
};
```

---

### 4.4 TanStack Query Provider & Query Keys (`src/lib/query/`)

#### 4.4.1 Canonical Query Keys (`src/lib/query/keys.ts`)
```typescript
export const queryKeys = {
  auth: {
    me: ['auth', 'me'] as const,
  },
  people: {
    siblings: ['people', 'siblings'] as const,
    students: (params?: any) => ['people', 'students', params] as const,
    student: (id: string) => ['people', 'student', id] as const,
    staff: ['people', 'staff'] as const,
  },
  attendance: {
    stats: (studentId: string, month?: number, year?: number) =>
      ['attendance', 'stats', studentId, month, year] as const,
    records: (params?: any) => ['attendance', 'records', params] as const,
  },
  fees: {
    structures: (grade?: string, year?: string) => ['fees', 'structures', grade, year] as const,
    concessions: ['fees', 'concessions'] as const,
  },
  pulse: {
    metrics: ['pulse', 'metrics'] as const,
  },
  academics: {
    terms: ['academics', 'terms'] as const,
  },
  transport: {
    routes: ['transport', 'routes'] as const,
    buses: ['transport', 'buses'] as const,
  },
  safety: {
    visitors: ['safety', 'visitors'] as const,
  },
  admin: {
    auditLogs: ['admin', 'audit-logs'] as const,
  },
};
```

#### 4.4.2 React Query Provider (`src/lib/query/provider.tsx`)
```typescript
'use client';

import React, { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

export function makeQueryClient(): QueryClient {
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 60 * 1000, // 1 minute fresh cache
        gcTime: 10 * 60 * 1000, // 10 minutes garbage collection
        retry: (failureCount, error: any) => {
          if (error?.status === 401 || error?.status === 403 || error?.status === 404) {
            return false;
          }
          return failureCount < 1;
        },
        refetchOnWindowFocus: false,
      },
      mutations: {
        retry: 0,
      },
    },
  });
}

let browserQueryClient: QueryClient | undefined = undefined;

export function getQueryClient(): QueryClient {
  if (typeof window === 'undefined') {
    return makeQueryClient();
  }
  if (!browserQueryClient) {
    browserQueryClient = makeQueryClient();
  }
  return browserQueryClient;
}

export function QueryProvider({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(() => getQueryClient());

  return (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  );
}
```

---

### 4.5 Auth Store & Multi-Child Selector (`src/lib/auth/`)

#### 4.5.1 Edge & Client Cookie Helpers (`src/lib/auth/cookies.ts`)
```typescript
import { UserRole } from '@bomis/shared';

export interface StoredTokens {
  accessToken: string | null;
  refreshToken: string | null;
  role: UserRole | null;
}

function parseCookie(name: string): string | null {
  if (typeof document === 'undefined') return null;
  const match = document.cookie.match(new RegExp(`(^|;\\s*)(${name})=([^;]*)`));
  return match ? decodeURIComponent(match[3]) : null;
}

export function getAuthTokens(): StoredTokens {
  return {
    accessToken: parseCookie('bomis_access_token'),
    refreshToken: parseCookie('bomis_refresh_token'),
    role: parseCookie('bomis_user_role') as UserRole | null,
  };
}

export function setAuthTokens(accessToken: string, refreshToken: string, role: UserRole) {
  if (typeof document === 'undefined') return;
  // 15 min expiry for access token
  document.cookie = `bomis_access_token=${encodeURIComponent(accessToken)}; Path=/; Max-Age=900; SameSite=Lax`;
  // 7 days expiry for refresh token
  document.cookie = `bomis_refresh_token=${encodeURIComponent(refreshToken)}; Path=/; Max-Age=604800; SameSite=Lax`;
  document.cookie = `bomis_user_role=${encodeURIComponent(role)}; Path=/; Max-Age=604800; SameSite=Lax`;
}

export function clearAuthTokens() {
  if (typeof document === 'undefined') return;
  document.cookie = 'bomis_access_token=; Path=/; Max-Age=0; SameSite=Lax';
  document.cookie = 'bomis_refresh_token=; Path=/; Max-Age=0; SameSite=Lax';
  document.cookie = 'bomis_user_role=; Path=/; Max-Age=0; SameSite=Lax';
  document.cookie = 'bomis_active_child_id=; Path=/; Max-Age=0; SameSite=Lax';
}

export function setActiveChildCookie(childId: string) {
  if (typeof document === 'undefined') return;
  document.cookie = `bomis_active_child_id=${encodeURIComponent(childId)}; Path=/; Max-Age=604800; SameSite=Lax`;
}

export function getActiveChildCookie(): string | null {
  return parseCookie('bomis_active_child_id');
}
```

#### 4.5.2 Auth Store Implementation (`src/lib/auth/store.ts`)
```typescript
import { UserRole } from '@bomis/shared';
import { LinkedSibling } from '../api/people';
import { setAuthTokens, clearAuthTokens, setActiveChildCookie, getActiveChildCookie, getAuthTokens } from './cookies';
import { useSyncExternalStore } from 'react';

export interface AuthUser {
  id: string;
  email: string | null;
  phone: string | null;
  role: UserRole;
  schoolId: string;
  firstName: string;
  lastName: string;
}

export interface AuthState {
  user: AuthUser | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  linkedChildren: LinkedSibling[];
  activeChildId: string | null;
  activeChild: LinkedSibling | null;
}

class AuthStore {
  private state: AuthState;
  private listeners = new Set<() => void>();

  constructor() {
    const tokens = typeof window !== 'undefined' ? getAuthTokens() : { accessToken: null, refreshToken: null, role: null };
    const savedChildId = typeof window !== 'undefined' ? getActiveChildCookie() : null;
    const savedUserStr = typeof window !== 'undefined' ? localStorage.getItem('bomis_user') : null;
    let savedUser: AuthUser | null = null;
    try {
      if (savedUserStr) savedUser = JSON.parse(savedUserStr);
    } catch {}

    this.state = {
      user: savedUser,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      isAuthenticated: !!tokens.accessToken,
      linkedChildren: [],
      activeChildId: savedChildId,
      activeChild: null,
    };
  }

  getState = () => this.state;

  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };

  private notify() {
    this.listeners.forEach((l) => l());
  }

  setSession = (user: AuthUser, accessToken: string, refreshToken: string) => {
    setAuthTokens(accessToken, refreshToken, user.role);
    if (typeof window !== 'undefined') {
      localStorage.setItem('bomis_user', JSON.stringify(user));
    }
    this.state = {
      ...this.state,
      user,
      accessToken,
      refreshToken,
      isAuthenticated: true,
    };
    this.notify();
  };

  setLinkedChildren = (children: LinkedSibling[]) => {
    let activeId = this.state.activeChildId;
    // If no active child or active child not in list, default to first child (e.g. Aarav Patel)
    if (!activeId || !children.some((c) => c.id === activeId)) {
      activeId = children[0]?.id || null;
    }
    if (activeId) {
      setActiveChildCookie(activeId);
    }
    const activeChild = children.find((c) => c.id === activeId) || null;

    this.state = {
      ...this.state,
      linkedChildren: children,
      activeChildId: activeId,
      activeChild,
    };
    this.notify();
  };

  setActiveChildId = (childId: string) => {
    setActiveChildCookie(childId);
    const activeChild = this.state.linkedChildren.find((c) => c.id === childId) || null;
    this.state = {
      ...this.state,
      activeChildId: childId,
      activeChild,
    };
    this.notify();
  };

  logout = () => {
    clearAuthTokens();
    if (typeof window !== 'undefined') {
      localStorage.removeItem('bomis_user');
    }
    this.state = {
      user: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,
      linkedChildren: [],
      activeChildId: null,
      activeChild: null,
    };
    this.notify();
  };
}

export const authStore = new AuthStore();

export function useAuthStore<T>(selector: (state: AuthState) => T): T {
  return useSyncExternalStore(
    authStore.subscribe,
    () => selector(authStore.getState()),
    () => selector(authStore.getState())
  );
}
```

#### 4.5.3 Multi-Child Switcher Hook (`src/lib/auth/use-child-switcher.ts`)
```typescript
'use client';

import { useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuthStore, authStore } from './store';
import { peopleApi, LinkedSibling } from '../api/people';
import { queryKeys } from '../query/keys';
import { UserRole } from '@bomis/shared';

export function useChildSwitcher() {
  const queryClient = useQueryClient();
  const user = useAuthStore((s) => s.user);
  const activeChild = useAuthStore((s) => s.activeChild);
  const activeChildId = useAuthStore((s) => s.activeChildId);
  const linkedChildren = useAuthStore((s) => s.linkedChildren);

  const isParent = user?.role === UserRole.PARENT;

  // Automatically fetch linked siblings for parents
  const { data: siblings, isLoading } = useQuery({
    queryKey: queryKeys.people.siblings,
    queryFn: peopleApi.getLinkedSiblings,
    enabled: isParent,
  });

  useEffect(() => {
    if (siblings && siblings.length > 0) {
      authStore.setLinkedChildren(siblings);
    }
  }, [siblings]);

  const switchChild = (childId: string) => {
    if (childId === activeChildId) return;

    authStore.setActiveChildId(childId);

    // Invalidate all child-dependent queries so the dashboard immediately renders new child's data
    queryClient.invalidateQueries({ queryKey: ['attendance'] });
    queryClient.invalidateQueries({ queryKey: ['fees'] });
    queryClient.invalidateQueries({ queryKey: ['people', 'student'] });
  };

  return {
    children: linkedChildren,
    activeChild,
    activeChildId,
    switchChild,
    isLoading,
    hasMultipleChildren: linkedChildren.length > 1,
  };
}
```

---

### 4.6 Global Providers Wrapper (`src/app/layout.tsx`)

```tsx
import React from 'react';
import { QueryProvider } from '../lib/query/provider';
import './globals.css';

export const metadata = {
  title: 'BOMIS Sambalpur | Unified School Platform',
  description: 'Operating system for Birla Open Minds International School, Sambalpur',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#F4F8FA] text-[#0F2942] antialiased">
        <QueryProvider>
          {children}
        </QueryProvider>
      </body>
    </html>
  );
}
```

---

### 4.7 Route Rewrites in `apps/web/next.config.mjs`

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['@bomis/shared', '@bomis/ui'],
  reactStrictMode: true,
  async rewrites() {
    return [
      {
        source: '/api/v1/:path*',
        destination: `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'}/api/v1/:path*`,
      },
    ];
  },
};

export default nextConfig;
```

---

## 5. Verification Method

### 5.1 Independent Code & File Verification
1. Verify `apps/web/src/middleware.ts` exists and enforces `ROUTE_ROLE_PERMISSIONS` against edge cookies.
2. Verify `apps/web/src/lib/api/client.ts` uses the standard envelope `ApiResponse<T>` from `@bomis/shared/src/contracts/index.ts`.
3. Verify `apps/web/src/lib/api/auth.ts` calls `POST /api/v1/auth/otp/send`, `/otp/verify`, `/staff/login`, `/refresh`, and `/logout`.
4. Verify `apps/web/src/lib/auth/use-child-switcher.ts` calls `GET /api/v1/people/guardians/siblings` and exposes `switchChild()` which invalidates child queries.
5. Verify `apps/web/src/lib/query/provider.tsx` exports `QueryProvider` and wraps root `layout.tsx`.

### 5.2 Build & Typecheck Verification
When workers implement the files:
- Run `pnpm --filter @bomis/web typecheck` (or `tsc --noEmit -p apps/web/tsconfig.json`) to confirm zero TypeScript compilation errors.
- Run `pnpm --filter @bomis/web build` to verify successful Next.js 14 App Router static compilation and edge middleware generation.

### 5.3 Invalidation Conditions
- Any changes in NestJS response envelope structure in `packages/shared/src/contracts/index.ts`.
- Any modification of `UserRole` enum values in `packages/shared/src/enums/index.ts`.
- Any route path rename in `apps/api/src/modules/auth/auth.controller.ts`.
