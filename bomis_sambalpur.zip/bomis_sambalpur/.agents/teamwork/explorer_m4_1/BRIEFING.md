# BRIEFING — 2026-10-19T05:08:00Z

## Mission
Investigate and design Next.js 14 App Router architecture, route groups, role-based middleware, type-safe API client for NestJS /api/v1, TanStack Query setup, and Zustand auth store with multi-child selector for M4.

## 🔒 My Identity
- Archetype: explorer
- Roles: Web Portal Architecture & Data Layer Specialist
- Working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_1
- Original parent: 29096207-ec62-4de3-8de4-3261b9a78aa2
- Milestone: M4 (Web Portal Architecture & Data Layer)

## 🔒 Key Constraints
- Read-only investigation — do NOT implement directly in source tree apps/web
- Ground all designs in PROJECT.md, ORIGINAL_REQUEST.md, packages/shared, and existing NestJS API contracts
- Provide concrete interfaces, file layouts, middleware logic, API wrapper patterns, and TanStack Query configs
- Self-contained handoff with 5 components

## Current Parent
- Conversation ID: 29096207-ec62-4de3-8de4-3261b9a78aa2
- Updated: 2026-10-19T04:55:00Z

## Investigation State
- **Explored paths**:
  - `apps/api/src/modules/*` (all 12 controllers: auth, people, attendance, fees, academics, pulse, transport, safety, ai, admin, health)
  - `apps/api/src/common/interceptors/transform.interceptor.ts` (API response envelope)
  - `apps/api/src/common/filters/http-exception.filter.ts` (API error envelope)
  - `packages/shared/src/*` (contracts, enums, schemas, types, RBAC permissions)
  - `packages/ui/src/*` (brand tokens #0F2942 / #FF6B4A, roleBadgeColors, attendanceStatusStyles, tailwind preset)
  - `apps/web/*` (package.json, tsconfig.json, tailwind.config.ts, next.config.mjs, layout.tsx, page.tsx)
- **Key findings**:
  - NestJS API uniformly enforces `{ success: boolean, data: T | null, error?: ApiErrorDetail, timestamp: string, correlationId: string }`.
  - Auth endpoints: `POST /api/v1/auth/otp/send`, `POST /api/v1/auth/otp/verify`, `POST /api/v1/auth/staff/login`, `POST /api/v1/auth/refresh`, `POST /api/v1/auth/logout`.
  - Multi-child linking is supported via `GET /api/v1/people/guardians/siblings` returning linked children (Aarav Patel Grade 5A, Ananya Patel Grade 2A).
  - Web portal dependencies include `@tanstack/react-query`, `lucide-react`, `react-hook-form`, `zod`, `tailwind-merge`, `clsx`, `@bomis/shared`, `@bomis/ui`.
- **Unexplored areas**:
  - None within M4 architecture & data layer scope.

## Key Decisions Made
- Designed unified Next.js 14 App Router layout separating `(auth)` and `(dashboard)` route groups.
- Designed Edge Runtime compatible `middleware.ts` verifying JWT roles against `ROUTE_ROLE_PERMISSIONS` and syncing auth cookies.
- Designed type-safe HTTP client with automatic 401 refresh queue, correlation tracing, and envelope unwrap.
- Designed TanStack Query client, canonical query keys, and custom query/mutation hooks.
- Designed reactive auth store supporting JWT token rotation, user profile, and active child switcher with query invalidation.

## Artifact Index
- DISPATCH.md — Task assignment and requirements
- BRIEFING.md — Working memory and status
- progress.md — Liveness heartbeat and milestone tracking
- handoff.md — Final structured 5-component deliverable with architectural blueprint
