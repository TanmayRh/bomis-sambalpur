# Dispatch: Explorer 1 (M4 Web Portal Architecture & Data Layer)

- **Target Agent**: `teamwork_preview_explorer`
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_1`
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Parent Conversation ID**: `29096207-ec62-4de3-8de4-3261b9a78aa2`
- **Authoritative Request**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`
- **Project Master Specification**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`
- **API Contracts & Enums**: `packages/shared/src`

## Mission & Objectives
Investigate and design the core architecture for Milestone M4 (`apps/web` - Next.js 14 App Router Web Portal):
1. **App Router Structure & Routing**:
   - Route groups: `(auth)` for login (Mobile OTP for Parents, Email+Password for Staff), `(dashboard)` for role-tailored dashboards.
   - Role route protection: Next.js middleware / client route guards verifying JWT roles (`ADMIN`, `PRINCIPAL`, `TEACHER`, `ACCOUNTANT`, `PARENT`, `SUPER_ADMIN`).
2. **API Client & State Management**:
   - Type-safe API client consuming NestJS API (`apps/api` at `/api/v1`) using standardized envelope `{ success, data, error, timestamp, correlationId }`.
   - TanStack Query (`@tanstack/react-query`) provider and custom hooks for queries and mutations.
   - Auth store managing JWT access tokens, rotating refresh tokens, active user profile, and active child selector (for multi-child parents).
3. **Deliverable**:
   - Write structured exploration report in `handoff.md` with complete directory blueprint, file paths, concrete interface contracts, and implementation plan.
   - Send message back to parent (`29096207-ec62-4de3-8de4-3261b9a78aa2`) upon completion.


## 2026-10-19T04:53:40Z
You are Explorer 1 (M4 Web Portal Architecture & Data Layer).
Your Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_1
Project Root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur
Parent Conversation ID: 29096207-ec62-4de3-8de4-3261b9a78aa2

Read DISPATCH.md in your working directory first.
Read the authoritative request at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
Read the project master specification at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md

Investigate and design the Next.js 14 App Router structure, routing, route groups ((auth), (dashboard)), role-based route middleware, type-safe API client consuming NestJS API at /api/v1, TanStack Query provider, and auth store (JWT tokens, active user profile, active child selector).
Write handoff.md in your working directory and send a message back to parent (29096207-ec62-4de3-8de4-3261b9a78aa2) upon completion.
