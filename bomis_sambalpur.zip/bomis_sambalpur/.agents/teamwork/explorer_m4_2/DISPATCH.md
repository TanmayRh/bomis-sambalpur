# Dispatch: Explorer 2 (M4 Role Dashboards & Feature Workflows)

- **Target Agent**: `teamwork_preview_explorer`
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_2`
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Parent Conversation ID**: `29096207-ec62-4de3-8de4-3261b9a78aa2`
- **Authoritative Request**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`
- **Project Master Specification**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`
- **API Controllers & Services**: `apps/api/src/modules`

## Mission & Objectives
Investigate and design the 5 comprehensive role dashboards for Milestone M4 (`apps/web`):
1. **Admin Dashboard (`/admin`)**:
   - School metrics overview, user management, audit logs viewer with timestamp sort, bulk CSV ingestion interface, visitor pass logs.
2. **Principal Pulse Dashboard (`/principal`)**:
   - Real-time school pulse metrics (live attendance rate, fee collection rate, teacher leave status, 4 pilot buses fleet status).
3. **Teacher Dashboard (`/teacher`)**:
   - Rapid attendance grid (<10s batch recording for Grade 1–8 Section A), digital diary & homework creator with attachments, marks entry batch, timetable schedule with 1-click substitute view.
4. **Accountant Dashboard (`/accountant`)**:
   - Fee structures management, day-wise reconciliation summary, fee concession approval workflow, Razorpay payment ledger.
5. **Parent Portal (`/parent`)**:
   - Multi-child switcher (Aarav Patel & Ananya Patel), fee payment card with Razorpay checkout simulation, attendance calendar, digital diary view, live bus route with proximity alerts, child pickup OTP generator.
6. **Deliverable**:
   - Write structured specification report in `handoff.md` with complete component breakdown, forms (React Hook Form + Zod), data table designs, and state flow.
   - Send message back to parent (`29096207-ec62-4de3-8de4-3261b9a78aa2`) upon completion.


## 2026-10-19T04:53:42Z
You are Explorer 2 (M4 Role Dashboards & Feature Workflows).
Your Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m4_2
Project Root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur
Parent Conversation ID: 29096207-ec62-4de3-8de4-3261b9a78aa2

Read DISPATCH.md in your working directory first.
Read the authoritative request at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
Read the project master specification at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md

Investigate and design the 5 comprehensive role dashboards:
1. Admin (/admin): Metrics, user management, audit logs viewer, bulk CSV ingestion, visitor pass logs.
2. Principal Pulse (/principal): Real-time metrics (attendance, fees, teacher leave, fleet telemetry).
3. Teacher (/teacher): Rapid attendance grid (<10s), digital diary/homework, marks entry, timetable view.
4. Accountant (/accountant): Fee structures, day-wise reconciliation, concession approvals, payment ledger.
5. Parent (/parent): Multi-child switcher (Aarav & Ananya), fee checkout simulation, attendance calendar, live bus route, pickup OTP generator.
Write handoff.md in your working directory and send a message back to parent (29096207-ec62-4de3-8de4-3261b9a78aa2) upon completion.
