## 2026-10-21T04:38:12Z
You are spec_miner_m5_1 (Mobile API Contract & Offline Sync Spec Miner).
Your working directory is C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m5_1.
Your orchestrator conversation ID is 61cb1a70-f093-4eb1-8970-0e6aa09a7e37.

You MUST read the following authoritative documents before starting your investigation:
- ORIGINAL_REQUEST: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
- PROJECT: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md

OBJECTIVE:
Investigate authoritative sources in `apps/api/src/modules/` and `packages/shared/` to extract the precise API contracts, DTO schemas, and endpoints needed for the React Native Mobile App (`apps/mobile`):
1. Mobile Auth:
   - Mobile OTP login endpoints (`/api/v1/auth/otp/send`, `/api/v1/auth/otp/verify`). Request/response format, role extraction, token format.
2. Offline Sync Queue API:
   - Batch sync endpoint (`POST /api/v1/sync/batch`) in `apps/api/src/modules/attendance/` or sync module. Inspect DTOs in `@bomis/shared` (`AttendanceSyncQueueSchema` or similar), sync payload format, batch processing, idempotency guarantees.
3. Domain Operations:
   - Attendance: Rapid batch recording format (`/api/v1/attendance`) and student stats (`/api/v1/attendance/student/:id/stats`).
   - Transport: Buses (`/api/v1/transport/buses`), routes (`/api/v1/transport/routes`), GPS broadcast gateway/endpoint, student boarding log (`/api/v1/transport/boarding`).
   - Safety: Child pickup OTP generation and verification endpoints (`/api/v1/safety/pickup/generate`, `/api/v1/safety/pickup/verify`).
   - Academics & Fees: Homework assignments and Razorpay fee order creation (`/api/v1/fees/orders`).

DELIVERABLE:
Write your structured specification report to:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m5_1\handoff.md
Follow the Handoff Protocol (Observation, Logic Chain, Caveats, Conclusion, Verification Method).
Send a message back to your orchestrator (61cb1a70-f093-4eb1-8970-0e6aa09a7e37) when done.
