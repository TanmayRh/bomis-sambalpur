# Mobile API Contract & Offline Sync Specification Report (Milestone M5)

## Observation

Authoritative sources investigated across the monorepo:
- **Shared Contracts & Zod Schemas**:
  - `packages/shared/src/schemas/index.ts` (Lines 1-306)
  - `packages/shared/src/enums/index.ts` (Lines 1-170)
  - `packages/shared/src/contracts/index.ts` (Lines 1-33)
  - `packages/shared/src/rbac/index.ts` (Lines 1-189)
  - `packages/shared/src/types/index.ts` (Lines 1-82)
- **API Controllers & Services**:
  - `apps/api/src/main.ts` (Global prefix `api/v1`, port 4000)
  - `apps/api/src/modules/auth/auth.controller.ts` & `auth.service.ts`
  - `apps/api/src/modules/attendance/sync.controller.ts`, `attendance.controller.ts` & `attendance.service.ts`
  - `apps/api/src/modules/transport/transport.controller.ts` & `transport.service.ts`
  - `apps/api/src/modules/safety/safety.controller.ts` & `safety.service.ts`
  - `apps/api/src/modules/fees/fees.controller.ts` & `fees.service.ts`
  - `apps/api/src/modules/people/people.controller.ts` & `people.service.ts`
  - `apps/api/src/modules/academics/academics.controller.ts` & `academics.service.ts`
- **Architecture & Infrastructure Specifications**:
  - `docs/adr/0004-offline-first-sync-architecture.md` (Lines 1-90)
  - `apps/api/src/database/seed-fixtures.ts` (Seed accounts & symbolic IDs)
  - `docs/postman/bomis_postman_collection.json` (Automated API tests)
  - `apps/api/src/adversarial-m3-round2.spec.ts` (Edge cases & security rules)

### Standard Response Envelope (`ApiResponse<T>`)
Every REST endpoint (except streamable binary files) returns data wrapped in:
```typescript
{
  success: boolean;
  data: T | null;
  error?: {
    code: string;
    message: string;
    details?: any;
  } | null;
  timestamp: string;      // ISO 8601 UTC
  correlationId: string;  // UUID or string from x-correlation-id header
}
```

---

## Features Discovered

| # | Category | Feature | Description | Inputs | Outputs | Error Behavior | Discovered Via |
|---|----------|---------|-------------|--------|---------|----------------|----------------|
| 1 | Mobile Auth | Send Mobile OTP | Dispatches 6-digit OTP (mock `123456` in dev/test) to Indian phone with 300s TTL | `POST /api/v1/auth/otp/send`<br>`{ phone: string, schoolId?: string, purpose?: string }` | `{ expiresInSeconds: 300, message: "OTP sent successfully" }` | 400 `VALIDATION_FAILED` if phone fails regex `^\+91[6-9]\d{9}$` | `apps/api/src/modules/auth/auth.controller.ts:11` |
| 2 | Mobile Auth | Verify Mobile OTP | Verifies OTP for Parents & Students; returns JWT access + refresh token pair | `POST /api/v1/auth/otp/verify`<br>`{ phone: string, code: string }` (or `otp`) | `{ accessToken: string, refreshToken: string, user: { id, email, phone, role, schoolId, firstName, lastName } }` | 401 `UNAUTHORIZED` if OTP invalid/expired; 401 `USER_NOT_FOUND` if phone not registered | `apps/api/src/modules/auth/auth.controller.ts:18` |
| 3 | Mobile Auth | Staff Credential Login | Authenticates Teachers, Drivers, Principals via email & bcrypt password | `POST /api/v1/auth/staff/login`<br>`{ email: string, password: string }` | Token pair + user object | 400 `VALIDATION_FAILED` if fields missing; 401 `UNAUTHORIZED` for bad credentials | `apps/api/src/modules/auth/auth.controller.ts:25` |
| 4 | Mobile Auth | Token Refresh | Rotates 7-day refresh token with family tracking for fresh 15-min access token | `POST /api/v1/auth/refresh`<br>`{ refreshToken: string }` | Token pair + user object | 400 `VALIDATION_FAILED` if missing; 401 `UNAUTHORIZED` if expired, revoked, or non-existent user | `apps/api/src/modules/auth/auth.controller.ts:32` |
| 5 | Mobile Auth | Session Logout | Revokes active session and blacklists refresh token in Redis for 7 days | `POST /api/v1/auth/logout`<br>Header: `Authorization: Bearer <token>`<br>`{ refreshToken?: string }` | `{ message: "Session revoked successfully" }` | 401 `UNAUTHORIZED` if access token missing/invalid | `apps/api/src/modules/auth/auth.controller.ts:38` |
| 6 | Offline Sync | Outbox Batch Sync | Deduplicates idempotency keys and flushes queued offline events to DB | `POST /api/v1/sync/batch`<br>Roles: ADMIN, SUPER_ADMIN, TEACHER, TRANSPORT_STAFF, PARENT<br>`{ events: OfflineSyncEvent[] }` | `{ syncedCount: number, results: Array<{ id: string, status: "SYNCED" \| "IDEMPOTENT_SKIPPED" }> }` | 400 `VALIDATION_FAILED` if events empty; 401 `UNAUTHORIZED` if unauthenticated | `apps/api/src/modules/attendance/sync.controller.ts:20` |
| 7 | Attendance | Rapid Batch Attendance | Records whole-class attendance in <10s by applying default status with exception list | `POST /api/v1/attendance`<br>Roles: TEACHER, ADMIN, SUPER_ADMIN, PRINCIPAL<br>`{ date: "YYYY-MM-DD", classId?: string, sectionId?: string, defaultStatus?: AttendanceStatus, exceptions?: Array<{ studentId, status, remarks? }> }` | `{ processedCount: number, presentCount: number, absentCount: number, halfDayCount: number, date: string, status: "RECORDED" }` | 400 `VALIDATION_FAILED` if date missing or invalid | `apps/api/src/modules/attendance/attendance.controller.ts:22` |
| 8 | Attendance | Granular Batch Attendance | Raw student-by-student attendance submission | `POST /api/v1/attendance/batch`<br>Roles: TEACHER, ADMIN, PRINCIPAL<br>`{ date: string, schoolId?: string, sectionId?: string, records: Array<{ studentId, status, remarks? }> }` | `{ processedCount: number, date: string }` | 400 `VALIDATION_FAILED` if records empty | `apps/api/src/modules/attendance/attendance.controller.ts:30` |
| 9 | Attendance | Monthly Attendance Stats | Cumulative stats using CBSE formula `((present + 0.5*half) / total) * 100`; alerts if <75% | `GET /api/v1/attendance/students/:id?month=10&year=2026`<br>Roles: PARENT, STUDENT, TEACHER, ADMIN | `{ studentId, month, year, totalWorkingDays, presentDays, absentDays, halfDays, percentage, lowAttendanceAlert, cbseCompliant }` | 404 `NOT_FOUND` if student doesn't exist | `apps/api/src/modules/attendance/attendance.controller.ts:38` |
| 10 | Attendance | Query Attendance Records | Filter attendance by date, class, or student | `GET /api/v1/attendance?date=...&studentId=...` | Array of attendance records | 401 `UNAUTHORIZED` | `apps/api/src/modules/attendance/attendance.controller.ts:56` |
| 11 | Attendance | Submit Leave Application | Submits student or staff casual/medical leave request | `POST /api/v1/attendance/leaves`<br>`{ fromDate, toDate, reason, leaveType?, studentId?, staffId? }` | `{ leaveId, status: "PENDING", message: "Leave application submitted successfully" }` | 400 `VALIDATION_FAILED` if dates or reason missing | `apps/api/src/modules/attendance/attendance.controller.ts:69` |
| 12 | Transport | List Bus Routes | Returns 4 arterial routes with GPS coordinates and stop sequences | `GET /api/v1/transport/routes`<br>Roles: ADMIN, PRINCIPAL, TRANSPORT_STAFF, PARENT, TEACHER | Array of routes `{ id, name, code, startPoint, endPoint, stops: [{ id, name, lat, lng, order }] }` | 401 `UNAUTHORIZED` | `apps/api/src/modules/transport/transport.controller.ts:20` |
| 13 | Transport | List Fleet Buses | Returns 4 pilot buses with OD-15 license plates and real-time telemetry | `GET /api/v1/transport/buses`<br>Roles: ADMIN, PRINCIPAL, TRANSPORT_STAFF, PARENT | Array of buses `{ id, registrationNumber, busNumber, capacity, model, status, currentRouteId, driverStaffId, telemetry }` | 401 `UNAUTHORIZED` | `apps/api/src/modules/transport/transport.controller.ts:34` |
| 14 | Transport | Record Boarding Scan | Logs student QR boarding/deboarding at bus stop | `POST /api/v1/transport/boarding/scan`<br>Roles: TRANSPORT_STAFF, ADMIN<br>`{ busId, studentId, stopId, action: "BOARD" \| "DEBOARD" \| "BOARDED" \| "DEBOARDED", lat, lng, timestamp? }` | `{ scanId, busId, studentId, action, stopId, message: "Boarding scan registered successfully" }` | 400 `VALIDATION_FAILED` if busId, studentId, or action missing | `apps/api/src/modules/transport/transport.controller.ts:47` |
| 15 | Transport | Broadcast GPS Telemetry | Driver mini-app telemetry ping; emits geofence proximity alerts | `POST /api/v1/transport/gps-ping`<br>Roles: TRANSPORT_STAFF, ADMIN<br>`{ busId?: string, vehicleId?: string, routeId?: string, latitude: number, longitude: number, speed?: number, heading?: number, timestamp?: string }` | `{ recorded: true, busId: string, proximityAlertsSent: 1 }` | 401 `UNAUTHORIZED` | `apps/api/src/modules/transport/transport.controller.ts:55` |
| 16 | Safety | Verify Child Pickup | Verifies single-use 6-digit OTP at campus gate for afternoon dispersal | `POST /api/v1/safety/pickup/verify`<br>Roles: ADMIN, PRINCIPAL, TRANSPORT_STAFF<br>`{ studentId: string, pickupOtp: string, gateNumber: string }` | `{ authorized: boolean, studentId, guardianId, gateNumber, verifiedAt, dismissalTime, message }` | 400 `VALIDATION_FAILED` if OTP is not 6 digits (`/^\d{6}$/`) | `apps/api/src/modules/safety/safety.controller.ts:41` |
| 17 | Safety | Generate Pickup OTP (Service) | Issues dynamic 6-digit OTP with 30-min expiry for parent app | Service method: `generatePickupAuthorization(studentId, guardianId, customOtp?)` | `{ id, student_id, guardian_id, otp, status: "ACTIVE", expires_at, created_at }` | Status switches to `USED` on verify; `EXPIRED` after 30 min | `apps/api/src/modules/safety/safety.service.ts:202` |
| 18 | Safety | Create Visitor Pass | Pre-approves visitor with time-limited QR gate pass | `POST /api/v1/safety/visitors`<br>`{ visitorName, visitorPhone, purpose, hostStaffId, expectedDate }` | `{ passId, qrCodeData, visitorName, status: "PRE_APPROVED" }` | 400 `VALIDATION_FAILED` | `apps/api/src/modules/safety/safety.controller.ts:21` |
| 19 | Safety | Zero-Log Bullying Report | Anonymous DPDP incident report; completely unlinked from user identity/IP | `POST /api/v1/safety/incidents/anonymous`<br>Public route<br>`{ incidentType, grade, location, description, timestamp? }` | `{ trackingCode: "INC-XXXXXX", status: "RECEIVED", message, timestamp }` | 400 `VALIDATION_FAILED` if description < 10 chars | `apps/api/src/modules/safety/safety.controller.ts:55` |
| 20 | Fees | Create Razorpay Order | Creates payment order in paise; enforces mandatory `Idempotency-Key` header | `POST /api/v1/fees/orders`<br>Header: `idempotency-key: <uuid>`<br>Roles: PARENT, ADMIN, ACCOUNTANT<br>`{ studentId, installmentNumber, amountPaise, paymentMethod? }` | `{ razorpayOrderId: "order_...", amount: number, amountPaise: number, currency: "INR", status: "created", studentId, installmentNumber, paymentMethod, createdAt }` | 400 `MISSING_IDEMPOTENCY_KEY` if header missing; 409 `IDEMPOTENCY_CONFLICT` if payload changes for same key | `apps/api/src/modules/fees/fees.controller.ts:48` |
| 21 | Fees | Get Fee Structures | Lists term, annual, activity, transport fee slabs for student's grade | `GET /api/v1/fees/structures?grade=5&academicYear=2026-2027`<br>Roles: PARENT, ADMIN, ACCOUNTANT | Array of structures `{ id, grade, academicYear, category, totalAmount, frequency }` | 401 `UNAUTHORIZED` | `apps/api/src/modules/fees/fees.controller.ts:24` |
| 22 | Fees | Download Tax Receipt | Retrieves fee tax receipt metadata and download URL | `GET /api/v1/fees/receipts/:id`<br>Roles: PARENT, ADMIN, ACCOUNTANT | `{ id, receiptId, receiptNumber, studentId, amount, currency: "INR", status: "SUCCESS", downloadUrl, createdAt }` | 404 `NOT_FOUND` if invalid receipt ID | `apps/api/src/modules/fees/fees.controller.ts:70` |
| 23 | People | Parent Linked Siblings | Fetches all enrolled children linked to the authenticated parent account | `GET /api/v1/people/guardians/siblings`<br>Roles: PARENT, ADMIN<br>CurrentUser context | Array of students: `[{ id, admissionNumber, rollNumber, firstName, lastName, grade, section, classId, sectionId, bloodGroup, emergencyContact, relationship }]` | Zero leakage: returns `[]` for unlinked guardian | `apps/api/src/modules/people/people.controller.ts:38` |
| 24 | People | Student Profile Detail | Retrieves decrypted student profile with DPDP medical fields | `GET /api/v1/people/students/:id`<br>Roles: PARENT, TEACHER, ADMIN | Detailed student object with decrypted blood group and emergency contact | 404 `NOT_FOUND` | `apps/api/src/modules/people/people.controller.ts:60` |
| 25 | Academics | Homework & Digital Diary Schema | Canonical contract for homework assignments | `@bomis/shared` schema `CreateHomeworkSchema`<br>`{ classId: uuid, sectionId: uuid, subjectId: uuid, title: string, description: string, dueDate: "YYYY-MM-DD", attachments?: url[] }` | Model `Homework` & `HomeworkSubmission` with statuses `ASSIGNED`, `SUBMITTED`, `REVIEWED`, `RESUBMISSION_REQUESTED` | Zod validation errors on non-UUID or invalid date format | `packages/shared/src/schemas/index.ts:198` |

---

## Edge Cases

| # | Feature | Input | Observed Behavior |
|---|---------|-------|-------------------|
| 1 | Mobile OTP Send | Phone `9876543210` (missing `+91`) or `+915999999999` (non-Indian mobile digit) | Fails regex `/^\+91[6-9]\d{9}$/`. Throws 400 Bad Request with `{ code: "VALIDATION_FAILED", message: "Invalid Indian mobile number (+91XXXXXXXXXX)" }`. |
| 2 | Mobile OTP Verify | Valid phone, but wrong OTP (e.g. `000000`) or expired TTL (>300s) | Throws 401 Unauthorized `{ code: "UNAUTHORIZED", message: "Invalid or expired OTP" }`. Redis key is not deleted. |
| 3 | Mobile OTP Verify | Unregistered phone number (e.g. `+919999999999`) with correct OTP | Throws 401 Unauthorized `{ code: "USER_NOT_FOUND", message: "No registered account found for mobile number [+919999999999]" }`. |
| 4 | Offline Sync Batch | Empty `events: []` payload | Throws 400 Bad Request `{ code: "VALIDATION_FAILED", message: "At least one sync event is required" }`. |
| 5 | Offline Sync Batch | Replaying identical event with same `idempotencyKey` | Second execution detects key `sync:${idempotencyKey}` in Redis and returns `{ id, status: "IDEMPOTENT_SKIPPED" }` without re-mutating database. |
| 6 | Offline Sync Batch | Mixed batch containing `ATTENDANCE_BATCH` and `BOARDING_SCAN` | Processes each event sequentially, marking each event either `SYNCED` or `IDEMPOTENT_SKIPPED`, and caches all processed keys for 86400s (24 hours). |
| 7 | Rapid Attendance | Empty exception array `exceptions: []` | Entire roster in class/section is recorded with `defaultStatus` (defaults to `PRESENT`). `processedCount` equals roster count; `presentCount` equals roster count. |
| 8 | Rapid Attendance | Exception with unknown symbolic ID | `resolveId` safely falls back to input string; record is registered for that student identifier. |
| 9 | Monthly Stats | Student with 0 recorded attendance records in requested month | Returns `{ totalWorkingDays: 0, presentDays: 0, absentDays: 0, halfDays: 0, percentage: 0, lowAttendanceAlert: false, cbseCompliant: true }`. Avoids division by zero (NaN) by returning 0%. |
| 10 | Monthly Stats | Attendance percentage exactly 74.99% (below CBSE 75% bar) | Formula `((present + 0.5 * half) / total) * 100` computes percentage; sets `lowAttendanceAlert: true` and `cbseCompliant: false`. |
| 11 | Child Pickup Verify | Pickup OTP not exactly 6 digits (e.g. `12345`, `1234567`, `abcdef`) | Throws 400 Bad Request `{ code: "VALIDATION_FAILED", message: "Pickup OTP must be exactly 6 digits" }`. |
| 12 | Child Pickup Verify | Replay of already verified OTP (`status === 'USED'`) at same or different gate | Returns `{ authorized: false, studentId, message: "Pickup authorization has already been used" }`. Prevents duplicate pickup child-theft vulnerabilities. |
| 13 | Child Pickup Verify | Expired authorization (>30 minutes after creation) | Status transitions to `EXPIRED`; returns `{ authorized: false, studentId, message: "Pickup OTP has expired" }`. |
| 14 | Child Pickup Verify | Wrong OTP entered on active authorization | Returns `{ authorized: false, studentId, message: "Invalid pickup OTP" }`. Crucially, authorization status remains `ACTIVE` so guardian can retry with the correct code. |
| 15 | Child Pickup Verify | Student with no recorded authorization | Returns `{ authorized: false, studentId, message: "No active pickup authorization found for student" }`. |
| 16 | Fee Razorpay Order | Missing `idempotency-key` HTTP header | Throws 400 Bad Request `{ code: "MISSING_IDEMPOTENCY_KEY", message: "Idempotency-Key header is mandatory for payment order creation" }`. |
| 17 | Fee Razorpay Order | Identical `idempotency-key` with altered payload amount or installment | SHA-256 hash mismatch detects payload tampering; throws 409 Conflict `{ code: "IDEMPOTENCY_CONFLICT", message: "Conflicting request payload for existing Idempotency-Key" }`. |
| 18 | Fee Razorpay Order | Identical `idempotency-key` with identical payload | Returns original cached Razorpay order object from Redis with identical `razorpayOrderId`. |
| 19 | Linked Siblings | Authenticated parent with 2 enrolled children (Patel family) | Returns array of 2 students (Aarav in Grade 5A and Ananya in Grade 2A) with decrypted emergency contacts and blood groups. |
| 20 | Linked Siblings | Unlinked guardian / parent with no enrolled children | Returns empty array `[]`. Zero cross-tenant leakage of other students. |
| 21 | Anonymous Incident | Description shorter than 10 characters | Throws 400 Bad Request `{ code: "VALIDATION_FAILED", message: "Please provide a detailed incident description (at least 10 characters)" }`. |
| 22 | Refresh Token | Forged or tampered signature on JWT refresh token | Throws 401 Unauthorized `{ code: "UNAUTHORIZED", message: "Invalid or expired refresh token: invalid signature" }`. |
| 23 | Refresh Token | Ghost user ID encoded in valid JWT signature | Throws 401 Unauthorized `{ code: "USER_NOT_FOUND", message: "User associated with refresh token does not exist" }`. Never falls back to default admin. |

---

## Logic Chain

1. **Mobile Multi-Role Authentication Pipeline**:
   - The React Native mobile app (`apps/mobile`) targets 4 distinct user roles: Parents (`PARENT`), Students (`STUDENT`), Teachers (`TEACHER`), and Transport Drivers (`TRANSPORT_STAFF`).
   - Parents and Students authenticate via `POST /api/v1/auth/otp/send` and `POST /api/v1/auth/otp/verify`. In development/test mode, the deterministic mock OTP is `'123456'`.
   - Teachers and Drivers authenticate via `POST /api/v1/auth/staff/login` using email and password (e.g. `arundhati.dash@bomis-sambalpur.edu.in` / `Admin@Sambalpur2026`).
   - Successful authentication yields a standardized token pair: a 15-minute access token (`accessToken`) and a 7-day refresh token (`refreshToken`).
   - The decoded JWT payload contains `{ sub, id, userId, email, phone, role, schoolId, jti }`. The mobile app extracts `user.role` to conditionally render the appropriate role dashboard.
   - Token renewal is handled via `POST /api/v1/auth/refresh`, and session termination via `POST /api/v1/auth/logout`.

2. **Offline-First Synchronization Architecture (ADR 0004)**:
   - For teachers marking morning attendance in network dead zones and drivers scanning bus boarding QR codes along remote routes (e.g. Burla/Hirakud), network connectivity is intermittent.
   - The mobile client uses an offline SQLite outbox table (`local_sync_outbox`) structured as:
     `id (UUID)`, `action_type ('ATTENDANCE_BATCH' | 'BOARDING_SCAN' | 'GPS_PING')`, `endpoint`, `method`, `payload (JSON)`, `idempotency_key ('idemp-<uuid>')`, `created_at (ms)`, `status ('PENDING' | 'SYNCING' | 'RESOLVED' | 'FAILED')`.
   - When a teacher marks attendance or a driver scans a student pass, the transaction is written immediately to local SQLite, updating the UI optimistically in <10ms.
   - Upon network restoration, the sync engine drains up to 25 pending records in FIFO order via `POST /api/v1/sync/batch`.
   - The backend checks each event's `idempotencyKey` against Redis (`sync:${key}`) with 24-hour TTL:
     - If previously processed, the server skips re-insertion and returns `{ id, status: "IDEMPOTENT_SKIPPED" }`.
     - If new, the server applies the mutation to the database and returns `{ id, status: "SYNCED" }`.
   - The client marks acknowledged events as resolved and purges them from the local outbox.

3. **Attendance Rapid Batch & Statistical Compliance**:
   - Fast classroom submission uses `POST /api/v1/attendance`: the teacher selects a section and date, with all students defaulting to `PRESENT` and only absent/late exceptions transmitted.
   - Monthly statistics endpoint `GET /api/v1/attendance/students/:id?month=<M>&year=<Y>` calculates attendance using CBSE rules:
     `Attendance % = ((Present Days + 0.5 * Half Days) / Total Working Days) * 100`.
   - If percentage falls below 75%, `lowAttendanceAlert: true` and `cbseCompliant: false` are returned, prompting a warning banner in the Parent and Student mobile dashboards.

4. **Transport Fleet Telemetry & Student Boarding**:
   - Drivers broadcast live GPS coordinates via `POST /api/v1/transport/gps-ping` every 5–10 seconds. The server updates the vehicle's telemetry record and triggers geofence proximity alerts ("bus is 5 minutes away").
   - Students board or deboard by displaying dynamic QR codes, which the driver scans using the camera in the driver mini-app. Scans hit `POST /api/v1/transport/boarding/scan` (or are queued in SQLite if offline).
   - Parents track the 4 pilot buses via `GET /api/v1/transport/buses` and view route maps via `GET /api/v1/transport/routes`.

5. **Child Pickup Security & Single-Use Dismissal OTP**:
   - For afternoon campus dispersal, parents generate a dynamic 6-digit dismissal OTP (valid for 30 minutes) on their mobile screen.
   - Campus security or gatekeepers verify the code via `POST /api/v1/safety/pickup/verify`.
   - The backend enforces strict single-use semantics: the authorization record transitions from `ACTIVE` to `USED`. Any subsequent attempt at Gate 1, Gate 2, or Main Gate is rejected with `"Pickup authorization has already been used"`.
   - Expired authorizations (>30 minutes) transition to `EXPIRED` and are rejected with `"Pickup OTP has expired"`.

6. **Academics & Financial Safety**:
   - Homework assignments follow `CreateHomeworkSchema` in `@bomis/shared`. Teachers publish homework with attachments; students view assignments and submit files; parents monitor due dates.
   - Parents create Razorpay installment fee orders via `POST /api/v1/fees/orders`. The mandatory `idempotency-key` header protects against accidental duplicate charges if a parent taps "Pay Now" multiple times on a flaky cellular connection.
   - Upon successful payment, tax receipts are accessible via `GET /api/v1/fees/receipts/:id`.

7. **Multi-Child Sibling Linking**:
   - In `GET /api/v1/people/guardians/siblings`, the server resolves the authenticated parent's `guardian_id` and queries linked students.
   - A single parent account (e.g. Dr. Rajesh Kumar Patel) seamlessly toggles between siblings (Aarav in Grade 5A and Ananya in Grade 2A) within the mobile app, with complete data isolation from other families.

---

## Caveats

1. **Student Stats Endpoint URL Structure**:
   - The dispatch prompt referenced `/api/v1/attendance/student/:id/stats`.
   - Authoritative codebase ground truth (`apps/api/src/modules/attendance/attendance.controller.ts:38` and `docs/postman/bomis_postman_collection.json:652`) exposes this functionality at:
     `GET /api/v1/attendance/students/:id?month=10&year=2026`.
   - The mobile API client should call `GET /api/v1/attendance/students/:id` with `month` and `year` query parameters.

2. **Pickup OTP Generation Route vs Service Method**:
   - `SafetyService` contains the full business method `generatePickupAuthorization(studentId, guardianId, customOtp?)` which creates a 30-minute `ACTIVE` authorization record.
   - Currently, `SafetyController` exposes `POST /api/v1/safety/pickup/verify`, while in the Web parent portal (`PickupOtpCard`), the OTP is deterministically derived or generated on the client and verified at the gate.
   - For the mobile app, the client can display the child dismissal OTP directly (default mock `482910` or hash-derived 6-digit code with 30-min timer), which matches the seed fixtures and passes `POST /api/v1/safety/pickup/verify`.

3. **Transport Real-Time Protocol**:
   - The system utilizes HTTP REST polling/push (`POST /api/v1/transport/gps-ping` and `GET /api/v1/transport/buses`) for vehicle telemetry and proximity alerts. A dedicated WebSocket gateway (`@WebSocketGateway`) is not required for the mobile app, as the REST telemetry endpoints are optimized for cellular network resilience and offline sync.

4. **CBSE Attendance Working Days Division-by-Zero**:
   - When querying a month with zero recorded school days, the backend returns `0%` with `lowAttendanceAlert: false`. The mobile UI should display `"No working days recorded"` rather than an alarming red alert.

---

## Conclusion

The authoritative NestJS backend (`apps/api`) and shared library (`@bomis/shared`) provide a complete, well-tested, and robust set of API contracts for the React Native Mobile App (`apps/mobile`):
- **Authentication**: Seamless dual auth with Indian mobile OTP regex validation, JWT bearer tokens, and role-based access.
- **Offline Sync**: Durable SQLite outbox pattern conforming to ADR 0004 with 24-hour Redis idempotency deduplication.
- **Rapid Operations**: Sub-10s attendance batches, student statistics with CBSE 75% alerting, and student boarding logs.
- **Safety & Transport**: Real-time bus fleet monitoring, geofence alerts, pre-approved visitor passes, and replay-proof single-use child dismissal OTPs.
- **Financial Rigor**: Idempotent Razorpay order generation preventing duplicate fee deductions.

The specifications documented above provide everything required for the mobile frontend engineer to implement `apps/mobile`.

---

## Verification Method

1. **TypeScript Schema & Type Congruence**:
   Inspect canonical Zod schemas in `packages/shared/src/schemas/index.ts` and ensure all mobile request payloads match their corresponding types (`MobileOtpRequest`, `VerifyOtp`, `OfflineSyncBatch`, `RapidAttendanceBatch`, `CreateRazorpayOrder`, `StudentBoardingLog`, `VerifyChildPickup`).

2. **API Route Inspection**:
   Inspect route decorators and paths across:
   - `apps/api/src/modules/auth/auth.controller.ts`
   - `apps/api/src/modules/attendance/sync.controller.ts`
   - `apps/api/src/modules/attendance/attendance.controller.ts`
   - `apps/api/src/modules/transport/transport.controller.ts`
   - `apps/api/src/modules/safety/safety.controller.ts`
   - `apps/api/src/modules/fees/fees.controller.ts`
   - `apps/api/src/modules/people/people.controller.ts`

3. **Adversarial & Unit Test Suite Coverage**:
   Inspect `apps/api/src/adversarial-m3-round2.spec.ts` and `apps/api/src/modules/attendance/attendance.service.spec.ts` for exact behavioral assertions on:
   - Single-use child pickup OTP invalidation across multiple gates
   - Offline batch sync idempotency skipping
   - CBSE weighted half-day attendance formula calculations
   - Razorpay mandatory `Idempotency-Key` header enforcement
   - Multi-child sibling isolation under `getLinkedSiblings`

4. **Postman Collection Verification**:
   Inspect `docs/postman/bomis_postman_collection.json` under folders `01_Auth`, `03_Attendance`, `04_Fees`, `06_Transport`, and `07_Safety` to confirm exact request bodies, HTTP methods, headers, and query parameters.
