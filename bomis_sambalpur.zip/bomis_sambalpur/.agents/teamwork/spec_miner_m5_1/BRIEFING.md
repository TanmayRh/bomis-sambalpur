# BRIEFING — 2026-10-21T05:00:00Z

## Mission
Extract precise API contracts, DTO schemas, and endpoints from backend (`apps/api/src/modules/`) and `@bomis/shared` (`packages/shared/`) needed for the React Native Mobile App (`apps/mobile`), covering Mobile Auth, Offline Sync Queue, Attendance, Transport & GPS, Safety/Pickup OTP, and Academics & Fees.

## 🔒 My Identity
- Archetype: Specification Miner
- Roles: Mobile API Contract & Offline Sync Spec Miner
- Working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m5_1
- Original parent: 61cb1a70-f093-4eb1-8970-0e6aa09a7e37
- Milestone: M5 - Mobile App Implementation

## 🔒 Key Constraints
- Read-only probe; do NOT implement anything.
- Probe authoritative sources in `apps/api/src/modules/` and `packages/shared/`.
- Document all discovered features, edge cases, error conditions, and DTO schemas.
- Follow Handoff Protocol (Observation, Logic Chain, Caveats, Conclusion, Verification Method) and Specification Miner tables.

## Current Parent
- Conversation ID: 61cb1a70-f093-4eb1-8970-0e6aa09a7e37
- Updated: 2026-10-21T05:00:00Z

## Task Summary
- **What to build**: Mobile API specification report for apps/mobile
- **Success criteria**: Exhaustive extraction of endpoints, request/response formats, DTOs, offline sync queue mechanics, authentication flow, and domain endpoints.
- **Interface contracts**: PROJECT.md, packages/shared, apps/api
- **Code layout**: packages/shared, apps/api, apps/mobile

## Key Decisions Made
- Prioritize backend source code (`apps/api/src/modules/*`) and `@bomis/shared` as primary ground-truth contracts.
- Documented note on student stats URL: `GET /api/v1/attendance/students/:id?month=10&year=2026` is the authoritative route.
- Documented ADR 0004 offline SQLite outbox pattern (`local_sync_outbox`) and backend batch sync endpoint (`POST /api/v1/sync/batch`).

## Artifact Index
- DISPATCH.md — Dispatch assignment
- progress.md — Liveness heartbeat and progress
- handoff.md — Final specification report
