## 2026-10-22T10:54:37Z
You are worker_m6_adversarial_hardening.
Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m6_adversarial_hardening
DISPATCH.md: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m6_adversarial_hardening\DISPATCH.md
Authoritative Sources:
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md (MANDATORY: read first!)
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\challenger_m6_1\challenge.md
- C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\challenger_m6_2\challenge.md

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Write Ownership:
- apps/api/src/modules/auth/auth.service.ts
- apps/api/src/modules/fees/fees.service.ts
- apps/api/src/modules/transport/transport.service.ts
- apps/api/src/adversarial-m6.spec.ts

Tasks:
1. In apps/api/src/modules/auth/auth.service.ts:
   - In rotateRefreshToken(refreshTokenString): Check await this.redis.get("blacklist:" + refreshTokenString). If blacklisted, throw UnauthorizedException({ code: 'TOKEN_REVOKED', message: 'Refresh token has been revoked' }).
   - In sendOtp(phone): Sliding window rate limit via Redis key otp_count:${phone}. If requests in 15m > 5, throw HttpException({ code: 'RATE_LIMIT_EXCEEDED', message: 'Too many OTP requests. Please wait 15 minutes.' }, 429).
   - In verifyOtp(phone, otp): Failed attempt lockout via Redis key otp_failed:${phone}. If failed attempts >= 5, lock out for 15m and throw HttpException({ code: 'ACCOUNT_LOCKED', message: 'Too many failed OTP attempts. Account locked for 15 minutes.' }, 429). On success, delete key.
2. In apps/api/src/modules/fees/fees.service.ts:
   - In processWebhook(rawBody, signature):
     * Check timestamp freshness: if rawBody?.created_at, verify Math.floor(Date.now() / 1000) - Number(rawBody.created_at) <= 300. If expired (> 300s or < -60s), throw BadRequestException({ code: 'WEBHOOK_TIMESTAMP_EXPIRED', message: 'Webhook timestamp expired' }).
     * Duplicate event check: if Redis has webhook_event:${paymentEntity?.id || rawBody?.event_id}, return { processed: true, duplicate: true, message: 'Event already processed' }. Otherwise cache it with TTL 86400s.
     * Constant-time signature verification: Buffer.from(expectedSignature).length === Buffer.from(signature).length && crypto.timingSafeEqual(Buffer.from(expectedSignature), Buffer.from(signature)).
     * If order is not found, throw NotFoundException({ code: 'ORDER_NOT_FOUND', message: 'Unrecognized order ID in webhook' }) instead of assigning to Aarav Patel.
   - In createRazorpayOrder():
     * Acquire lock lock:fees:idemp:${idempotencyKey} during order generation.
3. In apps/api/src/modules/transport/transport.service.ts:
   - In recordGpsPing(payload):
     * Calculate spherical Haversine distance from (payload.latitude, payload.longitude) to BOMIS Sambalpur campus (lat: 21.4984, lng: 83.9781).
     * If distance <= 1.5 km, proximityAlertsSent: 1; if distance > 1.5 km, proximityAlertsSent: 0.
4. In apps/api/src/adversarial-m6.spec.ts:
   - Populate this file with comprehensive Jest test suites verifying all the above Tier 5 adversarial hardenings (session revocation on refresh, webhook replay & timestamp rejection, OTP flood & lockout, Haversine distance calculation, and idempotency lock).
5. Document all changes and verified test assertions in handoff.md.
6. Send completion report back to orchestrator.
