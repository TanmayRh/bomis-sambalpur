# Monorepo, Shared Packages & Schema Specification Analysis
**Project**: Birla Open Minds International School (BOMIS), Sambalpur  
**Document**: Specification Survey Analysis (Phase 0 Foundation)  
**Author**: Monorepo & Schema Spec Miner (`spec_miner_survey_1`)  
**Target Workspaces**: `/apps/api`, `/apps/web`, `/apps/mobile`, `/packages/shared`, `/packages/ui`, `/infra`, `/docs`  

---

## 1. Executive Summary & Monorepo Architecture Blueprint

The BOMIS Sambalpur Unified School Platform is a multi-tenant, production-grade school operating system designed to replace fragmented legacy tools (WhatsApp, paper diaries, spreadsheets, physical fee receipts) with a centralized TypeScript monorepo managed via **Turborepo** and **pnpm workspaces**.

### 1.1 Architecture Goals
1. **Strict Type Congruence**: End-to-end type safety spanning backend domain models, API payloads, Next.js web application, and React Native (Expo) mobile apps through `@bomis/shared`.
2. **Regulatory DPDP Compliance**: Complete alignment with the Digital Personal Data Protection (DPDP) Act 2023, including automated 90-day soft-delete retention schedules, immutable cryptographic erasure auditing, granular consent ledger, and AES-256-GCM field-level encryption for sensitive health/financial/Aadhaar data.
3. **Multi-Tenant Row-Level Security (RLS)**: Strict tenant isolation keyed by `school_id` enforced both at the application ORM layer and at the PostgreSQL database level using PostgreSQL Row-Level Security (`current_setting('app.current_school_id')`).
4. **Resilient Local Infrastructure**: Zero-config containerized development environment via Docker Compose providing PostgreSQL 16, Redis 7, MinIO (S3-compatible object storage), and Mailpit (SMTP sandbox).

---

## 2. Monorepo Structure & Package Boundaries

### 2.1 Workspace Directory Tree
```text
bomis_sambalpur/
├── .github/
│   └── workflows/                # CI/CD pipelines (test, lint, typecheck, newman)
├── apps/
│   ├── api/                      # NestJS modular monolith backend
│   │   ├── src/
│   │   │   ├── common/           # Interceptors, filters, guards, decorators, pino logger
│   │   │   ├── modules/          # Auth, users, students, staff, attendance, fees, etc.
│   │   │   ├── prisma/           # Prisma service, client wrapper, RLS middleware
│   │   │   └── main.ts
│   │   ├── test/                 # Unit & e2e test suites
│   │   ├── tsconfig.json
│   │   └── package.json
│   ├── web/                      # Next.js 14 App Router portal (Admin, Teacher, Accountant, Parent)
│   │   ├── app/                  # App router routes & layouts
│   │   ├── components/           # UI components using shadcn/ui and @bomis/ui
│   │   ├── hooks/                # TanStack query hooks, auth hooks
│   │   ├── lib/                  # API client, session management
│   │   ├── public/
│   │   ├── tsconfig.json
│   │   └── package.json
│   └── mobile/                   # React Native (Expo) cross-platform app
│       ├── app/                  # Expo Router / Navigation
│       ├── src/
│       │   ├── components/       # Native UI components
│       │   ├── hooks/            # Offline-first sync hooks, storage hooks
│       │   ├── services/         # FCM push, GPS tracking, offline queue
│       │   └── theme/            # Theme bridge to @bomis/ui tokens
│       ├── app.json
│       ├── tsconfig.json
│       └── package.json
├── packages/
│   ├── shared/                   # Pure TypeScript domain contracts, Zod schemas, types, RBAC
│   │   ├── src/
│   │   │   ├── contracts/        # API response envelope, pagination, query contracts
│   │   │   ├── enums/            # Domain enums (Roles, Statuses, PaymentMethod, etc.)
│   │   │   ├── rbac/             # Permissions map, role definitions, permission matrix
│   │   │   ├── schemas/          # Zod validation schemas (Auth, Attendance, Fees, etc.)
│   │   │   ├── types/            # Inferred TypeScript types from Zod schemas
│   │   │   └── index.ts
│   │   ├── tsconfig.json
│   │   └── package.json
│   └── ui/                       # Design tokens, brand assets, shared component primitives
│       ├── src/
│       │   ├── tokens/           # Color palette (#0F2942, #FF6B4A), typography, spacing
│       │   ├── tailwind/         # Tailwind CSS preset & theme config
│       │   ├── components/       # Cross-framework design tokens & CSS constants
│       │   └── index.ts
│       ├── tsconfig.json
│       └── package.json
├── infra/
│   ├── docker/
│   │   ├── postgres/             # Init SQL scripts (RLS, extensions, pgcrypto, uuid-ossp)
│   │   └── minio/                # Bucket creation script
│   ├── docker-compose.yml        # Dev services (Postgres 16, Redis 7, MinIO, Mailpit)
│   └── .env.example
├── docs/
│   ├── adr/                      # Architecture Decision Records
│   ├── schema/                   # DB ERD diagrams & data dictionary
│   └── postman/                  # Postman collection & environment for Newman CI
├── prisma/
│   ├── schema.prisma             # Master Prisma schema with DPDP models & RLS
│   ├── migrations/               # Prisma migrations
│   └── seed.ts                   # Master seed data (BOMIS Sambalpur, Grades 1-8, 4 buses)
├── pnpm-workspace.yaml           # pnpm workspace definition
├── turbo.json                    # Turborepo task pipeline configuration
├── package.json                  # Root monorepo scripts & dev tooling
├── tsconfig.base.json            # Base TypeScript compiler settings
└── .gitignore
```

### 2.2 Workspace Dependency Graph
```mermaid
graph TD
    Shared["@bomis/shared<br/>(Zod, Types, Enums, RBAC, Envelope)"]
    UI["@bomis/ui<br/>(Brand tokens, Tailwind preset)"]
    API["apps/api<br/>(NestJS Monolith)"]
    Web["apps/web<br/>(Next.js 14 App Router)"]
    Mobile["apps/mobile<br/>(Expo React Native)"]

    API -->|depends on| Shared
    Web -->|depends on| Shared
    Web -->|depends on| UI
    Mobile -->|depends on| Shared
    Mobile -->|depends on| UI
```

### 2.3 Turborepo Pipeline Configuration (`turbo.json`)
```json
{
  "$schema": "https://turbo.build/schema.json",
  "globalDependencies": [".env", ".env.local"],
  "tasks": {
    "build": {
      "dependsOn": ["^build"],
      "outputs": [".next/**", "!.next/cache/**", "dist/**"]
    },
    "lint": {
      "dependsOn": ["^build"]
    },
    "typecheck": {
      "dependsOn": ["^build"]
    },
    "test": {
      "dependsOn": ["^build"],
      "outputs": ["coverage/**"]
    },
    "dev": {
      "cache": false,
      "persistent": true
    },
    "db:generate": {
      "cache": false
    }
  }
}
```

---

## 3. Shared Package Contracts (`/packages/shared`)

### 3.1 Standard API Response Envelope
All REST API endpoints in BOMIS Sambalpur must conform to the unified envelope specification:
```typescript
export interface ApiResponse<T = any> {
  success: boolean;
  data: T | null;
  error?: {
    code: string;           // E.g., 'AUTH_INVALID_CREDENTIALS', 'VALIDATION_FAILED', 'FORBIDDEN'
    message: string;        // Human-readable message in English
    details?: any;          // Field-level validation errors or metadata
  };
  timestamp: string;        // ISO 8601 UTC string (e.g. '2026-10-17T11:00:00.000Z')
  correlationId: string;    // X-Correlation-ID / Request UUID for distributed tracing
}

export interface PaginatedData<T> {
  items: T[];
  pagination: {
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPrevPage: boolean;
  };
}
```

### 3.2 Domain Enums
The domain requires the following canonical enums:

1. **UserRole**:
   - `SUPER_ADMIN`: Global platform superuser.
   - `ADMIN`: School campus administrator / principal's office.
   - `PRINCIPAL`: Academic & administrative executive head.
   - `TEACHER`: Faculty member with class/section assignment.
   - `ACCOUNTANT`: Financial officer managing fees, concessions, reconciliation.
   - `STUDENT`: Enrolled pupil with access to diary, homework, report cards.
   - `PARENT`: Guardian/Parent linked to one or more children.
   - `DRIVER_TRANSPORT`: Bus driver or transport marshal transmitting telematics and QR scans.

2. **UserStatus**: `ACTIVE`, `INACTIVE`, `SUSPENDED`, `PENDING_VERIFICATION`.
3. **Gender**: `MALE`, `FEMALE`, `OTHER`.
4. **AttendanceStatus**: `PRESENT`, `ABSENT`, `LATE`, `HALF_DAY`, `EXCUSED`.
5. **FeeFrequency**: `ONE_TIME`, `ANNUAL`, `TERM`, `MONTHLY`, `CUSTOM`.
6. **PaymentStatus**: `PENDING`, `SUCCESS`, `FAILED`, `REFUNDED`.
7. **PaymentMethod**: `RAZORPAY_UPI`, `RAZORPAY_NETBANKING`, `RAZORPAY_CARD`, `CASH`, `CHEQUE`, `BANK_TRANSFER`.
8. **HomeworkStatus**: `ASSIGNED`, `SUBMITTED`, `REVIEWED`, `RESUBMISSION_REQUESTED`.
9. **ExamTerm**: `TERM_1`, `TERM_2`, `UNIT_TEST_1`, `UNIT_TEST_2`, `MID_TERM`, `FINAL`.
10. **BusTripType**: `MORNING_PICKUP`, `AFTERNOON_DROP`, `SPECIAL_EVENT`.
11. **BoardingStatus**: `SCHEDULED`, `BOARDED`, `DEBOARDED`, `ABSENT`.
12. **ConsentType**: `DATA_PROCESSING`, `HEALTH_RECORDS`, `MEDIA_RELEASE`, `TRANSPORT_TRACKING`, `SMS_NOTIFICATIONS`.
13. **ConsentStatus**: `GRANTED`, `REVOKED`, `EXPIRED`.
14. **AuditAction**: `CREATE`, `UPDATE`, `DELETE`, `LOGIN`, `LOGOUT`, `CONSENT_CHANGE`, `PAYMENT`, `DATA_ERASURE`.
15. **ConcessionStatus**: `PENDING`, `APPROVED`, `REJECTED`.
16. **VisitorPassStatus**: `PRE_APPROVED`, `ACTIVE_ON_CAMPUS`, `CHECKED_OUT`, `EXPIRED`, `DENIED`.

### 3.3 Role-Based Access Control (RBAC) Permissions Matrix
The 8 roles map to specific permission strings formatted as `<resource>:<action>`:

| Resource | SUPER_ADMIN | ADMIN | PRINCIPAL | TEACHER | ACCOUNTANT | STUDENT | PARENT | DRIVER |
|---|---|---|---|---|---|---|---|---|
| **Users / Staff** | Full | CRUD | View/Approve | View Self | View Self | No Access | No Access | View Self |
| **Students / Master** | Full | CRUD | Full View/Edit | View Class | View List | View Self | View Children | View Manifest |
| **Attendance** | Full | CRUD/Override | View/Override | Mark/View Assigned | View Reports | View Self | View Children | No Access |
| **Fees & Payments** | Full | View/Approve Concessions | View Reports | No Access | Full CRUD/Reconciliation | View Self | Pay/View Receipts | No Access |
| **Homework & Diary** | Full | View All | View All | CRUD Assigned | No Access | View/Submit | View/Acknowledge | No Access |
| **Timetable & Substitution**| Full | CRUD | CRUD/Approve | View Assigned | No Access | View Class | View Children | View Route Sched |
| **Exams & Report Cards** | Full | CRUD Terms | Approve/Publish | Marks Entry Assigned | No Access | View Published | View Published | No Access |
| **Transport & GPS** | Full | CRUD Routes | View Fleet | View Bus Roster | No Access | View Own Bus | Live Track Child | Broadcast GPS/Scan QR |
| **Audit Logs & DPDP** | Full | View School Logs | View School Logs | No Access | View Audit Trail | View Own Consents| View Own Consents | No Access |

### 3.4 Zod Validation Schemas
Shared schemas ensure 100% type congruence across apps:
- `LoginSchema` (`phone` / `email`, `password` or OTP request).
- `OtpRequestSchema` & `OtpVerifySchema` (E.164 phone validation, 6-digit OTP code).
- `CreateStudentSchema` (admissionNumber, rollNumber, firstName, lastName, dob, gender, classId, sectionId, emergencyContact).
- `MarkAttendanceSchema` (date, sectionId, records: array of `{ studentId, status, remarks }`, offlineId).
- `InitiatePaymentSchema` (studentId, installmentId, amount, paymentMethod, idempotencyKey).
- `RazorpayWebhookSchema` (event, payload, signature header verification).
- `TimetableSlotSchema` (dayOfWeek, periodNumber, subjectId, teacherId, roomId, sectionId).
- `TransportGpsPingSchema` (vehicleId, routeId, latitude, longitude, speed, heading, timestamp).
- `BoardingScanSchema` (studentId, vehicleId, stopId, scanType: `BOARD` | `DEBOARD`, timestamp).
- `ConsentRecordSchema` (userId, consentType, version, status, ipAddress, userAgent).

---

## 4. Shared UI Design Tokens (`/packages/ui`)

### 4.1 BOMIS Sambalpur Brand Color Palette
The visual identity of Birla Open Minds International School, Sambalpur features a disciplined academic color palette:

- **Primary Brand Navy / Deep Teal**:
  - `primary-900`: `#071726` (Deep Navy backdrop)
  - `primary-800`: `#0F2942` (**BOMIS Primary Navy** - Header bars, primary buttons, branding)
  - `primary-700`: `#1A3A5C` (Card borders, accent navigation)
  - `primary-600`: `#254E7A`
  - `primary-100`: `#EBF2F8`
  - `primary-50`: `#F4F8FA`
- **Accent Warm Coral**:
  - `accent-600`: `#E05232` (Active/Pressed state)
  - `accent-500`: `#FF6B4A` (**BOMIS Warm Coral** - CTA highlights, emergency tags, bus markers, fee due badges)
  - `accent-400`: `#FF886E`
  - `accent-100`: `#FFEAE5`
  - `accent-50`: `#FFF5F2`
- **Functional Semantics**:
  - `success`: `#10B981` (Present, Paid, On-Time)
  - `warning`: `#F59E0B` (Late, Partial Fee, Pending Review)
  - `danger`: `#EF4444` (Absent, Overdue, SOS Alert, Revoked)
  - `info`: `#3B82F6` (Notices, Announcements)
- **Neutrals**:
  - `background`: `#FFFFFF` (Surface background)
  - `surface-muted`: `#F8FAFC` (Sidebar, table zebra stripes)
  - `border`: `#E2E8F0`
  - `text-primary`: `#0F172A`
  - `text-secondary`: `#64748B`

### 4.2 Typography & Spacing Tokens
- **Font Families**:
  - Heading: `'Outfit', 'Plus Jakarta Sans', sans-serif`
  - Body: `'Inter', -apple-system, BlinkMacSystemFont, sans-serif`
  - Monospace (Codes, Roll Numbers, Receipts): `'JetBrains Mono', 'Fira Code', monospace`
- **Border Radius**:
  - `sm`: `4px`, `md`: `8px`, `lg`: `12px`, `xl`: `16px`, `full`: `9999px`

---

## 5. Prisma Schema Architecture & DPDP Act Compliance

### 5.1 Multi-Tenant Isolation & Postgres RLS Strategy
1. **Tenant Column**: Every single business model includes `school_id String @db.Uuid`.
2. **Indexing**: Composite index on `[school_id, id]` and `[school_id, ...]` on all queryable foreign keys.
3. **Database RLS Policies**:
   ```sql
   ALTER TABLE "Student" ENABLE ROW LEVEL SECURITY;
   CREATE POLICY tenant_isolation_policy ON "Student"
     USING (school_id = NULLIF(current_setting('app.current_school_id', true), '')::uuid);
   ```
4. **Prisma Middleware / Client Extension**:
   All NestJS database queries wrap execution with Prisma `$extends` or `$transaction` setting the transaction local session variable:
   `SET LOCAL app.current_school_id = '<current_user_school_id>'`.

### 5.2 DPDP Act (2023) Compliance Architecture
1. **Soft Delete & 90-Day Retention Schedule**:
   - Every sensitive model implements:
     - `deleted_at DateTime?`
     - `retention_until DateTime?`
   - When a user, student, or guardian requests account deletion, `deleted_at = now()` and `retention_until = now() + interval '90 days'`.
   - Active queries enforce `where: { deleted_at: null }`.
   - **BullMQ Cryptographic Erasure Worker**: Runs daily at 02:00 AM UTC. Identifies records where `retention_until < now()`. Irreversibly overwrites PII (name becomes `[ERASED]`, email becomes `hash@erased.internal`, phone cleared) and writes an audit log entry of type `DATA_ERASURE`.
2. **Consent Ledger (`Consent`)**:
   - Explicit opt-in tracking for data collection, biometric/photo publishing, health info, and GPS tracking.
   - Records `user_id`, `school_id`, `consent_type`, `version`, `status` (`GRANTED`/`REVOKED`), `granted_at`, `revoked_at`, `ip_address`, `user_agent`, and `proof_hash` (SHA-256 HMAC of consent terms + timestamp).
3. **Field-Level Encryption (AES-256-GCM)**:
   - Sensitive columns stored with `_encrypted` suffix as hex/base64 strings containing IV, Ciphertext, and Auth Tag:
     - `Student.blood_group_encrypted`
     - `Student.medical_notes_encrypted`
     - `Guardian.aadhaar_number_encrypted`
     - `Guardian.annual_income_encrypted`

### 5.3 Immutable Audit Logging Architecture (`AuditLog`)
- Table `audit_logs` records all mutations.
- PostgreSQL rule or trigger prevents `UPDATE` or `DELETE` statements on `audit_logs`:
  ```sql
  CREATE RULE audit_logs_no_update AS ON UPDATE TO "audit_logs" DO INSTEAD NOTHING;
  CREATE RULE audit_logs_no_delete AS ON DELETE TO "audit_logs" DO INSTEAD NOTHING;
  ```
- Attributes tracked: `id`, `school_id`, `user_id`, `action`, `entity_type`, `entity_id`, `before_state` (JSONB), `after_state` (JSONB), `diff` (JSONB), `ip_address`, `user_agent`, `created_at`.

### 5.4 Prisma Data Models (31 Models)

1. `School`: Multi-tenant root (BOMIS Sambalpur).
2. `User`: Core authentication entity (email, phone, password_hash, role, status).
3. `RefreshToken`: Token rotation & session invalidation.
4. `Student`: Academic pupil master record.
5. `Guardian`: Parent/Guardian profile.
6. `StudentGuardian`: Junction table for sibling linking & parental rights.
7. `Staff`: Teacher & administrative employee record.
8. `AcademicYear`: School operational session (e.g. 2026-2027).
9. `Class`: Grade level entity (Grade 1 to Grade 12).
10. `Section`: Class section division (Section A, B, etc.).
11. `Subject`: Academic curriculum subject.
12. `TeacherAssignment`: Mapping of teachers to sections and subjects.
13. `Attendance`: Daily student attendance record with offline sync support.
14. `StaffAttendance`: Daily employee clock-in/clock-out tracking.
15. `FeeCategory`: Tuition, Transport, Lab, Admission, Library.
16. `FeeStructure`: Fee schedule per Class & Academic Year.
17. `FeeConcession`: Approved scholarship/concession discounts.
18. `FeeInstallment`: Split payment milestone schedules per student.
19. `Payment`: Transaction ledger with Idempotency Key & Razorpay metadata.
20. `Homework`: Teacher assignment record with rich text and attachments.
21. `HomeworkSubmission`: Student submission and grading record.
22. `Timetable`: Weekly period schedule with clash-prevention constraints.
23. `TeacherAbsenceSubstitution`: Dynamic substitute teacher allocations.
24. `Exam`: CBSE-pattern examination schedule (Term 1, Term 2, Unit Tests).
25. `ExamSubject`: Specific subject exam parameters and max/pass marks.
26. `MarksEntry`: Student score entry with locking and teacher signature.
27. `TransportRoute`: Bus transit routes.
28. `TransportStop`: Geo-located stops with scheduled ETAs.
29. `Vehicle`: School fleet buses (4 pilot buses: 3 small, 1 full-size).
30. `StudentTransport`: Student bus route and pickup stop assignment.
31. `TransportTelemetry`: Real-time GPS coordinate pings.
32. `BoardingEvent`: Student QR boarding/deboarding logs.
33. `NoticeCircular`: Digital diary announcements and acknowledgements.
34. `VisitorPass`: Gate security QR visitor passes.
35. `Consent`: DPDP consent ledger.
36. `AuditLog`: Immutable audit trail.

---

## 6. Infrastructure & Docker Compose Specification (`/infra`)

### 6.1 Container Services
1. **PostgreSQL 16**:
   - Image: `postgres:16-alpine`
   - Port: `5432:5432`
   - Extensions: `uuid-ossp`, `pgcrypto`
   - Healthcheck: `pg_isready -U bomis_user -d bomis_db`
   - Volume: `bomis_postgres_data:/var/lib/postgresql/data`
2. **Redis 7**:
   - Image: `redis:7-alpine`
   - Port: `6379:6379`
   - Command: `redis-server --requirepass bomis_redis_pass --appendonly yes`
   - Healthcheck: `redis-cli -a bomis_redis_pass ping`
   - Volume: `bomis_redis_data:/data`
3. **MinIO (S3-Compatible Object Store)**:
   - Image: `minio/minio:latest`
   - Command: `server /data --console-address ":9001"`
   - Ports: `9000:9000` (S3 API), `9001:9001` (Web Console)
   - Default Bucket: `bomis-storage` (homework attachments, receipts, student photos)
   - Volume: `bomis_minio_data:/data`
4. **Mailpit (Local SMTP Testing Sandbox)**:
   - Image: `axllent/mailpit:latest`
   - Ports: `1025:1025` (SMTP server), `8025:8025` (Web UI)

### 6.2 One-Command Bootstrapping Sequence
The developer and CI workflow requires:
```bash
# 1. Start all infrastructure containers
docker compose -f infra/docker-compose.yml up -d

# 2. Install workspace dependencies
pnpm install

# 3. Apply Prisma migrations to PostgreSQL
pnpm db:migrate

# 4. Populate realistic seed data (BOMIS Sambalpur, Grades 1-8 Sec A, 4 Buses)
pnpm db:seed

# 5. Launch all dev servers concurrently via Turborepo
pnpm dev
```

---

## 7. Features Discovered

| # | Category | Feature | Description | Inputs | Outputs | Error Behavior | Discovered Via |
|---|---|---|---|---|---|---|---|
| 1 | Architecture | Turborepo Monorepo Scaffold | Root pnpm workspace with Turbo task caching for build, test, lint, typecheck, dev | `turbo.json`, `pnpm-workspace.yaml` | Coordinated monorepo builds | Task failure on cycle or build error | R1 Monorepo Foundation |
| 2 | Backend API | NestJS Modular Monolith | `/apps/api` domain-separated modules with global validation pipes and filters | HTTP Requests, DTOs | Standardized API response | Global HttpExceptionFilter envelope | R1 /apps/api spec |
| 3 | Observability | Pino Structured Logging | High-performance JSON logger injecting `correlationId` and `request_id` | HTTP Headers / Requests | Formatted JSON stdout log | Fallback correlation ID generation | R1 /apps/api spec |
| 4 | API Docs | Swagger OpenAPI | Auto-generated interactive API documentation at `/api/docs` | NestJS Controller decorators | Swagger JSON & UI | 404 in production if disabled | R1 /apps/api spec |
| 5 | Health Monitoring| /health & /ready Endpoints | Liveness and readiness probes checking DB, Redis, and storage connections | HTTP GET `/health`, `/ready` | `{ status: 'ok', details: { db: 'up', redis: 'up' } }` | HTTP 503 Service Unavailable | R1 /apps/api spec |
| 6 | Web Portal | Next.js 14 App Router | Multi-role responsive dashboard using Tailwind CSS and shadcn/ui primitives | User sessions, URL routes | Server/Client rendered views | Next.js error boundary & 404 page | R1 /apps/web spec |
| 7 | Mobile App | Expo React Native App | Cross-platform iOS/Android app with offline queue sync and FCM notifications | Touch events, offline queue | Native screens & push alerts | SQLite queue on network failure | R1 /apps/mobile spec |
| 8 | Shared Types | Type Synchronization Package | Pure TS types and Zod schemas shared across web, mobile, and API | Schema definitions | Inferred TS types & Zod parse | ZodError with path-level details | R1 Acceptance Criteria |
| 9 | Brand Design | BOMIS Sambalpur UI Tokens | Official design system tokens (Navy `#0F2942`, Coral `#FF6B4A`, Slate) | Token imports / Tailwind preset | Consistent CSS variables & classes | Fallback to base neutral theme | R1 /packages/ui spec |
| 10| Infra Dev | Local Docker Compose | Multi-container dev setup (Postgres 16, Redis 7, MinIO, Mailpit) | `docker compose up -d` | Running background services | Container restart on crash | R1 /infra spec |
| 11| Documentation | Architecture Decision Records | Structured ADRs in `/docs/adr` documenting tech stack choices | Markdown templates | Architectural reference docs | Review rejection on undocumented change | R1 /docs spec |
| 12| Testing | Newman Postman Automation | Headless Newman runner for `/docs/postman` collections in GitHub Actions | Postman JSON collection & env | JUnit test report, exit code 0 | CI pipeline failure on test fail | R1 / Acceptance Criteria |
| 13| Data Isolation| Multi-Tenant school_id Indexing | All business models partitioned by `school_id` with composite indexes | Query filters, ORM calls | Tenant-scoped data rows | Database constraint / foreign key violation | R2 Data Model spec |
| 14| Database Security| PostgreSQL Row-Level Security | Engine-level data fencing using `app.current_school_id` session setting | Database connection context | Row filtering at SQL level | Zero rows returned if tenant mismatch | R2 Data Model spec |
| 15| Data Privacy | DPDP 90-Day Retention Schedule | Soft deletion with `retention_until` timestamp calculated at deletion | User deletion request | Soft-deleted record | Query ignores deleted rows | R2 DPDP Compliance |
| 16| Data Privacy | BullMQ Cryptographic Erasure | Background worker that irreversibly scrubs expired PII after 90 days | Daily cron schedule | Scrambled PII & Erasure Audit Log | Job retry with exponential backoff | R2 DPDP Compliance |
| 17| Data Privacy | Granular Consent Ledger | Explicit tracking of parent/user permissions with cryptographic SHA-256 hash | Consent grant/revoke events | Cryptographically signed ledger entry | Reject processing if consent missing | R2 DPDP Compliance |
| 18| Cryptography | AES-256-GCM Field Encryption | Application-layer encryption for blood group, medical history, Aadhaar | Plaintext sensitive string | IV:Ciphertext:Tag string | Decryption failure if key invalid | R2 DPDP Compliance |
| 19| Security | Immutable Audit Logging | Dedicated `audit_logs` table tracking user, entity, diff, IP, user-agent | Any CRUD operation | Append-only audit record | Database rule blocks UPDATE/DELETE | R2 Data Model spec |
| 20| Identity | Mobile OTP & Password Auth | Phone OTP for parents/students, password + OTP for school staff | Phone number or Email + credentials | Short-lived JWT & Refresh Token | HTTP 401 Unauthorized / Rate limit | R3 Auth spec |
| 21| Session Mgmt | Rotating JWT Refresh Tokens | Secure refresh token rotation with token family revocation on reuse | Refresh token header/cookie | New JWT & New Refresh Token | Revoke entire family if token reused | R3 Auth spec |
| 22| Security | RBAC Authorization Guard | 8 distinct roles guarding endpoints via `@Roles()` decorator | JWT payload role | Authorized controller handler | HTTP 403 Forbidden | R3 RBAC spec |
| 23| People Mgmt | Multi-Child Sibling Linking | Single parent login managing multiple enrolled siblings seamlessly | Parent guardian ID | Array of linked Student profiles | 404 if child not linked | R3 People spec |
| 24| People Mgmt | Bulk CSV Import / Export | Batch student/staff onboarding with dry-run validation | Multipart CSV file upload | Validation report & inserted records | Row-by-row validation error report | R3 People spec |
| 25| Attendance | Rapid Teacher Attendance Grid | Sub-10 second batch class attendance submission with status toggles | Class section, date, student status array| Attendance records created | HTTP 400 on duplicate submission | R3 Attendance spec |
| 26| Attendance | Offline Sync Queue | Mobile offline attendance caching and auto-sync on connectivity return | SQLite local queue | Synced DB records | Conflict resolution (latest wins) | R3 Attendance spec |
| 27| Notifications | Instant FCM Parent Push Alerts | Automated push notification sent when child is marked absent or late | Attendance mark event | FCM push message dispatched | Log notification failure, do not abort mark | R3 Attendance spec |
| 28| Academic Diary| Digital Diary & Homework | Rich text assignments with file attachments and submission tracking | Title, rich text, files, due date | Homework entity created | Validation error on missing fields | R3 Homework spec |
| 29| Financial | Razorpay Payment Integration | Webhook-verified payment gateway supporting UPI, Netbanking, Cards | Order initiation payload | Razorpay order ID, payment checkout | Webhook signature verification error | R3 Fees spec |
| 30| Financial | Idempotency Protection | `Idempotency-Key` header enforcement on fee payment endpoints | Unique UUID header | Cached previous response or new charge | HTTP 409 Conflict on concurrent duplicate | R3 Acceptance Criteria |
| 31| Financial | Concession Approval Workflow | Multi-step approval for scholarships and staff discounts | Concession request | Discount applied to installment | HTTP 403 if unauthorized approver | R3 Fees spec |
| 32| Academics | Automated Timetable Generator | Schedule matrix generator with room and teacher clash detection | Class, periods, teacher allocations | Timetable grid schedule | HTTP 422 Unprocessable on clash | R4 Timetable spec |
| 33| Academics | One-Click Teacher Substitution| Dynamic substitute reassignment when teacher is marked on leave | Absent teacher ID, date | Substitute timetable override | Alert if no substitute teacher free | R4 Timetable spec |
| 34| Academics | CBSE Report Card Generator | Term marks aggregation, grade computation, BullMQ PDF rendering | Student exam marks | Rendered PDF stored in MinIO | Marking out-of-range validation error | R4 Exams spec |
| 35| Telematics | Live GPS Bus Tracking | WebSocket / Socket.IO broadcast of bus coordinates from driver mini-app | Lat/Lng pings from driver | Real-time map update for parents | Reconnect on socket disconnect | R4 Transport spec |
| 36| Telematics | Geofenced Proximity Alerts | Automatic parent notification when bus enters 5-minute radius of stop | Vehicle GPS ping | Triggered push notification | Suppress duplicates within same trip | R4 Transport spec |
| 37| Transport | QR Student Boarding Scanning | Driver mini-app scans student ID card QR at pickup and drop stops | QR payload, vehicle ID, stop ID | Boarding log timestamped | Warning if student boards wrong bus | R4 Transport spec |
| 38| Safety | Visitor QR Gate Pass | Pre-approved visitor badge generation with check-in/out timestamps | Visitor info, photo, person to meet | QR Pass sent to visitor SMS/Email | Expired pass rejected at gate | R5 Safety spec |
| 39| Safety | Child Pickup Verification | OTP or QR verification before gate security releases child to guardian | Guardian scan / OTP input | Authorized gate exit clearance | Security siren / deny exit on failure | R5 Safety spec |
| 40| Dev Setup | One-Command Bootstrap Script | Single command orchestration of container spin up, migration, seeding | Terminal command | Fully running local platform | Stop with actionable error on missing tool | Acceptance Criteria |

---

## 8. Edge Cases & Boundary Conditions

| # | Feature | Input / Condition | Observed / Required Behavior |
|---|---|---|---|
| 1 | DPDP Erasure | Retention period (90 days) elapses while legal hold or audit inquiry is pending | System retains encrypted audit metadata but strips direct PII; flags record as legally exempt if flag set. |
| 2 | Multi-Tenancy | API request includes valid JWT for School A, but path param requests `/schools/:schoolB/students` | Interceptor verifies JWT tenant matches path and query; immediately raises HTTP 403 Forbidden and logs security audit. |
| 3 | Payment Idempotency | Client sends duplicate payment request with identical `Idempotency-Key` within 100ms | Cache lock intercepts second request, waits for first to complete, returns exact same payment receipt without charging twice. |
| 4 | Razorpay Webhooks | Webhook payload received with invalid cryptographic HMAC signature header | Webhook controller rejects request with HTTP 400 Bad Request; logs security incident; does not credit fee installment. |
| 5 | Razorpay Webhooks | Identical webhook event received multiple times (network retry) | Webhook handler checks `razorpay_payment_id` uniqueness in Payment table; returns HTTP 200 OK without double-crediting. |
| 6 | Offline Attendance | Teacher marks attendance offline, device clock is skewed back by 3 hours | Server validates server-side sync timestamp against class schedule date; rejects timestamps outside valid class hours. |
| 7 | Offline Attendance | Teacher submits attendance for student whose status was already marked 'EXCUSED' by Principal | Server applies precedence rules: Principal administrative override takes precedence; returns notification to teacher. |
| 8 | Timetable Generator | Class requires 6 math periods/week, but available math teachers only have 4 unallocated slots | Generator fails with detailed clash diagnosis: identifies teacher bottleneck and suggests substitute period allocations. |
| 9 | Teacher Substitution | Assigned substitute teacher is scheduled for leave on the exact same date | System detects double-absence conflict; prompts admin to select from remaining available teachers qualified in subject. |
| 10| Transport Telematics | Driver phone loses GPS signal inside tunnel or remote Sambalpur zone for 10 minutes | Driver app buffers GPS coordinates in local SQLite; flushes chronological batch once cellular connectivity is restored. |
| 11| Student Boarding QR | Student scans QR card at bus stop B, but their registered route is Bus 3 Stop A | Driver scanner displays visual alert: "Unscheduled Boarding Alert — Route 1 Student on Bus 3"; logs special boarding event. |
| 12| Parent Child Linking | Sibling A attends Grade 2, Sibling B attends Grade 7 under same guardian phone number | Parent mobile app provides instant one-tap child switcher without requiring re-authentication; token scopes child contexts. |
| 13| Field Encryption | Application encryption key `APP_ENCRYPTION_KEY` rotated in production | Decryption utility supports key version prefix (e.g. `v1:...`, `v2:...`) allowing smooth transition and lazy re-encryption. |
| 14| Bulk CSV Import | CSV contains 500 student rows where row 42 has an invalid date of birth format | Dry-run validation fails row 42 specifically, returning exact line number and column error; valid rows staged for commit. |
| 15| Audit Log Tampering | Database user attempts `DELETE FROM "audit_logs" WHERE id = '...'` directly via psql | PostgreSQL rule `audit_logs_no_delete` executes DO INSTEAD NOTHING; table remains strictly append-only. |
