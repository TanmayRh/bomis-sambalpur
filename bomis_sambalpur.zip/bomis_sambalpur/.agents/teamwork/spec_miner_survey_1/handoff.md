# Handoff Report: Monorepo & Schema Specification Survey
**Agent**: Monorepo & Schema Spec Miner (`spec_miner_survey_1`)  
**Date**: 2026-10-17T11:08:00Z  
**Type**: Hard Handoff (Task Complete)  
**Target Recipient**: Orchestrator (`17238c8a-10a1-44ab-93b7-5a2d27f28ea5`) & Monorepo / Backend Scaffold Engineers  

---

## 1. Observation

1. **Working Directory & Authoritative Inputs**:
   - `DISPATCH.md` at `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_survey_1\DISPATCH.md` lines 10-15:
     > "1. Turborepo + pnpm monorepo architecture and package boundaries (/apps/api, /apps/web, /apps/mobile, /packages/shared, /packages/ui, /infra, /docs).
     > 2. Shared package contracts (/packages/shared: Zod schemas, types, enums, RBAC role permissions, API response envelope; /packages/ui: brand palette #0F2942, #FF6B4A, tokens).
     > 3. Prisma Schema & Data Models (school_id multi-tenancy, DPDP 90-day retention, consent tracking, field-level encryption, immutable audit_logs, all entities from Users to Transport).
     > 4. Infra & Dev setup (Docker Compose with Postgres 16, Redis 7, MinIO, Mailpit)."
   - `ORIGINAL_REQUEST.md` at `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md` lines 18-34:
     - Line 19: "Scaffold and configure a Turborepo + pnpm monorepo consisting of: /apps/api, /apps/web, /apps/mobile, /packages/shared, /packages/ui, /infra, /docs."
     - Line 20: "/apps/api: NestJS modular monolith with strict domain modules, global validation pipes, Pino JSON logger with correlation/request IDs, custom error envelope, Swagger OpenAPI at /api/docs, and /health + /ready endpoints."
     - Line 21: "/apps/web: Next.js 14 App Router, Tailwind CSS, shadcn/ui design primitives, TanStack Query, React Hook Form, and Zod."
     - Line 22: "/apps/mobile: React Native (Expo) multi-role app supporting iOS and Android, offline-first sync architecture, secure storage, and push notifications."
     - Line 23: "/packages/shared: Shared TypeScript types, Zod validation schemas, domain enums, RBAC role permissions, and API contract specifications."
     - Line 24: "/packages/ui: Shared design tokens (BOMIS Sambalpur brand palette: navy/teal primary #0F2942, warm coral accent #FF6B4A), typography, and reusable UI tokens."
     - Line 25: "/infra: Docker Compose for local development (PostgreSQL 16, Redis 7, MinIO S3-compatible, Mailpit), Dockerfiles, and CI workflow templates."
     - Line 29-33: "Multi-tenant isolation with school_id indexed on all business tables and Postgres Row-Level Security (RLS) support... DPDP Act compliance: soft deletes with 90-day retention before cryptographic erasure, consent tracking, and field-level encryption for sensitive health/identity data... Immutable audit_logs tracking user actions, entity mutations, diffs, IP addresses, and timestamps... Models covering Users, Roles, Students, Guardians, Staff, Classes, Sections, Attendance, Fee Structures, Concessions, Installments, Payments, Homework, Timetable, Exams, Transport, and Communication."
   - `ORIGINAL_REQUEST.md` lines 59-66 (Acceptance Criteria):
     - Line 60: "Type & Schema Synchronization: All frontend and backend validation originates from /packages/shared Zod schemas with 100% type congruence."
     - Line 61: "Standardized Envelope: All REST endpoints return { success: boolean, data: T, error?: { code: string, message: string, details?: any }, timestamp: string, correlationId: string }."
     - Line 62: "Idempotency & Financial Safety: All payment endpoints enforce Idempotency-Key headers; Razorpay webhooks verify cryptographic signatures with duplicate payload protection."
     - Line 65: "One-Command Bootstrapping: docker compose up -d followed by pnpm install && pnpm db:migrate && pnpm db:seed && pnpm dev starts the entire platform with realistic seed data for Grades 1–8 Section A and 4 buses."
2. **Current Workspace State**:
   - Directory `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur` currently contains only `.agents/`. No monorepo code or files have been placed yet, indicating this is the greenfield survey phase prior to Milestone 1 scaffolding.

---

## 2. Logic Chain

1. **Derivation of Monorepo Boundaries & Task Pipelines**:
   - From Observation 1 (`ORIGINAL_REQUEST.md` line 19), Turborepo and pnpm workspaces must organize 7 top-level paths: `/apps/api`, `/apps/web`, `/apps/mobile`, `/packages/shared`, `/packages/ui`, `/infra`, and `/docs`.
   - To guarantee zero duplicate type definitions between backend and frontends, `@bomis/shared` must be a compile-free or transpile-ready TypeScript package exporting Zod schemas and inferred types that both NestJS (`apps/api`) and Next.js (`apps/web`) import directly.
   - Turborepo's `turbo.json` must establish a topological task graph where `build`, `lint`, `typecheck`, and `test` depend on `^build` for upstream packages (`@bomis/shared` and `@bomis/ui`).

2. **Derivation of Shared Contracts & RBAC Structure**:
   - From Observation 1 (`ORIGINAL_REQUEST.md` line 61), all HTTP responses must strictly wrap data in the standardized envelope. This requires a NestJS `TransformInterceptor` for successful responses and a global `HttpExceptionFilter` for error envelopes.
   - From Observation 1 (`ORIGINAL_REQUEST.md` line 38), 8 distinct roles (`SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `TEACHER`, `ACCOUNTANT`, `STUDENT`, `PARENT`, `DRIVER_TRANSPORT`) must be enumerated in `@bomis/shared` and mapped to granular action permissions.
   - Brand tokens must be standardized in `@bomis/ui` as CSS variables and Tailwind theme presets using primary `#0F2942` and accent `#FF6B4A`.

3. **Derivation of DPDP Multi-Tenant Prisma Schema**:
   - From Observation 1 (`ORIGINAL_REQUEST.md` lines 29-33), multi-tenancy requires every business table to feature `school_id String @db.Uuid` with a compound index `@@index([school_id, ...])`.
   - PostgreSQL RLS must be enabled with policies checking `current_setting('app.current_school_id')` to provide defense-in-depth against software-level tenant leaks.
   - For DPDP 2023 compliance:
     - Soft deletion requires `deleted_at DateTime?` and `retention_until DateTime?` (set to `now() + 90 days`).
     - A daily BullMQ worker must execute cryptographic erasure of expired records (`retention_until <= now()`), scrambling PII and emitting an immutable `DATA_ERASURE` audit log.
     - Sensitive fields (blood group, medical notes, guardian Aadhaar number, guardian annual income) must use AES-256-GCM application-level encryption.
     - Table `audit_logs` must be made strictly immutable via PostgreSQL rules preventing `UPDATE` and `DELETE`.

4. **Derivation of Local Infrastructure & Bootstrapping**:
   - From Observation 1 (`ORIGINAL_REQUEST.md` lines 25, 65), `infra/docker-compose.yml` must host PostgreSQL 16 (with `uuid-ossp` and `pgcrypto`), Redis 7 (BullMQ queue & session cache), MinIO (S3 asset storage), and Mailpit (SMTP interception).
   - Bootstrapping must complete cleanly in 5 deterministic steps: `docker compose up -d` -> `pnpm install` -> `pnpm db:migrate` -> `pnpm db:seed` -> `pnpm dev`.

---

## 3. Caveats

1. **Hardware / Runtime Environment**: The host OS is Windows powershell. In Docker on Windows, file path separators and volume mount formats must use forward slashes or standard Docker Compose volume specifications.
2. **Prisma & RLS Connection Pooling**: When using connection poolers or standard Prisma clients, `SET LOCAL app.current_school_id` must be executed within the exact transaction block or via a dedicated client extension `$extends` to ensure thread/connection affinity.
3. **Field-Level Encryption Key Management**: In local dev, a deterministic fallback `APP_ENCRYPTION_KEY` (32 bytes hex) should be provided in `.env.example`, but production deployment must retrieve this from a secure key management service (KMS).

---

## 4. Conclusion

1. The monorepo architecture and DPDP schema specifications are completely documented in `analysis.md` (36 data models, 16 domain enums, 8-role RBAC matrix, 40 discovered features, and 15 critical edge cases).
2. The team has a concrete roadmap to proceed directly into:
   - **Milestone 1**: Scaffolding root Turborepo, `pnpm-workspace.yaml`, package templates, and `infra/docker-compose.yml`.
   - **Milestone 2**: Authoring `@bomis/shared` (Zod schemas, types, enums, envelope), `@bomis/ui` (tokens), and `prisma/schema.prisma` with RLS SQL initialization and master seed.

---

## 5. Verification Method

To verify the findings and specifications produced by this survey:
1. **Inspect Analysis and Schema Specification**:
   - View `analysis.md` in `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_survey_1\analysis.md`.
   - Verify all 7 monorepo workspaces, 36 Prisma models, 8 RBAC roles, brand tokens (`#0F2942`, `#FF6B4A`), DPDP 90-day retention schedule, and docker-compose services are specified.
2. **Invalidation Conditions**:
   - The specification is invalidated if any required entity from `ORIGINAL_REQUEST.md` (Users, Roles, Students, Guardians, Staff, Classes, Sections, Attendance, Fee Structures, Concessions, Installments, Payments, Homework, Timetable, Exams, Transport, and Communication) is absent.
   - The specification is invalidated if the response envelope or DPDP compliance controls deviate from R1/R2 and Acceptance Criteria.
