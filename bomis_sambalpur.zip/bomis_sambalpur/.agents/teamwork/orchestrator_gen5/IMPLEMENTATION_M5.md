# Master Implementation Blueprint: Milestone M5 (React Native Expo Mobile App)

## Architecture Overview
Package: `apps/mobile/` (`@bomis/mobile`)
Platform: React Native (Expo SDK 51), TypeScript, `@bomis/shared`, `@bomis/ui`.
Target Persona Roles:
1. **Parent** (`PARENT`): Multi-child sibling switcher (Aarav & Ananya Patel), attendance summary, live bus telemetry with 5-min geofence alert banner for Sakhipada Chhak, fee checkout simulation with RFC 4122 UUID Idempotency-Key, and afternoon pickup single-use 6-digit OTP card with 30-min countdown timer & QR pass.
2. **Student** (`STUDENT`): Digital student ID card with dynamic QR code (House Kalinga, emergency contacts, medical notes), homework & digital diary with status toggles, weekly timetable schedule.
3. **Teacher** (`TEACHER`): Rapid attendance grid (<10s SLA) with 1-click "Mark All Present", exception cycling (`PRESENT`, `ABSENT`, `LATE`, `HALF_DAY`), and offline outbox queue dispatch (`/api/v1/sync/batch`).
4. **Transport Driver** (`TRANSPORT_STAFF`): Route 1 Budharaja Shuttle 4 stops navigation, live GPS broadcaster toggle (periodic location dispatch every 5s), student boarding/deboarding QR scanner with manual fallback.

## Design Tokens & Brand Identity
- **Primary Navy**: `#0F2942` (Header bars, active tabs, primary buttons)
- **Accent Coral**: `#FF6B4A` (Active highlights, notifications, CTAs)
- **Background**: `#F8FAFC`
- **Surface**: `#FFFFFF`
- **Border / Divider**: `#E2E8F0`
- **Text Headings**: `#0F172A`, **Text Secondary**: `#64748B`
- **Status Colors**:
  - Success: `#10B981` (Present, Paid, On-time)
  - Warning: `#F59E0B` (Late, Approaching Geofence)
  - Danger: `#EF4444` (Absent, Overdue, Expired OTP)
  - Info: `#3B82F6` (Notices, Half Day)

## Code Layout & Component Manifest (`apps/mobile/src/`)

### 1. Storage & Offline Sync Layer (`src/services/`)
- `storage-adapter.ts`: 3-tier Adaptive Storage Engine (`IStorageAdapter`) supporting in-memory, web local storage, and async storage without native platform crashes.
- `outbox-queue.ts`: Outbox repository managing pending events (`ATTENDANCE_BATCH`, `BOARDING_SCAN`, `GPS_PING`) with client UUIDs and idempotency keys (`idem_<action>_<uuid>`).
- `sync-manager.ts`: Background sync engine monitoring connectivity, batch-dispatching outbox events to `POST /api/v1/sync/batch`, and clearing synced items.
- `api-client.ts`: Typed fetch client unwrapping standard `ApiResponse<T>` envelope `{ success, data, error, timestamp, correlationId }`, with 401 refresh handling and offline fallback fixtures matching seed data.
- `location-service.ts`: Driver GPS broadcaster simulating Budharaja Shuttle trajectory (Budharaja Fatak -> Sakhipada Chhak -> Ainthapali Chowk -> Campus Gate) and emitting geofence events.

### 2. State & Context Layer (`src/state/`)
- `auth-context.tsx`: Context managing session state, active user profile, mobile token, and active role.
- `parent-context.tsx`: Context managing active child selection (Aarav Patel vs Ananya Patel) with zero cross-child state bleeding.

### 3. Atomic & Shell UI Primitives (`src/components/ui/`)
- `BOMISButton.tsx`: Variants (`primary`, `accent`, `outline`, `ghost`, `danger`), sizes (`sm`, `md`, `lg`), loading spinner.
- `BOMISCard.tsx`: Card container with rounded borders (`rounded-2xl`), elevation shadows, header/content slots.
- `BOMISBadge.tsx`: Pill badges for attendance status, RBAC roles, and geofence alerts with verified contrast.
- `BOMISInput.tsx`: Accessible text/number input with label, prefix icon, and error helper text.
- `BOMISHeader.tsx`: Branded top bar showing campus logo, CBSE affiliation 1530267 badge, active role indicator, and logout trigger.

### 4. Role Screens (`src/screens/`)
- `AuthScreen.tsx`: Indian mobile phone OTP login form + 1-click evaluation quick login presets for all 4 roles.
- `ParentScreen.tsx`: Sibling switcher, attendance metrics card, live bus tracker with 5-minute geofence alert banner, fee checkout modal with Idempotency-Key UUID, and dismissal OTP card with 30-min countdown timer & dynamic QR.
- `StudentScreen.tsx`: Digital student ID card with dynamic QR, homework & assignments list, and weekly timetable grid.
- `TeacherScreen.tsx`: Rapid attendance grid (<10s SLA) for 40-student roster with 1-click "Mark All Present", exception cycling, offline queue badge, and homework poster.
- `DriverScreen.tsx`: Route 1 Budharaja Shuttle stops list, live GPS broadcaster toggle (5s interval), and student boarding/deboarding QR scanner with manual search fallback.

### 5. Application Entrypoint (`apps/mobile/App.tsx`)
- Roots `AuthProvider` and `ParentProvider`.
- Switches views between `AuthScreen` and the active role screen (`ParentScreen`, `StudentScreen`, `TeacherScreen`, `DriverScreen`).
- Renders global offline sync indicator banner when outbox has pending records.

### 6. Verification Suite (`apps/mobile/src/__tests__/`)
- `mobile.spec.ts`: Verification of offline outbox queuing, idempotency key generation, multi-child state isolation, 30-minute OTP countdown lifecycle, and rapid attendance delta dispatch.
