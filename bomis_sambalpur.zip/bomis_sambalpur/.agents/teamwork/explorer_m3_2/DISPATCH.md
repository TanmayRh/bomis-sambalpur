# Dispatch: Explorer M3-2 (Domain Modules & App Architecture)

- Target Agent: teamwork_preview_explorer
- Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_2
- Project Root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur
- Authoritative Sources:
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md (MANDATORY)
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\docs\postman\bomis_postman_collection.json
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\packages\shared
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_survey_1\analysis.md
  - C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\DEAD_ENDS.md


## 2026-10-18T06:56:55Z
You are Explorer 2 for Milestone M3 (NestJS Modular Monolith API) of the BOMIS Sambalpur Unified School Platform.

Your Working Directory:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_2

Project Root:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur

Dispatch Details:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_2\DISPATCH.md

Authoritative Sources to Read (MANDATORY):
1. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
2. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
3. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\TEST_INFRA.md
4. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\docs\postman\bomis_postman_collection.json
5. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\packages\shared
6. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_survey_1\analysis.md
7. C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\DEAD_ENDS.md

Your Mission:
Investigate and design the Domain Modules Architecture and Application Plumbing for NestJS (/apps/api):
1. App Plumbing:
   - Global Validation Pipe utilizing `@bomis/shared` Zod schemas or NestJS validation pipe.
   - Global `HttpExceptionFilter` producing the standard `ApiResponse<T>` envelope for all exceptions.
   - Global `TransformInterceptor` wrapping successful responses into `ApiResponse<T>` with matching `x-correlation-id`.
   - Swagger OpenAPI bootstrap at `/api/docs` with bearer auth definition.
   - Terminus / Health probes at `/health` and `/ready`.
2. Auth & RBAC Module:
   - Dual authentication (Mobile OTP for Parents/Students with mock code `123456`, Email+Password for Staff).
   - JWT Access Token (15m) + Rotating Refresh Token (7d) with Redis / DB family invalidation.
   - `@Roles(...)` decorator and `RolesGuard` validating against the 8 canonical roles in `@bomis/shared`.
   - Public route decorator `@Public()` and current user decorator `@CurrentUser()`.
3. Domain Modules Breakdown & Inter-module boundaries:
   - `people`: Student & Staff profiles, multi-child sibling linkage under guardian, bulk CSV streaming import.
   - `attendance`: Rapid classroom mark (<10s), offline `/api/v1/sync/batch` queue with idempotency, absence push notification trigger.
   - `fees`: Fee structures, Razorpay order generation, HMAC-SHA256 webhook signature verification, `Idempotency-Key` distributed locks, fee receipt PDF generator.
   - `academics`: CBSE 9-point scale grading logic, timetable conflict checker, 1-click teacher substitution.
   - `transport`: GPS ping telematics, Socket.IO gateway, student QR boarding logging.
   - `safety`: Gate visitor pass QR, child pickup OTP verification, anonymous anti-bullying reporting.
   - `ai`: Grade-appropriate curriculum study buddy mock assistant, teacher remarks assist with human-in-the-loop review.
   - `pulse`: Principal Pulse live metrics aggregation API.
4. Comprehensive test strategy for unit & e2e testing of `/apps/api`.

Output:
Write your full investigation report to `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_2\analysis.md`.
Write your handoff report to `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_2\handoff.md` with:
- Observation
- Logic Chain
- Caveats
- Conclusion
- Verification Method
Send a completion message with summary and report path back to the orchestrator.
Do NOT modify any source code files.
