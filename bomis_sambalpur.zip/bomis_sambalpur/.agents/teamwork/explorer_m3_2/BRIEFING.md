# BRIEFING — 2026-10-18T07:15:00Z

## Mission
Investigate and design Domain Modules Architecture and Application Plumbing for NestJS (/apps/api) in Milestone M3.

## 🔒 My Identity
- Archetype: explorer
- Roles: domain modules architecture and application plumbing investigation for NestJS (/apps/api)
- Working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m3_2
- Original parent: 13f64a87-d8b4-4bd5-b7bb-78d55fbd0e64
- Milestone: M3 (NestJS Modular Monolith API)

## 🔒 Key Constraints
- Read-only investigation — do NOT implement
- Do NOT modify any source code files
- Adhere to the 8 canonical roles in @bomis/shared
- Adhere to ApiResponse<T> envelope and x-correlation-id requirements
- Support dual auth (Mobile OTP mock 123456, Email+Password)
- Detailed domain module breakdowns and inter-module boundaries
- Comprehensive test strategy for unit & e2e testing of /apps/api

## Current Parent
- Conversation ID: 13f64a87-d8b4-4bd5-b7bb-78d55fbd0e64
- Updated: 2026-10-18T07:15:00Z

## Investigation State
- **Explored paths**:
  - `ORIGINAL_REQUEST.md` (R1-R5, AC1-AC6)
  - `PROJECT.md` (Modular monolith layout, canonical enums, 8 roles, standard response envelope)
  - `TEST_INFRA.md` (5-tier testing pyramid, Postman test assertions, SLA <1000ms)
  - `DEAD_ENDS.md` (No fake facade mock passes, avoid uncompiled TS exports for node runtime)
  - `packages/shared/` (Zod schemas, types, enums, rbac matrix, standard envelope)
  - `docs/postman/bomis_postman_collection.json` (43 requests across 8 folders + health + RBAC negative gates)
  - `docs/postman/bomis_postman_environment.json` & `docs/postman/run-newman.js`
  - `prisma/schema.prisma` (36 DPDP-compliant models) & `prisma/seed.ts` (Deterministic SEED_IDS, users, passwords)
  - `apps/api/` (`CryptoService`, `main.ts`, `app.module.ts`, `package.json`, `jest.config.js`)
- **Key findings**:
  - Global prefix `api/v1` must exclude `health` and `ready` probes because Postman calls them at `/health` and `/ready`.
  - `TransformInterceptor` must bypass envelope wrapping for raw binary streams (PDF receipts, CSV exports).
  - `VerifyOtpSchema` expects `code`, but Postman sends `otp: "123456"`; DTO must support both fields.
  - Staff password seeded as `Admin@Sambalpur2026`, Parent as `Bomis@Sambalpur2026`, Mobile OTP mock code `123456`.
  - Token rotation requires token family revocation when a revoked token is re-submitted.
  - Full module boundaries and dependency graph defined for all 8 domain modules (`people`, `attendance`, `fees`, `academics`, `transport`, `safety`, `ai`, `pulse`).
- **Unexplored areas**: None within the assigned mission scope.

## Key Decisions Made
- Authored exhaustive architecture blueprint and implementation guide in `analysis.md`.
- Authored 5-component handoff report in `handoff.md`.
- Outlined concrete code blueprints for all plumbing components (`HttpExceptionFilter`, `TransformInterceptor`, `ZodValidationPipe`, Swagger, Terminus).
- Designed in-memory fallback strategy for offline/CI execution.

## Artifact Index
- DISPATCH.md — Task assignment and instructions
- BRIEFING.md — Situational awareness and working memory
- progress.md — Liveness heartbeat and step tracker
- analysis.md — Full investigation report and architecture blueprint
- handoff.md — 5-component handoff report
