# Dispatch: Worker M3 Remediation

- **Role**: Implementer, QA & Domain Specialist (`teamwork_preview_worker`)
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m3_remediation`
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Authoritative Request**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`
- **Project Master Specification**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`
- **Remediation Plan**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen3\REMEDIATION_M3.md`
- **Reviewer 2 Findings**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\reviewer_m3_2_gen2\handoff.md`

## Mandatory Integrity Warning
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

## Remediation Objectives
Implement all 5 mandatory items specified in `REMEDIATION_M3.md`:

1. **Authentic Child Pickup Dismissal OTP (`apps/api/src/modules/safety/safety.service.ts`)**:
   - Remove regex facade `/^\d{6}$/.test(...)`.
   - Maintain active `pickupAuthorizations` in `MockStoreService` (e.g. for student `stu_grade5a_001` and guardian `user_parent_patel`, store active OTP `'482910'`).
   - Authenticate incoming `pickupOtp` against stored OTP. Return `{ authorized: true, ... }` on match; throw `UnauthorizedException` or return `{ authorized: false, ... }` on mismatch or expired OTP.
   - Update `safety.service.spec.ts` to verify valid OTP passes and invalid OTP is rejected.

2. **Dynamic Attendance Percentage Calculation (`apps/api/src/modules/attendance/attendance.service.ts`)**:
   - Remove hardcoded constants `22, 20, 1, 1`.
   - Query `mockStore.attendance` / `prisma.attendance` for student's records in the requested month/year.
   - Aggregate actual counts of `PRESENT`, `HALF_DAY`, and `ABSENT`.
   - Calculate percentage dynamically: `((presentDays + 0.5 * halfDays) / totalWorkingDays) * 100` (guard `totalWorkingDays > 0 ? ... : 0`).
   - Trigger `lowAttendanceAlert = percentage < 75` and `cbseCompliant = !lowAttendanceAlert`.
   - Update `attendance.service.spec.ts` to actually invoke `service.getStudentMonthlyStats(...)` with compliant and low-attendance fixtures.

3. **Dynamic Administrative Audit Trail (`apps/api/src/modules/admin/admin.service.ts`)**:
   - Remove static 2-element array literal.
   - Query `mockStore.auditLogs` / `prisma.auditLog.findMany()`.
   - Record dynamic audit events and return entries sorted by timestamp descending.

4. **Integrate Field-Level Encryption (`apps/api/src/common/crypto/crypto.service.ts`)**:
   - Provide and export `CryptoService` in `CommonModule` or `DatabaseModule`.
   - Inject `CryptoService` into `PeopleService`.
   - Encrypt sensitive student PII (`blood_group` -> `blood_group_encrypted`, `emergency_contact` -> `emergency_contact_encrypted`) using AES-256-GCM before storing.
   - Decrypt when retrieving student profile for authorized users.
   - Add unit tests verifying encrypted storage and decrypted retrieval.

5. **Prisma Schema Alignment & Webhook Validation**:
   - In `academics.service.ts`: Replace `prisma.examTerm.findMany()` with `prisma.exam.findMany()` or mockStore terms.
   - In `people.service.ts`: Update `guardian.student_guardians` to `guardian.children`.
   - In `people.service.ts`: Align `prisma.student.create` arguments with `model Student` fields in `schema.prisma`.
   - In `fees.service.ts`: Align `prisma.feeStructure.findMany` with `model FeeStructure` fields (`class_id`, `academic_year_id`, `fee_category_id`, `amount`).
   - In `fees.service.ts`: Reject webhook calls missing `x-razorpay-signature` header with HTTP 400 Bad Request.

## Verification Commands
After implementing all changes, run:
```bash
pnpm --filter @bomis/api test
pnpm --filter @bomis/api typecheck
pnpm --filter @bomis/api build
```
Deliver your handoff report to `handoff.md` in your working directory.


## 2026-10-18T15:27:34Z
You are Worker M3 Remediation (teamwork_preview_worker).
Your Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m3_remediation
Project Root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur

Read your DISPATCH.md at:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m3_remediation\DISPATCH.md
Read the remediation plan at:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen3\REMEDIATION_M3.md
Read the Reviewer 2 critique at:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\reviewer_m3_2_gen2\handoff.md
Read ORIGINAL_REQUEST.md at:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Task:
Implement the 5 remediation items:
1. Authentic Child Pickup Dismissal OTP in safety.service.ts (authentic store and validation against student/guardian record).
2. Dynamic Attendance calculation in attendance.service.ts (aggregate actual records, remove constant 22,20,1,1).
3. Dynamic administrative audit trail in admin.service.ts (query real logs, remove static 2-item array).
4. Integrate CryptoService into PeopleService for DPDP-compliant field encryption (AES-256-GCM).
5. Align Prisma queries with prisma/schema.prisma (prisma.exam, guardian.children, student.create, feeStructure).

Run verification commands:
- pnpm --filter @bomis/api test
- pnpm --filter @bomis/api typecheck
- pnpm --filter @bomis/api build
Deliver your handoff report to handoff.md in your working directory and message back when done.
