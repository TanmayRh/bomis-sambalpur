# Task Assignment: E2E Test Suite & Postman Newman Architect

## Working Directory
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\test_writer_e2e_1

## Authoritative Reference Files
- ORIGINAL_REQUEST.md: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`
- PROJECT.md: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`
- Frontend/QA Analysis: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_3\analysis.md`
- Backend Analysis: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_2\analysis.md`

## Scope of Work (E2E Testing Track)
1. Author `TEST_INFRA.md` in `.agents/teamwork/` per project specification template.
2. Establish `/docs/postman` directory structure:
   - `bomis_postman_collection.json`: Comprehensive multi-role API collection covering all 8 roles and domain endpoints:
     - Auth & OTP login (`/api/v1/auth/otp/send`, `/api/v1/auth/otp/verify`, `/api/v1/auth/staff/login`, `/api/v1/auth/refresh`)
     - People Management (Users, Students, Guardians, Staff)
     - Attendance Grid & Offline Sync (`/api/v1/attendance`, `/api/v1/sync/batch`)
     - Fees & Razorpay (`/api/v1/fees/structures`, `/api/v1/fees/orders`, `/api/v1/fees/webhook`, `/api/v1/fees/receipts/:id`)
     - Academics & CBSE Grading (`/api/v1/academics/terms`, `/api/v1/academics/marks/batch`, `/api/v1/academics/timetable/clash-check`)
     - Transport Fleet (`/api/v1/transport/routes`, `/api/v1/transport/buses`, `/api/v1/transport/boarding/scan`)
     - Safety & Visitor Passes (`/api/v1/safety/visitors`, `/api/v1/safety/pickup/verify`, `/api/v1/safety/incidents/anonymous`)
     - System Health Probes (`/health`, `/ready`)
   - Pre-request scripts injecting correlation IDs (`x-correlation-id`) and JWT bearer tokens.
   - Post-request assertions verifying HTTP status, standard response envelope (`{ success, data, error, timestamp, correlationId }`), idempotency handling, and data schema.
   - `bomis_postman_environment.json`: Local development environment variables (`baseUrl`, `jwt_token`, `school_id`, etc.).
   - `run-newman.js` / runner script for executing the collection headlessly.
3. Establish Architecture Decision Records in `/docs/adr/`:
   - `0001-monorepo-turborepo-pnpm.md`
   - `0002-dpdp-multi-tenant-isolation-rls.md`
   - `0003-standard-api-response-envelope.md`
   - `0004-offline-first-sync-architecture.md`
4. Deliver detailed handoff report in your working directory (`handoff.md`).

## Mandatory Integrity Warning
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.


## 2026-10-17T11:09:36Z
[Message] timestamp=2026-10-17T11:09:36Z sender=17238c8a-10a1-44ab-93b7-5a2d27f28ea5 priority=MESSAGE_PRIORITY_HIGH content=You are E2E Test Suite & Postman Newman Architect for BOMIS Sambalpur.
Your working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\test_writer_e2e_1
Read your task instructions at C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\test_writer_e2e_1\DISPATCH.md and C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md.

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Scope:
Create TEST_INFRA.md in .agents/teamwork/, create docs/postman with bomis_postman_collection.json (covering all 8 roles, standard response envelope assertions, auth pre-request scripts, correlation ID generation, and domain endpoints), bomis_postman_environment.json, and run-newman.js runner script. Create architecture decision records (ADRs) in docs/adr/.
Run syntax/validation checks. Write handoff.md in your working directory and notify the orchestrator when complete.
