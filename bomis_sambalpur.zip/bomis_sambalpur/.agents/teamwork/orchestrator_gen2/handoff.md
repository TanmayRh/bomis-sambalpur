# Soft Handoff: Orchestrator Generation 2 to Orchestrator Generation 3

- **Predecessor**: Orchestrator Generation 2 (`teamwork_preview_orchestrator`)
- **Successor**: Orchestrator Generation 3 (`teamwork_preview_orchestrator`)
- **Parent Conversation ID**: `f0c35bf8-64ac-47bc-b1c3-1f42570e30fe` (Sentinel)
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Gen 2 Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen2`
- **Gen 3 Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen3`
- **Timestamp**: 2026-10-18T06:55:00Z

---

## 1. Milestone State

| # | Milestone Name | Scope | Dependencies | Status | Gate Verdict |
|---|----------------|-------|--------------|--------|--------------|
| M1 | Monorepo Foundation & Tooling | Turborepo, pnpm workspace, root configs, infra/docker-compose.yml | none | DONE | PASS (CLEAN) |
| E2E| E2E Postman Newman CI Track | 4-tier test runner, /docs/postman, TEST_READY.md | none | DONE | PASS |
| M2 | Shared Packages & DPDP Schema | @bomis/shared, @bomis/ui, 36 Prisma models, AES-256-GCM Crypto, Postgres RLS, Seed Generator | M1 | DONE | PASS (CLEAN) |
| M3 | NestJS Modular Monolith API | /apps/api core, auth, RBAC, domain modules, BullMQ, Socket.IO | M2 | PLANNED (NEXT) | Pending |
| M4 | Next.js 14 Web Portal | /apps/web, shadcn/ui, role dashboards (Admin, Principal, Teacher, Accountant, Parent) | M2, M3 | PLANNED | Pending |
| M5 | React Native Mobile App | /apps/mobile, Expo, offline SQLite queue, camera QR, driver GPS | M2, M3 | PLANNED | Pending |
| M6 | Final Verification & Hardening | Pass 100% E2E tests (Tiers 1-4) then Adversarial Hardening (Tier 5) | M3, M4, M5, E2E | PLANNED | Pending |

---

## 2. Completed in Generation 2 (Milestone M2)

1. **`@bomis/shared`**:
   - 8 Canonical RBAC roles + `DRIVER_TRANSPORT` alias.
   - 41 Granular permissions across 12 domains in `RolePermissionsMap` with `hasPermission()` utility.
   - 20 Domain enums (16 canonical + 4 supplemental).
   - 30 Domain Zod validation schemas and 30 inferred TypeScript types.
   - Standard API response envelope (`ApiResponse<T>`) and `PaginatedData<T>`.
   - Comprehensive unit test suite in `packages/shared/test/shared.spec.ts`.

2. **`@bomis/ui`**:
   - Official brand design tokens (#0F2942 Navy, #FF6B4A Warm Coral), 50–900 scales, typography, spacing, border radii.
   - Component primitives: `roleBadgeColors` for 8 roles, `attendanceStatusStyles`, `buttonVariants`.
   - Tailwind preset `bomisTailwindPreset` consumed by `apps/web/tailwind.config.ts`.
   - Unit test suite in `packages/ui/test/tokens.spec.ts`.

3. **`prisma/schema.prisma` Hardened**:
   - Exactly 36 production models across 9 domains with full relations and composite indexes.
   - Multi-tenant isolation: `school_id String @db.Uuid` on all 35 tenant models.
   - DPDP Act (2023) 90-day retention schedule: `deleted_at`, `retention_until`, and `@@index([deleted_at])` on all 17 personal data models.
   - `Consent` ledger model with SHA-256 HMAC `proof_hash String @db.VarChar(64)`.
   - Immutable `AuditLog` table with PostgreSQL engine rules (`DO INSTEAD NOTHING`) in `infra/postgres/init_rls.sql`.
   - Field-level encrypted PII mapped to `@db.Text` (`blood_group_encrypted`, `medical_notes_encrypted`, `aadhaar_number_encrypted`, `annual_income_encrypted`, `pan_number_encrypted`, `visitor_id_number_encrypted`).
   - Hardened via Challenger remediation:
     - `Payment.receipt_number` tenant-scoped via `@@unique([school_id, receipt_number])`.
     - `Payment.student` enforced via `onDelete: Restrict` to protect statutory 8-year accounting retention.
     - `VisitorPass.pass_code` tenant-scoped via `@@unique([school_id, pass_code])`.
     - `FeeInstallment` idempotency enforced via `@@unique([school_id, student_id, fee_structure_id, installment_number])`.
     - Performance indexes added to `Student`, `Payment`, `FeeInstallment`, `StudentGuardian`, `FeeConcession`, and `VisitorPass`.
     - Referential relations to `Staff` on `FeeConcession` (`ConcessionApprover`) and `VisitorPass` (`VisitorHost`).

4. **AES-256-GCM Field-Level Cryptography**:
   - Implemented in `apps/api/src/common/crypto/crypto.service.ts`.
   - 96-bit random IVs, 128-bit authentication tags, version prefix (`v1:...`), AAD tenant binding, key length validation, and zero-downtime rotation.
   - Unit tests in `apps/api/src/common/crypto/crypto.service.spec.ts`.

5. **Realistic Seed Data Generator**:
   - Implemented in `prisma/seed.ts`.
   - Seeds BOMIS Sambalpur root school, Academic Year 2026-2027, Grades 1–8 Section A, classrooms (101-204), CBSE subjects.
   - Seeds 8 RBAC users with deterministic credentials matching Newman tests (`admin@bomis-sambalpur.edu.in` / `Admin@Sambalpur2026`, `+919876543210` / mock OTP `123456`).
   - Seeds 4 pilot buses with `OD-15` Sambalpur plates, 4 routes with 15 geofenced stops, and Patel family multi-child sibling linkages across 5A and 2A.
   - 100% idempotent via upserts and compound unique constraints.

6. **Gate 2 Verification**:
   - Build/test verification: PASS
   - Reviewer M2-Rem-1 (`613db4ca-5542-4dd7-b337-7c1bc3d77e3b`): APPROVE
   - Reviewer M2-Rem-2 (`258b0888-d203-49d4-880e-46dd79e4cf24`): APPROVE
   - Challenger M2-Rem-1 (`7e66feec-f14e-467e-be88-decfcfa81440`): APPROVE
   - Challenger M2-Rem-2 (`3ef20537-29e6-4cf5-8882-8c25e25c4653`): APPROVE
   - Forensic Auditor M2-Rem-1 (`82edd2eb-92ce-4933-978b-09f82977f8ef`): CLEAN

---

## 3. Active Subagents

- **0 Active Subagents**: All 16 subagents spawned in Generation 2 have delivered their handoff reports and are completed.

---

## 4. Pending Decisions & Constraints for Gen 3

1. **Parent Identity**: Your parent is Sentinel (`f0c35bf8-64ac-47bc-b1c3-1f42570e30fe`). Send status reports and final completion messages to this ID via `send_message`.
2. **Dispatch-Only Constraint**: Do NOT write application source code directly. Always delegate implementation to workers, verification to reviewers, challengers, and forensic auditors.
3. **Audit Binary Veto**: A CLEAN forensic audit is strictly required. Any INTEGRITY VIOLATION immediately vetoes the gate.
4. **Environment Command Permission**: Note that terminal command executions (`pnpm test`, `npx prisma`) may trigger environmental permission denials. When workers encounter this, require thorough static verification, TypeScript compiler type-checking, and full test suite authoring.

---

## 5. Remaining Work & Concrete Next Steps for Gen 3

Advance immediately to **Milestone M3: NestJS Modular Monolith API**:
1. Initialize Orchestrator Gen 3 directory: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen3`.
2. Start 10-minute heartbeat cron via `schedule(CronExpression="*/10 * * * *")`.
3. Dispatch Milestone M3 Explorers to map the modular monolith domain architecture:
   - Core & Infra: Prisma service with RLS middleware, Pino structured logger with `correlationId` AsyncLocalStorage, global validation pipe, HttpExceptionFilter standard envelope (`ApiResponse<T>`), Swagger OpenAPI at `/api/docs`, Terminus `/health` & `/ready` probes.
   - Auth Module: Dual authentication (Parent/Student mobile OTP via mock code `123456`, Staff email+password/OTP), rotating JWT refresh tokens with family revocation, 8-role RBAC `@Roles()` guards.
   - People Master: Multi-child sibling linking under guardian, streaming bulk CSV ingestion with row validation error reporting.
   - Attendance Module: Rapid attendance grid (<10s classroom mark), `/api/v1/sync/batch` offline sync queue with conflict resolution, instant FCM push absence alert dispatch.
   - Homework & Diary: Rich text homework, MinIO attachment storage, student submission tracking.
   - Fees & Financial Safety: Fee structure & installment generation, multi-step concession approvals, Razorpay payment gateway integration (mock test mode) with HMAC webhook signature verification, `Idempotency-Key` header financial safety, BullMQ fee tax receipt PDF generator.
   - Academics & CBSE: CBSE 9-point grading validation, timetable scheduler with teacher/room clash detection, 1-click substitute teacher reassignment, BullMQ report card PDF generator.
   - Transport Fleet: Socket.IO GPS location gateway, geofence 5-minute proximity alerts, QR student boarding/deboarding logging.
   - Safety & Governance: QR visitor pass management, child pickup OTP verification, anonymous anti-bullying incident reporting, DPDP health record access controls.
   - AI Assistance: Grade-appropriate study buddy mock assistant, teacher lesson planner draft remarks assist with mandatory human approval.
4. Dispatch Worker M3 to implement the NestJS modules.
5. Run Milestone M3 Verification Gate (2 Reviewers, 2 Challengers, 1 Forensic Auditor).
6. Proceed to Milestone M4 (Next.js Web Portal) and M5 (React Native Mobile App).

---

## 6. Key Artifacts Index

- `ORIGINAL_REQUEST.md`: Authoritative User Requirements
- `PROJECT.md`: Master Architecture, Feature Inventory, Milestones, and Interface Contracts
- `TEST_INFRA.md`: E2E Test Suite Specification
- `TEST_READY.md`: E2E Test Suite Readiness Signal
- `GATE_STATUS.md`: Gate History for M1 (PASS) and M2 (PASS)
- `spec_miner_survey_1/analysis.md`: Complete Architectural Blueprint & Specifications
- `packages/shared`: Canonical domain enums, 8-role RBAC permissions matrix, Zod validation schemas, API envelope contracts
- `packages/ui`: BOMIS Sambalpur brand tokens (#0F2942, #FF6B4A), component style maps, Tailwind preset
- `prisma/schema.prisma`: 36 Production models with multi-tenant `school_id`, DPDP 90-day retention, AES-256-GCM encrypted fields, consent ledger, immutable audit logs
- `apps/api/src/common/crypto/crypto.service.ts`: Enterprise AES-256-GCM cryptographic utility with key rotation and AAD tenant binding
- `prisma/seed.ts`: Realistic idempotent seed data generator for Grades 1–8 Section A, 4 pilot buses (`OD-15`), and deterministic Newman credentials
- `infra/postgres/init_rls.sql`: PostgreSQL kernel-level Row-Level Security policies and immutable audit engine rules
