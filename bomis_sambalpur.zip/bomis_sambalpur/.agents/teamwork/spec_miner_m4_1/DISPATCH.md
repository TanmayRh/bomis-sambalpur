# Dispatch: Spec Miner (M4 UI Primitives, Brand Tokens & Design System)

- **Target Agent**: `teamwork_preview_spec_miner`
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m4_1`
- **Project Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`
- **Parent Conversation ID**: `29096207-ec62-4de3-8de4-3261b9a78aa2`
- **Authoritative Request**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`
- **Project Master Specification**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`
- **UI Package**: `packages/ui`

## Mission & Objectives
Mine and specify the design system, brand tokens, and UI primitives for Milestone M4 (`apps/web`):
1. **Brand Tokens & Tailwind CSS**:
   - Primary: `#0F2942` (BOMIS Navy/Teal), Accent: `#FF6B4A` (Warm Coral), Backgrounds, Text, Muted neutrals.
   - Tailwind CSS configuration extending colors, font families, and container utilities.
2. **Component Library (shadcn/ui primitives)**:
   - Atomic components needed in `apps/web/src/components/ui`: Button, Input, Card, Badge, Table, Dialog, Select, Tabs, Alert, Avatar, DropdownMenu.
   - Composite layout primitives: DashboardShell, Sidebar, TopNavbar, UserNav, RoleSwitcher, StatCard, DataTable.
3. **Responsive Design & Accessibility**:
   - Mobile-first responsive breakpoints (sm, md, lg, xl).
   - Touch targets and accessible contrast.
4. **Deliverable**:
   - Write structured specification report in `handoff.md` with full component code templates, styling rules, and test plan.
   
## 2026-10-19T04:53:46Z
[Message] timestamp=2026-10-19T04:53:46Z sender=29096207-ec62-4de3-8de4-3261b9a78aa2 priority=MESSAGE_PRIORITY_HIGH
content=You are Spec Miner (M4 UI Primitives, Brand Tokens & Design System).
Your Working Directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m4_1
Project Root: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur
Parent Conversation ID: 29096207-ec62-4de3-8de4-3261b9a78aa2

Read DISPATCH.md in your working directory first.
Read the authoritative request at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
Read the project master specification at: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md

Mine and design the design tokens (BOMIS palette #0F2942 Navy, #FF6B4A Warm Coral), Tailwind CSS configuration, shadcn/ui atomic components (Button, Input, Card, Badge, Table, Dialog, Select, Tabs, Alert), composite shell (Sidebar, TopNavbar, UserNav, RoleSwitcher, StatCard), and component testing strategy.
Write handoff.md in your working directory and send a message back to parent (29096207-ec62-4de3-8de4-3261b9a78aa2) upon completion.
