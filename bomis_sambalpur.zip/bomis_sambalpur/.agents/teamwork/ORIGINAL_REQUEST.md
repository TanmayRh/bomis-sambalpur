# Original User Request

## Initial Request — 2026-10-17T10:59:49Z

# Teamwork Project Prompt — Approved & Ready for Execution

> Status: Launched — Delegated to teamwork_preview
> Goal: Multi-agent execution of Phase 0 Foundation & Monorepo Scaffold
> Requested team: Full multi-agent engineering team (Monorepo Architect, NestJS Backend Engineer, Next.js / React Native Frontend Engineer, QA / Postman Engineer, DevOps Specialist)

Unified School Platform for Birla Open Minds International School, Sambalpur (Odisha) — a production-grade, multi-role school operating system replacing fragmented tools (paper diaries, WhatsApp groups, spreadsheets, manual fee receipts) with a high-performance TypeScript monorepo.

Working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur
Integrity mode: development

## Requirements

### R1. Architecture & Monorepo Foundation (Phase 0)
Scaffold and configure a Turborepo + pnpm monorepo consisting of:
- /apps/api: NestJS modular monolith with strict domain modules, global validation pipes, Pino JSON logger with correlation/request IDs, custom error envelope, Swagger OpenAPI at /api/docs, and /health + /ready endpoints.
- /apps/web: Next.js 14 App Router, Tailwind CSS, shadcn/ui design primitives, TanStack Query, React Hook Form, and Zod.
- /apps/mobile: React Native (Expo) multi-role app supporting iOS and Android, offline-first sync architecture, secure storage, and push notifications.
- /packages/shared: Shared TypeScript types, Zod validation schemas, domain enums, RBAC role permissions, and API contract specifications.
- /packages/ui: Shared design tokens (BOMIS Sambalpur brand palette: navy/teal primary #0F2942, warm coral accent #FF6B4A), typography, and reusable UI tokens.
- /infra: Docker Compose for local development (PostgreSQL 16, Redis 7, MinIO S3-compatible, Mailpit), Dockerfiles, and CI workflow templates.
- /docs: Architecture Decision Records (ADRs), DB schema documentation, and Newman-automated Postman collections.

### R2. Data Model & DPDP-Compliant Multi-Tenant Schema (Phase 0/1)
Implement a comprehensive Prisma schema with:
- Multi-tenant isolation with school_id indexed on all business tables and Postgres Row-Level Security (RLS) support.
- Digital Personal Data Protection (DPDP) Act compliance: soft deletes with 90-day retention before cryptographic erasure, consent tracking, and field-level encryption for sensitive health/identity data.
- Immutable audit_logs tracking user actions, entity mutations, diffs, IP addresses, and timestamps.
- Models covering Users, Roles, Students, Guardians, Staff, Classes, Sections, Attendance, Fee Structures, Concessions, Installments, Payments, Homework, Timetable, Exams, Transport, and Communication.

### R3. Identity, RBAC & Core Operations MVP (Phase 1)
Implement:
- Auth: Mobile OTP login for parents/students, email + password/OTP for staff, short-lived JWTs, rotating refresh tokens, session revocation, and rate limiting.
- RBAC: 8 distinct roles (Parent, Student, Teacher, Principal, Admin, Accountant, Transport/Driver, Super Admin).
- People management: Student and staff master profiles, multi-child sibling linking, guardian access control, and bulk CSV import/export.
- Attendance: Teacher rapid attendance grid (<10 seconds per class), offline queue sync, instant FCM parent push alerts, and staff attendance/leave module.
- Digital Diary & Homework: Rich text, file attachments, submission tracking, read receipts, and circular acknowledgements.
- Fees: Fee categories, structures, concession approval workflows, Razorpay payment gateway integration (UPI/Netbanking/Cards test mode), receipt generation, day-wise reconciliation, and accountant collection dashboard.

### R4. Academics, Transport & Communication (Phase 2)
Implement:
- Timetable: Automated schedule generator with teacher/room clash detection and one-click teacher absence substitution.
- Exams & Report Cards: Configurable CBSE-pattern terms and grading scales, marks entry with validation, and automated PDF report card rendering via BullMQ background workers.
- Transport: Routes, stops, driver mini-app broadcasting GPS coordinates via WebSockets/Socket.IO, student boarding/deboarding QR scanning, geofence-based "5-minute away" parent alerts, and fleet monitoring for 4 pilot buses (3 small, 1 full-size).
- Communication: School-hours constrained parent-teacher chat, emergency SOS broadcasts, multi-lingual support (English, Hindi, Odia), and PTM slot scheduling.

### R5. AI Layer, Safety & Advanced Operations (Phases 3-4)
Implement:
- AI Layer: Concept-explaining Study Buddy with syllabus grounding, teacher lesson planner & rubric assistant, draft report card remarks generator (mandatory human-in-the-loop teacher edit/approval), and parent natural-language concierge.
- Safety: Visitor management with QR pre-approved gate passes, OTP/QR child pickup verification, anonymous anti-bullying reporting, and access-controlled health records.
- Operations: Digital student/staff ID cards with QR, library catalog & circulation, and Principal's real-time Pulse dashboard.

## Acceptance Criteria

### Verification & Quality Assurance
- [ ] Type & Schema Synchronization: All frontend and backend validation originates from /packages/shared Zod schemas with 100% type congruence.
- [ ] Standardized Envelope: All REST endpoints return { success: boolean, data: T, error?: { code: string, message: string, details?: any }, timestamp: string, correlationId: string }.
- [ ] Idempotency & Financial Safety: All payment endpoints enforce Idempotency-Key headers; Razorpay webhooks verify cryptographic signatures with duplicate payload protection.
- [ ] Test Coverage: Minimum 70% test coverage on business logic (fee calculation, attendance percentages, grading algorithms, timetable clash detection), with role-scoping tests verifying zero unauthorized data exposure.
- [ ] Postman & Newman CI: Exported Postman collection and environment in /docs/postman featuring pre-request role authentication, test assertions on all endpoints, and passing cleanly in GitHub Actions CI.
- [ ] One-Command Bootstrapping: docker compose up -d followed by pnpm install && pnpm db:migrate && pnpm db:seed && pnpm dev starts the entire platform with realistic seed data for Grades 1–8 Section A and 4 buses.

## Follow-up — 2026-10-20T07:05:19Z

Server restarted. Account switched and fresh quota is fully active. Resume immediately: check on Orchestrator Gen 5, synthesize M4 verification gate findings, apply the remediation fixes for M4, achieve clean approval, and advance to Milestone M5 (React Native Expo Mobile App) and M6 (Final Verification).

## Follow-up — 2026-10-20T08:59:41Z

Temporary capacity spike cleared. Continue working immediately: supervise worker_m4_remediation and Orchestrator Gen 5, complete Gate Iteration 2 re-verification, mark Milestone M4 DONE, and proceed to Milestone M5 (React Native Expo Mobile App) and Milestone M6 (Final Verification).

## Follow-up — 2026-10-21T04:35:06Z

Server restarted. System has fresh capacity. Resume execution immediately: acknowledge worker_m4_remediation handoff, convene Gate Iteration 2 re-verification, mark Milestone M4 DONE, and proceed to Milestone M5 (React Native Expo Mobile App for iOS and Android) and Milestone M6 (Final Verification).

## Follow-up — 2026-10-22T09:54:18Z

Server restarted. Quota has fully reset. Resume immediately: supervise Orchestrator Gen 6, complete Milestone M6 Phase 1 (100% E2E test runs) and Phase 2 (Adversarial Hardening), run the final Forensic Integrity Audit, and deliver the final Victory Audit report.

## Follow-up — 2026-10-22T10:05:59Z

Server restarted. Resume immediately: supervise Orchestrator Gen 6, synthesize explorer_m6_1/2/3 findings, dispatch worker for E2E test runs, run Tier 5 adversarial hardening, conduct the final Forensic Integrity Audit, and deliver the final Victory Audit.


## Follow-up — 2026-10-22T11:30:01Z

Server restarted. System is active. Resume immediately: supervise Orchestrator Gen 6, collect challenger_m6_recheck verdict, certify Milestone M6 DONE, and conduct the final Victory Audit to declare project completion!
