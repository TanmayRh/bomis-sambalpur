# DISPATCH — 2026-10-21T05:35:00Z

## Milestone M5 Remediation Worker Task Assignment

- **Role**: `worker` (`teamwork_preview_worker`)
- **Assigned Worker Name**: `worker_m5_remediation`
- **Orchestrator Conversation ID**: `61cb1a70-f093-4eb1-8970-0e6aa09a7e37`
- **Target Application**: `apps/mobile/` (`@bomis/mobile`)
- **Exclusive Write Ownership**:
  - `apps/mobile/src/__tests__/mobile.spec.ts`
  - `apps/mobile/src/screens/ParentScreen.tsx`

---

## Authoritative Reference Documents
Before starting work, read:
1. `ORIGINAL_REQUEST.md`: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md`
2. `PROJECT.md`: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md`
3. `GATE_STATUS.md`: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen5\GATE_STATUS.md`
4. `CHALLENGER_M5_1_REPORT`: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\challenger_m5_1\handoff.md`

---

## Mandatory Integrity Warning
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

---

## Detailed Task Scope

### 1. Resolve Strict TypeScript Index Errors in `apps/mobile/src/__tests__/mobile.spec.ts`
The monorepo root `tsconfig.base.json` enforces `"noUncheckedIndexedAccess": true`.
In `apps/mobile/src/__tests__/mobile.spec.ts`, array index lookups treat elements as `T | undefined`. Add non-null assertions (`!`) or type guards across all array accesses:
- Line 103: `expect(all[0]!.id).toBe(item.id);`
- Line 110: `let current = (await outbox.getAll())[0]!;`
- Lines 111, 115, 121: `expect(current.status)...`
- Line 130: `items[0]!.timestamp = Date.now() - 2 * 86400000;`
- Line 140: `expect(remaining[0]!.id).toBe(freshItem.id);`
- Line 184: `expect(result?.results[0]!.status).toBe('SYNCED');`
- Line 196: `const aarav = SEED_PERSONAS.PARENT.children[0]!;`
- Line 197: `const ananya = SEED_PERSONAS.PARENT.children[1]!;`
- Line 230: `childDataMap[aarav!.id]!.attendanceRate`
- Line 233: `childDataMap[ananya!.id]!.attendanceRate`
- Lines 292-294:
  - `roster[1]!.status = AttendanceStatus.ABSENT;`
  - `roster[5]!.status = AttendanceStatus.LATE;`
  - `roster[12]!.status = AttendanceStatus.HALF_DAY;`
- Lines 320-321:
  - `const fatak = ROUTE_1_BUDHARAJA_WAYPOINTS[0]!;`
  - `const sakhipada = ROUTE_1_BUDHARAJA_WAYPOINTS[1]!;`
- Line 336:
  - `ROUTE_1_BUDHARAJA_WAYPOINTS[1]!.latitude` and `ROUTE_1_BUDHARAJA_WAYPOINTS[1]!.longitude`
- Verify any other array accesses in `mobile.spec.ts` to ensure 100% type cleanliness under `noUncheckedIndexedAccess: true`.

### 2. Synchronize Countdown Timer in `apps/mobile/src/screens/ParentScreen.tsx`
In `apps/mobile/src/screens/ParentScreen.tsx` (around lines 70–76), inside the `useEffect` listening to `dismissalPass.expiresAt`:
Synchronously calculate and set `setSecondsRemaining(Math.max(0, Math.floor((dismissalPass.expiresAt - Date.now()) / 1000)))` BEFORE starting `setInterval(...)`. This ensures immediate synchronization with zero 1-second lag when switching active siblings (Aarav vs Ananya).

---

## Verification & Deliverable Requirements
1. Run typecheck / compilation on `@bomis/mobile` (e.g. `pnpm --filter @bomis/mobile typecheck` or `tsc --noEmit -p apps/mobile/tsconfig.json`).
2. Run tests (e.g. `pnpm --filter @bomis/mobile test`).
3. Document exact commands run and output status in your handoff report.
4. Write your full handoff report to:
   `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m5_remediation\handoff.md`
5. Send a completion message back to orchestrator (`61cb1a70-f093-4eb1-8970-0e6aa09a7e37`).
