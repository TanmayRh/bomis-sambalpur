# BRIEFING — 2026-10-21T04:48:00Z

## Mission
Investigate and design technical plumbing for offline-first synchronization, hardware simulation, and secure storage in `apps/mobile`.

## 🔒 My Identity
- Archetype: explorer
- Roles: Mobile Offline Sync & Hardware Emulation Explorer
- Working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m5_2
- Original parent: 61cb1a70-f093-4eb1-8970-0e6aa09a7e37
- Milestone: M5 (Mobile Experience & Hardware Emulation)

## 🔒 Key Constraints
- Read-only investigation — do NOT implement
- Inspect existing codebase (`apps/mobile`, `apps/api`, packages, shared contracts, schemas)
- Design must support iOS, Android, and web preview (Expo)
- Design must account for Sambalpur network conditions (intermittent 4G/edge)

## Current Parent
- Conversation ID: 61cb1a70-f093-4eb1-8970-0e6aa09a7e37
- Updated: 2026-10-21T04:48:00Z

## Investigation State
- **Explored paths**:
  - `apps/mobile/package.json`, `app.json`, `App.tsx`, `tsconfig.json`
  - `apps/api/src/modules/attendance/sync.controller.ts`, `attendance.service.ts`
  - `apps/api/src/modules/transport/transport.controller.ts`, `transport.service.ts`
  - `apps/api/src/modules/safety/safety.controller.ts`, `safety.service.ts`
  - `apps/api/src/modules/auth/auth.controller.ts`, `auth.service.ts`
  - `apps/api/src/database/seed-fixtures.ts`
  - `packages/shared/src/contracts/index.ts`, `schemas/index.ts`, `types/index.ts`, `enums/index.ts`
  - `apps/web/src/lib/api-client.ts`, `auth-store.ts`, `apps/web/src/components/modules/parent/live-bus-tracker.tsx`, `pickup-otp-card.tsx`, `rapid-attendance-grid.tsx`
- **Key findings**:
  - Backend `POST /api/v1/sync/batch` handles `ATTENDANCE_BATCH`, `BOARDING_SCAN`, `GPS_PING` with Redis idempotency deduplication (`sync:${cacheKey}`), caching for 86400s.
  - `@bomis/shared` provides `OfflineSyncEventSchema` & `OfflineSyncBatchSchema` which strictly type sync payloads.
  - Transport GPS broadcasting is accepted at `POST /api/v1/transport/gps-ping` and boarding scans at `POST /api/v1/transport/boarding/scan`.
  - Child pickup verification at `POST /api/v1/safety/pickup/verify` strictly enforces 6-digit numeric OTP, status `ACTIVE`, and single-use transition to `USED`.
  - Lean dependency profile in `apps/mobile`: requires an isomorphic storage abstraction that seamlessly supports Native (AsyncStorage / SecureStore), Web Preview (`localStorage`), and Headless Node/Jest (`MemoryStorageAdapter`).
- **Unexplored areas**: None. Complete evidence chain gathered across backend, shared packages, and web frontend.

## Key Decisions Made
- Designed 3-tier Adaptive Storage Architecture (`IStorageAdapter`) with zero native crash risk in Expo Web.
- Designed Outbox Storage Queue with idempotency keys, automatic replay on reconnect, and exponential backoff retry.
- Designed Sambalpur Route Waypoint GPS Simulator with Haversine 5-minute geofence alert for Sakhipada Chhak (`OD-15-AB-1001`).
- Designed Student QR scanner with camera support + simulator fallback toolbar.
- Designed Dismissal OTP dynamic QR generator with 30-min countdown and single-use gate validation.
- Designed `MobileApiClient` with standard envelope unwrapping, concurrency-safe token refresh, and seed data offline fallback fixtures.

## Artifact Index
- DISPATCH.md — incoming dispatch instructions
- BRIEFING.md — persistent situational awareness
- progress.md — liveness heartbeat
- handoff.md — final technical design report
