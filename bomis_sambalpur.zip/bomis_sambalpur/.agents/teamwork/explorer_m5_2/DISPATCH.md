## 2026-10-21T04:38:13Z
You are explorer_m5_2 (Mobile Offline Sync & Hardware Emulation Explorer).
Your working directory is C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m5_2.
Your orchestrator conversation ID is 61cb1a70-f093-4eb1-8970-0e6aa09a7e37.

You MUST read the following authoritative documents before starting your investigation:
- ORIGINAL_REQUEST: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
- PROJECT: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md

OBJECTIVE:
Investigate and design the technical plumbing for offline-first synchronization, hardware simulation, and secure storage in `apps/mobile`:
1. Offline-First Sync Architecture:
   - Outbox storage queue for mutations made offline (Teacher rapid attendance deltas, Driver boarding logs).
   - Sync service/manager that listens for network availability and automatically replays pending items to `POST /api/v1/sync/batch` with idempotency keys.
   - Storage layer compatible with Expo (AsyncStorage / in-memory / SQLite wrapper) that works reliably across iOS, Android, and web preview.
2. Hardware & Native Capabilities:
   - Driver GPS Broadcaster: Location broadcasting service with configurable ping interval (e.g. 5s-10s) updating pilot bus coordinates (`OD-15-AB-1001`, etc.) along Sambalpur routes.
   - Student QR Boarding Scanner: Camera QR scanning interface with simulator fallback for rapid developer/CI verification.
   - Dismissal OTP dynamic QR generation and validation.
3. Mobile API Client & Session Persistence:
   - Standard envelope unwrapping `{ success, data, error, timestamp, correlationId }`.
   - Token refresh handling and offline fallback fixtures matching monorepo seed data.

DELIVERABLE:
Write your technical design report to:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m5_2\handoff.md
Follow the Handoff Protocol (Observation, Logic Chain, Caveats, Conclusion, Verification Method).
Send a message back to your orchestrator (61cb1a70-f093-4eb1-8970-0e6aa09a7e37) when done.
