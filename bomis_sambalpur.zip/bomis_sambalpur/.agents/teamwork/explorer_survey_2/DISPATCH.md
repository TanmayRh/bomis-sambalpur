# Task Assignment: Backend & Operations Explorer

## Working Directory
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_2

## Authoritative Reference
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md

## Mission
Analyze ORIGINAL_REQUEST.md with focus on:
1. NestJS Modular Monolith API architecture (/apps/api), global validation pipes, Pino JSON logger with correlation/request IDs, standardized error envelope, Swagger OpenAPI at /api/docs, and health/ready endpoints.
2. Auth & RBAC (8 roles: Parent, Student, Teacher, Principal, Admin, Accountant, Transport/Driver, Super Admin; mobile OTP, email+password/OTP, short-lived JWT, refresh tokens, session revocation, rate limiting).
3. Core domain modules:
   - People management (Students, Guardians, Staff, sibling linking, CSV import/export)
   - Attendance (rapid grid <10s, offline sync queue, FCM parent alerts, staff leaves)
   - Diary & Homework (rich text, attachments, submissions, read receipts)
   - Fees (categories, structures, concessions workflow, Razorpay integration, idempotency, day-wise reconciliation)
   - Academics (CBSE timetable clash detection, substitution, CBSE grading, BullMQ PDF report card rendering)
   - Transport (WebSockets/Socket.IO GPS broadcast, QR boarding/deboarding, geofencing 5-min alert, 4 pilot buses)
   - AI & Safety (Study Buddy, Lesson planner, Report remarks, Visitor passes, Pickup OTP/QR, Anti-bullying, Health records)

Deliver comprehensive analysis to your working directory:
`analysis.md` and `handoff.md`.


## 2026-10-17T11:03:09Z
You are Backend & Operations Explorer for BOMIS Sambalpur.
Your working directory: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_2
Your task assignment: Read C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_2\DISPATCH.md and C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md.
Analyze all requirements for NestJS modular monolith API (/apps/api), 8-role RBAC, Auth with mobile OTP / email+password, people management, attendance grid & offline queue, fees & Razorpay integration, CBSE academics & report cards, transport tracking, AI & safety modules.
Write your detailed analysis to analysis.md and a self-contained handoff.md in your working directory.
Update progress.md with your liveness heartbeat. When done, send a message to orchestrator with your findings and file path.
