# Handoff Report: Backend & Operations Architecture

- **Author**: Backend & Operations Explorer (`explorer_survey_2`)
- **Date**: 2026-10-17T11:07:00Z
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_2`
- **Recipient**: Orchestrator (`17238c8a-10a1-44ab-93b7-5a2d27f28ea5`) & Monorepo Implementation Engineers

---

## 1. Observation

Direct observations from inspection of `ORIGINAL_REQUEST.md` (lines 1 to 66) and the workspace environment:

1. **Monorepo Layout & API Scope (`ORIGINAL_REQUEST.md:18-26`)**:
   - `/apps/api` must be structured as a NestJS modular monolith with strict domain modules.
   - Foundation infrastructure requires: global validation pipes, Pino JSON logger with correlation/request IDs, standardized error envelope, Swagger OpenAPI at `/api/docs`, and `/health` + `/ready` endpoints.
2. **Data Model & Regulatory Compliance (`ORIGINAL_REQUEST.md:28-33`)**:
   - Multi-tenant isolation requires indexed `school_id` on all business tables with Postgres Row-Level Security (RLS) support.
   - Compliance with the Digital Personal Data Protection (DPDP) Act 2023 requires: soft deletes with 90-day retention prior to cryptographic erasure, consent tracking (`ConsentLog`), and field-level encryption for sensitive health/identity data.
   - Immutable `audit_logs` tracking user actions, entity mutations, diffs, IP addresses, and timestamps.
3. **Identity & Core Operations (`ORIGINAL_REQUEST.md:35-42`)**:
   - 8 discrete roles: `Parent`, `Student`, `Teacher`, `Principal`, `Admin`, `Accountant`, `Transport/Driver`, `Super Admin`.
   - Dual authentication: Mobile OTP login for parents/students; email + password/OTP for staff.
   - Token lifecycle: Short-lived access JWTs, rotating refresh tokens, instant session revocation, and Redis-backed rate limiting.
   - People management: Student/staff master profiles, multi-child sibling linking under guardian accounts, CSV bulk import/export.
   - Attendance: Rapid classroom grid (<10 seconds per class), offline queue synchronization, automated parent FCM alerts for absences, staff leave management.
   - Digital Diary & Homework: Rich text descriptions, file attachments (MinIO), student submission tracking, circular read receipts.
   - Fees & Financial Safety: Fee categories/structures, concession approval workflows, Razorpay payment gateway integration (UPI/Netbanking/Cards test mode), automated digital PDF receipt generation, and day-wise reconciliation.
4. **Academics & Transport Operations (`ORIGINAL_REQUEST.md:44-50`)**:
   - Timetable: Clash detection (teacher and room availability) and one-click teacher absence substitution.
   - CBSE Examinations: Configurable CBSE terms (PT1, PT2, Half-Yearly, Annual), 9-point scholastic grading scale (A1 to E), co-scholastic grading (A, B, C), marks entry boundary validation, and asynchronous PDF report card rendering via BullMQ background workers.
   - Transport: 4 pilot buses (3 small, 1 full-size), driver mini-app broadcasting GPS coordinates via WebSockets/Socket.IO, student boarding/deboarding QR scanning, and geofence-based "5-minute away" parent push alerts.
5. **AI Layer & Safety (`ORIGINAL_REQUEST.md:51-55`)**:
   - AI features: Syllabus-grounded concept Study Buddy (Grades 1–8), teacher lesson planner/rubric assistant, draft report card remarks generator with mandatory human-in-the-loop teacher review/approval, and parent natural-language concierge.
   - Safety modules: Pre-approved visitor passes with QR verification, OTP/QR child pickup verification, anonymous anti-bullying incident reporting (zero IP/user logging), and access-controlled medical/health records.
6. **Acceptance Criteria (`ORIGINAL_REQUEST.md:57-66`)**:
   - Standardized REST envelope: `{ success: boolean, data: T, error?: { code, message, details }, timestamp, correlationId }`.
   - Idempotency & Financial Safety: Strict `Idempotency-Key` headers on payment endpoints; HMAC-SHA256 signature verification on Razorpay webhooks with duplicate payload protection.
   - Test Coverage: Minimum 70% business logic coverage (fees, attendance, grading, timetable clashes).

---

## 2. Logic Chain

1. **Modular Monolith Rationale (From Observation 1)**:
   A distributed microservices architecture would introduce unnecessary operational complexity, network latency, and transactional boundary issues for a single K-12 school deployment. A NestJS modular monolith with strict encapsulation (domain modules, shared TypeScript interfaces, event emitters) achieves identical architectural cleanliness while remaining simple to deploy and test.
2. **Unified Security & Dual Auth Rationale (From Observation 3)**:
   Parents in India predominantly interact via mobile devices and expect frictionless mobile OTP login, whereas faculty and administrative staff require structured email + password credentials with role-based dashboard access. Using short-lived access JWTs (15 min) and rotating refresh tokens (7 days) stored in Redis enables instant session revocation when staff depart or devices are compromised.
3. **Data Integrity & Financial Idempotency (From Observations 3 & 6)**:
   Fee payments are prone to double-submission (double-click by parents or delayed network retries). Applying a Redis distributed lock (`SET NX EX 30`) keyed on `Idempotency-Key` at `POST /api/v1/fees/orders` guarantees that duplicate requests return the existing transaction rather than re-billing the parent. Razorpay webhooks require raw body HMAC-SHA256 verification and atomic state checks to prevent duplicate credit processing.
4. **Asynchronous Background Processing (From Observations 3, 4, 5)**:
   Heavy operations such as rendering 500+ CBSE graphic PDF report cards, bulk FCM absence broadcasts to hundreds of parents, and nightly fee reconciliation cannot run within synchronous HTTP request loops. Utilizing BullMQ with Redis enables prioritized, concurrent background worker queues (`notifications-queue`, `report-cards-queue`, `receipts-queue`, `reconciliation-queue`, `dpdp-purge-queue`) with automatic retries and exponential backoff.
5. **Regulatory DPDP Compliance (From Observation 2)**:
   India's DPDP Act 2023 mandates that personal data cannot be retained indefinitely upon request and sensitive data must be guarded. Implementing a 90-day soft-delete grace period before irreversible cryptographic shredding, maintaining explicit consent records (`ConsentLog`), and encrypting health records with AES-256-GCM satisfies statutory mandates.
6. **Real-time Fleet Tracking Scalability (From Observation 4)**:
   With 4 pilot buses emitting GPS coordinates every 3 seconds, HTTP polling would generate excessive overhead. A Socket.IO WebSocket gateway (`/transport`) leveraging Redis `GEOADD` and room-based broadcasting provides sub-second parent updates and lightweight geofence proximity calculations without straining the main database.

---

## 3. Caveats

1. **SMS Gateway & Mock Provider**: In local development, an SMS gateway (e.g., MSG91/Twilio) requires external credentials. A development mock provider is specified that logs OTPs to the console/Pino logger and allows a deterministic test OTP (`123456`) in non-production environments.
2. **AI Provider API Keys**: AI modules (Study Buddy, Lesson Planner, Remarks Generator) interface with external LLMs (OpenAI/Anthropic/Gemini). In the local Docker compose test environment, an offline mock LLM adapter will be required when API keys are not supplied.
3. **Hardware Biometrics vs Software Attendance**: The rapid attendance grid and QR boarding/pickup are software-driven mobile/web workflows. Integration with physical hardware turnstiles or RFID bus card readers is deferred to future hardware integration phases.

---

## 4. Conclusion

The backend architecture and domain operations specification for BOMIS Sambalpur is fully formulated and ready for execution. The domain boundaries, API route matrix, 8-role RBAC security framework, DPDP compliance strategy, and BullMQ worker pipelines are completely documented in `analysis.md`. The design fulfills every item in `ORIGINAL_REQUEST.md` (R1–R5) and the project Acceptance Criteria.

---

## 5. Verification Method

To independently verify the backend analysis and prepare for Milestone 3 implementation:

1. **Inspect Documentation**:
   - Review `/apps/api` requirements and domain models in `analysis.md` (sections 1 through 15).
   - Cross-check with `ORIGINAL_REQUEST.md` lines 18–66 to verify 100% requirement coverage.
2. **Verify Architecture Contracts**:
   - Ensure the standard envelope `{ success, data, error, timestamp, correlationId }` is mapped in all controller signatures and exception filters.
   - Verify that all 8 roles (`SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `ACCOUNTANT`, `TEACHER`, `PARENT`, `STUDENT`, `TRANSPORT_STAFF`) are defined in `/packages/shared/src/enums/roles.enum.ts`.
3. **Post-Scaffold Build & Test Commands**:
   - Once `/apps/api` is scaffolded in Track 1:
     - Run build: `pnpm --filter @bomis/api build`
     - Run unit tests: `pnpm --filter @bomis/api test`
     - Run e2e tests: `pnpm --filter @bomis/api test:e2e`
     - Inspect Swagger UI at `http://localhost:4000/api/docs`
     - Verify health probes: `curl http://localhost:4000/health` and `curl http://localhost:4000/ready`
