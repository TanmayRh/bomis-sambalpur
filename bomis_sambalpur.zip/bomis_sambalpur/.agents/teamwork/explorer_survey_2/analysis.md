# Backend & Operations Architecture Analysis: BOMIS Sambalpur Unified School Platform

- **Author**: Backend & Operations Explorer
- **Date**: 2026-10-17T11:06:00Z
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_survey_2`
- **Target Application**: `/apps/api` (NestJS Modular Monolith)
- **Monorepo Root**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur`

---

## 1. Executive Summary & System Topology

The backend for Birla Open Minds International School (BOMIS), Sambalpur, is designed as a **high-throughput, modular monolith** built on **NestJS 10, TypeScript 5, PostgreSQL 16 with Row-Level Security (RLS), Redis 7, MinIO S3-compatible object storage, and BullMQ**.

### 1.1 Architectural Philosophy: Strict Modular Monolith
To avoid the distributed transaction overhead, network latency, and operational fragility of early microservices while maintaining strict domain encapsulation, the system is structured as a **Modular Monolith**:
- Every business domain is a dedicated NestJS module under `/apps/api/src/modules/`.
- Cross-module communication occurs via explicit TypeScript service interfaces and event emitters (`@nestjs/event-emitter`). Direct cross-module database writes or queries bypassing module services are strictly prohibited.
- All shared DTOs, Zod validation schemas, domain enums, and RBAC permission definitions are housed in `/packages/shared`, ensuring single-source-of-truth contract synchronization between backend, Next.js web portal, and Expo mobile app.
- Asynchronous and CPU-intensive workloads (PDF report cards, Razorpay fee reconciliation, bulk CSV ingestion, FCM push broadcasts) are offloaded to **BullMQ worker queues** backed by Redis.

```
                              ┌─────────────────────────────────────────┐
                              │            Client Apps                  │
                              │  - /apps/web (Next.js 14 App Router)    │
                              │  - /apps/mobile (React Native Expo)     │
                              └────────────────────┬────────────────────┘
                                                   │ HTTPS / WSS
                                                   ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                 NestJS 10 API (/apps/api)                              │
│                                                                                        │
│  [Global Middleware]                                                                   │
│   ├─ Pino Logger & Correlation ID (AsyncLocalStorage)                                  │
│   ├─ Rate Limiting (ThrottlerGuard + Redis)                                            │
│   └─ Standard Response & Error Envelope Interceptors                                   │
│                                                                                        │
│  [Identity & Security Layer]                                                           │
│   ├─ Mobile OTP & Email/Password Auth                                                  │
│   ├─ Short-lived JWT (15m) + Rotating Refresh Token (7d)                               │
│   └─ 8-Role RBAC & Multi-Tenant SchoolGuard                                            │
│                                                                                        │
│  [Domain Modules]                                                                      │
│   ├─ People & Sibling Module      ├─ Attendance & Offline Queue Module                 │
│   ├─ Diary & Homework Module      ├─ Fees & Razorpay Gateway Module                    │
│   ├─ CBSE Academics & Exams       ├─ Transport & Realtime GPS Gateway                  │
│   └─ Safety & AI Modules          └─ Audit Log & DPDP Purge Module                     │
└───────────────┬───────────────────────────┬───────────────────────────┬────────────────┘
                │                           │                           │
                ▼                           ▼                           ▼
    ┌───────────────────────┐   ┌───────────────────────┐   ┌───────────────────────┐
    │     PostgreSQL 16     │   │        Redis 7        │   │        MinIO S3       │
    │  - Tenant RLS         │   │  - Auth Sessions      │   │  - Attachments        │
    │  - DPDP Soft Deletes  │   │  - Throttler Cache    │   │  - PDF Report Cards   │
    │  - Immutable Audits   │   │  - BullMQ Queues      │   │  - Fee Receipts       │
    │                       │   │  - Socket.IO PubSub   │   │  - ID Card Assets     │
    └───────────────────────┘   └───────────────────────┘   └───────────────────────┘
```

---

## 2. NestJS Architecture & Foundation Infrastructure

### 2.1 Application Bootstrap & Global Pipes
The NestJS entry point (`/apps/api/src/main.ts`) establishes global resilience, observability, and validation constraints:
1. **Global Prefix**: All routes are namespaced under `/api/v1` (with exclusions for `/health`, `/ready`, and `/api/docs`).
2. **CORS & Security Headers**: Integrated with `helmet` for secure HTTP headers, configured with strict CORS origins for the web dashboard (`http://localhost:3000`) and mobile deep links.
3. **Global Validation Pipe**:
   - `whitelist: true` (strips unauthorized payload properties).
   - `forbidNonWhitelisted: true` (throws `400 Bad Request` on unexpected payload keys).
   - `transform: true` (automatically transforms plain objects to typed DTO classes).
   - Shared Zod validation pipes (`ZodValidationPipe` from `/packages/shared`) for polymorphic payload validation.
4. **Graceful Shutdown**: Enabled via `app.enableShutdownHooks()` to allow in-flight database transactions and Redis connections to terminate cleanly.

### 2.2 Pino JSON Logger with Correlation IDs
Every incoming HTTP request and WebSocket handshake is assigned a unique correlation ID (`x-correlation-id` header or UUID v4 fallback):
- Integrated via `nestjs-pino` and `pino-http`.
- Stored in Node.js `AsyncLocalStorage` so all internal service logs, database queries, and BullMQ jobs retain the active request correlation ID without parameter drilling.
- Sensitive fields (passwords, OTPs, credit cards, Aadhaar numbers, auth tokens) are automatically redacted using Pino's path-based redaction:
  `['req.headers.authorization', 'req.headers.cookie', '*.password', '*.otp', '*.token', '*.cardNumber']`.

### 2.3 Standardized Response & Error Envelope
All REST endpoints adhere strictly to the project acceptance criterion:

#### Success Envelope Format:
```json
{
  "success": true,
  "data": { ... },
  "timestamp": "2026-10-17T11:06:00.000Z",
  "correlationId": "d3b07384-d113-4ec3-a55e-2f9a888c3a5e"
}
```

#### Error Envelope Format:
```json
{
  "success": false,
  "data": null,
  "error": {
    "code": "INVALID_CREDENTIALS",
    "message": "The provided mobile number or OTP is incorrect.",
    "details": [
      { "field": "otp", "issue": "OTP has expired or does not match." }
    ]
  },
  "timestamp": "2026-10-17T11:06:00.000Z",
  "correlationId": "d3b07384-d113-4ec3-a55e-2f9a888c3a5e"
}
```

#### Implementation Mechanism:
- **`TransformInterceptor`**: Intercepts all successful controller returns, wraps the payload in `{ success: true, data, timestamp, correlationId }`.
- **`AllExceptionsFilter`**: Catches `HttpException`, Prisma database errors (`PrismaClientKnownRequestError`), and unhandled exceptions:
  - Maps Prisma `P2002` (unique constraint) to `409 Conflict` (`DUPLICATE_ENTITY`).
  - Maps Prisma `P2025` (record not found) to `404 Not Found` (`ENTITY_NOT_FOUND`).
  - Formats validation errors (`BadRequestException`) into structured error details arrays.
  - Generates standard error envelope preserving the active `correlationId`.

### 2.4 Swagger OpenAPI Documentation
- Mounted at `/api/docs`.
- Built with `@nestjs/swagger`, consuming DTO decorators and shared schema definitions.
- Supports Bearer JWT authentication and role-tagging across all endpoints.
- Exportable as `/docs/openapi.json` for automated client generation and Postman collection synchronization.

### 2.5 Health & Readiness Probes
Built using `@nestjs/terminus` exposed on:
- **`/health` (Liveness)**: Fast ping check confirming the Node process is responsive.
- **`/ready` (Readiness)**: Probes connectivity to:
  - PostgreSQL (via `PrismaHealthIndicator` executing `SELECT 1`).
  - Redis 7 (via `MicroserviceHealthIndicator` / Redis ping).
  - MinIO S3 (via S3 `ListBucketsCommand`).
  - BullMQ (queue connection status).
  - Returns `503 Service Unavailable` if critical backing services are unreachable.

---

## 3. Identity, Authentication & 8-Role RBAC Engine

### 3.1 The 8 Discrete Roles & Hierarchy
The platform defines 8 distinct roles in `/packages/shared/src/enums/roles.enum.ts`:

| Role Enum | Target Persona | Primary Permissions & Capabilities |
| :--- | :--- | :--- |
| `SUPER_ADMIN` | Platform Owners / Trustees | Multi-tenant school management, system settings, global audit logs, emergency override. |
| `ADMIN` | BOMIS Sambalpur School Administrator | Full school operational control: master data, staff onboarding, configuration, fees structure, reports. |
| `PRINCIPAL` | School Principal | Academic oversight, teacher observations, leave approvals, fee concession approvals, pulse dashboard. |
| `ACCOUNTANT` | School Accounts Staff | Fee collection, concession verification, offline payments, day-wise reconciliation, financial reports. |
| `TEACHER` | Class & Subject Teachers | Rapid attendance grid, digital diary, homework assignment, grading, substitution viewing, PTM slots. |
| `PARENT` | Guardians / Parents | View child profiles (multi-sibling switcher), online fee payments via Razorpay, bus tracking, chat, leaves. |
| `STUDENT` | Enrolled Students (Grade 1-8) | View homework, submit assignments, view timetable, access AI Study Buddy, report cards. |
| `TRANSPORT_STAFF` | Bus Drivers & Fleet Supervisors | Driver mini-app, GPS broadcasting, student boarding/deboarding QR scanning, route navigation. |

### 3.2 Dual Authentication Protocols

```
  [Parent / Student]                     [Staff / Teacher / Admin / Transport]
          │                                                │
          ▼                                                ▼
  Mobile Number Request                             Email + Password / OTP
          │                                                │
  Generate 6-digit OTP                             Verify bcrypt hash / OTP
  (Redis: 5 min TTL, max 3 tries)                          │
          │                                                │
  Verify OTP via SMS/Mock                                  │
          └───────────────────────┬────────────────────────┘
                                  │
                                  ▼
                     Issue Token Pair:
                     - Short-lived Access JWT (15 min)
                     - Cryptographic Refresh Token (7 days)
                     - Redis Session Record (Device IP, User-Agent)
```

1. **Mobile OTP Login (Parents & Students)**:
   - Endpoint: `POST /api/v1/auth/otp/request` -> Generates cryptographically secure 6-digit OTP, stores in Redis with a 300-second (5 min) TTL, rate-limited to 5 requests per 15 minutes per mobile number. Dispatches via SMS Gateway (or dev mock logger).
   - Endpoint: `POST /api/v1/auth/otp/verify` -> Validates OTP. Enforces max 3 failed attempts before invalidating the OTP.
2. **Email + Password / Staff OTP (Faculty, Staff, Admins, Drivers)**:
   - Endpoint: `POST /api/v1/auth/login` -> Authenticates using email and Argon2id/Bcrypt hashed password.
   - Supports optional staff 2FA / email OTP verification.

### 3.3 Token Lifecycle, Session Management & Revocation
- **Access Token**: Short-lived (15 minutes), signed with RS256 (or HMAC-SHA256 in development). Payload contains:
  `{ sub: string, email?: string, phone?: string, role: Role, schoolId: string, sessionId: string, iat: number, exp: number }`.
- **Refresh Token**: Long-lived (7 days), high-entropy 256-bit random string stored in the database `Session` table (hashed) and cached in Redis.
- **Rotation**: On every `/auth/refresh`, the old refresh token is immediately invalidated, and a new token pair is issued. Re-use of an already rotated refresh token triggers **instant revocation of all active sessions** for that user (compromise detection).
- **Session Revocation**:
  - `POST /api/v1/auth/logout`: Invalidates current session ID in Redis and DB.
  - `POST /api/v1/auth/revoke-all`: Clears all active Redis sessions for the user, forcing re-authentication across all devices.

### 3.4 Guards & Authorization Decorators
1. **`JwtAuthGuard`**: Validates JWT signature, checks expiration, and verifies that `sessionId` is not blacklisted in Redis.
2. **`RolesGuard`**: Evaluates role requirements declared via `@Roles(Role.ADMIN, Role.PRINCIPAL)`.
3. **`PermissionsGuard`**: Evaluates fine-grained permissions declared via `@RequirePermissions(Permission.ATTENDANCE_WRITE)`.
4. **`SchoolTenantGuard`**: Extracts `schoolId` from JWT and injects it into request context; ensures queries are strictly scoped to the user's school.

---

## 4. Domain Module 1: People & Identity Management

### 4.1 Master Profiles & Relational Mapping
- **`User`**: Core authentication record containing credentials, role, multi-tenant `schoolId`, DPDP consent flags.
- **`StudentProfile`**: Holds admission number (unique per school), roll number, class ID, section ID, date of birth, blood group, house, emergency contact, encrypted Aadhaar/identity field.
- **`GuardianProfile`**: Primary parent/guardian details, occupation, annual income bracket, alternate contact number.
- **`StaffProfile`**: Employee code, designation, department, qualification, date of joining, emergency contact.

### 4.2 Multi-Child Sibling Linking Architecture
A critical pain point in Indian K-12 schools is parents having multiple children enrolled in different grades (e.g., Grade 2 and Grade 7).
- Model: `StudentGuardian` join table:
  - `studentId`, `guardianId`, `relationType` (`FATHER`, `MOTHER`, `LOCAL_GUARDIAN`), `isPrimaryFeePayer`, `isPickupAuthorized`.
- When a Parent logs in, the backend returns all linked student profiles under `user.guardians[0].students`.
- The frontend and mobile apps provide a seamless **Child Switcher** context; API requests can pass `?studentId=<id>` or set `X-Student-Context: <id>` to view child-specific attendance, diary, and fee dues.

### 4.3 Bulk CSV Ingestion & Export Engine
- Handled via `PeopleService.bulkImportStudents(file: Express.Multer.File)`:
  - Uses streaming CSV parsing (`csv-parser` / `fast-csv`) to avoid memory spikes.
  - Validates every row against Zod `CreateStudentSchema`.
  - Performs atomic batch insertion inside a Prisma transaction with a chunk size of 50 records.
  - If invalid rows are detected, the API generates a line-by-line validation error manifest (`{ row: 14, field: "dob", error: "Invalid date format. Expected YYYY-MM-DD" }`) without crashing the process.

---

## 5. Domain Module 2: Attendance Grid & Offline Queue

### 5.1 Teacher Rapid Attendance Grid (<10s Execution)
Teachers must mark attendance for an entire classroom of 40 students in less than 10 seconds:
- **Optimization Strategy**: The API provides a **Batch Attendance Ingestion Endpoint**:
  `POST /api/v1/attendance/classes/:classId/sections/:sectionId/batch`
- **Default-Present Paradigm**: The payload expects only the list of non-present students, or a compact array of `{ studentId, status: AttendanceStatus }` where `AttendanceStatus = PRESENT | ABSENT | LATE | EXCUSED | HALF_DAY`.
- A single batch update query updates or inserts 40 records in PostgreSQL in <150ms.

```typescript
// Sample Rapid Batch Payload
{
  "date": "2026-10-17",
  "classId": "cls_g3_001",
  "sectionId": "sec_g3_a",
  "defaultStatus": "PRESENT",
  "exceptions": [
    { "studentId": "stu_014", "status": "ABSENT", "remarks": "Fever reported" },
    { "studentId": "stu_028", "status": "LATE", "remarks": "Bus delay 15m" }
  ]
}
```

### 5.2 Offline Sync Queue & Conflict Resolution
Classroom teachers frequently encounter intermittent school Wi-Fi connectivity:
- The mobile app records attendance in a local SQLite/WatermelonDB queue with a client-generated UUID `syncId` and client timestamp `recordedAt`.
- When connectivity resumes, the client pushes the queued entries to `POST /api/v1/attendance/sync`.
- **Conflict Resolution**:
  - The server checks whether attendance for that `studentId + date` has already been submitted or locked by Admin/Principal.
  - If submitted by the same teacher within the same day, the latest timestamp takes precedence.
  - If an administrative lock has been placed (e.g., after 11:00 AM daily cutoff), the record is flagged for administrative review rather than silently overwritten.

### 5.3 Instant FCM Parent Push Notification Engine
- Upon processing the attendance batch, an asynchronous event `attendance.marked` is dispatched.
- A BullMQ worker (`AttendanceNotificationConsumer`) identifies all students marked `ABSENT` or `LATE`.
- Looks up the linked guardian device push tokens (FCM) and dispatches instant alerts:
  - *Title*: `Attendance Alert - BOMIS Sambalpur`
  - *Body*: `Dear Parent, your ward [Student Name] has been marked ABSENT today (17 Oct 2026). Please contact the school office if this is an error.`
  - Employs localized push templates (English, Hindi, Odia).

### 5.4 Staff Attendance & Leave Management
- Staff check-in via biometric/geo-verified check-in or administrative register.
- Leave workflow: Staff submits leave request (`CASUAL`, `SICK`, `MATERNITY`, `EARNED`), routes to Principal for one-click approval, automatically updates staff availability for academic timetable substitution.

---

## 6. Domain Module 3: Digital Diary & Homework

### 6.1 Assignment Lifecycle & File Attachments
- **Creation**: Teacher creates homework entry:
  - Target: Class, Section, Subject.
  - Content: Rich text description (HTML/Markdown sanitized via DOMPurify).
  - Attachments: Stored in MinIO S3 bucket `school-homework`. The backend generates presigned upload URLs (`PUT`) with 15-minute expirations, preventing large binary payloads from traversing the NestJS API server.
  - Deadlines: Due date and submission type (`ONLINE_FILE`, `PHYSICAL_NOTEBOOK`, `READING`).
- **Student Submission**: Students upload completed assignments; status machine: `PENDING` -> `SUBMITTED` -> `LATE_SUBMISSION` -> `EVALUATED` -> `RESUBMISSION_REQUESTED`.
- **Teacher Grading**: Teachers view submissions in a unified grading dashboard, assign marks/grades, and leave audio or text feedback.

### 6.2 Digital Circulars & Read Receipts
- School circulars, event invitations, and urgent notices are published to specific audiences (`ALL_PARENTS`, `GRADE_WISE`, `STAFF_ONLY`).
- **Read Receipt Tracking**:
  - Model: `NoticeAcknowledgment` (`noticeId`, `userId`, `acknowledgedAt`, `deviceInfo`).
  - Enables Administrators to track real-time receipt metrics (e.g., "78% of Grade 4 parents have acknowledged the Winter Uniform circular").

---

## 7. Domain Module 4: Fees & Financial Safety Engine

### 7.1 Fee Structures & Installment Scheduling
BOMIS Sambalpur operates on configurable fee schedules:
- **`FeeCategory`**: Tuition, Transport, Admission, Annual Activities, Lab & Technology, Examination.
- **`FeeStructure`**: Defines amounts per Academic Year and Grade.
- **`FeeInstallment`**: Quarterly / Term-wise schedules with defined due dates and automatic late fine rules (e.g., ₹50/day after the 10th of the installment month).

### 7.2 Multi-Tier Concession Approval Workflow
- Concessions (Sibling discount, Merit scholarship, Staff ward discount, Economically Weaker Section - EWS):
  - Application initiated by Parent or Accountant with documentary evidence.
  - State machine: `DRAFT` -> `SUBMITTED` -> `VERIFIED_BY_ACCOUNTANT` -> `APPROVED_BY_PRINCIPAL` -> `APPLIED`.
  - Concession is immutably linked to the fee ledger; discounts cannot be altered once approved without an audit trail.

### 7.3 Razorpay Gateway Integration & Cryptographic Security
Online payments require zero-tolerance financial safeguards:

```
  Parent App               NestJS API (/fees)             Redis Lock             Razorpay API
      │                            │                           │                       │
      │── 1. Create Order ────────>│                           │                       │
      │   (Idempotency-Key)        │── 2. Acquire Lock ───────>│                       │
      │                            │── 3. Create Razorpay Order ──────────────────────>│
      │                            │<── 4. Order ID (order_xyz) ───────────────────────│
      │<── 5. Order & Key ID ──────│                           │                       │
      │                            │                           │                       │
      │ [Payment at Razorpay]      │                           │                       │
      │                            │                           │                       │
      │── 6. Client Verify ───────>│ (or Razorpay Webhook)     │                       │
      │   (sig, orderId, payId)    │── 7. HMAC-SHA256 Sig Check                        │
      │                            │── 8. Idempotent DB Update                         │
      │                            │── 9. Enqueue PDF Receipt                          │
      │<── 10. Success Envelope ───│                                                   │
```

1. **Order Creation (`POST /api/v1/fees/orders`)**:
   - Requires `Idempotency-Key` header.
   - Calculates the exact payable amount from outstanding installments, concessions, and accrued fines on the server (never trusts client amount).
   - Invokes Razorpay Orders API (`amount` in paise, currency `INR`, receipt tag).
   - Creates a pending `PaymentTransaction` record in the database.
2. **Strict Idempotency Guard**:
   - Interceptor checks Redis for `idempotency:<key>`. If locked, returns `409 Conflict` (processing in progress) or the cached response if already completed, preventing duplicate order generation.
3. **Webhook Verification (`POST /api/v1/fees/webhooks/razorpay`)**:
   - Enforces HMAC-SHA256 signature verification using the raw request body and `X-Razorpay-Signature` against `RAZORPAY_WEBHOOK_SECRET`.
   - Protects against duplicate webhook deliveries by checking if `paymentId` is already marked `SUCCESS` in the database.
4. **Digital PDF Receipt Generation**:
   - Upon successful payment verification, enqueues a BullMQ job `generate-fee-receipt`.
   - Generates a PDF containing:
     - BOMIS Sambalpur official crest, affiliation number, address.
     - Sequential receipt number (e.g., `BOMIS/2026-27/REC-04921`).
     - Student admission number, grade, section, parent name.
     - Itemized fee heads, concession deductions, payment mode, transaction ID, timestamp.
   - Uploads PDF to MinIO bucket `school-receipts` and sends SMS/email link to the parent.
5. **Day-wise Reconciliation Engine**:
   - Daily cron job reconciling Razorpay settlement APIs against the local ledger.
   - Generates an Accountant Reconciliation Report: Cash vs. Cheque vs. POS vs. Online Razorpay collections, highlighting discrepancies.

---

## 8. Domain Module 5: Academics & CBSE Operations

### 8.1 Automated Timetable Generator & Clash Detection
Timetable scheduling is subject to hard and soft constraints:
- **Constraints**:
  - No teacher can be assigned to more than one classroom during the same period (*Hard Constraint*).
  - No classroom/room (e.g., Physics Lab, Computer Lab, Playground) can host more than one section simultaneously (*Hard Constraint*).
  - Teacher daily workload caps (e.g., maximum 5 teaching periods per day).
  - Distribution of heavy subjects (Mathematics, Science) across morning periods.
- **Clash Detection Algorithm**:
  - Validates `(teacherId, dayOfWeek, periodNumber)` and `(roomId, dayOfWeek, periodNumber)` uniqueness.
  - Exposes an inspection API: `POST /api/v1/timetable/validate` returning conflict matrices before timetable publication.

### 8.2 One-Click Teacher Absence Substitution
- When a teacher is marked absent or on leave:
  - System identifies all affected timetable periods for that day.
  - Queries available teachers during those specific periods who:
    1. Are free (no class assigned in that period).
    2. Belong to the same subject department or have relevant grade competency.
    3. Have the lowest substitution load for the current week.
  - Admin/Principal clicks **"Auto-Substitute"**, instantly reassigning periods and sending push notifications to substituted teachers.

### 8.3 CBSE Examination & Grading Engine
BOMIS Sambalpur complies with the Central Board of Secondary Education (CBSE) assessment guidelines for Grades 1–8:
- **Assessment Terms**:
  - Term 1: Periodic Test 1 (PT1 - 10%), Notebook (5%), Subject Enrichment (5%), Half-Yearly Exam (80%). Total = 100 Marks.
  - Term 2: Periodic Test 2 (PT2 - 10%), Notebook (5%), Subject Enrichment (5%), Annual Exam (80%). Total = 100 Marks.
- **CBSE 9-Point Scholastic Grading Scale**:

| Marks Range (%) | Grade | Grade Point | Assessment Description |
| :--- | :--- | :--- | :--- |
| **91 – 100** | **A1** | 10.0 | Outstanding |
| **81 – 90** | **A2** | 9.0 | Excellent |
| **71 – 80** | **B1** | 8.0 | Very Good |
| **61 – 70** | **B2** | 7.0 | Good |
| **51 – 60** | **C1** | 6.0 | Fair |
| **41 – 50** | **C2** | 5.0 | Average |
| **33 – 40** | **D** | 4.0 | Minimum Passing Threshold |
| **32 & Below** | **E** | — | Needs Significant Improvement (Failed) |

- **Co-Scholastic Assessment**: 3-point grading scale (`A` = Outstanding, `B` = Very Good, `C` = Fair) covering Work Education, Art Education, Health & Physical Education, Discipline.

### 8.4 Asynchronous PDF Report Card Worker (BullMQ)
Generating 500+ multi-page graphic-heavy CBSE report cards synchronously causes HTTP timeouts.
- **BullMQ Pipeline**:
  - Trigger: `POST /api/v1/exams/terms/:termId/generate-report-cards`
  - Job payload: `{ schoolId, classId, sectionId, termId }`.
  - Queue: `report-cards-queue` with concurrency set to 4 workers.
  - Worker loads student marks, attendance summary, teacher remarks, co-scholastic grades.
  - Renders HTML template using Handlebars / React-PDF and outputs print-ready vector PDF via headless Chrome/Puppeteer.
  - Stores PDFs in MinIO bucket `report-cards/2026-27/term-1/` and updates the database record with the signed download URL.
  - Publishes progress events over WebSockets so the Admin UI displays a live progress bar ("Rendered 34 of 40 report cards...").

---

## 9. Domain Module 6: Transport Tracking & Fleet Operations

### 9.1 Fleet Configuration
The school operates a pilot fleet of **4 buses**:
- **3 Small Buses** (20–25 seater capacity, traversing narrow residential routes in Sambalpur).
- **1 Full-Size Bus** (50-seater capacity, operating on the main arterial route).

### 9.2 Real-time GPS Broadcasting via WebSockets / Socket.IO
- **Gateway**: `/transport` namespace in NestJS (`TransportGateway`).
- **Driver Mini-App**:
  - Authenticated via JWT (`TRANSPORT_STAFF` role).
  - Emits telemetry every 3–5 seconds:
    `emit('location:update', { busId: 'bus_01', lat: 21.4669, lng: 83.9812, speed: 34.5, heading: 120, timestamp: Date.now() })`.
- **Backend Processing**:
  - Updates the active bus position in Redis (`GEOADD school:transport:buses 83.9812 21.4669 bus_01`).
  - Broadcasts position to all subscribed parents in the room `room:bus:bus_01`.

### 9.3 Student Boarding / Deboarding QR Scanning
- Each student has a unique QR code on their digital/physical school ID card.
- As students enter or leave the bus, the driver or bus attendant scans the card using the mobile camera.
- Event: `POST /api/v1/transport/boardings`
  - Payload: `{ busId, studentId, stopId, action: 'BOARDED' | 'DEBOARDED', lat, lng }`.
- **Immediate Push Trigger**: The backend immediately dispatches an FCM push to the student's parents:
  `"Siddharth has boarded Bus 2 at Sakhipada Stop (07:42 AM)."`

### 9.4 Geofencing & "5-Minute Away" Proximity Alerts
- Each route defines an ordered list of bus stops with coordinates (`lat`, `lng`) and a designated geofence radius (typically 500 meters) or calculated ETA.
- As the bus moves, the server computes the distance and estimated arrival time to the next stop using the Haversine formula and average traffic velocity:
  $$\text{ETA} = \frac{\text{Distance to Stop}}{\text{Average Speed}}$$
- When $\text{ETA} \le 5\text{ minutes}$, the system emits an automated FCM alert to parents assigned to that stop:
  `"Bus 1 is 5 minutes away from your stop (Sakhipada). Please be ready."`

---

## 10. Domain Module 7: Safety & AI Layer

### 10.1 Safety Modules
1. **Visitor Management with QR Gate Passes**:
   - Parents or visitors pre-register or register at the gate: Name, phone, photo, host staff member, purpose of visit.
   - Host receives push notification to approve/reject visit.
   - On approval, a dynamic time-limited QR gate pass is generated. Security guards scan the QR pass at entry and exit, maintaining an auditable visitor log.
2. **Child Pickup Verification (OTP / Dynamic QR)**:
   - To prevent unauthorized student pickups at dismissal time:
   - Authorized guardian generates a dynamic, time-limited 6-digit OTP or refreshable QR code in their mobile app.
   - School gate attendant / teacher scans the QR or verifies the OTP against the student's authorized guardian roster before releasing the child.
3. **Anonymous Anti-Bullying Reporting System**:
   - Students can submit confidential incident reports regarding bullying, harassment, or safety concerns.
   - **Anonymity Guarantee**: The API does not record or persist `userId`, IP address, or user agent in the incident record.
   - Access to reports is strictly restricted via RBAC to the **Principal** and the **Designated School Counselor**.
4. **Access-Controlled Health Records (DPDP Compliant)**:
   - Stores chronic medical conditions, severe allergies, blood group, emergency medication, and doctor contact.
   - Sensitive medical notes are stored with **AES-256-GCM field-level encryption** in PostgreSQL.
   - Accessible exclusively to the School Infirmary/Nurse and Class Teacher; unauthorized access attempts are logged to `audit_logs`.

### 10.2 AI Layer Architecture & Guardrails
All AI capabilities interact through a dedicated `AiModule` interfacing with OpenAI/Anthropic/Gemini APIs via a standardized adapter:
1. **Concept-Explaining Study Buddy**:
   - Grounded strictly in the CBSE NCERT syllabus for Grades 1–8.
   - Configured with strict safety guardrails preventing non-educational dialogues, homework direct-answer exploitation, or inappropriate content.
2. **Teacher Lesson Planner & Rubric Assistant**:
   - Takes learning objectives, grade, and duration; generates structured CBSE-aligned lesson plans, classroom activities, and grading rubrics.
3. **Draft Report Card Remarks Generator**:
   - Synthesizes student academic performance, attendance rate, and co-scholastic participation into personalized narrative remarks.
   - **Mandatory Human-in-the-Loop**: Generated remarks are saved strictly as drafts; teachers must explicitly review, edit, and approve remarks before inclusion on official report cards.
4. **Parent Natural-Language Concierge**:
   - Answers parent inquiries regarding school timings, uniform guidelines, holiday calendars, and fee payment instructions based strictly on verified school policy documents.

---

## 11. Data Model & DPDP Act (2023) Regulatory Compliance

### 11.1 Multi-Tenant Isolation with Row-Level Security (RLS)
- Every business table includes an indexed `school_id` foreign key.
- For high-assurance isolation, PostgreSQL Row-Level Security (RLS) policies are configured:
  ```sql
  ALTER TABLE students ENABLE ROW LEVEL SECURITY;
  CREATE POLICY tenant_isolation_policy ON students
    USING (school_id = current_setting('app.current_school_id', true));
  ```
- The NestJS database middleware / Prisma client extension executes `SET LOCAL app.current_school_id = '<school_id>'` at the start of each request transaction.

### 11.2 Digital Personal Data Protection (DPDP) Act Compliance
- **Soft Deletes with 90-Day Retention**:
  - Tables maintain `deleted_at: DateTime?`.
  - When a student or parent requests data deletion or leaves the institution, `deleted_at` is set to `now()`.
  - Application queries automatically filter `deleted_at IS NULL`.
  - A scheduled daily BullMQ job (`dpdp-purge-queue`) purges records where `deleted_at < NOW() - INTERVAL '90 DAYS'`, executing irreversible cryptographic shredding (overwriting sensitive fields before hard deletion).
- **Consent Tracking**:
  - Model `ConsentLog`: Records `userId`, `consentType` (`DATA_PROCESSING`, `MEDIA_RELEASE`, `EMERGENCY_MEDICAL`), `grantedAt`, `ipAddress`, and `version`.
- **Field-Level Encryption**:
  - Sensitive personal data (Aadhaar numbers, personal health data, bank details) are encrypted at rest using AES-256-GCM prior to database persistence.

### 11.3 Immutable Audit Logging
- Model `AuditLog`:
  - Fields: `id`, `schoolId`, `userId`, `role`, `action` (`CREATE`, `UPDATE`, `DELETE`, `LOGIN`, `VIEW_HEALTH`), `entity`, `entityId`, `diffJson`, `ipAddress`, `userAgent`, `timestamp`.
  - Write-only from application code; no update or delete operations are permitted on this table.

---

## 12. Background Worker Architecture (BullMQ + Redis)

| Queue Name | Worker Concurrency | Job Types Handled | Retry Policy |
| :--- | :--- | :--- | :--- |
| `notifications-queue` | 10 | FCM Parent Alerts, SMS OTP delivery, Emergency Broadcasts. | 3 retries, exponential backoff (2s, 8s, 32s). |
| `report-cards-queue` | 4 | Puppeteer PDF Report Card rendering, S3 upload, signed URL generation. | 2 retries, 5s delay. |
| `receipts-queue` | 5 | Payment receipt PDF generation, parent email dispatch. | 3 retries, exponential backoff. |
| `reconciliation-queue` | 2 | Nightly Razorpay settlement cross-checking, ledger balancing. | 3 retries, 30s delay. |
| `dpdp-purge-queue` | 1 | Nightly cryptographic erasure of soft-deleted records (>90 days). | 5 retries with alerting. |

---

## 13. API Route Matrix & Contract Inventory

A summary of core backend endpoints implemented in `/apps/api`:

```
AUTH & SESSION MODULE:
  POST   /api/v1/auth/otp/request            Request mobile OTP (Rate-limited: 5/15m)
  POST   /api/v1/auth/otp/verify             Verify OTP, issue JWT & Refresh token
  POST   /api/v1/auth/login                  Staff email + password login
  POST   /api/v1/auth/refresh                Rotate refresh token, issue new access JWT
  POST   /api/v1/auth/logout                 Revoke current active session
  POST   /api/v1/auth/revoke-all             Revoke all sessions for user

PEOPLE & MASTER DATA MODULE:
  GET    /api/v1/people/students             List students with pagination & filters
  POST   /api/v1/people/students             Create student master record
  GET    /api/v1/people/students/:id         Get student details & linked guardians
  POST   /api/v1/people/students/bulk-import Ingest students via CSV stream
  GET    /api/v1/people/guardians/siblings   Fetch linked siblings for authenticated parent
  GET    /api/v1/people/staff                List teachers and administrative staff

ATTENDANCE MODULE:
  POST   /api/v1/attendance/batch            Rapid classroom grid attendance submission
  POST   /api/v1/attendance/sync             Offline queue reconciliation endpoint
  GET    /api/v1/attendance/students/:id     Student monthly attendance percentage & records
  POST   /api/v1/attendance/leaves           Submit staff/student leave application
  PATCH  /api/v1/attendance/leaves/:id       Approve/reject leave request

FEES & FINANCIAL ENGINE:
  GET    /api/v1/fees/structures             Fetch fee structures by class & academic year
  GET    /api/v1/fees/students/:id/dues      Fetch calculated student fee dues & fines
  POST   /api/v1/fees/orders                 Create Razorpay order (Idempotency-Key required)
  POST   /api/v1/fees/webhooks/razorpay      Razorpay webhook with HMAC-SHA256 signature
  GET    /api/v1/fees/receipts/:id           Download signed PDF payment receipt
  POST   /api/v1/fees/concessions            Apply for fee concession
  PATCH  /api/v1/fees/concessions/:id/status Approve/reject concession application

ACADEMICS & EXAMS MODULE:
  GET    /api/v1/timetable/classes/:id       Get weekly class timetable
  POST   /api/v1/timetable/validate          Verify teacher and room clash constraints
  POST   /api/v1/timetable/substitutions     One-click teacher absence substitution
  POST   /api/v1/exams/marks/batch           Bulk marks entry with CBSE boundary validation
  POST   /api/v1/exams/terms/:id/reports     Trigger async BullMQ PDF report card worker

TRANSPORT FLEET MODULE:
  WS     /transport                          WebSocket GPS stream & geofence notifications
  POST   /api/v1/transport/boardings         Log QR student boarding/deboarding event
  GET    /api/v1/transport/routes            Get bus routes, stops, and assigned students
  GET    /api/v1/transport/fleet/status      Real-time fleet monitoring snapshot

SAFETY & AI MODULE:
  POST   /api/v1/safety/visitors             Create pre-approved visitor pass
  POST   /api/v1/safety/pickup/verify        Verify child pickup OTP or dynamic QR
  POST   /api/v1/safety/bullying-reports     Submit anonymous anti-bullying incident
  POST   /api/v1/ai/study-buddy/chat         Query syllabus-grounded AI Study Buddy
  POST   /api/v1/ai/remarks/draft            Generate draft report card narrative remarks
```

---

## 14. Implementation Risk Analysis & Mitigations

| Identified Risk | Severity | Root Cause | Engineering Mitigation |
| :--- | :--- | :--- | :--- |
| **Financial Race Condition** | High | Multiple payment clicks or webhook retries during fee payment. | Enforce `Idempotency-Key` via Redis distributed lock (`SET NX EX 30`). Check transaction state before writing receipts. |
| **Attendance Lock Contention** | Medium | Concurrent offline sync and live teacher grid submissions. | Use database optimistic locking on attendance records; client timestamps dictate conflict resolution hierarchy. |
| **Report Card PDF Memory Spike** | High | Generating 500 Puppeteer PDFs simultaneously exhausts RAM. | Offload to BullMQ with strict concurrency limiter (`concurrency: 4`); stream generated PDFs directly to MinIO. |
| **GPS WebSocket Saturation** | Medium | High-frequency telemetry updates from 4 buses flooding Node event loop. | Throttle client emission rate to 1 Hz; use Redis GEO and broadcast updates only to subscribed bus rooms. |
| **DPDP Regulatory Breach** | High | Unauthorized access to student medical or personal identity data. | AES-256-GCM field encryption, RLS tenant isolation, and strict role guards on sensitive health routes. |

---

## 15. Conclusion & Handoff Readiness

The NestJS modular monolith architecture for BOMIS Sambalpur is fully analyzed and specified across all operational, financial, academic, and safety domains. The architecture strictly satisfies all requirements of `ORIGINAL_REQUEST.md` (R1–R5) and the core Acceptance Criteria:
1. Standardized response/error envelopes on all endpoints.
2. 100% synchronized Zod and DTO validation types sourced from `/packages/shared`.
3. Idempotent payment processing with cryptographic signature verification.
4. Robust 8-role RBAC enforcement with multi-tenant data isolation.
5. High-performance asynchronous background job processing via BullMQ.

This analysis provides the complete blueprint for the Backend Engineer and Monorepo Architect in upcoming execution milestones.
