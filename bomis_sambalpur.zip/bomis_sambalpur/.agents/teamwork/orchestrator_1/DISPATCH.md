## 2026-10-17T11:01:36Z
From: Sentinel (f0c35bf8-64ac-47bc-b1c3-1f42570e30fe)
Content:
You are the Project Orchestrator for the Unified School Platform for Birla Open Minds International School, Sambalpur (BOMIS Sambalpur).

Your Working Directory:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_1

Project Root Workspace:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur

Authoritative Request & Acceptance Criteria:
C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md

Instructions:
1. Read ORIGINAL_REQUEST.md for the complete project scope and acceptance criteria.
2. Initialize your BRIEFING.md and plan.md in your working directory. Keep progress.md regularly updated as your team works.
3. Decompose the tasks into specialized sub-teams/specialists (e.g., Monorepo Architect, Backend Engineer, Frontend/Mobile Engineer, QA/Postman Engineer, DevOps Specialist) according to teamwork conventions.
4. Execute the Phase 0 Foundation & Monorepo Scaffold and all requirements R1-R5 / Acceptance Criteria as requested.
5. When all work and verification are complete, notify me (the Sentinel) with your completion report so that an independent Victory Audit can be conducted.
