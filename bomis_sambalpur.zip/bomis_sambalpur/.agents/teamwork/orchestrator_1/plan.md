# Plan: BOMIS Sambalpur Unified School Platform

## Goal
Scaffold and execute Phase 0 Foundation & Monorepo Scaffold and all requirements R1-R5 / Acceptance Criteria for the Birla Open Minds International School, Sambalpur (BOMIS Sambalpur) Unified School Platform.

## Phases & Track Strategy
1. **Survey (Phase 0)**:
   - Spawn parallel Explorers / Spec Miners to analyze requirements from ORIGINAL_REQUEST.md.
   - Produce unified requirements map, architectural decisions, and feature inventory in `PROJECT.md`.
2. **Dual-Track Execution**:
   - **Track 1: Implementation Track**:
     - Milestone 1: Monorepo Scaffold & Core Tooling (Turborepo, pnpm workspaces, root config, tsconfig, Docker compose for Postgres, Redis, MinIO, Mailpit).
     - Milestone 2: Shared Types & DPDP Multi-Tenant Prisma Schema (/packages/shared, /packages/ui, Prisma models, RLS, audit logs, seed script).
     - Milestone 3: NestJS Backend Monolith (/apps/api: Auth, OTP, JWT, RBAC 8 roles, standard response envelope, global filters/pipes, modules for People, Attendance, Diary/Homework, Fees/Razorpay, Academics/Timetable/Exams, Transport, Safety, AI/Communication).
     - Milestone 4: Next.js Web App (/apps/web: Next.js 14 App Router, Tailwind CSS, shadcn/ui primitives, BOMIS brand palette navy/coral, TanStack Query, React Hook Form, Zod).
     - Milestone 5: React Native Mobile App (/apps/mobile: Expo, multi-role, offline-first sync, secure storage, push notification stubs).
   - **Track 2: E2E Testing & Postman Newman CI Track**:
     - Test runner, test infrastructure (`TEST_INFRA.md`).
     - Tier 1-4 Test Suites and Postman collections in `/docs/postman`.
     - Newman execution in CI / automated test runner script.
3. **Verification & Audit Gate**:
   - Worker tests + Reviewer evaluations + Challenger stress tests + Forensic Auditor integrity checks.
   - Report to Sentinel.
