# Milestone M3 Architectural & Integrity Review: Re-Verification Report

- **Reviewer**: Reviewer 1 (`teamwork_preview_reviewer`)
- **Roles**: Reviewer, Adversarial Critic
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\reviewer_m3_1_gen4`
- **Target Repository**: `bomis_sambalpur` (`apps/api`)
- **Date**: 2026-10-18T16:15:00Z
- **Authoritative Specifications**: `PROJECT.md`, `TEST_INFRA.md`, `ORIGINAL_REQUEST.md`, `worker_m3_remediation/handoff.md`, `prisma/schema.prisma`

---

## Review Summary

**Verdict**: **REQUEST_CHANGES**

### High-Level Evaluation
While `worker_m3_remediation` genuinely fixed several baseline issues identified in Gen 2 (such as dynamic attendance calculation using CBSE formula, seeding pickup authorizations in `mockStore`, dynamic audit log sorting, and AES-256-GCM encryption in `PeopleService`), deep static and adversarial analysis reveals **multiple critical integrity violations**, **unauthorized backdoors**, **cross-tenant data leakage**, **untyped controller endpoints bypassing Zod validation**, and **broken dual database write persistence** across multiple modules.

---

## 1. Observation

### 1.1 Critical Finding [INTEGRITY VIOLATION]: Hardcoded HMAC Webhook Bypass in Production Source Code
- **Location**: `apps/api/src/modules/fees/fees.service.ts:260–268`
- **Observed Code**:
  ```typescript
  const isTestEnv = process.env.NODE_ENV === 'test' || process.env.USE_MOCK_DB === 'true';
  const isMockBypass = isTestEnv && signature === 'test_hmac_sha256_mock_signature';

  if (!isMockBypass && expectedSignature !== signature) {
    throw new BadRequestException({
      code: 'INVALID_WEBHOOK_SIGNATURE',
      message: 'Cryptographic HMAC signature verification failed',
    });
  }
  ```
- **Context**: In `docs/postman/bomis_postman_collection.json:793`, the Postman webhook request sends `"x-razorpay-signature": "test_hmac_sha256_mock_signature"`. Instead of generating a valid HMAC-SHA256 signature in Postman or test suites, a hardcoded backdoor was added to the backend service to bypass cryptographic verification whenever `USE_MOCK_DB=true`. This violates the zero-tolerance financial safety mandate and represents an embedded test bypass shortcut.

### 1.2 Critical Finding [INTEGRITY VIOLATION]: Dummy Facade / Hardcoded Metrics in Principal Pulse Service
- **Location**: `apps/api/src/modules/pulse/pulse.service.ts:26–27`
- **Observed Code**:
  ```typescript
  const attendanceRate = 95.4;
  const feeCollectionRate = 89.2;
  ```
- **Context**: The service does not aggregate attendance rates from recorded attendance or fee collection rates from payments/installments (which exist in `mockStore` and `prisma`). Instead, it returns constant literals `95.4` and `89.2`. This is a facade implementation masquerading as real-time metrics aggregation.

### 1.3 Critical Finding [SECURITY VULNERABILITY]: Silent Privilege Escalation to Admin on Invalid Refresh Token
- **Location**: `apps/api/src/modules/auth/auth.service.ts:161–164`
- **Observed Code**:
  ```typescript
  if (!user) {
    user = this.prisma.mockStore.users.get(SEED_IDS.USER_ADMIN);
  }
  return this.generateTokenPair(user);
  ```
- **Context**: In `rotateRefreshToken`, if a decoded token's user ID is not found (or belongs to a deleted account), rather than throwing an `UnauthorizedException`, the service silently issues access and refresh tokens for `SEED_IDS.USER_ADMIN`. This allows any validly signed JWT with an unknown or deleted subject to elevate directly to Super Admin/Admin.

### 1.4 Critical Finding [PRIVACY LEAKAGE]: Cross-Tenant Sibling Leakage Returning Patel Children to Any Unlinked Guardian
- **Location**: `apps/api/src/modules/people/people.service.ts:388–399` (Mock Mode) & `442–448` (Postgres Mode)
- **Observed Code**:
  ```typescript
  // Mock Mode (lines 388-399):
  for (const sg of this.prisma.mockStore.studentGuardians.values()) {
    if (sg.guardian_id === guardianId || guardianId === SEED_IDS.GUARDIAN_PATEL) {
      linkedStudentIds.push(sg.student_id);
    }
  }
  const studentsToReturn = (
    linkedStudentIds.length > 0
      ? linkedStudentIds
      : [SEED_IDS.STUDENT_AARAV, SEED_IDS.STUDENT_ANANYA]
  )
  ...
  // PostgreSQL Mode (lines 442-448):
  if (!guardian || !guardian.children.length) {
    // Fallback query for seeded Patel parent
    const fallback = await this.prisma.student.findMany({
      where: {
        id: { in: [SEED_IDS.STUDENT_AARAV, SEED_IDS.STUDENT_ANANYA] },
        deleted_at: null,
      },
  ```
- **Context**: If any parent user has no registered children or calls `/people/guardians/siblings`, the API falls back to returning the student profiles, admission numbers, and decrypted health data (blood group, emergency contact) of Aarav and Ananya Patel. This violates DPDP Act tenant and identity isolation.

### 1.5 Critical Finding: Dual Database Mode Write Asymmetry (Mutations Never Persist to PostgreSQL)
- **Locations**:
  - `apps/api/src/modules/attendance/attendance.service.ts:98, 147, 314`: `recordRapidBatch`, `recordBatch`, and `applyLeave` write strictly to `this.prisma.mockStore.*.set(...)` and omit `prisma.attendance.createMany` or `prisma.attendance.create`.
  - `apps/api/src/modules/academics/academics.service.ts:158, 215, 307`: `createTerm`, `submitMarksBatch`, and `createSubstitution` write strictly to `this.prisma.mockStore.*.set(...)` and omit `prisma.exam.create`, `prisma.marksEntry.create`, and `prisma.teacherAbsenceSubstitution.create`.
  - `apps/api/src/modules/fees/fees.service.ts:155, 215, 283, 340`: `createStructure`, `createRazorpayOrder`, `processWebhook`, and `applyConcession` write strictly to `this.prisma.mockStore.*.set(...)` and omit `prisma.feeStructure.create`, `prisma.payment.create`, and `prisma.feeConcession.create`.
  - `apps/api/src/modules/transport/transport.service.ts:115, 152`: `recordBoardingScan` and `recordGpsPing` write strictly to `this.prisma.mockStore.*.set(...)` and omit `prisma.boardingEvent.create` and `prisma.transportTelemetry.create`.
  - `apps/api/src/modules/safety/safety.service.ts:45, 92, 190`: `createVisitorPass`, `verifyChildPickup`, and `recordAnonymousIncident` interact strictly with `this.prisma.mockStore.*` and omit `prisma.visitorPass.create` (and have no DB model for pickup/incident).
- **Context**: When `USE_MOCK_DB=false`, these write endpoints completely fail to persist data into PostgreSQL. When queries (e.g. `getStudentMonthlyStats`) query `this.prisma.attendance.findMany`, zero records are found.

### 1.6 Major Finding: Global Validation Pipe Not Wired & All Controllers Use `@Body() body: any`
- **Location**: All 11 controllers in `apps/api/src/modules/**/*`, `apps/api/src/main.ts`, `apps/api/src/app.module.ts`.
- **Observed Code**:
  - In `apps/api/src/common/pipes/zod-validation.pipe.ts`, `ZodValidationPipe` and `UseZod` are defined, but never registered in `main.ts` via `app.useGlobalPipes(...)` or `app.module.ts` via `APP_PIPE`.
  - Across all controllers (`auth.controller.ts`, `people.controller.ts`, `attendance.controller.ts`, `fees.controller.ts`, `academics.controller.ts`, `transport.controller.ts`, `safety.controller.ts`, `ai.controller.ts`), every POST/PUT method uses `@Body() body: any` without any DTO or schema validation pipe.
  - `@bomis/shared` exports 20+ canonical Zod schemas, but they are completely bypassed at the HTTP controller boundary.

### 1.7 Major Finding: Pino Logger Not Wired into NestJS
- **Location**: `apps/api/src/main.ts:6`, `apps/api/src/app.module.ts:28–69`, `apps/api/package.json:28–30`.
- **Observed Code**: `pino`, `pino-http`, and `pino-pretty` are in `package.json`, but `main.ts` calls `NestFactory.create(AppModule)` without configuring Pino as the NestJS logger (e.g., using `nestjs-pino` or a custom Pino logger wrapper). NestJS uses its standard internal logger.

### 1.8 Major Finding: Missing Terminus Dependency & Dummy Readiness Probes
- **Location**: `apps/api/src/modules/health/health.controller.ts:46–50`.
- **Observed Code**:
  ```typescript
  return {
    status: 'ready',
    checks: {
      database: dbStatus,
      redis: 'up',
      minio: 'up',
    },
  };
  ```
- **Context**: `@nestjs/terminus` is not installed. `redis: 'up'` and `minio: 'up'` are hardcoded string constants without actual ping checks against Redis or MinIO.

### 1.9 Major Finding: Optional Idempotency-Key on Payments
- **Location**: `apps/api/src/modules/fees/fees.service.ts:175, 185–198`.
- **Context**: If `idempotencyKey` is not passed in the request header, `createRazorpayOrder` proceeds without throwing `BadRequestException`, violating Acceptance Criteria AC-3 ("All payment endpoints enforce Idempotency-Key headers").

### 1.10 Major Finding: Hardcoded Geofence Alert & Missing Socket.IO Gateway
- **Location**: `apps/api/src/modules/transport/transport.service.ts:169`.
- **Context**: Returns literal `proximityAlertsSent: 1` on every GPS ping without calculating Haversine distance (< 1.5km). There is no WebSocket/Socket.IO gateway implemented in `apps/api`.

---

## 2. Logic Chain

1. **Integrity Violations**:
   - In `fees.service.ts:261`, the condition `signature === 'test_hmac_sha256_mock_signature'` is hardcoded into the business service specifically so that incoming test webhooks pass without cryptographic verification. Under our reviewer mandate, embedded test-specific shortcuts that bypass security mechanisms are an **INTEGRITY VIOLATION**.
   - In `pulse.service.ts:26–27`, returning fixed numbers `95.4` and `89.2` for attendance and fee collection rates rather than computing them from available domain data constitutes a facade implementation.
2. **Security & Privacy Violations**:
   - In `auth.service.ts:162`, falling back to `SEED_IDS.USER_ADMIN` when a refresh token user is not found is a severe privilege escalation flaw.
   - In `people.service.ts:398 & 444`, falling back to returning Aarav and Ananya Patel's records whenever a parent has no children exposes protected student data across tenant boundaries, violating DPDP Act mandates.
3. **Architecture & Pluggability Failures**:
   - A core architectural requirement of M3 is dual database mode pluggability (`mockStore` vs live PostgreSQL).
   - In `attendance`, `academics`, `fees`, `transport`, and `safety`, write operations modify only in-memory Maps and execute no Prisma create calls. Therefore, the system is non-functional in PostgreSQL mode (`USE_MOCK_DB=false`).
4. **Validation & Logging Contracts**:
   - Acceptance Criteria require all validation to originate from `@bomis/shared` Zod schemas. Because controllers use `@Body() body: any` and `ZodValidationPipe` is not registered globally, incoming payloads are completely unvalidated at the gateway level.
   - Pino is installed but never initialized in `main.ts`.

---

## 3. Caveats

1. **Environment Shell Execution Policy**:
   - In accordance with the local execution environment policy, shell command execution via `run_command` was denied.
   - All observations and findings were established through comprehensive static AST code analysis, cross-file reference tracing, and schema contract comparison against `prisma/schema.prisma` and `@bomis/shared`.
2. **Remediated Baseline Items Acknowledged**:
   - The worker's remediation of dynamic CBSE attendance calculation, dynamic audit log retrieval, pickup authorization map matching in safety service, and AES-256-GCM encryption in `PeopleService` are genuine improvements and correctly implemented for in-memory mode.

---

## 4. Conclusion

Milestone M3 **cannot be approved** in its current state. The implementation contains critical integrity shortcuts (hardcoded webhook signature bypass, static Pulse metrics), severe security/privacy vulnerabilities (silent admin token fallback, Patel sibling data leakage), broken PostgreSQL write persistence across 5 domain modules, unvalidated controller payloads (`@Body() body: any`), and unintegrated Pino logger.

**Final Verdict**: **REQUEST_CHANGES**

### Actionable Remediation Requirements
1. **Remove HMAC Webhook Bypass (`fees.service.ts`)**:
   - Remove `isMockBypass` and `test_hmac_sha256_mock_signature`.
   - Update `docs/postman/bomis_postman_collection.json` or pre-request script to calculate the valid HMAC-SHA256 signature using the shared secret.
   - Require `idempotency-key` header on `createOrder` (throw 400 Bad Request if missing).
2. **Compute Real Pulse Metrics (`pulse.service.ts`)**:
   - Calculate `attendanceRate` dynamically from `attendance` records (e.g. today's or current month's percentage).
   - Calculate `feeCollectionRate` dynamically from `payments` versus total `feeInstallments`.
3. **Eliminate Admin Fallback in Auth (`auth.service.ts`)**:
   - In `rotateRefreshToken`, throw `UnauthorizedException({ code: 'USER_NOT_FOUND', message: 'User associated with refresh token no longer exists' })` when user is not found.
4. **Fix Sibling Data Isolation (`people.service.ts`)**:
   - In `getLinkedSiblings`, return an empty array `[]` (or 404) if a guardian has no linked children, instead of leaking Aarav and Ananya Patel's profiles.
5. **Implement PostgreSQL Writes in Dual Database Mode**:
   - For all mutation methods in `attendance`, `academics`, `fees`, `transport`, and `safety`, implement the `if (this.prisma.isMock)` branch for `mockStore` and the `else` branch using `this.prisma.<model>.create` / `createMany`.
6. **Enforce Global Validation & DTOs**:
   - Wire `ZodValidationPipe` globally in `main.ts` or bind schemas to controllers via `@UsePipes(new ZodValidationPipe(Schema))` using canonical `@bomis/shared` schemas.
   - Replace `@Body() body: any` with typed schemas/interfaces.
7. **Wire Pino Logger**:
   - Configure Pino as the global logger in `main.ts` with JSON formatting and AsyncLocalStorage correlation ID extraction.

---

## 5. Verification Method

To independently verify these findings:

1. **Verify HMAC Bypass**: Inspect `apps/api/src/modules/fees/fees.service.ts:260–268`. Observe `isMockBypass = isTestEnv && signature === 'test_hmac_sha256_mock_signature'`.
2. **Verify Hardcoded Pulse Metrics**: Inspect `apps/api/src/modules/pulse/pulse.service.ts:26–27`. Observe `attendanceRate = 95.4` and `feeCollectionRate = 89.2`.
3. **Verify Auth Admin Escalation**: Inspect `apps/api/src/modules/auth/auth.service.ts:161–164`. Observe fallback to `SEED_IDS.USER_ADMIN`.
4. **Verify Sibling PII Leak**: Inspect `apps/api/src/modules/people/people.service.ts:398` and `444`. Observe fallback returning `[SEED_IDS.STUDENT_AARAV, SEED_IDS.STUDENT_ANANYA]`.
5. **Verify Missing PostgreSQL Writes**: Inspect `apps/api/src/modules/attendance/attendance.service.ts:88–98, 136–148`. Observe absence of `this.prisma.attendance.create`.
6. **Verify Untyped Controllers**: Inspect `apps/api/src/modules/auth/auth.controller.ts:13, 20, 27` and `apps/api/src/modules/attendance/attendance.controller.ts:26, 34`. Observe `@Body() body: any`.
7. **Verify Pino Logger Integration**: Inspect `apps/api/src/main.ts:6` and `apps/api/src/app.module.ts:28–69`. Observe that Pino is not configured as the application logger.
