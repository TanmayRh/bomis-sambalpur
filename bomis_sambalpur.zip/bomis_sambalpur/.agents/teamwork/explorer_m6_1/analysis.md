# Technical Analysis: BOMIS Sambalpur E2E Postman Newman Test Suite

- **Explorer**: `explorer_m6_1`
- **Working Directory**: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m6_1`
- **Date**: 2026-10-22
- **Milestone**: M6 (Phase 1: Final Verification & Test Architecture)

---

## 1. Executive Summary

This investigation delivers a comprehensive audit of the automated API end-to-end test suite for the **Birla Open Minds International School (BOMIS), Sambalpur** Unified School Platform. The assets under review (`docs/postman/bomis_postman_collection.json`, `docs/postman/bomis_postman_environment.json`, `docs/postman/run-newman.js`, `docs/postman/README.md`) represent the headless API verification tier described in `TEST_INFRA.md` and required by `ORIGINAL_REQUEST.md` (Acceptance Criteria AC-2, AC-3, AC-5).

The collection comprehensively models **31 REST endpoints distributed across 9 domain folders**, covering all 8 application roles (`SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `TEACHER`, `ACCOUNTANT`, `STUDENT`, `PARENT`, `TRANSPORT_STAFF`), DPDP tenant isolation (`x-school-id`), rapid attendance (<10s), CBSE 9-point scale marks entry, Razorpay order/webhook financial safety, pilot bus fleet telemetry, dynamic QR gate passes, and negative RBAC security gates.

---

## 2. Postman Collection Architecture & 31-Endpoint Inventory

The collection `docs/postman/bomis_postman_collection.json` conforms to Postman Collection Schema v2.1.0 (`info.schema = https://schema.getpostman.com/json/collection/v2.1.0/collection.json`). Below is the complete catalog of all 31 requests mapped against the 9 domain folders, HTTP methods, controllers, and roles exercised:

| # | Folder | Request Name | Method | Route | Controller & Method | Target Role |
|---|---|---|---|---|---|---|
| 1 | **00_System_Health_and_Probes** | Liveness Probe | GET | `{{baseUrl}}/health` | `HealthController.getLiveness` | Public |
| 2 | | Readiness Probe | GET | `{{baseUrl}}/ready` | `HealthController.getReadiness` | Public |
| 3 | **01_Authentication_and_RBAC** | Request Mobile OTP | POST | `{{baseUrl}}/api/v1/auth/otp/send` | `AuthController.sendOtp` | Public / Parent / Student |
| 4 | | Verify Mobile OTP | POST | `{{baseUrl}}/api/v1/auth/otp/verify` | `AuthController.verifyOtp` | Public → Parent Token |
| 5 | | Staff Email Login | POST | `{{baseUrl}}/api/v1/auth/staff/login` | `AuthController.staffLogin` | Public → Admin / Staff Token |
| 6 | | Rotate Refresh Token | POST | `{{baseUrl}}/api/v1/auth/refresh` | `AuthController.refresh` | Public |
| 7 | | Revoke Session (Logout) | POST | `{{baseUrl}}/api/v1/auth/logout` | `AuthController.logout` | Authenticated |
| 8 | **02_People_Management** | List Students (Grade 5 Sec A) | GET | `{{baseUrl}}/api/v1/people/students` | `PeopleController.listStudents` | Admin |
| 9 | | Create Student Profile | POST | `{{baseUrl}}/api/v1/people/students` | `PeopleController.createStudent` | Admin |
| 10 | | Get Student Profile by ID | GET | `{{baseUrl}}/api/v1/people/students/{{studentId}}` | `PeopleController.getStudentById` | Admin |
| 11 | | Fetch Linked Siblings | GET | `{{baseUrl}}/api/v1/people/guardians/siblings` | `PeopleController.getLinkedSiblings` | Parent |
| 12 | | List Staff Directory | GET | `{{baseUrl}}/api/v1/people/staff` | `PeopleController.listStaff` | Admin |
| 13 | **03_Attendance_and_Offline_Sync** | Rapid Attendance Grid (<10s) | POST | `{{baseUrl}}/api/v1/attendance` | `AttendanceController.recordRapidBatch` | Admin / Teacher |
| 14 | | Offline Outbox Sync Batch | POST | `{{baseUrl}}/api/v1/sync/batch` | `SyncController.syncBatch` | Admin / Outbox Client |
| 15 | | Student Attendance Stats | GET | `{{baseUrl}}/api/v1/attendance/students/{{studentId}}` | `AttendanceController.getStudentStats` | Parent |
| 16 | **04_Fees_and_Financial_Safety** | Get Fee Structures by Grade | GET | `{{baseUrl}}/api/v1/fees/structures` | `FeesController.getStructures` | Admin |
| 17 | | Create Razorpay Payment Order | POST | `{{baseUrl}}/api/v1/fees/orders` | `FeesController.createOrder` | Parent |
| 18 | | Razorpay Webhook (HMAC-SHA256) | POST | `{{baseUrl}}/api/v1/fees/webhook` | `FeesController.handleWebhook` | Public (Signature auth) |
| 19 | | Download Fee Tax Receipt | GET | `{{baseUrl}}/api/v1/fees/receipts/{{receiptId}}` | `FeesController.getReceipt` | Parent |
| 20 | **05_Academics_and_CBSE_Grading** | Get Academic Terms | GET | `{{baseUrl}}/api/v1/academics/terms` | `AcademicsController.getTerms` | Admin |
| 21 | | Submit Marks Batch (9-Point Scale)| POST | `{{baseUrl}}/api/v1/academics/marks/batch` | `AcademicsController.submitMarks` | Admin / Teacher |
| 22 | | Timetable Clash Check | POST | `{{baseUrl}}/api/v1/academics/timetable/clash-check`| `AcademicsController.checkClash` | Admin / Teacher |
| 23 | **06_Transport_Fleet_Operations** | List Bus Routes and Stops | GET | `{{baseUrl}}/api/v1/transport/routes` | `TransportController.getRoutes` | Admin |
| 24 | | List 4 Pilot Buses | GET | `{{baseUrl}}/api/v1/transport/buses` | `TransportController.getBuses` | Admin |
| 25 | | Scan Student Boarding QR | POST | `{{baseUrl}}/api/v1/transport/boarding/scan` | `TransportController.scanBoarding` | Admin / Driver |
| 26 | **07_Safety_and_Visitor_Management** | Create Pre-Approved Gate Pass | POST | `{{baseUrl}}/api/v1/safety/visitors` | `SafetyController.createVisitorPass` | Admin |
| 27 | | Verify Child Pickup OTP | POST | `{{baseUrl}}/api/v1/safety/pickup/verify` | `SafetyController.verifyPickup` | Admin / Gatekeeper |
| 28 | | Anonymous Anti-Bullying Report | POST | `{{baseUrl}}/api/v1/safety/incidents/anonymous` | `SafetyController.recordAnonymousIncident`| Public (Zero-log) |
| 29 | **08_RBAC_Negative_Gates** | Parent Blocked from Audit Logs | GET | `{{baseUrl}}/api/v1/admin/audit-logs` | `AdminController.getAuditLogs` | Parent (Expects 403) |
| 30 | | Student Blocked from Marks Entry | POST | `{{baseUrl}}/api/v1/academics/marks/batch` | `AcademicsController.submitMarks` | Student (Expects 403) |
| 31 | | Driver Blocked from Fee Structs | GET | `{{baseUrl}}/api/v1/fees/structures` | `FeesController.getStructures` | Driver (Expects 403) |

---

## 3. Standard Response Envelope Verification & Assertions

### 3.1 Contract Specification
`ORIGINAL_REQUEST.md` (AC-2) and `PROJECT.md` define the mandatory response envelope:
```typescript
export interface ApiResponse<T> {
  success: boolean;
  data: T | null;
  error?: {
    code: string;
    message: string;
    details?: any;
  } | null;
  timestamp: string;
  correlationId: string;
}
```

### 3.2 Collection-Level Global Test Script
In `bomis_postman_collection.json` (lines 36–81), a global test script runs on every request:
```javascript
// Global Test: Validate BOMIS Standard API Response Envelope
pm.test('Standard Response Envelope matches { success, data, error, timestamp, correlationId }', function () {
  var contentType = pm.response.headers.get('content-type') || '';
  if (contentType.includes('application/pdf') || contentType.includes('text/csv')) {
    return; // Bypass validation for binary/file streams
  }

  var json = pm.response.json();
  pm.expect(json).to.be.an('object');
  pm.expect(json).to.have.property('success');
  pm.expect(json.success).to.be.a('boolean');
  pm.expect(json).to.have.property('timestamp');
  pm.expect(json).to.have.property('correlationId');

  var reqCorrelationId = pm.variables.get('correlationId');
  if (reqCorrelationId && json.correlationId) {
    pm.expect(json.correlationId).to.eql(reqCorrelationId);
  }

  if (json.success === true) {
    pm.expect(json).to.have.property('data');
  } else {
    pm.expect(json).to.have.property('error');
    pm.expect(json.error).to.be.an('object');
    pm.expect(json.error).to.have.property('code');
    pm.expect(json.error).to.have.property('message');
  }
});
```

### 3.3 Server-Side Implementation Congruence
The server mirrors this exact contract in two locations:
1. `apps/api/src/common/interceptors/transform.interceptor.ts`: Intercepts successful responses, checks `StreamableFile` and content types, extracts `correlationId` from `traceStorage` / headers, and wraps into `ApiResponse<T>`.
2. `apps/api/src/common/filters/http-exception.filter.ts`: Catches all `HttpException` and `ZodError` exceptions, maps HTTP statuses to domain error codes (`VALIDATION_FAILED`, `FORBIDDEN`, `UNAUTHORIZED`, etc.), and produces `{ success: false, data: null, error: { code, message, details }, timestamp, correlationId }`.

---

## 4. Dynamic Request Correlation ID & Financial Idempotency

### 4.1 Automated Pre-Request Script
`bomis_postman_collection.json` (lines 8–34) executes three pre-request injections on every request:
1. **Dynamic Correlation ID**:
   ```javascript
   var correlationId = 'corr-' + pm.variables.replaceIn('{{$guid}}');
   pm.variables.set('correlationId', correlationId);
   pm.request.headers.upsert({ key: 'x-correlation-id', value: correlationId });
   ```
2. **Conditional Financial & Sync Idempotency Injection**:
   ```javascript
   var path = pm.request.url.getPath();
   if (['POST', 'PUT', 'PATCH'].includes(pm.request.method)) {
     if (path.includes('orders') || path.includes('payments') || path.includes('sync') || path.includes('attendance')) {
       var idempotencyKey = 'idemp-' + pm.variables.replaceIn('{{$guid}}');
       pm.variables.set('idempotencyKey', idempotencyKey);
       pm.request.headers.upsert({ key: 'Idempotency-Key', value: idempotencyKey });
     }
   }
   ```
3. **Tenant Header Injection**:
   ```javascript
   var schoolId = pm.variables.get('school_id') || 'sch_bomis_sambalpur_001';
   pm.request.headers.upsert({ key: 'x-school-id', value: schoolId });
   ```

### 4.2 Server Correlation Context
In `apps/api/src/common/context/correlation-context.middleware.ts`, `CorrelationContextMiddleware` captures `x-correlation-id` (or falls back to `corr-${randomUUID()}`), resolves `x-school-id` via `resolveSchoolId()` mapping symbolic `sch_bomis_sambalpur_001` to canonical seed UUID `SEED_SCHOOL_ID = 'e4b3c2a1-0001-4000-8000-000000000001'`, and injects it into `traceStorage` (`AsyncLocalStorage<RequestTraceContext>`).

---

## 5. Newman Test Runner (`run-newman.js`) & CLI Environment

### 5.1 Runner Feature Matrix
The runner script `docs/postman/run-newman.js` provides:
- `--baseUrl=<url>`: Overrides `environment.values['baseUrl']` dynamically (default `http://localhost:4000`).
- `--folder=<name>`: Restricts Newman to a single domain folder (e.g. `--folder="04_Fees_and_Financial_Safety"`).
- `--reporters=<list>`: Configures reporters (e.g. `cli`, `json`, `html`).
- `--export=<path>`: Specifies destination file for JSON summary report.
- `--bail`: Halts Newman on the first assertion failure.
- `--help`: Prints command line options.
- Diagnostic fallback: If `newman` is not in `node_modules`, it parses collection and environment JSON files, prints folder breakdown and counts, and exits cleanly.

### 5.2 Dependency Audit
- Monorepo root `package.json` line 30 contains `"newman": "^6.1.2"` under `devDependencies`.
- Project `node_modules` is currently not present on disk. Executing `node docs/postman/run-newman.js` triggers the diagnostic fallback until dependencies are installed via `pnpm install`.

---

## 6. Critical Findings & Gap Analysis

Through deep inspection of the collection, environment, and backend security guards, we identified **one critical execution gap** that must be remediated for a clean 100% test pass:

### The `studentToken` and `driverToken` RBAC Trap
1. In `08_RBAC_Negative_Gates`:
   - Request 29 (`Parent Blocked from Admin Audit Logs`) uses `Bearer {{parentToken}}`.
   - Request 30 (`Student Blocked from Modifying Marks`) uses `Bearer {{studentToken}}`.
   - Request 31 (`Driver Blocked from Fee Structures`) uses `Bearer {{driverToken}}`.
2. In `bomis_postman_environment.json`:
   - `studentToken` is initialized to `""` (empty string).
   - `driverToken` is initialized to `""` (empty string).
3. In `01_Authentication_and_RBAC`:
   - Request 4 logs in Parent and populates `parentToken`.
   - Request 5 logs in Staff Admin and populates `adminToken` and `jwt_token`.
   - **No requests exist to authenticate a Student or a Driver.**
4. In `apps/api/src/common/guards/jwt-auth.guard.ts` (lines 37–43):
   ```typescript
   const token = authHeader.substring(7).trim();
   if (!token) {
     throw new UnauthorizedException({
       code: 'UNAUTHORIZED',
       message: 'Empty Bearer token',
     });
   }
   ```
5. **Consequence**: When Newman executes Requests 30 and 31, it sends `Authorization: Bearer `. `JwtAuthGuard` intercepts the request before `RolesGuard` is ever invoked, throwing HTTP **401 Unauthorized** instead of HTTP **403 Forbidden**.
   - Test assertion: `pm.response.to.have.status(403);`
   - Actual response: `401 Unauthorized`
   - **Result: Assertions 30 and 31 fail with `expected 401 to equal 403`.**

---

## 7. Recommendations for 100% E2E Test Execution in Phase 1

To achieve 100% clean test execution in Phase 1 / Milestone M6, implement the following four-step remediation:

### Step 1: Prime `studentToken` and `driverToken`
Choose one of two robust options:

- **Option A (Recommended: Collection Authentication Requests)**:
  Add two authentication requests to folder `01_Authentication_and_RBAC`:
  1. `Driver Staff Login`:
     - POST `{{baseUrl}}/api/v1/auth/staff/login`
     - Body: `{"email": "driver.bhoi@bomis-sambalpur.edu.in", "password": "Admin@Sambalpur2026"}`
     - Test script: `pm.environment.set('driverToken', json.data.accessToken);`
  2. `Student OTP Login`:
     - POST `{{baseUrl}}/api/v1/auth/otp/verify`
     - Body: `{"phone": "+919876543211", "otp": "123456"}`
     - Test script: `pm.environment.set('studentToken', json.data.accessToken);`

- **Option B (Pre-Seeded Environment Tokens)**:
  Pre-sign valid 1-year JWTs with `JWT_SECRET = 'bomis_jwt_secret_sambalpur_2026'` for `USER_STUDENT_AARAV` and `USER_DRIVER_BHOI`, and paste them directly into `bomis_postman_environment.json`.

### Step 2: Monorepo Bootstrapping
Install dependencies so `newman` is accessible:
```bash
pnpm install
```

### Step 3: Database & Backend Initialization
Start backing infrastructure and seed the database fixtures:
```bash
docker compose -f infra/docker-compose.yml up -d
pnpm db:migrate
pnpm db:seed
pnpm --filter @bomis/api start:dev
```

### Step 4: Full Suite Newman Execution
Execute the full collection with CLI reporter and JSON summary artifact:
```bash
node docs/postman/run-newman.js --baseUrl=http://localhost:4000 --reporters=cli,json --export=docs/postman/newman-report.json --bail
```
Expected outcome: 31/31 requests executed, 0 failed assertions, exit code 0.
