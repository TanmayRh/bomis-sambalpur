# Execution Plan: Milestone M5 React Native Expo Mobile Implementation

## Directory & Package Target
Package: `apps/mobile/` (`@bomis/mobile`)
Workspace: `C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\apps\mobile\`

## Execution Phases

### Phase 1: Services & Offline Sync Foundation (`apps/mobile/src/services/`)
- [ ] 1.1 `src/services/storage-adapter.ts`: 3-tier Adaptive Storage Engine (`IStorageAdapter`, `MemoryStorageAdapter`, `WebLocalStorageAdapter`, `createStorageAdapter`, `defaultStorage`).
- [ ] 1.2 `src/services/outbox-queue.ts`: Outbox queue repository (`OutboxRepository`, `OutboxItem`, idempotency key generation `idem_<actionType>_<id>`).
- [ ] 1.3 `src/services/sync-manager.ts`: NetworkMonitor & SyncManager orchestrating batch sync to `POST /api/v1/sync/batch`, stats notification, and idempotent deduplication.
- [ ] 1.4 `src/services/api-client.ts`: Typed fetch client unwrapping `ApiResponse<T>`, 401 refresh queue, offline fallback fixtures matching seed data.
- [ ] 1.5 `src/services/location-service.ts`: Driver GPS broadcaster simulating Budharaja Shuttle trajectory (Budharaja Fatak -> Sakhipada Chhak -> Ainthapali Chowk -> Campus Gate) and 5-min geofence alert detection.

### Phase 2: State & Context Providers (`apps/mobile/src/state/`)
- [ ] 2.1 `src/state/auth-context.tsx`: Auth state, user profile, tokens, role dispatch, 4 evaluation presets.
- [ ] 2.2 `src/state/parent-context.tsx`: Multi-child sibling state isolation (Aarav vs Ananya Patel), child-specific attendance, bus tracking, fee installments, dismissal pass.

### Phase 3: Branded UI Primitives (`apps/mobile/src/components/ui/`)
- [ ] 3.1 `src/components/ui/BOMISButton.tsx`: Variants (`primary`, `accent`, `outline`, `ghost`, `danger`), sizes (`sm`, `md`, `lg`), spinner.
- [ ] 3.2 `src/components/ui/BOMISCard.tsx`: Elevated container with rounded corners (16px), border, elevation.
- [ ] 3.3 `src/components/ui/BOMISBadge.tsx`: Status badges (`PRESENT`, `ABSENT`, etc.), role badges (`PARENT`, `STUDENT`, etc.), geofence badge.
- [ ] 3.4 `src/components/ui/BOMISInput.tsx`: Accessible input with label, prefix, helper text.
- [ ] 3.5 `src/components/ui/BOMISHeader.tsx`: Top bar with BOMIS crest, CBSE Affiliation #1530267 badge, active role indicator, user info, logout trigger.

### Phase 4: Role Screens (`apps/mobile/src/screens/`)
- [ ] 4.1 `src/screens/AuthScreen.tsx`: Phone OTP entry, dev autofill `123456`, and 4 Quick Evaluation Presets (Dr. Rajesh Patel, Aarav Patel, Mrs. Arundhati Dash, Maheswar Bhoi).
- [ ] 4.2 `src/screens/ParentScreen.tsx`: Sibling Switcher, Attendance summary & calendar, Live Bus Tracker with 5-minute geofence alert banner for Sakhipada Chhak, Fee Checkout with UUID Idempotency-Key, and Dismissal OTP Card with 30-min countdown timer & dynamic QR.
- [ ] 4.3 `src/screens/StudentScreen.tsx`: Digital Student ID Card with dynamic QR, House Kalinga, allergy tag, Homework & Digital Diary feed with status toggles, and Timetable schedule.
- [ ] 4.4 `src/screens/TeacherScreen.tsx`: Rapid Attendance Grid (<10s SLA) for 40-student roster, 1-click "Mark All Present", exception cycling, offline queue badge, and Homework Announcement Poster.
- [ ] 4.5 `src/screens/DriverScreen.tsx`: Route 1 Budharaja Shuttle 4 stops list, Live GPS Broadcaster toggle (5s pings), and Student Boarding QR Scanner with manual fallback.

### Phase 5: App Entrypoint & Verification
- [ ] 5.1 `apps/mobile/App.tsx`: App root combining AuthProvider, ParentProvider, multi-role navigation, global offline sync banner, role switcher.
- [ ] 5.2 `apps/mobile/src/__tests__/mobile.spec.ts`: Test suite verifying outbox queue, idempotency keys, multi-child isolation, 30-minute OTP countdown, rapid attendance delta calculation, and api client fallback fixtures.
- [ ] 5.3 Verify TypeScript imports from `@bomis/shared` and `@bomis/ui`.
- [ ] 5.4 Update BRIEFING.md, write handoff report in `handoff.md`, and notify orchestrator.
