## 2026-10-21T04:57:36Z
You are worker_m5_mobile (Milestone M5 Mobile Implementation Worker).
Your working directory is C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m5_mobile.
Your orchestrator conversation ID is 61cb1a70-f093-4eb1-8970-0e6aa09a7e37.

You MUST read the following authoritative documents before starting your work:
- ORIGINAL_REQUEST: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\ORIGINAL_REQUEST.md
- PROJECT: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\PROJECT.md
- IMPLEMENTATION BLUEPRINT: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\orchestrator_gen5\IMPLEMENTATION_M5.md
- SPEC MINER REPORT: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\spec_miner_m5_1\handoff.md
- ARCHITECTURE BLUEPRINT: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m5_1\handoff.md
- OFFLINE SYNC BLUEPRINT: C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\explorer_m5_2\handoff.md

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

SCOPE OF IMPLEMENTATION (Target package: apps/mobile/):
You have exclusive write ownership of files under `apps/mobile/`.
Implement the complete React Native Expo mobile application conforming to `IMPLEMENTATION_M5.md`:

1. Services & Storage (`apps/mobile/src/services/`):
   - `storage-adapter.ts`: Adaptive 3-tier storage adapter (`IStorageAdapter`) supporting in-memory, web local storage, and async storage wrapper safely without native module crashes.
   - `outbox-queue.ts`: Outbox repository storing offline events (`ATTENDANCE_BATCH`, `BOARDING_SCAN`, `GPS_PING`) with client UUIDs and idempotency keys (`idem_<actionType>_<id>`).
   - `sync-manager.ts`: Offline sync engine monitoring network state, batch-dispatching pending outbox events to `POST /api/v1/sync/batch`, and clearing synced items.
   - `api-client.ts`: Typed client unwrapping standard `ApiResponse<T>` envelope `{ success, data, error, timestamp, correlationId }`, with 401 refresh queue, and offline fallback fixtures matching seed data (Aarav & Ananya Patel, Arundhati Dash, Maheswar Bhoi).
   - `location-service.ts`: Driver GPS broadcaster simulating Budharaja Shuttle trajectory (Budharaja Fatak -> Sakhipada Chhak -> Ainthapali Chowk -> Campus Gate) and emitting geofence events.

2. State & Context (`apps/mobile/src/state/`):
   - `auth-context.tsx`: Context managing session state, user profile, mobile token, and active role.
   - `parent-context.tsx`: Context managing active child selection (Aarav Patel vs Ananya Patel) with clean child-scoped data isolation.

3. UI Primitives (`apps/mobile/src/components/ui/`):
   - `BOMISButton.tsx`: Variants (`primary`, `accent`, `outline`, `ghost`, `danger`), sizes, loading indicator.
   - `BOMISCard.tsx`: Card container with rounded borders (`rounded-2xl`), elevation shadows.
   - `BOMISBadge.tsx`: Badges for attendance status, RBAC roles, and geofence alerts.
   - `BOMISInput.tsx`: Accessible input with label, prefix icon, and error helper text.
   - `BOMISHeader.tsx`: Branded top bar showing campus logo, CBSE affiliation 1530267 badge, active role indicator, and logout trigger.

4. Role Screens (`apps/mobile/src/screens/`):
   - `AuthScreen.tsx`: Indian mobile phone OTP login form + 1-click evaluation quick login presets for all 4 roles (Dr. Rajesh Patel [Parent], Aarav Patel [Student], Mrs. Arundhati Dash [Teacher], Maheswar Bhoi [Driver]).
   - `ParentScreen.tsx`: Sibling switcher, attendance metrics card, live bus tracker with 5-minute geofence alert banner for Sakhipada Chhak, fee checkout modal with RFC 4122 UUID Idempotency-Key, and dismissal OTP card with 30-min countdown timer & dynamic QR.
   - `StudentScreen.tsx`: Digital student ID card with dynamic QR, homework & assignments list, and weekly timetable grid.
   - `TeacherScreen.tsx`: Rapid attendance grid (<10s SLA) for 40-student roster with 1-click "Mark All Present", exception cycling, offline queue badge, and homework poster.
   - `DriverScreen.tsx`: Route 1 Budharaja Shuttle stops list, live GPS broadcaster toggle (5s interval), and student boarding/deboarding QR scanner with manual search fallback.

5. Application Root (`apps/mobile/App.tsx`):
   - Wire `AuthProvider`, `ParentProvider`, view routing between `AuthScreen` and active role screen, and global offline sync banner.

6. Verification Suite (`apps/mobile/src/__tests__/mobile.spec.ts`):
   - Comprehensive tests validating offline outbox queuing, idempotency key generation, multi-child state isolation, 30-minute OTP countdown lifecycle, and rapid attendance delta dispatch.

VERIFICATION & DELIVERABLES:
1. Verify that all imports from `@bomis/shared` and `@bomis/ui` resolve cleanly.
2. Check that TypeScript typecheck passes (`tsc -p apps/mobile/tsconfig.json --noEmit` or `pnpm --filter @bomis/mobile typecheck`).
3. Write your full handoff report to:
   C:\Users\Hp\.gemini\antigravity\scratch\bomis_sambalpur\.agents\teamwork\worker_m5_mobile\handoff.md
4. Send a message to orchestrator (61cb1a70-f093-4eb1-8970-0e6aa09a7e37) upon completion.
