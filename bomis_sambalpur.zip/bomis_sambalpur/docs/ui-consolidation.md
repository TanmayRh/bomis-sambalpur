# 🏛️ BOMIS Sambalpur Unified School Platform
## UI Consolidation Blueprint & Edge-Case Architecture (`docs/ui-consolidation.md`)

> **Executive Goal:** Make the parent app understandable to an anxious, non-technical parent in under 3 seconds:
> 1. *Is school on?*
> 2. *Where is the bus?*
> 3. *Do I need to do anything?*
>
> This is a **consolidation job**, not a feature job. Eliminates static dashboard noise, removes all popup modals, and establishes a single calm **DayStream + AlertSlot + TodayBar + OneThing + MoreSheet** layout.

---

### 📊 1. Parent-Facing Component Disposition Matrix

| Current Element in `page.tsx` | Decision | Target Destination / Replacement |
| :--- | :--- | :--- |
| **Header Multi-Child Dropdown / "Switch Admission"** | **Remove** | Replaced by **TodayBar**: Aarav (5A) and Ananya (2A) displayed simultaneously. Merged into one line when schedules match; splits dynamically if asymmetric. |
| **Bottom Navigation Bar (7 Tabs)** | **Remove** | The entire parent experience is **one single screen** plus a bottom sheet (`MoreSheet` via `☰ More`). |
| **Alert Slot (Emergency Notification)** | **Keep & Elevate** | **`AlertSlot`**: Zero height on normal days. Shows at most 1 alert (highest severity). The ONLY place amber/red appears. |
| **Morning Assembly Card (Thought & Word)** | **Merge** | Consolidated into a single collapsed line inside `DayStream` with audio pronunciation in the chosen language. |
| **Live Bus Telemetry & Polyline Radar** | **Consolidate** | **`BusLine`**: Single line: `"🚌 Bus 3 reaches your stop at 7:42 • On time"`. Tap expands map. Replaces fake 24 km/h with 3 honest states: *Live*, *Estimated* (amber range), *Lost* (call driver). |
| **AI 60-Second Evening Digest** | **Merge** | Time-aware 3:30 PM stream item in `DayStream` containing the headline, bullets, and *"Ask Aarav at Dinner"* prompt. |
| **Canteen POS & Allergy Block Modal** | **Consolidate** | Inline tag on child row: `"🥜 Peanut allergy on file"`. Blocked purchases become quiet stream items: *"Canteen blocks flagged items, nothing eaten"*. |
| **Gate Pickup QR Modal** | **Merge** | In-place expansion in `DayStream` at 2:45 PM: Who -> Language -> Send -> Live tracking (Sent -> Opened -> Picked up). |
| **Voice-to-Rubric Teacher Modal** | **Move / Streamline**| Teacher retains pinned mic in Teacher Hub (`/teacher`). For parents, it feeds the 3:30 PM stream item without manual typing. |
| **PWA Install Guide Modal** | **Consolidate** | Removed from startup. Becomes a 1-line chip at bottom of stream: *"Turn on emergency alerts"* from 2nd visit onwards. Never shown during an active emergency alert. |
| **Demo Scaffolding (1-Click Fills, Face Shield Simulator, POS Tap)** | **Move behind Flag**| Accessible via subtle top **"⚡ Scenario Switcher"** bar or `?demo=1` flag. Excluded from production builds. |
| **Fee Payment / Invoice Screens** | **Consolidate** | **`FeeCard`**: 4 honest states: *Due*, *In Progress* (Calm Escrow Shield with 48h provisional pass), *Paid*, *Needs Help*. |
| **Simple Elder View** | **New Failsafe** | `[ 👴 Simple / ବଡ଼ ଅକ୍ଷର ]` toggle: Strips UI to two giant >=64px yellow/black cards with native Odia/Hindi voice playback and 6-digit verbal pass (`831 294`). |

---

### 🛡️ 2. The 5 Real-World Edge-Case Specifications

1. **6:45 AM Monsoon District Collector Closure**:
   - Amber/Red full-bleed `<AlertCard>`: `"No school today · By order of the District Collector, Sambalpur"`.
   - Action buttons: `[ ✓ Got it, we're staying home ]` and `[ ⚠ My child has already left ]`.
   - Completely suppresses bus radar and normal stream until acknowledged.
2. **11:59 PM UPI Fee Payment Timeout ("Calm Escrow Shield")**:
   - If gateway is pending: Amber `<FeeCard>` stating `"Payment in progress, your fee is safe"`.
   - Guaranteed: No late fee, child's exam not affected, Provisional receipt `#PROV-8821`, `[ Save as proof ]`.
3. **Sibling Asymmetry Trap**:
   - Distinct visual signatures: Aarav 5A (Blue circle 🔵) vs Ananya 2A (Purple diamond 🟣).
   - If Aarav has school but Ananya has a sports holiday, TodayBar cleanly splits into two distinct rows.
4. **Mid-Day Infirmary SOS**:
   - Pinned `<AlertCard>`: `"🩹 Aarav is with the school nurse · Twisted ankle 11:30 AM"`.
   - Reassurance first: Aarav is awake, ice applied, no medicine given.
   - Quick actions: `[ 📞 Call the nurse ]`, `[ 🚗 We're coming ]`, `[ 💬 Can't talk, WhatsApp me ]`.
5. **Simple Elder View (Dada Ji Gate Pass)**:
   - High-contrast yellow/black palette, >=22px text, >=64px buttons, >=7:1 contrast.
   - Massive child photo, script name in Odia/Hindi, Gate 1 QR, and 6-digit verbal PIN (`831 294`).

---

### 🌐 3. Tri-Lingual Language Catalog (English, Hindi, Odia)
All strings seeded from the master string table.
- Odia (`or`): Natural Odia translations using native Odia script (ଓଡ଼ିଆ) and time prefixes (`ସକାଳ`, `ଅପରାହ୍ନ`, `ସନ୍ଧ୍ୟା`, `ରାତି`).
- Hindi (`hi`): Standard Hindi translations (हिन्दी) and time prefixes (`सुबह`, `दोपहर`, `शाम`, `रात`).
- English (`en`): Clean, plain-language terminology.
- Digits: Always international standard Arabic digits (`0-9`) in all locales for unambiguous bus numbers, times, and amounts.
