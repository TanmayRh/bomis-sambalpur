# 🏛️ BOMIS Sambalpur Unified School Platform
## Master Software Architecture, DevOps & Engineering Verification Guide

> **Target Audience:** School Technology Evaluators, CS Teachers, Examiners, and Senior Full-Stack Engineers.  
> **School:** Birla Open Minds International School (BOMIS), Sambalpur, Odisha, India.  
> **Repository:** Monorepo using Next.js 14, NestJS 10, TypeScript, Prisma ORM, Docker, and GitHub Actions.

---

## 📑 Table of Contents
1. [Monorepo Architecture & Directory Structure](#1-monorepo-architecture--directory-structure)
2. [What is Postman & How to Run the Automated API Suite](#2-what-is-postman--how-to-run-the-automated-api-suite)
3. [What is a CI/CD Pipeline & GitHub Actions Setup](#3-what-is-a-cicd-pipeline--github-actions-setup)
4. [Containerization & DevOps (Docker Compose)](#4-containerization--devops-docker-compose)
5. [Frontend & Backend Integration Contracts](#5-frontend--backend-integration-contracts)
6. [Data Privacy & DPDP Act 2023 Security Architecture](#6-data-privacy--dpdp-act-2023-security-architecture)
7. [Teacher / Examiner Quick Verification Checklist](#7-teacher--examiner-quick-verification-checklist)

---

## 1. Monorepo Architecture & Directory Structure

The platform uses a **Turbo-powered TypeScript monorepo** pattern, separating concerns cleanly between client interfaces, business logic services, shared data models, and infrastructure.

```
bomis_sambalpur/
├── .github/
│   └── workflows/
│       └── ci.yml               # Automated CI/CD verification pipeline
├── apps/
│   ├── api/                     # Backend: NestJS 10 Modular Monolith (Port 4000)
│   │   ├── src/
│   │   │   ├── common/          # AES-256-GCM encryption, Zod pipes, Pino logger
│   │   │   ├── database/        # Prisma ORM + deterministic mock store
│   │   │   └── modules/         # 11 Domain modules (auth, attendance, fees, etc.)
│   │   ├── Dockerfile           # Multi-stage production container build
│   │   └── package.json
│   └── web/                     # Frontend: Next.js 14 App Router (Port 3000)
│       ├── public/              # PWA manifest.json, vector icons, /sw.js
│       ├── src/
│       │   ├── app/             # App Router pages (Calm Day-Stream page.tsx)
│       │   ├── components/      # UI components (TodayBar, BusLine, SimplePass)
│       │   └── lib/             # Tri-lingual i18n catalog (en, hi, or), formatTime
│       ├── Dockerfile           # Optimized Next.js standalone container
│       └── package.json
├── packages/
│   ├── shared/                  # End-to-end shared TypeScript contracts & Zod schemas
│   └── ui/                      # Shared design system components
├── docs/
│   ├── postman/                 # Automated Postman v2.1 collection & Newman runner
│   │   ├── bomis_sambalpur_api.postman_collection.json
│   │   ├── bomis_postman_environment.json
│   │   └── run-newman.js        # Headless Newman execution script
│   ├── software-architecture-guide.md  # (This comprehensive guide)
│   └── ui-consolidation.md      # Parent Calm UI design specification
├── docker-compose.yml           # Local multi-container orchestration
├── package.json                 # Monorepo root scripts & tooling
└── turbo.json                   # Build graph caching & execution pipeline
```

---

## 2. What is Postman & How to Run the Automated API Suite

### What is Postman?
**Postman** is an industry-standard API testing and development platform. Instead of testing backend endpoints manually in a browser, Postman organizes requests into an automated **Collection** that can test dozens of API routes in seconds, asserting response times, status codes (200, 201, 401, 403), and payload schemas.

### What is Newman?
**Newman** is the command-line (CLI) test runner for Postman. It allows running Postman collections headlessly inside automated scripts and CI/CD pipelines.

### Our Postman Suite Features:
* **Collection Format**: Postman v2.1.0 standard (`docs/postman/bomis_sambalpur_api.postman_collection.json`).
* **Environment Variables**: Automatic injection of `baseUrl`, `accessToken`, `school_id`, and `correlationId`.
* **Automated Test Scripts (`pm.test`)**: Every request checks:
  1. Valid HTTP Status Code.
  2. Standard response envelope: `{ success: true, data: ..., error: null, timestamp, correlationId }`.
  3. Response latency SLA (`< 1000ms`).
  4. Automatic token extraction for subsequent role-based requests.

### How to Run the Postman Tests:

#### Option A: Headless via Node.js / Newman Runner
Ensure the backend API is running (`node dist/main.js` on port 4000), then execute:
```bash
# Run the complete test suite
node docs/postman/run-newman.js

# Run a specific domain module (e.g., Authentication & RBAC)
node docs/postman/run-newman.js --folder="01_Authentication_and_RBAC"
```

#### Option B: In the Postman Desktop App
1. Open Postman Desktop.
2. Click **Import** (top left).
3. Select `docs/postman/bomis_sambalpur_api.postman_collection.json` and `docs/postman/bomis_postman_environment.json`.
4. Click **Run Collection** to watch all 11 modules execute automatically.

---

## 3. What is a CI/CD Pipeline & GitHub Actions Setup

### What is a CI/CD Pipeline?
* **CI (Continuous Integration)**: An automated robot that runs every time code is pushed to GitHub. It automatically installs dependencies, checks for code style errors (linting), validates TypeScript types, runs automated test suites, and verifies that the app builds without errors.
* **CD (Continuous Delivery / Deployment)**: Automatically packages the validated code into production containers (Docker) and prepares it for deployment to cloud servers (e.g. AWS, GCP, Vercel).

### Our GitHub Actions Workflow (`.github/workflows/ci.yml`):
Whenever code is pushed or a Pull Request is opened against `main` or `develop`, the pipeline executes the following quality gates in order:

1. **Checkout Source Code**: Clones the monorepo into an isolated Ubuntu 22.04 runner.
2. **Setup Node.js 20 & pnpm 9**: Configures the high-performance package manager with deterministic dependency caching.
3. **Monorepo Dependency Cache**: Restores `~/.pnpm-store` to make subsequent runs 5x faster.
4. **Code Quality Linting (`pnpm lint`)**: Scans for syntax bugs and unused imports.
5. **TypeScript Strict Type Compliance (`pnpm typecheck`)**: Compiles all projects with zero type warnings.
6. **Automated Unit & Integration Tests (`pnpm test`)**: Runs Vitest / Jest test suites across all packages.
7. **Monorepo Artifact Build (`pnpm build`)**: Builds production Next.js standalone and NestJS compiled bundles.

---

## 4. Containerization & DevOps (Docker Compose)

The monorepo includes **Docker** and **Docker Compose** configuration so the entire school platform can be spun up on any computer with a single command without installing Node.js, PostgreSQL, or Redis manually.

### Multi-Container Stack (`docker-compose.yml`):
* `bomis_postgres`: PostgreSQL 16 Alpine multi-tenant database.
* `bomis_redis`: Redis 7 Alpine in-memory cache and session store.
* `bomis_api`: NestJS 10 REST API server running on port `4000`.
* `bomis_web`: Next.js 14 standalone frontend running on port `3000`.

### Running with Docker:
```bash
# Start all services in the background
docker-compose up -d

# View live logs
docker-compose logs -f

# Stop all services
docker-compose down
```

---

## 5. Frontend & Backend Integration Contracts

### Dual-Mode Architecture:
To ensure 100% reliability during evaluation, local demos, and offline testing, the backend features a deterministic **Dual-Mode Data Layer**:
* When `USE_MOCK_DB=true`: Backed by an in-memory mock store pre-seeded with 28 students (Grade 5A), 4 OD-15 school buses, official timetable, and fee structures. Zero external database required!
* When `USE_MOCK_DB=false`: Connects directly to production PostgreSQL via Prisma ORM with Row-Level Security (RLS).

### Standard API Response Envelope:
Every API response follows a strict, predictable JSON envelope validated by Zod pipes:
```json
{
  "success": true,
  "data": { ... },
  "error": null,
  "timestamp": "2026-10-28T10:20:39.046Z",
  "correlationId": "corr-e16228e1-1665-475d-9ec5-4d82e3fefe0b"
}
```

---

## 6. Data Privacy & DPDP Act 2023 Security Architecture

As an Indian educational institution, BOMIS Sambalpur complies with **Section 9 of the Digital Personal Data Protection (DPDP) Act 2023** (Processing of Personal Data of Children):

1. **Field-Level AES-256-GCM Encryption**:
   - Sensitive minor identifiers (Aadhaar numbers, guardian mobile numbers, medical allergy files) are encrypted using AES-256-GCM with unique initialization vectors (IVs) before persistence.
2. **Parental Consent Ledger**:
   - Tracks explicit parental consent for school media (`photo_consent: true/false`).
   - If a parent revokes consent, the platform's **AI Face-Shield** automatically applies a protective blur filter over the child's face in class photo albums.
3. **Role-Based Access Control (RBAC)**:
   - 8 strictly segregated roles: `PARENT`, `STUDENT`, `TEACHER`, `PRINCIPAL`, `ADMIN`, `SUPER_ADMIN`, `ACCOUNTANT`, `TRANSPORT_STAFF`.
   - Parents cannot access other families' records or admin audit logs (enforces `403 Forbidden`).
4. **Immutable Audit Logging**:
   - Every staff access to student records generates a tamper-evident audit record logged at `/api/v1/admin/audit-logs`.

---

## 7. Teacher / Examiner Quick Verification Checklist

When presenting this project to your teacher or software examiner, you can demonstrate the following live in 3 minutes:

| Test / Feature | Command or Action | Expected Result |
|---|---|---|
| **1. Web Frontend Health** | Open [http://localhost:3000](http://localhost:3000) | Displays Calm Day-Stream Parent App with 0-height AlertSlot, TodayBar, and BusLine |
| **2. Backend API Health** | Open [http://localhost:4000/health](http://localhost:4000/health) | Returns HTTP 200 `{"status": "ok"}` with correlation ID |
| **3. Interactive Swagger Docs** | Open [http://localhost:4000/api/docs](http://localhost:4000/api/docs) | Displays OpenAPI 3.0 documentation for all 11 modules |
| **4. Postman Newman Test** | Run `node docs/postman/run-newman.js --folder="01_Authentication_and_RBAC"` | Executes 11 API requests, evaluates 44 assertions, passes 100% |
| **5. Tri-Lingual Localization** | Tap `[ ଓଡ଼ିଆ ]` or `[ हिन्दी ]` in the app header | Instantly switches all cards to native Odia / Hindi with cultural time buckets (`ସକାଳ`, `ଅପରାହ୍ନ`) |
| **6. Emergency Edge Cases** | Click `[ 🌧️ 6:45 AM Closure ]` in the top scenario bar | Full-bleed monsoon closure lockdown card appears with speech audio playback |
| **7. Grandparent Elder Mode** | Click `[ 👴 Simple / ବଡ଼ ଅକ୍ଷର ]` in the header | High-contrast yellow/black gate pass with 6-digit verbal PIN (`8 3 1 2 9 4`) and child switcher |
