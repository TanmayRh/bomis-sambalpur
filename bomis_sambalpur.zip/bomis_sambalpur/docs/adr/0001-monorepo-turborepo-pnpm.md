# ADR 0001: Monorepo Architecture with Turborepo and pnpm Workspaces

## Status
Accepted

## Date
2026-10-17

## Context & Problem Statement
Birla Open Minds International School (BOMIS), Sambalpur requires a unified digital operating system encompassing multiple applications:
- A backend modular monolith REST/WebSocket API (`/apps/api`).
- A responsive Next.js 14 web portal for school administrators, principals, teachers, and accountants (`/apps/web`).
- A cross-platform React Native Expo mobile application for parents, students, teachers, and transport drivers (`/apps/mobile`).
- Shared domain contracts, validation schemas, and types (`/packages/shared`).
- Shared brand design tokens and UI components (`/packages/ui`).
- Local infrastructure containerization (`/infra`).

Managing these systems across decoupled, independent repositories introduces significant friction:
1. Schema and contract drift between backend endpoints and frontend/mobile clients.
2. Fragmented dependency management, redundant package installations, and version mismatch.
3. Complex multi-repo CI/CD orchestration and delayed integration feedback.
4. Duplicate domain logic (e.g., fee math, CBSE grading conversions, role permission matrices).

## Decision Drivers
- **Contract Congruence**: Need 100% type safety and synchronized Zod validation between API and client applications.
- **Developer Velocity**: Fast local builds, unified linting, typechecking, and testing across all workspaces with one command.
- **Disk & Network Efficiency**: Efficient package hoisting, fast installation times, and strict dependency isolation to prevent phantom dependencies.
- **Task Pipeline Caching**: Intelligent computation caching to avoid rebuilding unchanged packages or re-running tests.

## Considered Options
1. **Multi-Repo Architecture**: Separate git repositories for API, Web, Mobile, and Shared packages.
2. **Turborepo + pnpm Workspaces**: Monorepo using pnpm's content-addressable storage and Turborepo's pipeline graph caching.
3. **Nx Monorepo**: Heavyweight workspace orchestrator with deep framework plugins.
4. **Lerna + npm/yarn v1**: Legacy monorepo tooling.

## Decision Outcome
Chosen Option: **Turborepo with pnpm Workspaces**.

### Rationale:
- **pnpm Workspaces**: pnpm uses a content-addressable storage mechanism with hard links, preventing dependency duplication on developer machines while strictly enforcing declared dependencies (preventing phantom dependencies).
- **Turborepo**: High-performance Rust-based build system that creates a declarative dependency graph (`turbo.json`), enables local and remote computation caching, and runs independent tasks (lint, build, test, typecheck) in parallel with maximum CPU core utilization.
- **Shared Package Integration**: `@bomis/shared` and `@bomis/ui` are consumed by `/apps/api`, `/apps/web`, and `/apps/mobile` as native workspace packages (`workspace:*`), allowing instantaneous hot-reloading when types or schemas change without requiring npm publish steps.

## Consequences

### Positive:
- **Single Source of Truth**: Data models, Zod validation schemas, and RBAC role enums live in `/packages/shared` and are imported directly across all three applications.
- **Atomic Commits**: Full-stack features (e.g., a new fee concession type affecting DB schema, API endpoint, web accountant view, and parent mobile screen) can be committed, reviewed, and tested in a single atomic Pull Request.
- **Fast CI Execution**: Turborepo caches successful builds and test runs; only affected packages and downstream dependents are tested in CI pipelines.
- **One-Command Bootstrapping**: Developers can bootstrap the entire ecosystem with `docker compose up -d && pnpm install && pnpm db:migrate && pnpm db:seed && pnpm dev`.

### Negative / Trade-offs:
- **Repository Size**: Monorepo git history will grow faster than separate repositories.
- **Tooling Rigor**: Requires strict workspace boundary linting to prevent accidental circular imports or leaking backend-only libraries into React Native/Expo bundles.
- **Expo Monorepo Setup**: React Native Metro bundler requires specific `watchFolders` and monorepo hoisting configurations.

## Compliance & Verification
- Workspace package configuration validated via `pnpm-workspace.yaml`.
- Pipeline orchestration verified via `turbo.json`.
- Type integrity verified via root command `pnpm typecheck`.
- Monorepo bootstrapping verified via root command `pnpm dev`.
