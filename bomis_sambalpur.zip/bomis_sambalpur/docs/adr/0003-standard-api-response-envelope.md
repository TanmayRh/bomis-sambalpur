# ADR 0003: Standardized API Response and Error Envelope Architecture

## Status
Accepted

## Date
2026-10-17

## Context & Problem Statement
In distributed multi-role systems encompassing web dashboards, mobile applications, and offline synchronization queues, inconsistent API response structures are a primary source of frontend bugs, unhandled exceptions, and poor observability. Common failure modes include:
1. Endpoints returning bare payloads on success (e.g., arrays or raw objects) without consistent metadata.
2. Divergent error shapes between framework errors (NestJS `HttpException`), database errors (Prisma exceptions), and validation errors (Zod validation pipes).
3. Missing correlation IDs preventing end-to-end tracing from client logs to server logs and database queries.
4. Difficulty in distinguishing expected business errors (e.g., `STUDENT_ALREADY_MARKED_PRESENT`) from internal technical failures (`DATABASE_CONNECTION_ERROR`).

To fulfill Acceptance Criterion AC-2, all REST endpoints must strictly adhere to a standardized envelope structure.

## Decision Drivers
- **Contract Predictability**: Client applications and automated test runners should expect an identical top-level JSON structure across 100% of REST endpoints.
- **Distributed Observability**: Every request and response must carry a unified correlation ID linking client telemetry, HTTP access logs, Pino JSON server logs, and audit entries.
- **Structured Error Reporting**: Form validation errors must provide machine-readable error arrays pinpointing specific field failures for direct binding to React Hook Form and Zod resolvers.
- **Graceful Degradation**: Clear separation between boolean `success`, domain `data`, and structured `error` objects.

## Considered Options
1. **Ad-hoc Controller Responses**: Allow each controller method to format its own return value; errors handled by default NestJS filter.
2. **GraphQL API**: Use GraphQL schema where errors and data are standardized by the GraphQL specification.
3. **Global NestJS Transform Interceptor & Global Exception Filter**: Implement global interceptors that wrap all controller outputs and catch all exceptions into a canonical TypeScript interface.

## Decision Outcome
Chosen Option: **Global NestJS Transform Interceptor and Exception Filter with AsyncLocalStorage Correlation Tracking**.

### Specification:

#### 1. Canonical TypeScript Interface (`@bomis/shared`)
```typescript
export interface ApiErrorDetail {
  field?: string;
  issue: string;
}

export interface ApiError {
  code: string;
  message: string;
  details?: ApiErrorDetail[] | Record<string, any>;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data: T | null;
  error?: ApiError | null;
  timestamp: string;
  correlationId: string;
}
```

#### 2. Success Envelope Transformation
- Controller methods return raw business entities or DTOs (e.g., `Promise<StudentProfile>`).
- Global `TransformInterceptor` intercepts the output:
  - Extracts the active request correlation ID from Node.js `AsyncLocalStorage` (or `x-correlation-id` header).
  - Generates ISO-8601 UTC timestamp.
  - Wraps payload into `{ success: true, data: result, timestamp, correlationId }`.

#### 3. Standardized Error Handling Filter
- Global `AllExceptionsFilter` catches all thrown exceptions:
  - Standardizes HTTP status codes.
  - Maps known Prisma errors (e.g., `P2002` to `DUPLICATE_ENTITY` with `409 Conflict`, `P2025` to `ENTITY_NOT_FOUND` with `404 Not Found`).
  - Maps Zod validation failures into structured `details` array containing target field names and error messages.
  - Sets `success: false`, `data: null`, and populates `error: { code, message, details }`.
  - Preserves the request's `correlationId` in the error response.

## Consequences

### Positive:
- **Zero Ambiguity for Clients**: The Next.js web portal, Expo mobile app, and Postman Newman runner parse responses using a single universal wrapper.
- **Effortless Tracing**: In production, when a parent reports an issue with fee payment or attendance, the parent app displays the `correlationId`. Support staff can query Pino logs in seconds using that exact ID.
- **Automated QA Assertions**: Postman test scripts execute a single global validation snippet against `correlationId`, `success`, and `timestamp` on every request.

### Negative / Trade-offs:
- **Payload Overhead**: Slight serialization overhead adding the envelope wrapper around small responses.
- **Non-Standard Binary Streaming**: Endpoints returning raw file streams (e.g., PDF downloads at `/api/v1/fees/receipts/:id`) must bypass the `TransformInterceptor` using a custom `@BypassEnvelope()` decorator.

## Compliance & Verification
- Interceptor implemented in `/apps/api/src/common/interceptors/transform.interceptor.ts`.
- Filter implemented in `/apps/api/src/common/filters/all-exceptions.filter.ts`.
- Postman Collection global assertion:
  ```javascript
  pm.test("Standard Response Envelope Format is strictly valid", function () {
      var json = pm.response.json();
      pm.expect(json).to.have.property('success');
      pm.expect(json).to.have.property('timestamp');
      pm.expect(json).to.have.property('correlationId');
  });
  ```
- Verified in Newman test runs across 100% of API routes.
