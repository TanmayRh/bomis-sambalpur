# ADR 0002: DPDP Act (2023) Compliance and Multi-Tenant Isolation via PostgreSQL Row-Level Security (RLS)

## Status
Accepted

## Date
2026-10-17

## Context & Problem Statement
The BOMIS Sambalpur platform handles sensitive personal data belonging to minors (students in Grades 1 through 8), guardians, and faculty. In August 2023, the Government of India enacted the **Digital Personal Data Protection (DPDP) Act, 2023**, establishing stringent legal obligations for "Data Fiduciaries" processing personal data of children, including:
1. Verifiable parental consent prior to processing minor data.
2. Prohibition against tracking, behavioral monitoring, or targeted advertising directed at children.
3. Strict data minimization and purpose limitation.
4. Right to data erasure upon withdrawal of consent or student departure, with regulatory retention mandates.
5. Strict tenant isolation to prevent unauthorized cross-school or cross-student data leakage.

In addition, as the platform expands to multiple campuses or trusts, complete architectural multi-tenancy is required from Day 1 to ensure that queries cannot inadvertently cross tenant boundaries.

## Decision Drivers
- **Regulatory Mandate**: Full adherence to DPDP Act (2023) statutory penalties (up to ₹250 crore for data breaches involving children).
- **Defense-in-Depth**: Multi-tenant isolation enforced at the database engine level, not merely in application-level `WHERE` clauses.
- **Auditability**: Complete, tamper-proof, immutable audit trail for every read, write, and deletion involving sensitive student information.
- **Cryptographic Security**: Sensitive health and identity data must remain encrypted at rest even in the event of database backup exposure.

## Considered Options
1. **Application-Level Multi-Tenancy Only**: Relying on Prisma queries manually appending `where: { schoolId }`.
2. **Database-Per-Tenant**: Creating a separate PostgreSQL database for each institution/campus.
3. **Schema-Per-Tenant**: Creating separate PostgreSQL schemas (`CREATE SCHEMA tenant_x`) on a shared instance.
4. **Shared Database with PostgreSQL Row-Level Security (RLS) + DPDP Lifecycle Layer**: Shared tables with indexed `school_id`, PostgreSQL RLS policies, AES-256-GCM field encryption, and 90-day soft-delete retention with BullMQ cryptographic shredding.

## Decision Outcome
Chosen Option: **Shared Database with PostgreSQL Row-Level Security (RLS) and DPDP Lifecycle Architecture**.

### Architecture Specifications:

#### 1. PostgreSQL Row-Level Security (RLS)
- Every business table incorporates an indexed `school_id` UUID column.
- Row-Level Security is enabled across all tenant tables:
  ```sql
  ALTER TABLE students ENABLE ROW LEVEL SECURITY;
  CREATE POLICY tenant_isolation_policy ON students
    USING (school_id = current_setting('app.current_school_id', true)::uuid);
  ```
- NestJS Prisma middleware / database service executes `SET LOCAL app.current_school_id = '<school_id>'` within the transaction context of every incoming authenticated request.

#### 2. DPDP Soft Deletes & 90-Day Retention Shredder
- All student, guardian, and academic records include `deleted_at: DateTime?`.
- Deletion requests trigger soft deletion (`deleted_at = NOW()`), immediately hiding records from application queries.
- Under Indian educational record retention norms, records remain in soft-delete state for **90 days**.
- A nightly BullMQ worker (`dpdp-purge-queue`) identifies records where `deleted_at < NOW() - INTERVAL '90 DAYS'`.
- Cryptographic shredding is executed: sensitive personal fields (Aadhaar, medical notes, phone numbers, contact addresses) are overwritten with randomized cryptographically secure bytes before the row is permanently dropped from the database.

#### 3. Field-Level Data Encryption
- Sensitive medical notes, psychological counselor reports, and national identity numbers (Aadhaar) are encrypted at rest using **AES-256-GCM** with unique initialization vectors (IV) before persistence in PostgreSQL.
- Encryption keys are managed via environment secrets (`ENCRYPTION_SECRET_KEY`) with rotation capability.

#### 4. Immutable Audit Logs
- The `audit_logs` table records `id`, `schoolId`, `userId`, `role`, `action` (`CREATE`, `UPDATE`, `DELETE`, `LOGIN`, `VIEW_HEALTH`), `entity`, `entityId`, `diffJson`, `ipAddress`, `userAgent`, and `timestamp`.
- Postgres table permissions prevent `UPDATE` or `DELETE` operations on `audit_logs` by the application user.

## Consequences

### Positive:
- **Bulletproof Tenant Isolation**: Even if a developer forgets to filter by `school_id` in a custom SQL or Prisma query, Postgres RLS prevents cross-tenant records from being returned.
- **DPDP Act Compliance**: Fully compliant with parental consent tracking, purpose limitation, and the right to erasure.
- **Tamper Evidence**: All administrative interventions, marks alterations, and health record inspections are permanently audited.

### Negative / Trade-offs:
- **Connection Pooling Overhead**: RLS requires setting session-local variables (`SET LOCAL`), requiring transactional query execution or connection-level state resets when using PgBouncer.
- **Query Planning Complexity**: Postgres query planner must evaluate RLS policy expressions, which can slightly affect join performance on massive tables without proper indexing on `school_id`.

## Compliance & Verification
- RLS policy creation script verified in Prisma migrations (`prisma/migrations/`).
- Automated negative tests in `test/tenant-isolation-rls.spec.ts` assert that queries executed without the matching `school_id` session setting return zero records.
- BullMQ purge worker tested in `test/dpdp-shredding-audit.spec.ts`.
