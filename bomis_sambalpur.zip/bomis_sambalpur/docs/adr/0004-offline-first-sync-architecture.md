# ADR 0004: Offline-First Synchronization Architecture & Queue Protocol

## Status
Accepted

## Date
2026-10-17

## Context & Problem Statement
Birla Open Minds International School is situated in Sambalpur, Odisha. Operational realities in the region include:
1. **Intermittent Cellular Coverage**: School buses navigating peripheral and semi-urban routes (such as Burla, Hirakud, Khetrajpur) frequently pass through 2G or zero-signal dead zones.
2. **Classroom Wi-Fi Saturation**: When 20+ teachers simultaneously submit morning attendance grids at 08:30 AM, local Wi-Fi access points experience severe congestion and high packet loss.
3. **Operational Immediacy**: Bus boarding QR scanning must execute in under 1 second per student at transit stops to maintain bus schedules. Teachers must complete class attendance in under 10 seconds. Neither workflow can afford to wait for network roundtrips.

A synchronous, online-only mobile architecture would lead to failed attendance submissions, unrecorded bus boarding events, frustrated faculty, and anxious parents.

## Decision Drivers
- **Zero Data Loss Guarantee**: Any action performed by a teacher or transport staff must be durably persisted locally before network transmission.
- **Sub-Second Interaction Speed**: Optimistic local UI updates ensuring instant feedback regardless of network state.
- **Idempotent Batch Processing**: The server must ingest batches of delayed events without creating duplicate records or corrupted ledger states.
- **Deterministic Conflict Resolution**: Clear business precedence rules when multi-device or delayed submissions conflict.

## Considered Options
1. **Online-Only with Simple Retry**: Block the user interface on network failure; show retry dialogs.
2. **Third-Party Sync Engine (e.g., CouchDB/PouchDB or Firebase Realtime DB)**: Offload sync to a managed cloud database.
3. **Custom Local SQLite Outbox Queue with Batch Sync API**: Local SQLite database in React Native (`expo-sqlite`), FIFO event outbox, client-side idempotency keys, and dedicated backend batch sync endpoint (`POST /api/v1/sync/batch`).

## Decision Outcome
Chosen Option: **Custom Local SQLite Outbox Queue with Batch Sync API (`/api/v1/sync/batch`) and Multi-Layer Conflict Resolution**.

### Architecture Specifications:

#### 1. Local SQLite Outbox Schema (`apps/mobile`)
```sql
CREATE TABLE IF NOT EXISTS local_sync_outbox (
  id TEXT PRIMARY KEY,                 -- Client-generated UUIDv4
  action_type TEXT NOT NULL,           -- 'ATTENDANCE_BATCH' | 'TRANSPORT_SCAN' | 'HOMEWORK_SUBMIT'
  endpoint TEXT NOT NULL,              -- Target API route
  method TEXT NOT NULL,                -- 'POST' | 'PATCH'
  payload TEXT NOT NULL,               -- JSON serialized event
  idempotency_key TEXT NOT NULL UNIQUE,-- Client idempotency key (idemp-<uuid>)
  created_at INTEGER NOT NULL,         -- Client timestamp (epoch ms)
  retry_count INTEGER DEFAULT 0,
  status TEXT DEFAULT 'PENDING',       -- 'PENDING' | 'SYNCING' | 'FAILED' | 'RESOLVED'
  error_message TEXT
);
```

#### 2. Sync Engine Lifecycle
1. **Capture**: When a teacher marks attendance or a driver scans a bus QR code, the record is immediately written to local SQLite and appended to `local_sync_outbox` with status `PENDING`. The UI immediately reflects success.
2. **Connectivity Detection**: `NetInfo` listener monitors network transitions. When online status is detected:
   - A mutex lock is acquired to prevent concurrent sync loops.
   - The top 25 `PENDING` outbox records are retrieved in FIFO chronological order.
3. **Batch Transmission**:
   - The client issues `POST /api/v1/sync/batch` containing the array of serialized operations.
   - Header `x-correlation-id` and authorization bearer tokens are attached.
4. **Backend Processing & Idempotency**:
   - NestJS `SyncModule` iterates through items within an atomic database transaction.
   - Each operation checks Redis/Postgres for prior execution using `idempotency_key`.
   - If already processed, the cached result is returned without re-executing business mutations.
5. **Drain & Cleanup**:
   - Successfully committed operations return `{ id, success: true }`.
   - The client removes resolved records from `local_sync_outbox`.
   - Temporary failures apply exponential backoff ($2^n$ seconds, up to 5 attempts).

#### 3. Conflict Resolution Precedence Rules
- **Attendance Records**:
  - Teacher is authoritative for classroom attendance.
  - If multiple offline records arrive for the same student on the same date, the latest client `created_at` timestamp takes precedence.
  - If an administrative lockdown has occurred (e.g., post-11:00 AM daily cutoff), the submission is flagged for Administrative Review in `audit_logs` rather than silently overwriting.
- **Transport Scans**:
  - Scans are append-only time-series events (`transport_scans`).
  - No overwrite conflicts can occur; duplicate scans within a 30-second window for the same student and bus are deduplicated at the client layer.

## Consequences

### Positive:
- **Resilience**: Drivers and teachers can operate for entire shifts completely offline with zero data loss.
- **Performance**: Classroom attendance can be marked in under 5 seconds since local SQLite writes take < 10ms.
- **Battery & Bandwidth Optimization**: Batching events minimizes radio wakeups and connection handshake overhead on mobile devices.

### Negative / Trade-offs:
- **Client Storage Management**: Local SQLite tables must be periodically pruned of acknowledged records to prevent unbounded database growth on mobile devices.
- **Timestamp Drift**: Relies on client device clocks; server enforces sanity bounds (rejecting events claiming to be recorded in the future or > 7 days in the past).

## Compliance & Verification
- Outbox schema and sync loop implemented in `apps/mobile/src/services/sync-outbox.service.ts`.
- Backend batch sync endpoint implemented in `apps/api/src/modules/sync/sync.controller.ts`.
- Automated test coverage in `test/offline-sync-queue.spec.ts` asserting idempotency key deduplication, batch transaction rollback on fatal errors, and conflict resolution precedence.
