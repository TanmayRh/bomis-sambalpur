const fs = require('fs');
const path = require('path');

const collection = {
  info: {
    _postman_id: "e9f1a234-7890-4abc-9def-0123456789ab",
    name: "BOMIS Sambalpur - Unified School Platform API Suite (v2.1)",
    description: "Production-grade, exhaustive Postman test suite for Birla Open Minds International School (BOMIS), Sambalpur. Covers 100% of API modules: Auth & RBAC (8 roles), People, Attendance & Offline Sync, Fees (Razorpay & Idempotency), Academics (CBSE 9-point scale), Transport (Fleet Telemetry), Safety (Zero-log & Passes), AI Layer (Study Buddy & NEP 2020 Voice HPC), Principal Pulse Dashboard, and Admin DPDP Audit Trails with automated pre-request scripts, environment management, and comprehensive assertions.",
    schema: "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  event: [
    {
      listen: "prerequest",
      script: {
        type: "text/javascript",
        exec: [
          "// 1. Generate unique request correlation ID",
          "var correlationId = 'corr-' + pm.variables.replaceIn('{{$guid}}');",
          "pm.variables.set('correlationId', correlationId);",
          "pm.request.headers.upsert({ key: 'x-correlation-id', value: correlationId });",
          "",
          "// 2. Generate Idempotency-Key for mutating payment, attendance, and sync endpoints",
          "var path = pm.request.url.getPath();",
          "if (['POST', 'PUT', 'PATCH'].includes(pm.request.method)) {",
          "  if (path.includes('orders') || path.includes('payments') || path.includes('sync') || path.includes('attendance')) {",
          "    var idempotencyKey = 'idemp-' + pm.variables.replaceIn('{{$guid}}');",
          "    pm.variables.set('idempotencyKey', idempotencyKey);",
          "    pm.request.headers.upsert({ key: 'Idempotency-Key', value: idempotencyKey });",
          "  }",
          "}",
          "",
          "// 3. Inject school tenant header",
          "var schoolId = pm.variables.get('school_id') || 'sch_bomis_sambalpur_001';",
          "pm.request.headers.upsert({ key: 'x-school-id', value: schoolId });",
          "",
          "// 4. Client-side fallback dynamic JWT generation for negative test suites",
          "function signJwtPostman(payload, secret) {",
          "  var header = { alg: 'HS256', typ: 'JWT' };",
          "  function b64url(source) {",
          "    var b64 = CryptoJS.enc.Base64.stringify(source);",
          "    return b64.replace(/=+$/, '').replace(/\\+/g, '-').replace(/\\//g, '_');",
          "  }",
          "  var eh = b64url(CryptoJS.enc.Utf8.parse(JSON.stringify(header)));",
          "  var ep = b64url(CryptoJS.enc.Utf8.parse(JSON.stringify(payload)));",
          "  var sig = CryptoJS.HmacSHA256(eh + '.' + ep, secret);",
          "  return eh + '.' + ep + '.' + b64url(sig);",
          "}",
          "var sec = pm.variables.get('jwtSecret') || 'bomis_jwt_secret_sambalpur_2026';",
          "if (!pm.environment.get('studentToken') && !pm.variables.get('studentToken')) {",
          "  var st = signJwtPostman({",
          "    sub: 'u1000000-0501-4000-8000-000000000001',",
          "    id: 'u1000000-0501-4000-8000-000000000001',",
          "    userId: 'u1000000-0501-4000-8000-000000000001',",
          "    email: 'aarav.patel@student.bomis-sambalpur.edu.in',",
          "    phone: '+919876543211',",
          "    role: 'STUDENT',",
          "    schoolId: 'e4b3c2a1-0001-4000-8000-000000000001'",
          "  }, sec);",
          "  pm.environment.set('studentToken', st);",
          "}",
          "if (!pm.environment.get('driverToken') && !pm.variables.get('driverToken')) {",
          "  var dt = signJwtPostman({",
          "    sub: 'u1000000-0020-4000-8000-000000000001',",
          "    id: 'u1000000-0020-4000-8000-000000000001',",
          "    userId: 'u1000000-0020-4000-8000-000000000001',",
          "    email: 'driver.bhoi@bomis-sambalpur.edu.in',",
          "    phone: '+919437200001',",
          "    role: 'TRANSPORT_STAFF',",
          "    schoolId: 'e4b3c2a1-0001-4000-8000-000000000001'",
          "  }, sec);",
          "  pm.environment.set('driverToken', dt);",
          "}"
        ]
      }
    },
    {
      listen: "test",
      script: {
        type: "text/javascript",
        exec: [
          "// Global Test: Validate HTTP Status Code is valid",
          "pm.test('HTTP Status Code is valid and recognized', function () {",
          "  pm.expect(pm.response.code).to.be.oneOf([200, 201, 202, 204, 400, 401, 403, 404, 409, 422, 429]);",
          "});",
          "",
          "// Global Test: Validate BOMIS Standard API Response Envelope",
          "pm.test('Standard Response Envelope matches { success, data, error, timestamp, correlationId }', function () {",
          "  var contentType = pm.response.headers.get('content-type') || '';",
          "  if (contentType.includes('application/pdf') || contentType.includes('text/csv')) {",
          "    return;",
          "  }",
          "  var json = pm.response.json();",
          "  pm.expect(json).to.be.an('object');",
          "  pm.expect(json).to.have.property('success');",
          "  pm.expect(json.success).to.be.a('boolean');",
          "  pm.expect(json).to.have.property('timestamp');",
          "  pm.expect(json).to.have.property('correlationId');",
          "});",
          "",
          "// Global Test: Response Time within enterprise SLA (< 1000ms)",
          "pm.test('Response latency within SLA (< 1000ms)', function () {",
          "  pm.expect(pm.response.responseTime).to.be.below(1000);",
          "});"
        ]
      }
    }
  ],
  item: []
};

// ============================================================================
// 1. System Health & Probes
// ============================================================================
const healthFolder = {
  name: "00_System_Health_and_Probes",
  description: "Kubernetes/Docker liveness and readiness probes verifying system uptime, DB connectivity, Redis cache, and storage status.",
  item: [
    {
      name: "Liveness Probe (GET /health)",
      request: {
        method: "GET",
        header: [],
        url: { raw: "{{baseUrl}}/health", host: ["{{baseUrl}}"], path: ["health"] },
        description: "Heartbeat probe returning uptime and node status."
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Liveness probe returns healthy 200 OK', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.status).to.eql('ok');",
            "  pm.expect(json.data.uptime).to.be.a('number');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Readiness Probe (GET /ready)",
      request: {
        method: "GET",
        header: [],
        url: { raw: "{{baseUrl}}/ready", host: ["{{baseUrl}}"], path: ["ready"] },
        description: "Readiness probe verifying DB, Redis cache, and MinIO storage availability."
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Readiness probe confirms backing dependencies', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.status).to.eql('ready');",
            "  pm.expect(json.data.checks.database).to.be.oneOf(['up', 'degraded']);",
            "  pm.expect(json.data.checks.redis).to.eql('up');",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 2. Authentication & RBAC
// ============================================================================
const authFolder = {
  name: "01_Authentication_and_RBAC",
  description: "Role-Based Access Control and multi-factor authentication: OTP issuance, password login, token refresh, and session revocation.",
  item: [
    {
      name: "Request Mobile OTP (Parent / Student)",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            phone: "+919876543210",
            schoolId: "{{school_id}}",
            purpose: "LOGIN"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/otp/send", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "otp", "send"] },
        description: "Sends a 6-digit SMS OTP via gateway."
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('OTP sent successfully', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.success).to.be.true;",
            "});"
          ]
        }
      }]
    },
    {
      name: "Verify Mobile OTP (Parent Token Issue)",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            phone: "+919876543210",
            otp: "123456"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/otp/verify", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "otp", "verify"] },
        description: "Verifies parent OTP and returns JWT tokens."
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Parent OTP verified and token captured', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.success).to.be.true;",
            "  pm.expect(json.data).to.have.property('accessToken');",
            "  pm.environment.set('parentToken', json.data.accessToken);",
            "  pm.environment.set('refreshToken', json.data.refreshToken);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Request Mobile OTP for Student",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            phone: "+919876543211",
            schoolId: "{{school_id}}",
            purpose: "LOGIN"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/otp/send", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "otp", "send"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Student OTP sent successfully', function () {",
            "  pm.response.to.have.status(200);",
            "  pm.expect(pm.response.json().success).to.be.true;",
            "});"
          ]
        }
      }]
    },
    {
      name: "Verify Mobile OTP (Student Token Issue)",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            phone: "+919876543211",
            otp: "123456"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/otp/verify", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "otp", "verify"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Student token captured', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.success).to.be.true;",
            "  pm.environment.set('studentToken', json.data.accessToken);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Staff Email Login (Admin Token Issue)",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            email: "admin@bomis-sambalpur.edu.in",
            password: "Password123!"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/staff/login", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "staff", "login"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Admin logged in and token saved', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.success).to.be.true;",
            "  pm.expect(json.data.user.role).to.eql('ADMIN');",
            "  pm.environment.set('adminToken', json.data.accessToken);",
            "  pm.environment.set('jwt_token', json.data.accessToken);",
            "  pm.environment.set('token', json.data.accessToken);",
            "  pm.environment.set('refreshToken', json.data.refreshToken);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Staff Email Login (Principal Token Issue)",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            email: "principal@bomis-sambalpur.edu.in",
            password: "Password123!"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/staff/login", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "staff", "login"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Principal token captured', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.user.role).to.eql('PRINCIPAL');",
            "  pm.environment.set('principalToken', json.data.accessToken);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Staff Email Login (Teacher Token Issue)",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            email: "teacher@bomis-sambalpur.edu.in",
            password: "Password123!"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/staff/login", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "staff", "login"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Teacher token captured', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.user.role).to.eql('TEACHER');",
            "  pm.environment.set('teacherToken', json.data.accessToken);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Staff Email Login (Accountant Token Issue)",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            email: "accountant@bomis-sambalpur.edu.in",
            password: "Password123!"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/staff/login", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "staff", "login"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Accountant token captured', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.user.role).to.eql('ACCOUNTANT');",
            "  pm.environment.set('accountantToken', json.data.accessToken);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Staff Email Login (Driver Token Issue)",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            email: "driver.bhoi@bomis-sambalpur.edu.in",
            password: "Password123!"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/staff/login", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "staff", "login"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Driver token captured', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.user.role).to.eql('TRANSPORT_STAFF');",
            "  pm.environment.set('driverToken', json.data.accessToken);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Rotate Refresh Token (/api/v1/auth/refresh)",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            refreshToken: "{{refreshToken}}"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/refresh", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "refresh"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Token rotation returned new accessToken', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.have.property('accessToken');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Revoke Session (Logout)",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{adminToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            refreshToken: "{{refreshToken}}"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/auth/logout", host: ["{{baseUrl}}"], path: ["api", "v1", "auth", "logout"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Session successfully terminated', function () {",
            "  pm.response.to.have.status(200);",
            "  pm.expect(pm.response.json().success).to.be.true;",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 3. People Management
// ============================================================================
const peopleFolder = {
  name: "02_People_Management",
  description: "Student profiles, guardians, staff roster, sibling linkages, and bulk CSV/JSON ingestion.",
  item: [
    {
      name: "List Students with Grade/Section Filter",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{adminToken}}" }],
        url: {
          raw: "{{baseUrl}}/api/v1/people/students?grade=5&section=A&limit=30",
          host: ["{{baseUrl}}"],
          path: ["api", "v1", "people", "students"],
          query: [
            { key: "grade", value: "5" },
            { key: "section", value: "A" },
            { key: "limit", value: "30" }
          ]
        }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Students list retrieved with pagination', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.students).to.be.an('array');",
            "  pm.expect(json.data.students.length).to.be.above(0);",
            "  pm.environment.set('studentId', json.data.students[0].id);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Create Student Master Profile",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{adminToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            first_name: "Rohan",
            last_name: "Meher",
            admission_number: "ADM-2026-9001",
            grade: 5,
            section: "A",
            dob: "2015-08-15",
            gender: "MALE",
            blood_group: "B+"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/people/students", host: ["{{baseUrl}}"], path: ["api", "v1", "people", "students"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Student profile created with 201 Created', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.have.property('id');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Get Student Profile by ID",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{teacherToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/people/students/{{studentId}}", host: ["{{baseUrl}}"], path: ["api", "v1", "people", "students", "{{studentId}}"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Single student details retrieved', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.have.property('first_name');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Fetch Linked Siblings (Parent Context)",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{parentToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/people/guardians/siblings", host: ["{{baseUrl}}"], path: ["api", "v1", "people", "guardians", "siblings"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Linked siblings list retrieved', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.siblings).to.be.an('array');",
            "});"
          ]
        }
      }]
    },
    {
      name: "List Staff Members",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{principalToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/people/staff", host: ["{{baseUrl}}"], path: ["api", "v1", "people", "staff"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Staff directory returned', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.staff).to.be.an('array');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Bulk Student Ingestion",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{adminToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            students: [
              { first_name: "Pooja", last_name: "Panda", grade: 5, section: "A", admission_number: "ADM-2026-9002" },
              { first_name: "Subham", last_name: "Dash", grade: 5, section: "A", admission_number: "ADM-2026-9003" }
            ]
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/people/students/bulk-import", host: ["{{baseUrl}}"], path: ["api", "v1", "people", "students", "bulk-import"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Bulk students ingested successfully', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.importedCount).to.be.above(0);",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 4. Attendance & Offline Sync
// ============================================================================
const attendanceFolder = {
  name: "03_Attendance_and_Offline_Sync",
  description: "Rapid classroom attendance marking (<10s SLA), granular records, student statistics, leave management, and offline SQLite-to-Cloud sync.",
  item: [
    {
      name: "Rapid Classroom Attendance Batch (<10s Submission)",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{teacherToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            classId: "{{classId}}",
            sectionId: "{{sectionId}}",
            date: "2026-10-17",
            defaultStatus: "PRESENT",
            absentees: ["{{studentId}}"],
            remarks: "Rapid morning muster"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/attendance", host: ["{{baseUrl}}"], path: ["api", "v1", "attendance"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Rapid attendance saved under 1000ms SLA', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.recordedCount).to.be.above(0);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Granular Attendance Batch Marking",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{teacherToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            records: [
              { studentId: "{{studentId}}", date: "2026-10-18", status: "PRESENT", period: 1 },
              { studentId: "{{studentId}}", date: "2026-10-18", status: "HALF_DAY", period: 2 }
            ]
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/attendance/batch", host: ["{{baseUrl}}"], path: ["api", "v1", "attendance", "batch"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Granular attendance records persisted', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.savedRecords).to.be.above(0);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Get Student Monthly Attendance Stats",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{parentToken}}" }],
        url: {
          raw: "{{baseUrl}}/api/v1/attendance/students/{{studentId}}?month=10&year=2026",
          host: ["{{baseUrl}}"],
          path: ["api", "v1", "attendance", "students", "{{studentId}}"],
          query: [
            { key: "month", value: "10" },
            { key: "year", value: "2026" }
          ]
        }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Monthly percentage calculated', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.have.property('percentage');",
            "  pm.expect(json.data.totalWorkingDays).to.be.above(0);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Query Attendance Records",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{principalToken}}" }],
        url: {
          raw: "{{baseUrl}}/api/v1/attendance?classId={{classId}}&date=2026-10-17",
          host: ["{{baseUrl}}"],
          path: ["api", "v1", "attendance"],
          query: [
            { key: "classId", value: "{{classId}}" },
            { key: "date", value: "2026-10-17" }
          ]
        }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Attendance query returns entries', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.records).to.be.an('array');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Submit Leave Application",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{parentToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            studentId: "{{studentId}}",
            startDate: "2026-11-01",
            endDate: "2026-11-03",
            reason: "Family function in Bhubaneswar",
            category: "CASUAL"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/attendance/leaves", host: ["{{baseUrl}}"], path: ["api", "v1", "attendance", "leaves"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Leave application created', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.status).to.eql('PENDING');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Offline Outbox Batch Synchronization (/api/v1/sync/batch)",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{teacherToken}}" },
          { key: "Idempotency-Key", value: "idemp-sync-{{$timestamp}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            deviceId: "tab_teacher_grade5a",
            lastSyncedAt: "2026-10-17T08:00:00.000Z",
            mutations: [
              {
                id: "mut-001",
                entity: "attendance",
                action: "UPSERT",
                payload: { studentId: "{{studentId}}", status: "PRESENT", date: "2026-10-17" }
              }
            ]
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/sync/batch", host: ["{{baseUrl}}"], path: ["api", "v1", "sync", "batch"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Batch sync processed with conflict resolution', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.syncedCount).to.eql(1);",
            "  pm.expect(json.data.conflicts).to.eql(0);",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 5. Fees & Financial Safety
// ============================================================================
const feesFolder = {
  name: "04_Fees_and_Financial_Safety",
  description: "Tuition structures, concessions, Razorpay order generation (Redis mutex lock), HMAC-SHA256 webhooks, and 80G tax receipts.",
  item: [
    {
      name: "Get Fee Structures by Grade",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{accountantToken}}" }],
        url: {
          raw: "{{baseUrl}}/api/v1/fees/structures?grade=5&academicYear={{academic_year}}",
          host: ["{{baseUrl}}"],
          path: ["api", "v1", "fees", "structures"],
          query: [
            { key: "grade", value: "5" },
            { key: "academicYear", value: "{{academic_year}}" }
          ]
        }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Fee structures array returned', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.structures).to.be.an('array');",
            "  pm.expect(json.data.structures.length).to.be.above(0);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Create Fee Structure",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{adminToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            grade: 5,
            academicYear: "{{academic_year}}",
            category: "Robotics & Innovation Lab Fee",
            totalAmount: 6000,
            frequency: "TERM"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/fees/structures", host: ["{{baseUrl}}"], path: ["api", "v1", "fees", "structures"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Fee structure created', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.totalAmount).to.eql(6000);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Create Razorpay Payment Order (Enforces Idempotency-Key)",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{parentToken}}" },
          { key: "Idempotency-Key", value: "idemp-fee-order-{{$timestamp}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            studentId: "{{studentId}}",
            installmentNumber: 2,
            amountPaise: 1650000,
            paymentMethod: "UPI"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/fees/orders", host: ["{{baseUrl}}"], path: ["api", "v1", "fees", "orders"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Razorpay order created with idempotency lock', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.success).to.be.true;",
            "  pm.expect(json.data).to.have.property('razorpayOrderId');",
            "  pm.environment.set('orderId', json.data.razorpayOrderId);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Razorpay Payment Webhook (HMAC-SHA256 Signature)",
      event: [
        {
          listen: "prerequest",
          script: {
            type: "text/javascript",
            exec: [
              "var secret = pm.environment.get('razorpayWebhookSecret') || 'rzp_webhook_secret_hmac_sample';",
              "var payloadObj = {",
              "  entity: 'event',",
              "  event: 'payment.captured',",
              "  created_at: Math.floor(Date.now() / 1000),",
              "  payload: {",
              "    payment: {",
              "      entity: {",
              "        id: 'pay_mock_' + Date.now(),",
              "        order_id: pm.environment.get('orderId') || 'order_authentic_001',",
              "        amount: 1650000,",
              "        currency: 'INR',",
              "        status: 'captured',",
              "        method: 'upi'",
              "      }",
              "    }",
              "  }",
              "};",
              "var compactBody = JSON.stringify(payloadObj);",
              "pm.request.body.raw = compactBody;",
              "var sig = CryptoJS.HmacSHA256(compactBody, secret).toString(CryptoJS.enc.Hex);",
              "pm.request.headers.upsert({ key: 'x-razorpay-signature', value: sig });"
            ]
          }
        },
        {
          listen: "test",
          script: {
            type: "text/javascript",
            exec: [
              "pm.test('Webhook processed cleanly with valid signature', function () {",
              "  pm.response.to.have.status(200);",
              "  var json = pm.response.json();",
              "  pm.expect(json.success).to.be.true;",
              "  pm.expect(json.data.processed).to.be.true;",
              "});"
            ]
          }
        }
      ],
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" }
        ],
        body: {
          mode: "raw",
          raw: "{}"
        },
        url: { raw: "{{baseUrl}}/api/v1/fees/webhook", host: ["{{baseUrl}}"], path: ["api", "v1", "fees", "webhook"] }
      }
    },
    {
      name: "Download PDF Fee Tax Receipt",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{parentToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/fees/receipts/{{receiptId}}", host: ["{{baseUrl}}"], path: ["api", "v1", "fees", "receipts", "{{receiptId}}"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('PDF Tax receipt download or JSON returned', function () {",
            "  pm.response.to.have.status(200);",
            "});"
          ]
        }
      }]
    },
    {
      name: "List Fee Concessions",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{accountantToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/fees/concessions", host: ["{{baseUrl}}"], path: ["api", "v1", "fees", "concessions"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Fee concessions list returned', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.concessions).to.be.an('array');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Apply for Fee Concession",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{parentToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            studentId: "{{studentId}}",
            category: "SIBLING_DISCOUNT",
            discountPercentage: 15,
            reason: "Second child enrolled at BOMIS Sambalpur"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/fees/concessions", host: ["{{baseUrl}}"], path: ["api", "v1", "fees", "concessions"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Fee concession submitted', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.status).to.eql('PENDING_REVIEW');",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 6. Academics & CBSE Grading
// ============================================================================
const academicsFolder = {
  name: "05_Academics_and_CBSE_Grading",
  description: "Academic terms, CBSE 9-point grading (A1 to E), teacher substitutions, and timetable clash evaluation.",
  item: [
    {
      name: "Get Academic Terms (CBSE Structure)",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{teacherToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/academics/terms", host: ["{{baseUrl}}"], path: ["api", "v1", "academics", "terms"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Academic terms retrieved', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.terms).to.be.an('array');",
            "  pm.expect(json.data.terms.length).to.be.above(0);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Create Academic Term",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{principalToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            name: "Term 3 (Special Winter Session)",
            academicYear: "{{academic_year}}",
            startDate: "2027-01-05",
            endDate: "2027-03-25",
            isCurrent: false
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/academics/terms", host: ["{{baseUrl}}"], path: ["api", "v1", "academics", "terms"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Academic term created', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.have.property('id');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Submit Marks Batch Entry (CBSE 9-Point Scale)",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{teacherToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            termId: "{{termId}}",
            subjectId: "sub_mathematics",
            marks: [
              { studentId: "{{studentId}}", score: 92, maxScore: 100 }
            ]
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/academics/marks/batch", host: ["{{baseUrl}}"], path: ["api", "v1", "academics", "marks", "batch"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Marks evaluated with CBSE 9-point scale', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.results[0].grade).to.eql('A1');",
            "  pm.expect(json.data.results[0].gradePoint).to.eql(10);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Timetable Clash Check",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{principalToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            teacherId: "{{teacherId}}",
            classId: "{{classId}}",
            dayOfWeek: "MONDAY",
            periodNumber: 3
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/academics/timetable/clash-check", host: ["{{baseUrl}}"], path: ["api", "v1", "academics", "timetable", "clash-check"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Timetable clash matrix evaluated', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.have.property('hasClash');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Teacher Absence Substitution Allocation",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{principalToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            absentTeacherId: "{{teacherId}}",
            substituteTeacherId: "usr_teacher_math_002",
            date: "2026-10-18",
            period: 2,
            reason: "Medical absence"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/academics/substitutions", host: ["{{baseUrl}}"], path: ["api", "v1", "academics", "substitutions"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Substitution created', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.status).to.eql('CONFIRMED');",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 7. Transport & Fleet Operations
// ============================================================================
const transportFolder = {
  name: "06_Transport_Fleet_Operations",
  description: "Bus routes, 4 pilot vehicles across Sambalpur routes, QR boarding scans, and live GPS telemetry telemetry pings.",
  item: [
    {
      name: "List Bus Routes and Stops",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{parentToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/transport/routes", host: ["{{baseUrl}}"], path: ["api", "v1", "transport", "routes"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Transport routes returned', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.routes).to.be.an('array');",
            "  pm.expect(json.data.routes.length).to.be.above(0);",
            "});"
          ]
        }
      }]
    },
    {
      name: "List 4 Pilot Buses and Telemetry Status",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{principalToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/transport/buses", host: ["{{baseUrl}}"], path: ["api", "v1", "transport", "buses"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Returned 4 pilot buses with live telemetry', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.buses).to.be.an('array');",
            "  pm.expect(json.data.buses.length).to.eql(4);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Scan Student Boarding / Deboarding QR",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{driverToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            studentId: "{{studentId}}",
            busId: "{{busId}}",
            direction: "BOARDING",
            stopName: "Khetrajpur Station Stop",
            timestamp: new Date().toISOString()
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/transport/boarding/scan", host: ["{{baseUrl}}"], path: ["api", "v1", "transport", "boarding", "scan"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Boarding scan registered', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.verified).to.be.true;",
            "});"
          ]
        }
      }]
    },
    {
      name: "Broadcast Fleet Vehicle GPS Telemetry",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{driverToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            busId: "{{busId}}",
            latitude: 21.4669,
            longitude: 83.9812,
            speedKmH: 38.5,
            heading: 145,
            timestamp: new Date().toISOString()
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/transport/gps-ping", host: ["{{baseUrl}}"], path: ["api", "v1", "transport", "gps-ping"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('GPS telemetry ping acknowledged', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.acknowledged).to.be.true;",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 8. Safety & Visitor Management
// ============================================================================
const safetyFolder = {
  name: "07_Safety_and_Visitor_Management",
  description: "Gate access passes, child pickup OTP verification, and DPDP-compliant zero-log anonymous incident reporting.",
  item: [
    {
      name: "Create Pre-Approved QR Visitor Pass",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{adminToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            visitorName: "Sunil Kumar Mohanty",
            visitorPhone: "+919437012345",
            purpose: "Guest Lecture on Artificial Intelligence",
            hostStaffId: "{{teacherId}}",
            expectedDate: "2026-10-28"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/safety/visitors", host: ["{{baseUrl}}"], path: ["api", "v1", "safety", "visitors"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Visitor pass created with QR payload', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.status).to.eql('PRE_APPROVED');",
            "  pm.expect(json.data).to.have.property('qrCodeData');",
            "  pm.environment.set('visitorPassId', json.data.passId);",
            "});"
          ]
        }
      }]
    },
    {
      name: "List Visitor Passes",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{principalToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/safety/visitors", host: ["{{baseUrl}}"], path: ["api", "v1", "safety", "visitors"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Visitor passes list retrieved', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.be.an('array');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Issue Child Pickup Authorization OTP for Parent",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{parentToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            studentId: "{{studentId}}",
            guardianId: "{{guardianId}}",
            otp: "482910"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/safety/pickup/authorize", host: ["{{baseUrl}}"], path: ["api", "v1", "safety", "pickup", "authorize"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Pickup authorization OTP generated', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.status).to.eql('ACTIVE');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Verify Child Pickup OTP / Dynamic QR",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{adminToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            studentId: "{{studentId}}",
            pickupOtp: "482910",
            gateNumber: "Gate 1 (Main Entrance)"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/safety/pickup/verify", host: ["{{baseUrl}}"], path: ["api", "v1", "safety", "pickup", "verify"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Child pickup authorization verified', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.authorized).to.be.true;",
            "  pm.expect(json.data.gateNumber).to.eql('Gate 1 (Main Entrance)');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Submit Zero-Log Anonymous Anti-Bullying Incident",
      request: {
        method: "POST",
        header: [{ key: "Content-Type", value: "application/json" }],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            incidentType: "BULLYING",
            grade: 5,
            location: "Junior Science Laboratory Corridor",
            description: "Repeated name-calling and pushing observed near water dispenser after lunch break."
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/safety/incidents/anonymous", host: ["{{baseUrl}}"], path: ["api", "v1", "safety", "incidents", "anonymous"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Anonymous incident submitted without logging identity', function () {",
            "  pm.response.to.have.status(201);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.status).to.eql('RECEIVED');",
            "  pm.expect(json.data).to.have.property('trackingCode');",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 9. AI Assistance Layer
// ============================================================================
const aiFolder = {
  name: "08_AI_Assistance_Layer",
  description: "NCERT-grounded Study Buddy chat, human-in-the-loop report card remarks, and CBSE NEP 2020 Voice HPC Rubric Parser.",
  item: [
    {
      name: "Syllabus Grounded Study Buddy Chat",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{studentToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            prompt: "Why does the Hirakud Dam near Sambalpur generate hydroelectric energy?",
            grade: 5,
            subject: "General Science"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/ai/study-buddy/chat", host: ["{{baseUrl}}"], path: ["api", "v1", "ai", "study-buddy", "chat"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Study Buddy answers with syllabus grounding', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.have.property('response');",
            "  pm.expect(json.data.sources).to.be.an('array');",
            "  pm.expect(json.data.grade).to.eql(5);",
            "});"
          ]
        }
      }]
    },
    {
      name: "Draft Report Card Remarks Generator",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{teacherToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            studentName: "Aarav Patel",
            subject: "Mathematics",
            grade: 5,
            strengths: "geometric problem-solving and mental arithmetic",
            areasForImprovement: "speed in multi-step word problem formulation"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/ai/lesson-planner/remarks", host: ["{{baseUrl}}"], path: ["api", "v1", "ai", "lesson-planner", "remarks"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Remarks generated with human-in-the-loop approval requirement', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.requiresTeacherApproval).to.be.true;",
            "  pm.expect(json.data.humanInTheLoop).to.be.true;",
            "  pm.expect(json.data.draftRemarks).to.be.a('string');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Voice-to-Rubric CBSE NEP 2020 HPC Parser",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{teacherToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            studentName: "Aarav Patel",
            transcript: "Aarav voluntarily led his group in assembling the solar irrigation model today. He helped his peers measure angles and demonstrated great patience.",
            grade: "5A",
            subject: "Environmental Science",
            language: "en"
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/ai/voice-hpc/parse", host: ["{{baseUrl}}"], path: ["api", "v1", "ai", "voice-hpc", "parse"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Voice observation parsed into 360-degree NEP 2020 rubrics', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data.complianceStandard).to.include('CBSE NEP 2020');",
            "  pm.expect(json.data.nep2020Rubrics).to.have.property('collaboration');",
            "  pm.expect(json.data).to.have.property('parentEveningDigestSnippet');",
            "  pm.expect(json.data).to.have.property('dinnerTablePrompt');",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 10. Principal Pulse Dashboard
// ============================================================================
const pulseFolder = {
  name: "09_Principal_Pulse_Dashboard",
  description: "Executive principal intelligence: real-time campus attendance percentage, fee collections, fleet readiness, and incident alerts.",
  item: [
    {
      name: "Get Principal Pulse Real-Time KPIs",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{principalToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/pulse/metrics", host: ["{{baseUrl}}"], path: ["api", "v1", "pulse", "metrics"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Pulse dashboard aggregates real-time school metrics', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.have.property('attendanceRate');",
            "  pm.expect(json.data).to.have.property('feeCollectionRate');",
            "  pm.expect(json.data.activeBuses).to.eql(4);",
            "  pm.expect(json.data.systemHealth).to.eql('HEALTHY');",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 11. Admin & DPDP Audit
// ============================================================================
const adminFolder = {
  name: "10_Admin_and_Audit_Trails",
  description: "DPDP Act 2023 compliant immutable audit logging and administrative compliance records.",
  item: [
    {
      name: "Get DPDP Administrative Audit Trail",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{adminToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/admin/audit-logs", host: ["{{baseUrl}}"], path: ["api", "v1", "admin", "audit-logs"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('DPDP audit trail retrieved for authorized admin', function () {",
            "  pm.response.to.have.status(200);",
            "  var json = pm.response.json();",
            "  pm.expect(json.data).to.be.an('array');",
            "});"
          ]
        }
      }]
    }
  ]
};

// ============================================================================
// 12. RBAC Negative Gates
// ============================================================================
const rbacNegativeFolder = {
  name: "11_RBAC_Negative_Gates",
  description: "Security boundary verification asserting 403 Forbidden when unauthorized roles attempt privileged operations.",
  item: [
    {
      name: "Parent Blocked from Admin Audit Logs (Asserts 403 Forbidden)",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{parentToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/admin/audit-logs", host: ["{{baseUrl}}"], path: ["api", "v1", "admin", "audit-logs"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Parent receives 403 Forbidden on Audit Logs', function () {",
            "  pm.response.to.have.status(403);",
            "  var json = pm.response.json();",
            "  pm.expect(json.success).to.be.false;",
            "  pm.expect(json.error.code).to.eql('FORBIDDEN');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Student Blocked from Modifying Marks (Asserts 403 Forbidden)",
      request: {
        method: "POST",
        header: [
          { key: "Content-Type", value: "application/json" },
          { key: "Authorization", value: "Bearer {{studentToken}}" }
        ],
        body: {
          mode: "raw",
          raw: JSON.stringify({
            termId: "{{termId}}",
            subjectId: "sub_mathematics",
            marks: [{ studentId: "{{studentId}}", score: 100, maxScore: 100 }]
          }, null, 2)
        },
        url: { raw: "{{baseUrl}}/api/v1/academics/marks/batch", host: ["{{baseUrl}}"], path: ["api", "v1", "academics", "marks", "batch"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Student receives 403 Forbidden on Marks Entry', function () {",
            "  pm.response.to.have.status(403);",
            "  var json = pm.response.json();",
            "  pm.expect(json.success).to.be.false;",
            "  pm.expect(json.error.code).to.eql('FORBIDDEN');",
            "});"
          ]
        }
      }]
    },
    {
      name: "Driver Blocked from Fee Structures (Asserts 403 Forbidden)",
      request: {
        method: "GET",
        header: [{ key: "Authorization", value: "Bearer {{driverToken}}" }],
        url: { raw: "{{baseUrl}}/api/v1/fees/structures", host: ["{{baseUrl}}"], path: ["api", "v1", "fees", "structures"] }
      },
      event: [{
        listen: "test",
        script: {
          type: "text/javascript",
          exec: [
            "pm.test('Driver receives 403 Forbidden on Fee Structures', function () {",
            "  pm.response.to.have.status(403);",
            "  var json = pm.response.json();",
            "  pm.expect(json.success).to.be.false;",
            "  pm.expect(json.error.code).to.eql('FORBIDDEN');",
            "});"
          ]
        }
      }]
    }
  ]
};

// Assemble collection
collection.item = [
  healthFolder,
  authFolder,
  peopleFolder,
  attendanceFolder,
  feesFolder,
  academicsFolder,
  transportFolder,
  safetyFolder,
  aiFolder,
  pulseFolder,
  adminFolder,
  rbacNegativeFolder
];

const targetFile = path.resolve(__dirname, 'bomis_sambalpur_api.postman_collection.json');
fs.writeFileSync(targetFile, JSON.stringify(collection, null, 2), 'utf8');
console.log(`Generated exhaustive Postman collection at: ${targetFile}`);

// Also keep bomis_postman_collection.json synchronized
const legacyFile = path.resolve(__dirname, 'bomis_postman_collection.json');
fs.writeFileSync(legacyFile, JSON.stringify(collection, null, 2), 'utf8');
console.log(`Synchronized legacy collection at: ${legacyFile}`);

// Calculate statistics
let totalReq = 0;
collection.item.forEach((f, i) => {
  const cnt = f.item ? f.item.length : 0;
  totalReq += cnt;
  console.log(` ${i+1}. [${f.name}]: ${cnt} endpoints`);
});
console.log(`Total Endpoints in Suite: ${totalReq}`);
