#!/usr/bin/env node
/**
 * Headless Newman Test Runner for BOMIS Sambalpur Unified School Platform
 * 
 * Usage:
 *   node docs/postman/run-newman.js [options]
 * 
 * Options:
 *   --baseUrl=<url>        Target backend base URL (default: http://localhost:4000)
 *   --folder=<name>        Execute a specific folder/domain (e.g. "04_Fees_and_Financial_Safety")
 *   --reporters=<list>     Comma-separated reporters (default: cli,json)
 *   --export=<path>        Path for JSON summary export (default: docs/postman/newman-report.json)
 *   --bail                 Stop on first test failure
 *   --help                 Display this help message
 */

const fs = require('fs');
const path = require('path');

// Parse CLI Arguments
const args = process.argv.slice(2);
const options = {
  baseUrl: 'http://localhost:4000',
  folder: null,
  reporters: ['cli'],
  exportPath: path.resolve(__dirname, 'newman-report.json'),
  bail: false
};

for (const arg of args) {
  if (arg.startsWith('--baseUrl=')) {
    options.baseUrl = arg.split('=')[1].replace(/\/$/, '');
  } else if (arg.startsWith('--folder=')) {
    options.folder = arg.split('=')[1];
  } else if (arg.startsWith('--reporters=')) {
    options.reporters = arg.split('=')[1].split(',');
  } else if (arg.startsWith('--export=')) {
    options.exportPath = path.resolve(process.cwd(), arg.split('=')[1]);
  } else if (arg === '--bail') {
    options.bail = true;
  } else if (arg === '--help' || arg === '-h') {
    console.log(`
BOMIS Sambalpur Newman Runner
-----------------------------
Usage: node docs/postman/run-newman.js [options]

Options:
  --baseUrl=<url>        API Base URL (default: http://localhost:4000)
  --folder=<name>        Target folder name to run exclusively
  --reporters=<reporters> Reporters to activate (cli, json, html)
  --export=<file>        Output file path for json report
  --bail                 Halt execution immediately upon test failure
  --help                 Show this help dialog
`);
    process.exit(0);
  }
}

// Locate collection and environment files
let collectionPath = path.resolve(__dirname, 'bomis_sambalpur_api.postman_collection.json');
if (!fs.existsSync(collectionPath)) {
  collectionPath = path.resolve(__dirname, 'bomis_postman_collection.json');
}
const environmentPath = path.resolve(__dirname, 'bomis_postman_environment.json');

if (!fs.existsSync(collectionPath)) {
  console.error(`[ERROR] Collection file not found at: ${collectionPath}`);
  process.exit(1);
}

if (!fs.existsSync(environmentPath)) {
  console.error(`[ERROR] Environment file not found at: ${environmentPath}`);
  process.exit(1);
}

// Load and prepare environment with overrides
const collection = JSON.parse(fs.readFileSync(collectionPath, 'utf8'));
const environment = JSON.parse(fs.readFileSync(environmentPath, 'utf8'));

// Override baseUrl in environment values
const baseUrlVar = environment.values.find(v => v.key === 'baseUrl');
if (baseUrlVar) {
  baseUrlVar.value = options.baseUrl;
} else {
  environment.values.push({
    key: 'baseUrl',
    value: options.baseUrl,
    type: 'default',
    enabled: true
  });
}

// Cryptographically prime studentToken and driverToken for RBAC Negative Gates (Requests 30 & 31)
const crypto = require('crypto');
const JWT_SECRET = process.env.JWT_SECRET || 'bomis_jwt_secret_sambalpur_2026';

function signJwtToken(payload, secret = JWT_SECRET) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const b64url = (str) => Buffer.from(typeof str === 'string' ? str : JSON.stringify(str)).toString('base64url');
  const h = b64url(header);
  const p = b64url(payload);
  const s = crypto.createHmac('sha256', secret).update(`${h}.${p}`).digest('base64url');
  return `${h}.${p}.${s}`;
}

function ensureEnvToken(key, payload) {
  let envEntry = environment.values.find(v => v.key === key);
  const token = signJwtToken(payload);
  if (envEntry) {
    if (!envEntry.value) {
      envEntry.value = token;
    }
  } else {
    environment.values.push({
      key,
      value: token,
      type: 'secret',
      enabled: true
    });
  }
  return token;
}

ensureEnvToken('studentToken', {
  sub: 'u1000000-0501-4000-8000-000000000001',
  id: 'u1000000-0501-4000-8000-000000000001',
  userId: 'u1000000-0501-4000-8000-000000000001',
  email: 'aarav.patel@student.bomis-sambalpur.edu.in',
  phone: '+919876543211',
  role: 'STUDENT',
  schoolId: 'e4b3c2a1-0001-4000-8000-000000000001'
});

ensureEnvToken('driverToken', {
  sub: 'u1000000-0020-4000-8000-000000000001',
  id: 'u1000000-0020-4000-8000-000000000001',
  userId: 'u1000000-0020-4000-8000-000000000001',
  email: 'driver.bhoi@bomis-sambalpur.edu.in',
  phone: '+919437200001',
  role: 'TRANSPORT_STAFF',
  schoolId: 'e4b3c2a1-0001-4000-8000-000000000001'
});

// Persist primed environment variables to disk
try {
  fs.writeFileSync(environmentPath, JSON.stringify(environment, null, 2), 'utf8');
} catch (e) {
  // In read-only environments, continue in-memory
}

console.log('===============================================================');
console.log(' BOMIS Sambalpur Unified School Platform - Newman Test Runner');
console.log('===============================================================');
console.log(` Target API Base URL : ${options.baseUrl}`);
console.log(` Collection Path     : ${collectionPath}`);
console.log(` Selected Folder     : ${options.folder || 'ALL (Full Suite)'}`);
console.log(` Reporters           : ${options.reporters.join(', ')}`);
console.log(` Bail on Failure     : ${options.bail}`);
console.log('===============================================================\n');

// Check if newman package is installed in node_modules
let newman;
try {
  newman = require('newman');
} catch (e) {
  console.warn('\n[DIAGNOSTIC] "newman" package is not installed in node_modules.');
  console.warn('To execute the Postman test collection, install newman via: pnpm add -D newman\n');
  console.log('[INFO] Static inspection of Postman Collection and Environment files:');
  console.log(`✓ Collection schema: ${collection.info.schema}`);
  console.log(`✓ Collection name  : ${collection.info.name}`);
  console.log(`✓ Folder count     : ${collection.item.length} folders`);
  
  let totalRequests = 0;
  for (const folder of collection.item) {
    const reqCount = folder.item ? folder.item.length : 0;
    totalRequests += reqCount;
    console.log(`   - [${folder.name}]: ${reqCount} requests`);
  }
  console.log(`✓ Total endpoints  : ${totalRequests} endpoints`);
  console.log(`✓ Environment vars : ${environment.values.length} variables configured`);
  console.warn('\n[SKIPPED] Test execution skipped: newman dependency is not installed.');
  process.exit(1);
}

// Configure newman execution parameters
const newmanOptions = {
  collection: collection,
  environment: environment,
  reporters: options.reporters,
  bail: options.bail
};

if (options.folder) {
  newmanOptions.folder = options.folder;
}

if (options.reporters.includes('json')) {
  newmanOptions.reporter = {
    json: {
      export: options.exportPath
    }
  };
}

// Execute newman
newman.run(newmanOptions, (err, summary) => {
  if (err) {
    console.error('[FATAL ERROR] Newman execution failed:', err);
    process.exit(1);
  }

  const { stats, failures } = summary.run;
  console.log('\n===============================================================');
  console.log(' Execution Summary');
  console.log('===============================================================');
  console.log(` Iterations : ${stats.iterations.total}`);
  console.log(` Requests   : ${stats.requests.total} (Failed: ${stats.requests.failed})`);
  console.log(` Prerequest : ${stats.prerequestScripts.total}`);
  console.log(` Testscripts: ${stats.testScripts.total}`);
  console.log(` Assertions : ${stats.assertions.total} (Failed: ${stats.assertions.failed})`);
  console.log('===============================================================');

  if (failures && failures.length > 0) {
    console.error(`\n[FAILED] ${failures.length} test assertions failed:`);
    failures.forEach((f, idx) => {
      console.error(` ${idx + 1}. [${f.source.name}] ${f.error.test}: ${f.error.message}`);
    });
    process.exit(1);
  } else {
    console.log('\n[SUCCESS] All BOMIS Sambalpur API assertions passed cleanly!');
    process.exit(0);
  }
});
