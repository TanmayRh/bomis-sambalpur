# BOMIS Sambalpur API Test Automation & Postman Newman Suite

This directory contains the automated end-to-end API test suite for the **Birla Open Minds International School (BOMIS), Sambalpur** Unified School Platform.

---

## 1. Directory Assets

| File | Purpose |
|---|---|
| `bomis_postman_collection.json` | Postman v2.1.0 collection containing 20+ endpoints across 9 domain modules with automated correlation ID injection, idempotency keys, and envelope assertions. |
| `bomis_postman_environment.json` | Local development and CI environment variables (`baseUrl`, `jwt_token`, `school_id`, `studentId`, etc.). |
| `run-newman.js` | Headless execution runner using Newman with CLI flags, static validation fallback, and summary reporting. |

---

## 2. Test Execution

### 2.1 Headless Execution via Node.js
```bash
# Execute full test collection against local API (default http://localhost:4000)
node docs/postman/run-newman.js

# Execute against custom target or staging server
node docs/postman/run-newman.js --baseUrl=https://api-staging.bomis-sambalpur.edu.in

# Execute a single domain module (e.g., Fees & Financial Safety)
node docs/postman/run-newman.js --folder="04_Fees_and_Financial_Safety"

# Export test report to JSON
node docs/postman/run-newman.js --reporters=cli,json --export=docs/postman/newman-report.json

# Fail fast on first assertion error
node docs/postman/run-newman.js --bail
```

### 2.2 Native Newman CLI
```bash
# Install newman globally or locally
pnpm add -D newman

# Run collection directly
newman run docs/postman/bomis_postman_collection.json \
  -e docs/postman/bomis_postman_environment.json \
  --reporters cli
```

### 2.3 Postman GUI Client
1. Open the Postman Desktop App.
2. Click **Import** in the upper left.
3. Drag and drop both `bomis_postman_collection.json` and `bomis_postman_environment.json`.
4. Select the environment **"BOMIS Sambalpur Local Development & CI"** in the top-right environment switcher.
5. Click **Run Collection** to execute all folders sequentially.

---

## 3. Standard Response Envelope Verification
Every response is automatically validated by the collection test scripts against the project standard:
```json
{
  "success": true,
  "data": { ... },
  "error": null,
  "timestamp": "2026-10-17T11:20:00.000Z",
  "correlationId": "corr-uuid"
}
```

---

## 4. RBAC Role Coverage
The collection asserts permissions and authorization boundaries across all 8 discrete roles:
1. `SUPER_ADMIN`
2. `ADMIN`
3. `PRINCIPAL`
4. `TEACHER`
5. `ACCOUNTANT`
6. `PARENT`
7. `STUDENT`
8. `TRANSPORT_STAFF`
