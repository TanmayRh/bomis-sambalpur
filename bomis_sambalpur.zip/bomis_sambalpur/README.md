# BOMIS Sambalpur Unified School Platform

> Production-grade, multi-role school operating system for Birla Open Minds International School, Sambalpur (Odisha).  
> Built as a high-performance TypeScript monorepo orchestrated with **Turborepo** and **pnpm workspaces**.

---

## 🏫 Monorepo Architecture

```
bomis_sambalpur/
├── apps/
│   ├── api/          # NestJS 10 modular monolith (Pino logger, DPDP encryption, Swagger OpenAPI)
│   ├── web/          # Next.js 14 App Router portal (Tailwind CSS, TanStack Query, shadcn/ui)
│   └── mobile/       # React Native Expo SDK 51+ cross-platform mobile application
├── packages/
│   ├── shared/       # Canonical Zod schemas, TypeScript types, 8 RBAC roles, standard API envelope
│   └── ui/           # Design tokens (#0F2942 Navy, #FF6B4A Warm Coral), Tailwind preset
├── infra/            # Docker Compose dev environment (PostgreSQL 16, Redis 7, MinIO, Mailpit)
├── docs/             # Architecture Decision Records (ADRs), DB schema, Newman Postman collection
├── prisma/           # Multi-tenant schema with RLS and realistic seed data
├── pnpm-workspace.yaml # Workspace definitions
└── turbo.json        # Turborepo task pipeline configuration
```

---

## ⚡ Quick Start

### 1. Prerequisites
- **Node.js**: `v18.0.0` or higher (`v20+` recommended)
- **Package Manager**: `pnpm` (`v8` or higher)
- **Container Runtime**: Docker & Docker Compose

### 2. Setup Environment
```bash
# Clone and enter directory
cd bomis_sambalpur

# Copy sample environment configuration
cp .env.example .env
```

### 3. Bootstrap Local Infrastructure
Start PostgreSQL 16, Redis 7, MinIO S3 object store, and Mailpit SMTP sandbox:
```bash
pnpm docker:up
```

### 4. Install Dependencies
```bash
pnpm install
```

### 5. Database Migration & Realistic Seeding
Run Prisma migrations and populate realistic seed data for BOMIS Sambalpur (Grades 1–8 Section A, 4 pilot buses, teachers, parents, students):
```bash
pnpm db:migrate
pnpm db:seed
```

### 6. Start Development Servers
Run all applications concurrently with Turborepo caching:
```bash
pnpm dev
```

---

## 🐳 Infrastructure Services

| Service | Port | Web Interface / Endpoints | Credentials |
|---------|------|---------------------------|-------------|
| **PostgreSQL 16** | `5432` | `localhost:5432/bomis_db` | User: `bomis_admin` / Pass: `bomis_dev_pass` |
| **Redis 7** | `6379` | `localhost:6379` | Pass: `bomis_redis_pass` |
| **MinIO S3 API** | `9000` | `http://localhost:9000` | User: `minioadmin` / Pass: `minioadmin` |
| **MinIO Console** | `9001` | `http://localhost:9001` | User: `minioadmin` / Pass: `minioadmin` |
| **Mailpit SMTP** | `1025` | `localhost:1025` | (No auth for local SMTP) |
| **Mailpit Web UI**| `8025` | `http://localhost:8025` | Interactive inbox viewer |

---

## 📜 Available Monorepo Scripts

- `pnpm build`: Run Turborepo cached build across all workspaces.
- `pnpm dev`: Start all apps in interactive hot-reload development mode.
- `pnpm lint`: Lint all packages and applications.
- `pnpm test`: Execute automated test suites.
- `pnpm typecheck`: Run TypeScript compiler checks across all workspaces.
- `pnpm format`: Format all source files with Prettier.
- `pnpm db:migrate`: Run Prisma migrations against the PostgreSQL container.
- `pnpm db:seed`: Seed realistic sample data into the database.
- `pnpm docker:up`: Launch local Docker Compose infrastructure in the background.
- `pnpm docker:down`: Gracefully stop local infrastructure containers.
- `pnpm docker:logs`: Tail live container logs.

---

## 🔐 Compliance & Security Highlights
- **DPDP Act (2023) Ready**: 90-day retention schedule for soft-deleted accounts followed by irreversible cryptographic erasure.
- **Field-Level Encryption**: AES-256-GCM encryption for sensitive Aadhaar numbers, health notes, and financial information.
- **Postgres Row-Level Security (RLS)**: Enforced tenant isolation via `current_setting('app.current_school_id')`.
- **Append-Only Audit Logs**: Tamper-evident database logs for compliance verification.
