# BOMIS Sambalpur Unified School Platform
## Master AI Review & Multi-Expert Simulation Pack (Unified Edition)

> **File Purpose:** A complete, self-contained dossier combining the full technical/UX codebase blueprint (**Method 3**) with the 4-persona expert simulation protocol (**Method 4**).  
> **Target Review Engines:** Claude 3.5 Sonnet, ChatGPT-4o, Gemini 1.5 Pro, DeepSeek V3/R1.  
> **School:** Birla Open Minds International School (BOMIS), Sambalpur, Odisha, India.  
> **Tech Stack:** Next.js 14 (App Router, Tailwind CSS, Lucide, Framer Motion), NestJS 10 (Modular Monolith, Pino, Zod), TypeScript, DPDP Act 2023 AES-256 Encryption, Razorpay Test Mode.

---

## 📋 SECTION 1: MASTER AI PROMPT & SIMULATION DIRECTIVE

> *AI Instructions: Read the technical specification below, adopt the 4 expert personas, and execute the multi-round evaluation protocol.*

```markdown
You are an elite, 4-person School Technology Evaluation Board convened to audit and elevate the school operating platform for Birla Open Minds International School (BOMIS), Sambalpur:

1. PERSONA 1 — The Anxious Indian Parent (PTA Lead): Mother of Aarav (Grade 5A) and Ananya (Grade 2A). Evaluates ease of use, morning stress reduction, emotional delight, and clarity without technical confusion.
2. PERSONA 2 — The Veteran CBSE School Principal (20+ yrs in Indian K-12): Evaluates alignment with CBSE CCE norms, NEP 2020 experiential learning, teacher workload sustainability, and campus discipline.
3. PERSONA 3 — The Data Privacy & DPDP Act (2023) Compliance Auditor: Evaluates child biometric & Aadhaar protection, parent consent workflows, GPS tracking access controls, and photo privacy in public stories.
4. PERSONA 4 — The Principal Full-Stack Cloud Architect: Evaluates Next.js 14 / NestJS 10 modular monolith structure, 8:00 AM attendance traffic spikes, offline resilience, and state management.

EXECUTE YOUR REVIEW IN 3 STRUCTURED ROUNDS:
- ROUND 1: Individual Critiques — Each expert gives their honest take, grading their domain out of 10.
- ROUND 2: Adversarial Debate — Experts challenge each other's priorities (e.g., Architect wants security vs Parent wants 1-click simplicity; Principal wants teacher logging vs Teacher workload limits).
- ROUND 3: The 10x Upgrade Consensus — The top 3 critical blindspots and the top 3 high-impact features to build next.
```

---

## 🏛️ SECTION 2: SYSTEM BLUEPRINT & ARCHITECTURE

### Monorepo Structure
```
bomis_sambalpur/
├── apps/
│   ├── api/                     # NestJS 10 Modular Monolith Backend (Port 4000)
│   │   ├── src/
│   │   │   ├── common/          # DPDP AES-256 Crypto, Pino Logger, Correlation ID, Zod Pipe
│   │   │   ├── database/        # In-Memory Deterministic Mock Store + Prisma Client
│   │   │   └── modules/
│   │   │       ├── auth/        # OTP Mobile Login (Dev Code: 123456) & Staff JWT
│   │   │       ├── people/      # 28 Students (Grade 5A), Guardians, Staff
│   │   │       ├── attendance/  # 1-Tap Class Batch Attendance + RFID Bus Logs
│   │   │       ├── fees/        # Razorpay Orders, Concession Waivers, GST Receipts
│   │   │       ├── academics/   # CBSE Terms, Marks Entry, Time Table, Substitutions
│   │   │       ├── transport/   # 4 Bus Routes (Khetrajpur, Burla, Ainthapali, Dhanupali)
│   │   │       ├── safety/      # Visitor QR Pass, Safe Pickup Verification, Anonymous Alerts
│   │   │       ├── ai/          # Study Buddy Assistant & Automated Teacher Remarks
│   │   │       ├── pulse/       # Principal Daily School Pulse Dashboard
│   │   │       └── admin/       # Audit Logs, DPDP Right-to-Erasure Workflow
│   │   └── package.json
│   └── web/                     # Next.js 14 App Router Frontend (Port 3000)
│       ├── src/
│       │   ├── app/
│       │   │   ├── page.tsx     # Full Interactive Parent Experience & Role Switcher
│       │   │   ├── login/       # OTP & Staff Password Login Flow
│       │   │   └── globals.css  # Tailwind CSS & Custom Animations
│       │   └── components/      # Stories Bar, Bus Radar, Canteen Wallet, PTM Video
│       └── package.json
└── packages/
    ├── shared/                  # Zod Schemas, Domain Enums, TypeScript Types
    └── ui/                      # Shared design tokens & Radix UI primitives
```

### Deterministic Dual-Mode Backend
* Operates self-contained offline via `USE_MOCK_DB=true` without external Docker dependencies.
* All endpoints, role authorizations, and data mutations persist in an in-memory transactional store.

---

## 🌟 SECTION 3: PARENT DELIGHT FEATURES BREAKDOWN

1. **Instagram-Style School Stories Bar:**
   * Visual window into daily school life (Science Fair Prep, Morning Assembly, Taekwondo Medals).
   * Interactive modal with time stamps, cheerful captions, and teacher commentary.

2. **"Aarav's Day in 60 Seconds" — AI Evening Learning Digest:**
   * Synthesizes Aarav's 8 periods into 3 digestible bullet points (Math, Science, Sports).
   * Generates a 1-click **"Ask Aarav at Dinner"** conversation starter: *"Ask Aarav: Tell me about the diorama your team built today!"*

3. **Live Bus Radar & Proximity Audio Chime:**
   * Tracks Bus #02 (OD-15-B-1002) traveling along the **Khetrajpur – Modipara – School** route.
   * Proximity ETA: **4 mins away**.
   * Includes a simulated audio **Chime 🔔** that sounds when the bus enters a 500m geofence.

4. **RFID Smart Canteen Meal Card & Wallet:**
   * Live balance (**₹480.00**), today's wholesome lunch menu (*Steamed Idli with Sambar & Coconut Chutney* — Vegetarian & Nut-Free).
   * 1-Tap Quick Recharge with mock UPI/Card approval (₹200, ₹500, ₹1,000).

5. **Gamified Homework Checklist with Confetti:**
   * Aarav's 3 daily tasks (Math, English, Science).
   * Checking off all tasks triggers an animated confetti explosion and awards **+25 Ashoka House Points**.

6. **1-on-1 PTM Video Conference Simulator:**
   * Simulated WebRTC meeting room with Aarav's Class Teacher (Mrs. Sunita Rao).
   * Features teacher camera feed, mic audio waves, screen sharing toggle, and real-time meeting notes.

7. **Digital Smart RFID ID Card & Health Profile:**
   * Barcode, blood group (`B+`), emergency phone, vision test (6/6), peanut allergy flags, and immunization dates.

8. **Multi-Child Switcher:**
   * Instant toggle between siblings: **Aarav (Grade 5-A)** and **Ananya (Grade 2-A)**.

---

## 🛡️ SECTION 4: DATA PRIVACY & COMPLIANCE (DPDP ACT 2023)

* **Field-Level Encryption:** Student Aadhaar numbers, guardian phone numbers, and sensitive health records encrypted via AES-256-GCM.
* **Parental Consent Manager:** Granular opt-in/opt-out for child campus photography in stories and AI data processing.
* **Audit Trails:** Immutable audit logging for staff record views (`/api/v1/admin/audit-logs`).
* **Safe Child Pickup QR:** One-time expiring cryptographic QR code required for campus security gate clearance.

---

## 👥 SECTION 5: ACTIVE ROLES & DEMO CREDENTIALS

| Role | Username / Identifier | Password / OTP | Key Workspaces |
| :--- | :--- | :--- | :--- |
| **Parent** | `9876543210` | `123456` | Stories, Bus Radar, Canteen, Homework, PTM Call, Smart ID |
| **Class Teacher** | `teacher@bomis-sambalpur.edu.in` | `Teacher@123` | Rapid Attendance (28 students), Marks Entry, Remarks |
| **Principal** | `principal@bomis-sambalpur.edu.in` | `Principal@123` | Daily School Pulse, Bus Fleet Safety, Fee Metrics |
| **Accountant** | `accountant@bomis-sambalpur.edu.in` | `Account@123` | Fee Ledgers, Concession Approvals, Razorpay Reconciliation |
| **Transport Manager** | `transport@bomis-sambalpur.edu.in` | `Transport@123` | 4 Sambalpur Routes, Bus GPS Pings, Boarding Logs |

---

## 🎯 SECTION 6: EXPECTED DELIVERABLE FROM THE REVIEWING AI

Please provide your review in the following format:

1. **Scorecard Matrix (Domain Ratings 1 to 10):**
   * Parent Delight & Usability Score: `/10`
   * CBSE Academic Reality Score: `/10`
   * DPDP Act (2023) Compliance Score: `/10`
   * Architecture & Scalability Score: `/10`
2. **The 4-Expert Debate Transcript:**
   * Transcribe the dialogue between the Parent, Principal, Auditor, and Architect highlighting their conflicting concerns.
3. **Top 3 Critical Blindspots:**
   * Vulnerabilities, edge cases, or usability flaws not currently handled.
4. **Top 3 Killer Features (10x Upgrades):**
   * Specific, creative additions that would make parents and school leadership love this platform even more.
